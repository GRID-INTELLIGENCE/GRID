# Databricks Integration - Quick Start Card

## 🚀 In 5 Minutes

### 1. Set Environment

```bash
export DATABRICKS_HOST=https://dbc-9747ff30-23c5.cloud.databricks.com
export databricks=<your-api-token>
```

### 2. Connect

```python
from src.integration.databricks import DatabricksClient
client = DatabricksClient()  # ✅ Connected!
```

### 3. List Clusters

```python
clusters = client.list_clusters()
for c in clusters:
    print(f"{c['cluster_name']} ({c['state']})")
```

### 4. Create a Job

```python
from src.integration.databricks import DatabricksJobsManager
jobs_mgr = DatabricksJobsManager(client)

job_id = jobs_mgr.create_notebook_job(
    job_name="my-job",
    notebook_path="/path/to/notebook",
    cluster_id="cluster-123"
)
```

### 5. Run It

```python
run_id = jobs_mgr.run_job(job_id)
status = jobs_mgr.get_run_status(run_id)
print(f"Status: {status['state']}")
```

---

## 📦 Core Classes

| Class                        | Purpose           | Import                                                              |
| ---------------------------- | ----------------- | ------------------------------------------------------------------- |
| `DatabricksClient`           | Connection & auth | `from src.integration.databricks import DatabricksClient`           |
| `DatabricksJobsManager`      | Job orchestration | `from src.integration.databricks import DatabricksJobsManager`      |
| `DatabricksClustersManager`  | Cluster lifecycle | `from src.integration.databricks import DatabricksClustersManager`  |
| `DatabricksNotebooksManager` | Notebook CRUD     | `from src.integration.databricks import DatabricksNotebooksManager` |

---

## 🔌 Common Operations

### Initialize Client

```python
client = DatabricksClient()
# Uses: DATABRICKS_HOST env var, 'databricks' token env var
```

### Cluster Operations

```python
# List
clusters = client.list_clusters()

# Get details
info = client.get_cluster("cluster-id")

# Start/Stop
client.start_cluster("cluster-id")
client.stop_cluster("cluster-id")
```

### Job Operations

```python
jobs_mgr = DatabricksJobsManager(client)

# Create
job_id = jobs_mgr.create_notebook_job(
    job_name="name",
    notebook_path="/path",
    cluster_id="id"
)

# Run
run_id = jobs_mgr.run_job(job_id)

# Monitor
status = jobs_mgr.get_run_status(run_id)

# List
all_jobs = jobs_mgr.list_jobs()

# Delete
jobs_mgr.delete_job(job_id)
```

### Notebook Operations

```python
notebooks_mgr = DatabricksNotebooksManager(client)

# Read
content = notebooks_mgr.read_notebook("/path/to/notebook")

# Write
notebooks_mgr.write_notebook("/path/to/notebook", content)

# List
items = notebooks_mgr.list_directory("/")

# Delete
notebooks_mgr.delete_notebook("/path/to/notebook")
```

---

## 🧪 Testing

### Run All Tests

```bash
pytest tests/unit/test_databricks_integration.py -v
```

### Expected Output

```
24 passed in 1.50s ✅
```

---

## 🔐 Environment Variables

| Variable           | Purpose               | Required    |
| ------------------ | --------------------- | ----------- |
| `DATABRICKS_HOST`  | Workspace URL         | Yes         |
| `databricks`       | API token             | Yes         |
| `DATABRICKS_TOKEN` | Alternative token var | Alternative |

**Example**:

```bash
export DATABRICKS_HOST=https://dbc-9747ff30-23c5.cloud.databricks.com
export databricks=dapi... # Your token
```

---

## ⚡ Quick Patterns

### With GRID Skills

```python
from grid.skills import Skill
from src.integration.databricks import DatabricksJobsManager, DatabricksClient

class DataProcessSkill(Skill):
    async def run(self, args):
        client = DatabricksClient()
        jobs_mgr = DatabricksJobsManager(client)
        job_id = jobs_mgr.create_notebook_job(**args)
        return {"job_id": job_id}
```

### Cost-Aware Execution

```python
def should_use_databricks(data_size_mb):
    return data_size_mb > 100  # Large datasets

if should_use_databricks(data_size):
    client = DatabricksClient()
    # ... delegate to Databricks
else:
    # ... process locally
```

### Job Monitoring Loop

```python
import time
from src.integration.databricks import DatabricksJobsManager, DatabricksClient

client = DatabricksClient()
jobs_mgr = DatabricksJobsManager(client)

run_id = jobs_mgr.run_job(job_id)

while True:
    status = jobs_mgr.get_run_status(run_id)
    if status['state'] in ('TERMINATED', 'SKIPPED', 'INTERNAL_ERROR'):
        print(f"Job finished: {status['result_state']}")
        break
    time.sleep(5)
```

---

## 🐛 Common Errors & Fixes

| Error                              | Fix                                               |
| ---------------------------------- | ------------------------------------------------- |
| `ModuleNotFoundError: databricks`  | `pip install databricks-sdk>=0.40.0`              |
| `TimeoutError`                     | Check DATABRICKS_HOST URL format (needs https://) |
| `401 Unauthorized`                 | Verify 'databricks' env var has valid token       |
| `No clusters available`            | Create cluster in Databricks UI first             |
| `Job creation failed: No notebook` | Use valid `/Workspace/...` path                   |

---

## 📖 Full Docs

- **Architecture**: [DATABRICKS_ARCHITECTURE.md](docs/integration/DATABRICKS_ARCHITECTURE.md)
- **Testing**: [DATABRICKS_TESTING_SUMMARY.md](docs/integration/DATABRICKS_TESTING_SUMMARY.md)
- **API Reference**: [DATABRICKS_QUICK_REFERENCE.md](docs/integration/DATABRICKS_QUICK_REFERENCE.md)
- **Interactive Demo**: [examples/databricks_integration_demo.ipynb](examples/databricks_integration_demo.ipynb)
- **Final Report**: [DATABRICKS_FINAL_REPORT.md](DATABRICKS_FINAL_REPORT.md)

---

## ✅ Status

| Component        | Status                  |
| ---------------- | ----------------------- |
| SDK Installation | ✅ Installed (0.77.0)   |
| Core Integration | ✅ Complete (5 modules) |
| Unit Tests       | ✅ 24/24 Passing        |
| Live Connection  | ✅ Verified             |
| Documentation    | ✅ Complete (4 guides)  |
| Example Code     | ✅ Available            |
| Production Ready | ✅ YES                  |

---

**Last Updated**: 2025-01-27
**Workspace**: https://dbc-9747ff30-23c5.cloud.databricks.com
**User**: irfankabir02@gmail.com
