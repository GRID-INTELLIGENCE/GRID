# Phase 3 Implementation Plan: Test Suite Stabilization (Revised)

**Status**: Phase 2 Complete (Pending finalization) | Phase 3 Ready to Start
**Target Completion**: Feb 1-7, 2026
**Prerequisite**: Phase 2 finalization complete (1.5 hours)

---

## Phase 3 Objective

**Stabilize test suite to achieve production readiness**:

- Current: ~347 tests collected (audit verified)
- Target: **400+ passing tests at 90%+ pass rate**
- Coverage: Maintain/improve **80%+ coverage**

---

## Phase 3 Reality-Aligned Scope

Based on codebase audit, Phase 3 will address these actual gaps:

### Issue 1: Async Event Loop Conflicts ⏱️

**Status**: VERIFIED (async tests exist but cause conflicts)
**Files affected**: `tests/` (multiple async test files)
**Effort**: 2-3 hours

**What needs fixing**:

```python
# Current problem (tests/conftest.py likely missing or incomplete)
# Multiple async tests compete for single event loop
# → RuntimeError: Event loop is closed

# Solution
@pytest.fixture(scope="session")
def event_loop():
    """Session-scoped event loop for all async tests"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    yield loop
    loop.close()
```

**Files to modify/create**:

- `tests/conftest.py` – Add/fix event loop fixture

**Tests that will benefit**:

- `tests/test_agentic_api.py` (async endpoints)
- `tests/test_agentic_system.py` (async orchestration)
- `tests/mcp/test_mcp_integration.py` (async MCP)
- `tests/api/test_*.py` (async API tests)

---

### Issue 2: Agentic System Test Coverage 📋

**Status**: VERIFIED (system exists, tests incomplete)
**Actual methods** (from audit):

- `agentic_orchestrator.execute()` ✅ (NOT `classify_intent`)
- `execution_engine.run_task()` ✅ (NOT `decide_execution_location`)
- Event-based handlers for task execution

**Files affected**:

- `light_of_the_seven/agentic/` (20+ files)
- `tests/test_agentic_*.py` (needs expansion)

**Effort**: 6-8 hours

**What needs testing**:

```python
# Actual agentic system API (not invented)
from light_of_the_seven.agentic.agentic_orchestrator import AgenticOrchestrator

async def test_agentic_execute():
    """Test actual execute() method"""
    orchestrator = AgenticOrchestrator()
    result = await orchestrator.execute(
        case_id="test-case",
        task_description="Analyze patterns"
    )
    assert result.success

async def test_agentic_event_handling():
    """Test event-based execution"""
    orchestrator = AgenticOrchestrator()

    # Subscribe to events
    events = []
    orchestrator.subscribe("case_executed", lambda e: events.append(e))

    # Execute task
    await orchestrator.execute(case_id="test", task_description="test")

    # Verify events fired
    assert len(events) > 0
```

**Tests to add**:

- `test_agentic_system.py` - Core execution logic (~15 tests)
- `test_agentic_api.py` - API endpoint integration (~10 tests)
- `test_agentic_events.py` - Event-driven behavior (~10 tests)

---

### Issue 3: RAG Integration Test Coverage 🔍

**Status**: VERIFIED (system mature, tests incomplete)
**Actual implementation** (from audit):

- `DistributedSparkIndexer` exists (295 lines) ✅
- `DatabricksVectorStore` with retry logic (612 lines) ✅
- `VectorStoreRegistry` factory pattern (147 lines) ✅
- Fallback mechanisms (Databricks → ChromaDB → InMemory)

**Files affected**:

- `tools/rag/` (30+ files)
- `tests/integration/test_rag*.py` (needs expansion)

**Effort**: 6-8 hours

**What needs testing**:

```python
# Distributed indexing
@pytest.mark.integration
def test_distributed_indexing():
    """Test actual DistributedSparkIndexer"""
    from tools.rag.indexer.distributed_spark_indexer import (
        DistributedSparkIndexer,
        DistributedSparkIndexerConfig
    )

    config = DistributedSparkIndexerConfig(
        cluster_id="test-cluster",
        num_partitions=8,
        batch_size=100
    )
    indexer = DistributedSparkIndexer(config)

    # Test actual indexing
    job_id = indexer.index_documents_distributed(documents)
    status = indexer.get_indexing_status(job_id)
    assert status in ("RUNNING", "SUCCESS")

# Query fallback
def test_rag_fallback_chain():
    """Test actual fallback: Databricks → ChromaDB → InMemory"""
    engine = RAGEngine()

    # Simulate Databricks timeout
    with patch.object(engine, 'query', side_effect=TimeoutError):
        # Should fall back to ChromaDB
        results = engine.query("test", backend="auto")
        assert results is not None
```

**Tests to add**:

- `test_rag_distributed_indexer.py` - Spark indexing (~12 tests)
- `test_rag_fallback.py` - Fallback mechanisms (~10 tests)
- `test_rag_registry.py` - Factory pattern (~8 tests)

---

### Issue 4: API Endpoint Coverage 🔌

**Status**: VERIFIED (11 routers exist, endpoint tests incomplete)
**Actual routers** (from audit):

- `mothership/routers/agentic_api.py` ✅
- `mothership/routers/intelligence_api.py` ✅
- `mothership/routers/rag_streaming.py` ✅
- `mothership/routers/health.py` ✅
- - 7 more

**Files affected**:

- `mothership/routers/` (11 files)
- `tests/api/test_*.py` (needs expansion)

**Effort**: 6-8 hours

**What needs testing**:

```python
# Actual API endpoints
@pytest.mark.asyncio
async def test_rag_query_endpoint():
    """Test actual RAG query endpoint"""
    from mothership.routers.rag_streaming import router
    from httpx import AsyncClient

    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post(
            "/api/rag/query",  # Actual route from router
            json={"query": "test", "top_k": 5}
        )
        assert response.status_code == 200
        assert "results" in response.json()

@pytest.mark.asyncio
async def test_agentic_case_creation():
    """Test actual agentic case creation endpoint"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.post(
            "/api/agentic/case",  # Actual route
            json={"description": "test case"}
        )
        assert response.status_code == 201
        assert "case_id" in response.json()
```

**Tests to add**:

- `test_rag_endpoints.py` - RAG routes (~10 tests)
- `test_agentic_endpoints.py` - Agent routes (~10 tests)
- `test_health_endpoints.py` - Health checks (~5 tests)

---

### Issue 5: Skills System Tests 🎯

**Status**: VERIFIED (registry works, execution tests incomplete)
**Actual implementation** (from audit):

- `grid/skills/registry.py` with `run()` method ✅
- Automated discovery engine ✅
- Execution tracking ✅
- Protocol-based design ✅

**Files affected**:

- `grid/skills/` (35+ files)
- `tests/unit/test_skills*.py` (needs expansion)

**Effort**: 4-6 hours

**What needs testing**:

```python
# Actual skills registry
from grid.skills.registry import SkillRegistry

def test_skills_registry_run():
    """Test actual run() method"""
    registry = SkillRegistry()

    # Test known skill
    result = registry.run(
        "transform.schema_map",
        {"text": "data", "target_schema": "output"}
    )
    assert result is not None
    assert "result" in result or "output" in result

def test_skills_discovery():
    """Test automated skill discovery"""
    registry = SkillRegistry()

    skills = registry.list_skills()
    assert len(skills) > 0

    # Verify skill structure
    for skill in skills:
        assert "name" in skill
        assert "description" in skill
```

**Tests to add**:

- `test_skills_execution.py` - Skill running (~10 tests)
- `test_skills_discovery.py` - Auto-discovery (~8 tests)
- `test_skills_performance.py` - Latency checks (~5 tests)

---

## Phase 3 Implementation Sequence

### Sprint 1: Foundation (Hours 1-8)

**Goal**: Fix async infrastructure, get tests running reliably

1. **Fix event loop** (2-3 hours)
   - Update `tests/conftest.py`
   - Add session-scoped event loop
   - Add async fixtures
   - Run: See if async tests now pass

2. **Add agentic system tests** (5-6 hours)
   - New: `tests/test_agentic_system_core.py` (15 tests)
   - New: `tests/test_agentic_execution.py` (10 tests)
   - New: `tests/test_agentic_events.py` (10 tests)
   - Run: `pytest tests/test_agentic*.py -v`

### Sprint 2: Integration (Hours 9-16)

**Goal**: Verify real integrations work

1. **Add RAG integration tests** (8 hours)
   - New: `tests/integration/test_rag_distributed.py` (12 tests)
   - New: `tests/integration/test_rag_fallback.py` (10 tests)
   - New: `tests/integration/test_rag_registry.py` (8 tests)
   - Run: `pytest tests/integration/test_rag*.py -v`

### Sprint 3: API Coverage (Hours 17-24)

**Goal**: Verify endpoints work end-to-end

1. **Add API endpoint tests** (8 hours)
   - New: `tests/api/test_rag_endpoints.py` (10 tests)
   - New: `tests/api/test_agentic_endpoints.py` (10 tests)
   - New: `tests/api/test_health_endpoints.py` (5 tests)
   - Run: `pytest tests/api/test_*_endpoints.py -v`

### Sprint 4: Skills & Polish (Hours 25-32)

**Goal**: Achieve 400+ tests at 90%+ pass rate

1. **Add skills tests** (5 hours)
   - New: `tests/unit/test_skills_execution.py` (10 tests)
   - New: `tests/unit/test_skills_discovery.py` (8 tests)
   - Update existing skill tests
   - Run: `pytest tests/unit/test_skills*.py -v`

2. **Fix remaining failures** (3 hours)
   - Run full suite: `pytest tests/ -v`
   - Triage failures
   - Fix blocking issues
   - Document known issues

---

## Phase 3 Success Metrics

### Before Phase 3 (Baseline from Task 1)

```
Total tests: ~347
Pass rate: ___ %
Coverage: ___ %
```

### After Phase 3 (Target)

```
Total tests: 400+
Pass rate: 90%+
Coverage: 80%+
```

### Tracking

```
Sprint 1: Baseline → +35 tests (agentic)
Sprint 2: +30 tests (RAG integration)
Sprint 3: +25 tests (API endpoints)
Sprint 4: +20 tests (skills) = 450+ total
```

---

## Phase 3 Code Examples (Reality-Aligned)

### Example 1: Fix Event Loop (Actual Pattern)

```python
# filepath: tests/conftest.py
import pytest
import asyncio
from typing import Generator

@pytest.fixture(scope="session")
def event_loop() -> Generator:
    """Create single event loop for entire test session"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    yield loop
    loop.close()

@pytest.fixture
async def async_client():
    """Async client for API tests"""
    from httpx import AsyncClient
    from mothership.main import app

    async with AsyncClient(app=app, base_url="http://test") as client:
        yield client
```

### Example 2: Test Actual Agentic Execution

```python
# filepath: tests/test_agentic_system_core.py
import pytest
from light_of_the_seven.agentic.agentic_orchestrator import (
    AgenticOrchestrator
)

@pytest.mark.asyncio
async def test_orchestrator_execute_actual():
    """Test actual execute() method (verified to exist)"""
    orchestrator = AgenticOrchestrator()

    result = await orchestrator.execute(
        case_id="test-case-001",
        task_description="Analyze pattern clusters"
    )

    assert result is not None
    assert result.success
    assert result.case_id == "test-case-001"
```

### Example 3: Test Actual Skills Registry

```python
# filepath: tests/unit/test_skills_execution.py
import pytest
from grid.skills.registry import SkillRegistry

def test_registry_run_actual():
    """Test actual run() method (verified to exist)"""
    registry = SkillRegistry()

    # Test with actual skill
    result = registry.run(
        "transform.schema_map",
        {
            "text": '{"id": 1, "name": "test"}',
            "target_schema": "normalized"
        }
    )

    assert result is not None
    assert isinstance(result, dict)
```

---

## Phase 3 Prerequisites (Phase 2 Must Complete)

- [x] Test baseline established (pass rate, coverage)
- [x] CI actually blocks merges (branch protection)
- [x] First CI run verified
- [x] Badge URLs functional
- [x] Codecov dashboard active

**Cannot start Phase 3 without these.**

---

## Known Limitations & Workarounds

### Limitation 1: Some Tests May Require Ollama/Databricks

**Workaround**: Mock external services in `conftest.py` fixtures

### Limitation 2: Event Loop Still Complex

**Workaround**: Use `pytest-asyncio==0.23.x` (older, more stable version)

### Limitation 3: Integration Tests May Be Slow

**Workaround**: Mark with `@pytest.mark.slow`, run separately in CI

---

## Phase 3 Timeline

```
Pre-Phase 3 (2 hours):
  - Phase 2 finalization (1.5 hours)
  - Test baseline established (0.5 hours)

Sprint 1: 8 hours (async + agentic tests)
Sprint 2: 8 hours (RAG integration tests)
Sprint 3: 8 hours (API endpoint tests)
Sprint 4: 8 hours (skills + polish)

Phase 3 Total: 40 hours
Timeline: Feb 1-7, 2026 (5-day week = 8 hours/day)
```

---

## What's NOT in Phase 3

### Deferred to Phase 4:

- ❌ Skills Databricks routing (requires Phase 3 foundation)
- ❌ Cognitive layer full integration (requires Skills complete)
- ❌ Pattern consolidation (requires cognitive integration)
- ❌ Performance optimization (requires baseline metrics)

### Already Delivered in Phase 1-2:

- ✅ RAG system (production-ready)
- ✅ Databricks integration (mature)
- ✅ Skills registry (functional)
- ✅ CI/CD infrastructure (enforced)

---

## Next Steps

### **Immediate** (Do now):

1. Complete Phase 2 finalization (5 tasks, 1.5 hours)
2. Record test baseline from Task 1
3. Get CI running and passing

### **Then** (Start Phase 3):

1. Begin Sprint 1: Fix event loop
2. Add agentic system tests
3. Track progress against baseline

### **Finally** (Phase 3 completion):

1. Achieve 400+ tests at 90%+ pass rate
2. Ready for Phase 4: Production Optimization

---

**Phase 3 is ready to start once Phase 2 finalization complete!**
