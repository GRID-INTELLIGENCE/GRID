# GRID Coverage Zoom Map — Extended Depth

## 1. Zoom Focus: Mothership (Application) Ecosystem
### 1.1 Routers and Their Submodules
| Router | Subcomponents | Dependencies | Observability hooks |
| --- | --- | --- | --- |
| `health.py` | `CockpitHealthCheck`, dependency on `services.CockpitService`, `metrics` collector, `StateStore` | `grid.resilience.api`, `infrastructure.monitoring.prometheus_metrics` | `/health`, `/ready`, `/live` metrics + logging middleware | 
| `auth.py` | Token validation, JWT claims, refresh cycle, rate limiter integration, `security.session_isolator` | `vection.security`, `application.mothership.dependencies` | Auth failure metrics, guardrails in `security_enforcer` | 
| `billing.py` | `UsageMeter` (see `services.billing.meter`), invoice listing, invoice payment, subscription tiers | `repositories.usage`, `models.payment`, `prometheus_metrics` counters | Billing usage metrics, event logging via `ghost_registry` | 
| `navigation.py` | Planning handler, decision handler, context enrichment, `rag_streaming` synergy | `api_core.ghost_registry`, `grid.components.node_modules` for helpers | HandlerMetrics, circuit breaker state tracked in `api_core` | 
| `rag_streaming.py` | RAG streaming, batch, session lifecycle, connectors to retrieval agents (RAG engine) | `tools.rag`, `grid.rag`, `application.mothership.rag_handlers` | Streaming response timing, operation metrics via `ghost_registry` | 

### 1.2 Services (Cockpit, Session, Operation, Alerts)
- `CockpitService` orchestrates `SessionService`, `OperationService`, `ComponentService`, `AlertService`. Maintains `CockpitState`, exposes `start`, `shutdown`, `get_health_summary`. Event pump uses `EventHandler` hooks tied into `grid.resilience.api`.  
- `SessionService` (located near line ~1200 in `services/__init__`) handles TTLs, concurrency, and interacts with `repositories.StateStore`.  
- `OperationService` coordinates `OperationStatus`, cancels operations during shutdown, emits `CockpitEvent`.  

### 1.3 Ghost Registry Internals
- `api_core.ghost_registry` stores handlers with states (`ACTIVE`, `DISABLED`, `CIRCUIT_OPEN`).  
- `HandlerMetrics` records latency/failure data; used by monitoring dashboards.  
- `summon_handler()` wraps invocations with security validations (`security.manager`, `security.input_validator`).  

## 2. Zoom Focus: VECTION Cognitive Engine
### 2.1 Core Workflow
1. `Vection.get_instance()` ensures singleton.  
2. `establish(session_id, event)` updates `SessionState`, adds to `_global_signals`, applies decay via `_maybe_decay()`.  
3. `query_emergent` uses `EmergenceSignal.matches_query()` to return top 10 signals.  
4. `project` uses `VelocityVector.project()` (see `schemas.velocity_vector`).  
5. `dissolve` tears down contexts, logs via `audit_logger`.  

### 2.2 Security Subsystems Depth
| Component | Description | Key Files | Monitoring/Audit |
| --- | --- | --- | --- |
| `SecurityManager` | Blocks operations failing rate limit/validation/anomaly. | `security/manager.py` | Logs to `AuditLogger`, emits metrics via `ghost_registry`. |
| `AuditLogger` | Hash-chain log events, JSON + human outputs, rotating file handler. | `security/audit_logger.py` | Partial index used by `verify_audit_trail`. |
| `RateLimiter` | Sliding window enforcement, `check`, `require`, `OperationType` enum. | `security/rate_limiter.py` | Exposed via resilience metrics. |
| `InputValidator` | Sanitizes metadata and content, warns on issues, used in middleware. | `security/input_validator.py` | Logs validation warnings, integrates with `SecurityManager`. |
| `AnomalyDetector` | Defines `DetectionThresholds`, `AnomalyAlert`, `AlertSeverity`. | `security/anomaly_detector.py` | Alerts trigger audit logging + optional blocking. |
| `SessionIsolator` | Enforces cross-session boundaries per operation `AccessType`. | `security/session_isolator.py` | Emits `ViolationRecord`, used by `CockpitService`. |

### 2.3 Worker Mesh Expansion
- `Projector` computes future context steps, exposes `get_projection()` helper used by `ActivityResonance`.  
- `Correlator` observes events, tries to pair them temporally; accessible via `get_correlator()` helper.  
- `Clusterer` groups similar events; interacts with `EventFeatures` dataclasses.  

## 3. Zoom Focus: GRID Intelligence Layer
### 3.1 Module Breakdown
- `essence.core_state` tracks `EssentialState`.  
- `patterns.recognition` implements `PatternRecognition`.  
- `awareness.context` exposes `Context`, `ContextSnapshot`.  
- `quantum` houses `LocomotionEngine`, `Quantizer`.  
- `senses` collects smell/touch/taste data, extends `SensoryProcessor`.  
- `processing.periodic` orchestrates `PeriodicProcessor`, `EmergencyRealtimeProcessor`.  
- `entry_points` exposes optimized API/CLI/service hooks.  

### 3.2 Integration Interfaces
- `interfaces.bridge.QuantumBridge` connects GRID intelligence into VECTION and Mothership layers.  
- `tracing` components capture `ActionTrace`, `TraceContext`, `TraceManager`, `TraceOrigin`, `TraceStore`.  

## 4. Zoom Focus: Resonance & Skills
### 4.1 Resonance Subsystems
- `ResonanceCLI.process()` instantiates `ActivityResonance`, manages `feedback_handler`, calls `start_feedback_loop()`/`stop_feedback_loop()`.  
- `ActivityResonance` uses `ContextProvider` (fast context aggregator) and `PathVisualizer` (calls `GridBridge` for path rendering).  
- API router includes WebSocket `/ws/{activity_id}` for live envelopes; uses `ADSR` feedback to signal phases.  
- `performance.py` endpoints (`/sales`, `/user-behavior`) rely on SQL fallbacks and `execute_fallback` to ensure resilience.  

### 4.2 Skills System Depth
- `Skills API` consults `IntelligenceInventory`, `NSRTracker` for metrics.  
- `diagnostics` endpoint aggregates `SkillsDiagnostics`, hooking into observability stack.  

## 5. Zoom Focus: Infrastructure & Seed Data
- `prometheus_metrics.define_metric()` exposes shared metrics; new metrics should plug into glyph `grid_api_requests_total`.  
- `grid/resilience/observed_decorators` includes decorated operations that auto-record metrics, used widely in `application/mothership`.  
- `seed/topics_seed.json` → `tools/rag/intelligence` pipeline to populate knowledge graphs.  

## 6. Depth Map: Dependencies & Data Flow
```
[Seeds] → tools/rag/intelligence → application/mothership/rag_handlers ↔ tools/rag/chat ↔ grid/rag
                                       ↓
                                   VECTION Core ↔ Security Stack
                                       ↓
                              GRID Intelligence Layer (patterns, awareness)
                                       ↓
                         Mothership API (Ghost Registry) ↔ Resonance CLI/API
```

### Observability Pathway
- Entry routes (FastAPI routers, CLI commands) flow through `ghost_registry`.  
- Metrics go into `prometheus_metrics` → exported to Prometheus.  
- Audit logs write to `logs/security/vection_audit.log`, verified via `verify_audit_trail.py`.  
- Security events feed to `RateLimiter`, `AnomalyDetector`, `SessionIsolator`.  

## 7. Next-Level Coverage Suggestions
1. **Telemetry Drilldowns:** Add per-submodule histograms (e.g., `health`, `billing`, `navigation`) using `define_metric`.  
2. **Dependency Map:** Annotate each dependency arrow in the architecture diagram with file paths from above.  
3. **Entry Point Depth:** For each entry point (API, CLI, audit, nul guard), capture nested components it exercises (router → service → repository).  
4. **Security Traceability:** Ensure every request path is covered by `security.manager`, `audit_logger`, and `ghost_registry`.  

---

This zoomed map increases depth for each cluster; let me know if you need the next layer (per-class methods, data flows per request, etc.).
