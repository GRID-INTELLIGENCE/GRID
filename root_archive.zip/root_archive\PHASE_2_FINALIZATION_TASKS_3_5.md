# Phase 2 Finalization: Tasks 3-5 (Manual GitHub Configuration)

**Status**: Ready for manual execution
**GitHub Organization**: `irfankabir02`
**Repository**: `GRID`
**Total Time**: ~30 minutes
**Blockers for Phase 3**: ✅ All tasks are blockers (especially Task 5)

---

## Task 3: Enable Branch Protection Rules ⏱️ 10 minutes

**Purpose**: Make CI actually block merges - prevent human error, enforce quality standards

**GitHub URL**: https://github.com/irfankabir02/GRID/settings/branches

### Step 1: Navigate to Branch Settings

1. Go to: https://github.com/irfankabir02/GRID/settings/branches
2. Scroll to **"Add rule"** button under "Branch protection rules"
3. Click **Add rule**

### Step 2: Create Rule for `main` Branch

**Fill in the form with these values**:

| Field                                  | Value             | Notes                                     |
| -------------------------------------- | ----------------- | ----------------------------------------- |
| Branch name pattern                    | `main`            | Exact match                               |
| Require a pull request before merging  | ✅ Checked        | Enforce code review                       |
| Require status checks to pass          | ✅ Checked        | CRITICAL: CI must pass                    |
| Required status checks                 | Select these 3:   | In this exact order:                      |
|                                        | `call-quality`    | Must pass (Black, Ruff, mypy, etc.)       |
|                                        | `call-tests`      | Must pass (pytest matrix: 3.11/3.12/3.13) |
|                                        | `all-checks`      | Orchestration check - must pass           |
| Require branches to be up to date      | ✅ Checked        | Prevent stale merges                      |
| Require code review before merging     | Leave unchecked\* | Optional, setup later if needed           |
| Require conversation resolution        | Leave unchecked   | Optional                                  |
| Require auto-deletion of head branches | ✅ Checked        | Clean up after merge                      |
| Dismiss stale PR approvals             | ✅ Checked        | Re-review after new commits               |

**Click: SAVE CHANGES**

### Step 3: Create Rule for `develop` Branch

Repeat Step 2 with:

- **Branch name pattern**: `develop` (instead of `main`)
- **All other settings**: SAME as main branch

### ✅ Verification

After saving both rules, you should see:

```
Branch protection rules

main — Protected branch
  - Requires a pull request before merging
  - Requires status checks to pass before merging (call-quality, call-tests, all-checks)
  - Requires branches to be up to date before merging

develop — Protected branch
  - [Same as above]
```

**What this accomplishes**:

- ✅ CI must pass before ANY merge
- ✅ Automatic code review reminders
- ✅ No stale approvals after new commits
- ✅ No merging without fresh branch state
- ❌ Blocks broken code from reaching main
- ❌ Blocks failed quality gates from reaching production

---

## Task 4: Link Codecov Account ⏱️ 15 minutes

**Purpose**: Track coverage trends, see PR impact on coverage, get coverage badges

**GitHub URL**: https://codecov.io/signup

### Step 1: Sign Up with GitHub

1. Go to: https://codecov.io/signup
2. Click **"Sign up with GitHub"** button
3. Enter GitHub credentials (if not already logged in)
4. Click **"Authorize Codecov by Sentry"** (when prompted)

### Step 2: Select Repository

1. After authorization, you'll see a list of repositories
2. Find **GRID** in the list
3. Click the toggle to **enable coverage tracking** for GRID

### Step 3: Verify Configuration

1. Go to: https://codecov.io/gh/irfankabir02/GRID
2. You should see a dashboard (empty until first CI run)
3. Settings are automatic - no additional config needed

### ✅ Verification (After Task 5)

After the first CI run, you should see:

- Coverage percentage displayed
- Coverage trend graph (will update with each run)
- PR coverage impact shown on each pull request
- Badge showing coverage status: `[![Coverage](https://codecov.io/...)]`

**What this accomplishes**:

- ✅ Coverage dashboard at https://codecov.io/gh/irfankabir02/GRID
- ✅ Coverage metrics in PR reviews
- ✅ Coverage badges on README
- ✅ Historical coverage trends
- ✅ Branch coverage comparison
- ✅ File-level coverage breakdown

**Note**: Codecov auto-uploads from CI, nothing else needed

---

## Task 5: Execute First CI Run 🚀 ⏱️ 5-40 minutes

**Purpose**: Verify end-to-end workflow, generate baseline metrics, test enforcement

### Part A: Create Test Branch (5 minutes)

```powershell
cd e:\grid

# 1. Create feature branch
git checkout -b phase2-finalization

# 2. Verify you're on the new branch
git branch -v
# Expected output: * phase2-finalization [latest commit]

# 3. Make a test change
echo "# Phase 2 Finalization - First CI Run" > PHASE_2_CI_TEST.md
echo "" >> PHASE_2_CI_TEST.md
echo "This file documents the first CI run on January 26, 2026" >> PHASE_2_CI_TEST.md

# 4. Stage and commit
git add PHASE_2_CI_TEST.md
git commit -m "test: verify Phase 2 CI workflow execution"

# 5. Push to GitHub
git push origin phase2-finalization
```

### Part B: Monitor CI Execution (30-40 minutes)

1. **Go to GitHub Actions**:
   - URL: https://github.com/irfankabir02/GRID/actions
   - Look for workflow with name: `"test: verify Phase 2 CI workflow execution"`

2. **Watch the workflows execute** (in this order):

   ```
   Time    │ Workflow              │ Duration  │ Status
   ────────┼───────────────────────┼───────────┼─────────
   0:00    │ ci-quality.yml        │ 2-3 min   │ Running...
           │ - Black               │ 30s       │
           │ - Ruff                │ 30s       │
           │ - mypy                │ 45s       │
           │ - Bandit              │ 30s       │
           │ - Safety              │ 30s       │
           │ - pre-commit          │ 15s       │
   ────────┼───────────────────────┼───────────┼─────────
   2:00    │ ci-test.yml           │ 15-24 min │ Running...
           │ - Python 3.11 tests   │ 5-8 min   │
           │ - Python 3.12 tests   │ 5-8 min   │ (parallel)
           │ - Python 3.13 tests   │ 5-8 min   │
   ────────┼───────────────────────┼───────────┼─────────
   24:00   │ ci.yml (orchestrator) │ <1 min    │ Verifying...
           │ - Service checks      │           │
   ────────┼───────────────────────┼───────────┼─────────
   25:00   │ TOTAL                 │ 25-27 min │ ✅ SUCCESS
   ```

3. **Expected Results**:

   | Check               | Expected            | Status                                         |
   | ------------------- | ------------------- | ---------------------------------------------- |
   | Black formatting    | All files compliant | ✅ Should pass                                 |
   | Ruff linting        | No violations       | ⚠️ May have issues (advisory mode)             |
   | mypy type checking  | No errors           | ⚠️ May have issues (advisory mode)             |
   | Bandit security     | No critical issues  | ⚠️ May have issues (advisory mode)             |
   | Safety dependencies | All safe            | ✅ Should pass                                 |
   | pre-commit hooks    | All pass            | ✅ Should pass                                 |
   | pytest (3.11)       | 90%+ pass           | ⚠️ 1,354 tests collected, 4 skip due to errors |
   | pytest (3.12)       | 90%+ pass           | ⚠️ Same as 3.11                                |
   | pytest (3.13)       | 90%+ pass           | ⚠️ Same as 3.11                                |
   | Coverage            | 80%+                | ⚠️ May be 70-80% initially                     |

### Part C: Create Pull Request (2 minutes, after CI passes)

Once CI completes successfully:

1. Go to: https://github.com/irfankabir02/GRID/pull/new/phase2-finalization
2. Fill in PR details:
   - **Title**: `feat: Phase 2 finalization - CI enforcement enabled`
   - **Description**:

     ```markdown
     # Phase 2 Finalization

     Completes Phase 2 CI/CD infrastructure deployment:

     - ✅ Tests: pytest with coverage enforcement (80% minimum)
     - ✅ Quality: 6-tool quality gate (Black, Ruff, mypy, Bandit, Safety, pre-commit)
     - ✅ Orchestration: Main workflow coordinates quality + tests
     - ✅ Branch protection: main & develop protected
     - ✅ Codecov: Coverage tracking enabled
     - ✅ First CI run: All workflows verified

     Baseline metrics (first run):

     - Tests collected: 1,354
     - Collection errors: 4 (HuggingFace integration - Phase 3 scope)
     - Expected pass rate: 90%+

     Ready for Phase 3: Test Suite Stabilization (Feb 1-7, 2026)
     ```

3. Click **Create pull request**

### Part D: Merge to Main (5 minutes)

1. Wait for branch protection checks to complete (should be ✅ all green)
2. Click **Merge pull request** (button becomes enabled when all checks pass)
3. Choose merge strategy: **Squash and merge** (recommended for cleaner history)
4. Confirm merge
5. ✅ First CI enforcement successful!

### ✅ Verification

After PR merge, you should see:

- ✅ All CI checks passed
- ✅ Coverage report in Codecov dashboard
- ✅ Badge updated showing status
- ✅ Test results archived in GitHub Actions

**What this accomplishes**:

- ✅ End-to-end CI/CD workflow validated
- ✅ Branch protection enforcement verified
- ✅ Codecov integration tested
- ✅ Baseline metrics captured
- ✅ Documentation updated
- ✅ Ready for Phase 3 test stabilization

---

## Summary: Phase 2 Complete ✅

| Task                      | Status              | Time          | Blocker |
| ------------------------- | ------------------- | ------------- | ------- |
| Task 1: Test baseline     | ✅ DONE             | 45 min        | ❌ No   |
| Task 2: Badge URLs        | ✅ DONE             | 2 min         | ❌ No   |
| Task 3: Branch protection | ⏳ PENDING          | 10 min        | ✅ YES  |
| Task 4: Codecov account   | ⏳ PENDING          | 15 min        | ❌ No   |
| Task 5: First CI run      | ⏳ PENDING          | 40 min        | ✅ YES  |
| **TOTAL PHASE 2**         | **⏳ 60% complete** | **1.5 hours** |         |

---

## Next Steps: Phase 3 (Test Stabilization)

Once Tasks 3-5 are complete:

1. Review baseline metrics from first CI run
2. Document any test failures
3. Begin Phase 3 Sprint 1: Async event loop + agentic tests
4. Target: 400+ tests at 90%+ pass rate by Feb 7

---

## Commands Reference

### If you need to redo a step:

```powershell
# Delete the test branch (if needed)
git checkout main
git branch -d phase2-finalization
git push origin --delete phase2-finalization

# Or create a different branch for testing
git checkout -b phase2-finalization-v2
```

### Monitor CI without pushing:

- GitHub Actions: https://github.com/irfankabir02/GRID/actions
- Recent workflows: https://github.com/irfankabir02/GRID/actions?query=workflow%3ACI
- Codecov dashboard: https://codecov.io/gh/irfankabir02/GRID
