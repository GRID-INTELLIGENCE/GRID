# GRID Profile: Components, Modules, Tools, Configs, and Integration

## 1. Application Layer (Mothership)
- **Main Entry:** `src/application/mothership/main.py` — FastAPI server with logging middleware, metrics exposure, security dependencies.  
- **Routers:** `health`, `auth`, `billing`, `navigation`, `rag_streaming`, `agentic` (FastAPI routers); handle API entry points.  
- **Services:** `CockpitService`, `SessionService`, `OperationService`, `ComponentService`, `AlertService`; coordinate state, session/timeouts, events.  
- **Repositories:** `db_repos`, `usage`, `state store`, `unit of work` for persistence.  
- **Security:** `security/api_sentinels`, middleware `security_enforcer`, `stream_monitor`.  
- **Schemas/Models/Exceptions:** Pydantic request/response models, `models.payment`, `models.subscription`, custom error hierarchy.  
- **Ghost Registry:** `api_core.py` centralizes handler registration, invocation, metrics, circuit breakers, security checks.  

## 2. Cognitive Core (VECTION)
- **Engine Modules:** `core/engine.py`, `stream_context.py`, `emergence_layer.py`, `velocity_tracker.py`, `context_membrane.py` orchestrate context emergence, session tracking, velocity vectors.  
- **Security Stack:** `security/manager.py`, `audit_logger.py`, `rate_limiter.py`, `input_validator.py`, `session_isolator.py`, `anomaly_detector.py`, `events.py`.  
- **Workers:** `workers/projector.py`, `workers/correlator.py`, `workers/clusterer.py` for projection, correlation, clustering.  
- **Interfaces/Protocols:** `interfaces/grid_bridge.py`, `protocols/discoverable.py`, `protocols/projectable.py` for cross-layer integration.  
- **Schemas:** `schemas/context_state.py`, `schemas/emergence_signal.py`, `schemas/velocity_vector.py`, representing VectionContext, Anchor, EmergenceSignal, VelocityVector.  
- **CLIs/Tools:** `security/verify_audit_trail.py` for audit validation, `demo.py` utilities.  

## 3. Intelligence Layer (GRID)
- **Core Packages:** `essence`, `patterns`, `awareness`, `evolution`, `interfaces`, `organization`, `prompts`, `quantum`, `senses`, `processing`, `entry_points`.  
- **Entry Point Orchestrators:** `APIEntryPoint`, `CLIEntryPoint`, `ServiceEntryPoint` exposures.  
- **Tracing Systems:** `tracing` package captures action origins, trace context history.  
- **Organization Modules:** Role/user/discipline management.  
- **Senses/Quantum:** Support multi-sensory data and quantized processing for locomotion and state updates.  

## 4. Resonance System
- **Activity Engine:** `application/resonance/activity_resonance.py`, `ResonanceFeedback`, `ADSR envelope`, `ContextProvider`, `PathVisualizer`.  
- **CLI:** `application/resonance/cli.py`, exposes process() for interactive commands, JSON/human output, feedback loop.  
- **API:** `application/resonance/api/router.py` routes `/process`, `/context`, `/paths`, `/envelope`, `/complete`, `/events`, `/ws/{activity_id}`, `/debug/config`.  
- **Performance API:** `application/resonance/api/performance.py` returns analytics on sales, user behavior, product/development data.  

## 5. Skills & Intelligence Tools
- **Skills API:** `application/skills/api.py` with health, intelligence, signal quality, diagnostics endpoints.  
- **RAG Tools:** `tools/rag/*` includes vector stores, chat, CLI, intelligence modules, indexers.  

## 6. Infrastructure & Monitoring
- **Prometheus Integration:** `infrastructure/monitoring/prometheus_metrics.py` exporting counters (`grid_api_requests_total`, `grid_errors_total`), histograms (`grid_api_request_duration_seconds`), cognitive load metrics.  
- **Resilience Metrics:** `grid/resilience/metrics.py`, `observed_decorators.py`, `api.py` exposing `/metrics` endpoints and observable retry/fallback data.  
- **NUL Guard:** `scripts/nul_guard/main.go` scans for artifact `nul` files, reports occurrences, supports blocklists.  

## 7. Configuration & Automation Tools
- **Environment Configs:** `config/env/development.env`, `.env.example`, `.env.production.template`, `litellm_config.yaml`.  
- **Routing/Delegation:** `config/api_routes.yaml`, `arena_config.yaml`, `delegation_spec.json`.  
- **Workflows:** `.windsurf/` settings, `workflows/*.md`, automation scripts.  
- **Docker/CI:** `.github/workflows/*` (CI/test/deploy), Docker compose for services, scripts `deploy.sh`, `migrate_to_wsl.sh`, etc.  

## 8. Tools & Seed Data
- **Seed Files:** `seed/topics_seed.json`, `seed/relationship_seed.yaml`, `seed/context_vectors.bin`.  
- **Scripts:** `scripts/agent_setup.ps1`, `scripts/nul_guard`, `scripts/nul_cleaner.bat`, `scripts/monitor_wsl_performance.sh`.  
- **Test Harnesses:** `tests/` folder (API, integration, performance, unit, mcp) covering entire stack.  

## 9. Observability & Security Tools
- **Audit Tools:** `security/audit_logger.py`, CLI `verify_audit_trail.py`, `events.py` emitter.  
- **Monitoring:** `grid/resilience/api.py`, `infrastructure/monitoring/prometheus_metrics.py`, `application/mothership/routers/health.py`.  
- **Ghost Registry:** Centralized invocation path ensures every handler registers metrics, security checks, circuit breakers.  

## 10. Entry Points & Services (Summary)
| Entry Point | Location | Function | Monitoring Hook |
|------------|----------|----------|-----------------|
| FastAPI (Mothership) | `src/application/mothership/main.py` | API surface | Logging + Prometheus + health/retry endpoints |
| Resonance CLI | `application/resonance/cli.py` | Activity tooling | Feedback logging + ADSR metrics |
| Audit CLI | `security/verify_audit_trail.py` | Audit validation | Chain integrity verification |
| NUL Guard | `scripts/nul_guard/main.go` | File system sentinel | Reports/blocklists |
| Ghost Registry | `application/mothership/api_core.py` | Handler control | HandlerMetrics + circuit breaker |
| VECTION Engine | `vection/core/engine.py` | Context emergence | Session stats + velocity data |

---

## Next Step Plan for Results
1. **Telemetry Expansion:** Instrument each entry point with millisecond granularity using existing Prometheus metrics and HandlerMetrics.  
2. **Security/Observability Integration:** Ensure audits/governance tie into Ghost Registry and VECTION security stack, covering every handler.  
3. **Historical Trace:** Use audit trail verifier and git history to timestamp first appearances and evolution for each profile area (Vite endpoint, Ghost registry, security).  
4. **Coverage & Reporting:** Keep `full_system_report.md`, `codebase_population_map.md`, `full_code_context_map.md`, `endpoint_monitoring_profile.md` synchronized with new telemetry/security data.  

Once you confirm, I'll generate the prioritized results referenced above with specific timestamps and tasks.
