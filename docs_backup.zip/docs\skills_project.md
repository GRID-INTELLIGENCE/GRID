# GRID Project-Specific Skills Documentation

**Purpose**: Domain-specific skills tied to GRID's specific capabilities. These skills integrate with GRID services like RAG, NER, knowledge graph, and git intelligence.

## Overview

Project-specific skills leverage GRID's infrastructure and services to provide domain-aware capabilities. They integrate with:
- **RAG System** (`tools/rag/`) - Local-first knowledge retrieval
- **NER Service** (`application/mothership/ner_service.py`) - Named entity recognition
- **Knowledge Graph** (`grid/knowledge/`) - Structured knowledge artifacts
- **Git Intelligence** (`scripts/git_intelligence.py`) - AI-powered git analysis

**Skills Registry**: `src/grid/skills/registry.py`
**Base Protocol**: `src/grid/skills/base.py`

## Skills Registry

**Registry Implementation**: `src/grid/skills/registry.py`
**Base Protocol**: `src/grid/skills/base.py`

### Registry Loading Process

The registry dynamically loads all built-in skills using `importlib`:

```python
def _load_builtin_skills(registry: SkillRegistry) -> None:
    import importlib
    import logging

    skills_to_load = [
        ("youtube_transcript_analyze", ".youtube_transcript_analyze"),
        ("intelligence_git_analyze", ".intelligence_git_analyze"),
        ("rag_query_knowledge", ".rag_query_knowledge"),
        ("patterns_detect_entities", ".patterns_detect_entities"),
        ("analysis_process_context", ".analysis_process_context"),
        ("cross_reference_explain", ".cross_reference_explain"),
        ("compress_articulate", ".compress_articulate"),
        ("context_refine", ".context_refine"),
        ("transform_schema_map", ".transform_schema_map"),
        ("topic_extractor", ".topic_extractor"),
        ("knowledge_capture", ".knowledge_capture"),
    ]

    for name, relative_path in skills_to_load:
        module = importlib.import_module(relative_path, package="grid.skills")
        skill = getattr(module, name)
        registry.register(skill)
```

### Project-Specific Skill Registration Table

| Skill ID | Module Path | Variable Name |
|----------|-------------|---------------|
| `rag.query_knowledge` | `grid.skills.rag_query_knowledge` | `rag_query_knowledge` |
| `patterns.detect_entities` | `grid.skills.patterns_detect_entities` | `patterns_detect_entities` |
| `analysis.process_context` | `grid.skills.analysis_process_context` | `analysis_process_context` |
| `intelligence.git_analyze` | `grid.skills.intelligence_git_analyze` | `intelligence_git_analyze` |
| `knowledge.capture` | `grid.skills.knowledge_capture` | `knowledge_capture` |
| `youtube.transcript_analyze` | `grid.skills.youtube_transcript_analyze` | `youtube_transcript_analyze` |

### CLI Integration

The CLI commands use the registry to list and run skills:

```python
# List skills (src/grid/__main__.py:162-178)
def skills_list_command(args: argparse.Namespace) -> int:
    from grid.skills.registry import default_registry

    payload = {
        "skills": [
            {
                "id": s.id,
                "name": s.name,
                "description": s.description,
            }
            for s in default_registry.list()
        ]
    }

    sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0

# Run skill (src/grid/__main__.py:181-204)
def skills_run_command(args: argparse.Namespace) -> int:
    from grid.skills.registry import default_registry

    skill = default_registry.get(args.skill_id)
    if skill is None:
        raise SystemExit(f"Unknown skill: {args.skill_id}")

    skill_args: Dict[str, Any] = {}
    if args.args_json or args.args_file:
        skill_args.update(_read_json_payload(args.args_json, args.args_file))

    result = skill.run(skill_args)

    sys.stdout.write(json.dumps(result, indent=2, ensure_ascii=False))
    return 0
```

### Registry Usage Examples

```python
from grid.skills.registry import default_registry

# List all available skills
skills = default_registry.list()
for skill in skills:
    print(f"{skill.id}: {skill.name}")

# Get a specific skill
skill = default_registry.get("rag.query_knowledge")
if skill:
    result = skill.run({"query": "How does RAG work?", "top_k": 5})
    print(result)

# Run skill directly
result = default_registry.get("patterns.detect_entities").run({
    "text": "John Smith works at Acme Corp on machine learning projects",
    "entity_types": ["PERSON", "ORG", "DOMAIN"]
})
```

## Skills List

1. `rag.query_knowledge` - Query GRID's RAG knowledge base
2. `patterns.detect_entities` - Named entity recognition using GRID's NER pipeline
3. `analysis.process_context` - Full GRID analysis pipeline (entities, patterns, sentiment, relationships)
4. `intelligence.git_analyze` - AI-powered git change analysis
5. `knowledge.capture` - Transform task results into structured Knowledge artifacts
6. `youtube.transcript_analyze` - Transcript analysis with optional RAG enrichment

---

## 1. `rag.query_knowledge`

**Purpose**: Query GRID's project knowledge base using the RAG system. Retrieves relevant documentation and provides LLM-generated answers.

### Capabilities

- Semantic search across GRID documentation
- Retrieves relevant documentation chunks with metadata
- Provides LLM-generated answers based on retrieved context
- Includes source metadata (path, distance, confidence)
- Supports variable retrieval depth (top_k)
- Uses local Ollama models (no external APIs)

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.rag_query_knowledge import rag_query_knowledge
# registry.register(rag_query_knowledge)
```

### Code Context

```29:111:src/grid/skills/rag_query_knowledge.py
def _query_knowledge(args: Mapping[str, Any]) -> Dict[str, Any]:
    """Query GRID's knowledge base (RAG system) using tools bridge."""
    if not _BRIDGE_AVAILABLE:
        return {
            "skill": "rag.query_knowledge",
            "status": "error",
            "error": "Tools bridge not available",
        }

    bridge = get_tools_bridge()
    if not bridge.is_rag_available():
        return {
            "skill": "rag.query_knowledge",
            "status": "error",
            "error": "RAG module not available",
        }

    query = args.get("query")
    if not query:
        return {
            "skill": "rag.query_knowledge",
            "status": "error",
            "error": "Missing required parameter: 'query'",
        }

    top_k = int(args.get("top_k", 5) or 5)
    temperature = float(args.get("temperature", 0.7) or 0.7)

    try:
        # Get RAG engine through bridge
        engine = bridge.get_rag_engine()
        if engine is None:
            return {
                "skill": "rag.query_knowledge",
                "status": "error",
                "error": "Failed to initialize RAG engine",
                "query": query,
            }
        result = engine.query(
            query_text=query,
            top_k=top_k,
            temperature=temperature,
            include_sources=True,
        )

        # Normalize output
        sources = []
        if result.get("sources"):
            for source in result["sources"]:
                sources.append(
                    {
                        "path": source.get("metadata", {}).get("path", "unknown"),
                        "distance": source.get("distance", 0),
                        "confidence": 1.0 - (source.get("distance", 0) / 2.0),  # Convert distance to confidence
                    }
                )

        return {
            "skill": "rag.query_knowledge",
            "status": "success",
            "query": query,
            "answer": result.get("answer", ""),
            "sources": sources,
            "retrieval_count": len(sources),
            "context_quality": sum(s["confidence"] for s in sources) / len(sources) if sources else 0,
        }

    except Exception as e:
        return {
            "skill": "rag.query_knowledge",
            "status": "error",
            "error": str(e),
            "query": query,
        }
```

### GRID Integration

- Uses `grid.integration.tools_bridge` to access RAG engine
- Integrates with `tools/rag/rag_engine.py`
- Uses local Ollama models: `nomic-embed-text-v2-moe:latest` for embeddings, `ministral` or `gpt-oss-safeguard` for LLM
- Vector store: ChromaDB in `.rag_db/`

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `query` | string | Yes | - | Query text to search knowledge base |
| `top_k` | integer | No | `5` | Number of relevant chunks to retrieve |
| `temperature` | float | No | `0.7` | LLM temperature for answer generation |

### Usage Examples

#### Basic Query

```powershell
.\venv\Scripts\python.exe -m grid skills run rag.query_knowledge --args-json "{query:'How does the pattern engine work?', top_k:3}"
```

**Output**:
```json
{
  "skill": "rag.query_knowledge",
  "status": "success",
  "query": "How does the pattern engine work?",
  "answer": "The pattern engine uses regex matching to detect cognition patterns including Flow, Spatial, Rhythm, Color, Repetition, Deviation, Cause, Time, and Combination patterns.",
  "sources": [
    {
      "path": "docs/architecture.md",
      "distance": 0.15,
      "confidence": 0.925
    },
    {
      "path": "src/grid/patterns/pattern_engine.py",
      "distance": 0.22,
      "confidence": 0.89
    },
    {
      "path": "docs/pattern_language.md",
      "distance": 0.28,
      "confidence": 0.86
    }
  ],
  "retrieval_count": 3,
  "context_quality": 0.89
}
```

#### Query with Custom Parameters

```powershell
.\venv\Scripts\python.exe -m grid skills run rag.query_knowledge --args-json "{query:'What is the GRID system?', top_k:5, temperature:0.5}"
```

### Dependencies

- **RAG Engine**: `tools/rag/rag_engine.py`
- **Ollama**: Local Ollama instance running
- **Embedding Model**: `nomic-embed-text-v2-moe:latest`
- **LLM Model**: `ministral` or `gpt-oss-safeguard`
- **Vector Store**: ChromaDB (`.rag_db/` directory)

### Error Handling

- Returns error if tools bridge not available
- Returns error if RAG module not available
- Returns error if RAG engine initialization fails
- Returns error if query parameter missing
- Handles exceptions gracefully with error messages

### Performance Notes

- **Query time**: 500ms - 2s (includes embedding + search + LLM generation)
- **Cached queries**: < 100ms (subsequent identical queries)
- **Context quality**: 0.0-1.0 (typically 0.8-0.95 for good matches)
- **Retrieval accuracy**: Depends on index quality and query specificity

---

## 2. `patterns.detect_entities`

**Purpose**: Extract and analyze named entities using GRID's NER pipeline. Detects persons, organizations, domains, and other entity types.

### Capabilities

- Named entity recognition (NER) using GRID's NER service
- Supports multiple entity types (PERSON, ORG, DOMAIN, etc.)
- Provides confidence scores for each entity
- Fallback to heuristic detection if NER service unavailable
- Returns entity positions (start, end) in text

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.patterns_detect_entities import patterns_detect_entities
# registry.register(patterns_detect_entities)
```

### Code Context

```73:123:src/grid/skills/patterns_detect_entities.py
def _detect_entities(args: Mapping[str, Any]) -> Dict[str, Any]:
    """Detect entities in text."""
    text = args.get("text")
    if not text:
        return {
            "skill": "patterns.detect_entities",
            "status": "error",
            "error": "Missing required parameter: 'text'",
        }

    entity_types = args.get("entity_types")
    if isinstance(entity_types, str):
        entity_types = [t.strip() for t in entity_types.split(",")]
    elif not entity_types:
        entity_types = ["PERSON", "ORG", "DOMAIN"]

    try:
        # Try to use GRID's NER service
        try:
            from application.mothership.ner_service import NERService

            ner = NERService()
            entities = ner.extract(text, entity_types=entity_types)
        except ImportError:
            # Fallback to simple detection
            entities = _simple_entity_detection(text, entity_types)

        return {
            "skill": "patterns.detect_entities",
            "status": "success",
            "entities": entities,
            "entity_count": len(entities),
            "extracted_from_chars": len(text),
            "entity_types_requested": entity_types,
        }

    except Exception as e:
        return {
            "skill": "patterns.detect_entities",
            "status": "error",
            "error": str(e),
        }
```

### GRID Integration

- Primary: Uses `application.mothership.ner_service.NERService`
- Fallback: Heuristic entity detection if NER service unavailable
- Entity types: PERSON, ORG, DOMAIN (default), extensible

### Heuristic Fallback

```22:70:src/grid/skills/patterns_detect_entities.py
# Fallback entity detection if NER service is not available
def _simple_entity_detection(text: str, entity_types: List[str]) -> List[Dict[str, Any]]:
    """Simple heuristic entity detection as fallback."""
    import re

    entities = []

    # PERSON patterns
    if "PERSON" in entity_types:
        person_pattern = r"\b[A-Z][a-z]+ [A-Z][a-z]+\b"
        for match in re.finditer(person_pattern, text):
            entities.append(
                {
                    "text": match.group(),
                    "type": "PERSON",
                    "start": match.start(),
                    "end": match.end(),
                    "confidence": 0.75,  # Lower confidence for heuristic
                }
            )

    # ORG patterns (ALL CAPS or Title Case with Corp/Inc/LLC)
    if "ORG" in entity_types:
        org_pattern = r"\b[A-Z][a-zA-Z]*(?:\s+[A-Z][a-zA-Z]*)*\s+(?:Corp|Inc|LLC|Ltd|Co|Company|Organization)\b"
        for match in re.finditer(org_pattern, text):
            entities.append(
                {
                    "text": match.group(),
                    "type": "ORG",
                    "start": match.start(),
                    "end": match.end(),
                    "confidence": 0.80,
                }
            )

    # DOMAIN patterns
    if "DOMAIN" in entity_types:
        domain_pattern = r"\b(?:machine learning|artificial intelligence|data science|software engineering|web development|cloud computing|devops|cybersecurity)\b"
        for match in re.finditer(domain_pattern, text, re.IGNORECASE):
            entities.append(
                {
                    "text": match.group(),
                    "type": "DOMAIN",
                    "start": match.start(),
                    "end": match.end(),
                    "confidence": 0.85,
                }
            )

    return entities
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `text` | string | Yes | - | Text to extract entities from |
| `entity_types` | array/string | No | `["PERSON", "ORG", "DOMAIN"]` | Entity types to detect (comma-separated string or array) |

### Usage Examples

#### Basic Entity Detection

```powershell
.\venv\Scripts\python.exe -m grid skills run patterns.detect_entities --args-json "{text:'John Smith works at Acme Corp on machine learning projects', entity_types:['PERSON','ORG','DOMAIN']}"
```

**Output**:
```json
{
  "skill": "patterns.detect_entities",
  "status": "success",
  "entities": [
    {
      "text": "John Smith",
      "type": "PERSON",
      "start": 0,
      "end": 10,
      "confidence": 0.98
    },
    {
      "text": "Acme Corp",
      "type": "ORG",
      "start": 21,
      "end": 30,
      "confidence": 0.95
    },
    {
      "text": "machine learning",
      "type": "DOMAIN",
      "start": 38,
      "end": 54,
      "confidence": 0.92
    }
  ],
  "entity_count": 3,
  "extracted_from_chars": 54,
  "entity_types_requested": ["PERSON", "ORG", "DOMAIN"]
}
```

#### Custom Entity Types

```powershell
.\venv\Scripts\python.exe -m grid skills run patterns.detect_entities --args-json "{text:'The GRID framework provides geometric resonance intelligence.', entity_types:'DOMAIN'}"
```

### Dependencies

- **Primary**: `application.mothership.ner_service.NERService` (if available)
- **Fallback**: Heuristic regex-based detection (always available)
- **No external services required** (works offline)

### Error Handling

- Returns error if text parameter missing
- Falls back to heuristic detection if NER service unavailable
- Handles exceptions gracefully

### Performance Notes

- **NER Service mode**: 100-500ms (depends on text length and entity count)
- **Heuristic mode**: < 50ms (regex pattern matching)
- **Confidence scores**: 0.75-0.98 (heuristic), 0.85-0.99 (NER service)
- **Entity detection accuracy**: Higher with NER service, acceptable with heuristic fallback

---

## 3. `analysis.process_context`

**Purpose**: Run GRID's full analysis pipeline on text. Combines entity extraction, pattern detection, relationship analysis, and sentiment.

### Capabilities

- Multi-stage analysis pipeline:
  1. Entity extraction (NER)
  2. Pattern detection (regex-based patterns)
  3. Sentiment analysis (heuristic word-based)
  4. Relationship mapping (entity-to-entity connections)
- Provides timing metadata for each stage
- Configurable options (include_sentiment, include_relationships)
- Returns comprehensive analysis results

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.analysis_process_context import analysis_process_context
# registry.register(analysis_process_context)
```

### Code Context

```64:175:src/grid/skills/analysis_process_context.py
def _process_context(args: Mapping[str, Any]) -> Dict[str, Any]:
    """Process text through full GRID analysis pipeline."""
    text = args.get("text")
    if not text:
        return {
            "skill": "analysis.process_context",
            "status": "error",
            "error": "Missing required parameter: 'text'",
        }

    include_sentiment = args.get("include_sentiment", True)
    include_relationships = args.get("include_relationships", True)
    max_entities = int(args.get("max_entities", 50) or 50)

    start_time = time.time()

    try:
        # Stage 1: Entity extraction
        from .patterns_detect_entities import _simple_entity_detection

        entities = _simple_entity_detection(text, ["PERSON", "ORG", "DOMAIN"])[:max_entities]
        stage1_time = time.time()

        # Stage 2: Pattern detection
        import re

        patterns = []
        pattern_map = {
            "feature_impl": r"feature\s+implementation",
            "bug_fix": r"bug\s+fix|fix\s+bug",
            "refactor": r"refactoring|refactor",
            "test_case": r"test\s+case|test",
            "documentation": r"documentation|docs",
        }
        for pattern_name, pattern_re in pattern_map.items():
            matches = list(re.finditer(pattern_re, text, re.IGNORECASE))
            if matches:
                patterns.append(
                    {
                        "pattern": pattern_name,
                        "count": len(matches),
                        "confidence": 0.85,
                    }
                )
        stage2_time = time.time()

        # Stage 3: Sentiment (if requested)
        sentiment = None
        if include_sentiment:
            sentiment = _simple_sentiment(text)
        stage3_time = time.time()

        # Stage 4: Relationships (if requested)
        relationships = []
        if include_relationships and len(entities) > 1:
            # Simple: create relationships between consecutive entities
            for i in range(len(entities) - 1):
                relationships.append(
                    {
                        "source": entities[i]["text"],
                        "target": entities[i + 1]["text"],
                        "type": "RELATED",
                        "confidence": 0.70,
                    }
                )
        stage4_time = time.time()

        result = {
            "skill": "analysis.process_context",
            "status": "success",
            "text_length": len(text),
            "entities": entities,
            "entity_count": len(entities),
            "patterns": patterns,
            "pattern_count": len(patterns),
        }

        if sentiment is not None:
            result["sentiment"] = sentiment

        if relationships:
            result["relationships"] = relationships
            result["relationship_count"] = len(relationships)

        result["analysis_metadata"] = {
            "duration_ms": int((time.time() - start_time) * 1000),
            "stages_completed": 4,
            "stage_times_ms": {
                "entities": int((stage1_time - start_time) * 1000),
                "patterns": int((stage2_time - stage1_time) * 1000),
                "sentiment": int((stage3_time - stage2_time) * 1000),
                "relationships": int((stage4_time - stage3_time) * 1000),
            },
        }

        return result

    except Exception as e:
        return {
            "skill": "analysis.process_context",
            "status": "error",
            "error": str(e),
        }
```

### GRID Integration

- Uses `patterns.detect_entities` for entity extraction
- Integrates multiple analysis stages
- Provides timing metadata for performance monitoring
- Pattern detection aligned with GRID's pattern language

### Sentiment Analysis

```22:61:src/grid/skills/analysis_process_context.py
def _simple_sentiment(text: str) -> str:
    """Simple heuristic sentiment detection."""
    positive_words = {
        "great",
        "excellent",
        "good",
        "amazing",
        "wonderful",
        "fantastic",
        "love",
        "awesome",
        "best",
        "perfect",
        "brilliant",
        "super",
    }
    negative_words = {
        "bad",
        "terrible",
        "horrible",
        "awful",
        "hate",
        "worst",
        "poor",
        "disgusting",
        "useless",
        "broken",
        "fail",
    }

    text_lower = text.lower()
    pos_count = sum(1 for w in positive_words if w in text_lower)
    neg_count = sum(1 for w in negative_words if w in text_lower)

    if pos_count > neg_count:
        return "positive"
    elif neg_count > pos_count:
        return "negative"
    else:
        return "neutral"
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `text` | string | Yes | - | Text to analyze |
| `include_sentiment` | boolean | No | `true` | Include sentiment analysis |
| `include_relationships` | boolean | No | `true` | Include relationship mapping |
| `max_entities` | integer | No | `50` | Maximum entities to extract |

### Usage Examples

#### Full Analysis

```powershell
.\venv\Scripts\python.exe -m grid skills run analysis.process_context --args-json "{text:'Great new feature implementation with bug fixes and documentation updates.', include_sentiment:true, include_relationships:true}"
```

**Output**:
```json
{
  "skill": "analysis.process_context",
  "status": "success",
  "text_length": 75,
  "entities": [],
  "entity_count": 0,
  "patterns": [
    {
      "pattern": "feature_impl",
      "count": 1,
      "confidence": 0.85
    },
    {
      "pattern": "bug_fix",
      "count": 1,
      "confidence": 0.85
    },
    {
      "pattern": "documentation",
      "count": 1,
      "confidence": 0.85
    }
  ],
  "pattern_count": 3,
  "sentiment": "positive",
  "relationships": [],
  "relationship_count": 0,
  "analysis_metadata": {
    "duration_ms": 145,
    "stages_completed": 4,
    "stage_times_ms": {
      "entities": 12,
      "patterns": 45,
      "sentiment": 23,
      "relationships": 65
    }
  }
}
```

#### Analysis Without Sentiment

```powershell
.\venv\Scripts\python.exe -m grid skills run analysis.process_context --args-json "{text:'GRID framework provides pattern recognition capabilities.', include_sentiment:false, include_relationships:true}"
```

### Dependencies

- Uses `patterns.detect_entities` internally
- No external services required (all heuristic-based)

### Performance Notes

- **Total processing time**: 100-500ms (depends on text length)
- **Stage breakdown**: Entities (10-50ms), Patterns (20-100ms), Sentiment (10-30ms), Relationships (20-200ms)
- **Pattern detection**: 5 predefined patterns (feature_impl, bug_fix, refactor, test_case, documentation)
- **Relationship mapping**: Creates relationships between consecutive entities

---

## 4. `intelligence.git_analyze`

**Purpose**: AI-powered analysis of git changes using GRID's intelligence module. Analyzes staged/unstaged changes, estimates complexity, and suggests actions.

### Capabilities

- Analyzes git changes (staged or unstaged)
- Estimates task complexity (1-10 scale)
- Suggests appropriate LLM model (ministral/gpt-oss-safeguard)
- Assesses risk level (low/medium/high)
- Provides change summary and suggested actions
- Uses local Ollama for AI analysis

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.intelligence_git_analyze import intelligence_git_analyze
# registry.register(intelligence_git_analyze)
```

### Code Context

```29:79:src/grid/skills/intelligence_git_analyze.py
def _analyze_git(args: Mapping[str, Any]) -> Dict[str, Any]:
    """Analyze current git changes with AI."""
    verbose = args.get("verbose", False)

    if not _INTELLIGENCE_AVAILABLE:
        return {
            "skill": "intelligence.git_analyze",
            "status": "error",
            "error": "GitIntelligence module not available",
        }

    try:
        intel = GitIntelligence(verbose=verbose)

        # Check if Ollama is available
        if not intel.client.is_available():
            return {
                "skill": "intelligence.git_analyze",
                "status": "offline",
                "error": "Ollama not available",
                "message": "Install Ollama: curl https://ollama.ai/install.sh | sh",
            }

        # Run analysis
        result = intel.analyze()

        # Normalize output
        return {
            "skill": "intelligence.git_analyze",
            "status": result.get("status", "analyzed"),
            "complexity": result.get("complexity", 0),
            "model": result.get("model", "unknown"),
            "analysis": result.get("analysis", ""),
            "message": result.get("message", ""),
        }

    except Exception as e:
        return {
            "skill": "intelligence.git_analyze",
            "status": "error",
            "error": str(e),
        }
```

### GRID Integration

- Uses `scripts/git_intelligence.py` - GitIntelligence class
- Integrates with local Ollama for AI analysis
- Analyzes git changes in current repository
- Provides complexity estimation and risk assessment

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `verbose` | boolean | No | `false` | Enable verbose output |

### Usage Examples

#### Basic Analysis

```powershell
.\venv\Scripts\python.exe -m grid skills run intelligence.git_analyze --args-json "{verbose:true}"
```

**Output**:
```json
{
  "skill": "intelligence.git_analyze",
  "status": "analyzed",
  "complexity": 7,
  "model": "ministral",
  "analysis": "Multi-file refactoring affecting core services. Changes include API modifications, database schema updates, and test updates. Risk: Medium - requires careful review.",
  "message": "Suggested actions: Run full test suite, review API changes, update documentation"
}
```

#### Offline Mode (Ollama Not Available)

**Output**:
```json
{
  "skill": "intelligence.git_analyze",
  "status": "offline",
  "error": "Ollama not available",
  "message": "Install Ollama: curl https://ollama.ai/install.sh | sh"
}
```

### Dependencies

- **GitIntelligence**: `scripts/git_intelligence.py`
- **Ollama**: Local Ollama instance running
- **Git Repository**: Must be run from a git repository

### Error Handling

- Returns error if GitIntelligence module not available
- Returns offline status if Ollama not available
- Handles git analysis exceptions gracefully

### Performance Notes

- **Analysis time**: 2-5s (depends on change size and Ollama response time)
- **Complexity scale**: 1-10 (1=trivial, 10=very complex)
- **Risk levels**: low, medium, high
- **Model selection**: Automatically selects ministral or gpt-oss-safeguard based on complexity

---

## 5. `knowledge.capture`

**Purpose**: Transform task results, logs, and affected files into structured Knowledge artifacts used by GRID and Windsurf.

### Capabilities

- Transforms raw task results into structured Knowledge format
- Creates knowledge artifacts with file mappings
- Links to affected files and related artifacts
- Supports tags and categorization
- Integrates with GRID's Knowledge Studio

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.knowledge_capture import knowledge_capture
# registry.register(knowledge_capture)
```

### Code Context

```10:71:src/grid/skills/knowledge_capture.py
def _capture_knowledge(args: Mapping[str, Any]) -> Dict[str, Any]:
    """
    Skill: knowledge.capture

    Transforms raw task results, logs, and affected files into
    the structured Knowledge format used by GRID and Windsurf.
    """
    studio = KnowledgeStudio()

    task_id = args.get("task_id")
    if not task_id:
        return {
            "skill": "knowledge.capture",
            "status": "error",
            "error": "Missing required parameter: 'task_id'"
        }

    title = args.get("title", f"System Insight: {task_id}")
    summary = args.get("summary")
    files = args.get("affected_files", [])
    tags = args.get("tags", [])

    if not summary:
        # If no summary is provided, we can't create a quality knowledge entry
        return {
            "skill": "knowledge.capture",
            "status": "error",
            "error": "Missing required parameter: 'summary'. Use 'compress.articulate' first if needed."
        }

    try:
        artifact = studio.synthesize(
            task_id=task_id,
            title=title,
            summary_text=summary,
            affected_files=files,
            tags=tags
        )

        return {
            "skill": "knowledge.capture",
            "status": "success",
            "case_id": artifact.id,
            "title": artifact.title,
            "summary_preview": artifact.summary[:100] + "...",
            "links_count": len(artifact.links)
        }
    except Exception as e:
        logger.error(f"Error in knowledge.capture skill: {e}", exc_info=True)
        return {
            "skill": "knowledge.capture",
            "status": "error",
            "error": str(e)
        }
```

### GRID Integration

- Uses `grid.knowledge.studio.KnowledgeStudio`
- Creates structured Knowledge artifacts
- Links to affected files
- Integrates with GRID's knowledge graph

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `task_id` | string | Yes | - | Unique task identifier |
| `title` | string | No | `"System Insight: {task_id}"` | Knowledge artifact title |
| `summary` | string | Yes | - | Summary text (can use `compress.articulate` first) |
| `affected_files` | array | No | `[]` | List of affected file paths |
| `tags` | array | No | `[]` | Tags for categorization |

### Usage Examples

#### Basic Knowledge Capture

```powershell
.\venv\Scripts\python.exe -m grid skills run knowledge.capture --args-json "{task_id:'TASK-123', title:'Fixed NER service bug', summary:'Fixed entity extraction issue in NER service that was causing incorrect confidence scores.', affected_files:['src/application/mothership/ner_service.py'], tags:['bug-fix', 'ner']}"
```

**Output**:
```json
{
  "skill": "knowledge.capture",
  "status": "success",
  "case_id": "CASE-abc123",
  "title": "Fixed NER service bug",
  "summary_preview": "Fixed entity extraction issue in NER service that was causing incorrect confidence scores...",
  "links_count": 1
}
```

#### With Compressed Summary

First compress the summary, then capture:

```powershell
# Step 1: Compress summary
.\venv\Scripts\python.exe -m grid skills run compress.articulate --args-json "{text:'Fixed entity extraction issue in NER service that was causing incorrect confidence scores for named entities.', max_chars:200, use_llm:false}"

# Step 2: Capture knowledge (use compressed output)
.\venv\Scripts\python.exe -m grid skills run knowledge.capture --args-json "{task_id:'TASK-123', summary:'Fixed entity extraction issue in NER service.', affected_files:['src/application/mothership/ner_service.py']}"
```

### Dependencies

- **KnowledgeStudio**: `grid.knowledge.studio.KnowledgeStudio`
- **Knowledge Graph**: GRID's knowledge graph system

### Error Handling

- Returns error if task_id missing
- Returns error if summary missing (suggests using compress.articulate first)
- Handles KnowledgeStudio exceptions gracefully

### Performance Notes

- **Processing time**: 100-500ms (depends on file count and summary length)
- **Artifact creation**: Creates structured Knowledge entry with metadata
- **File linking**: Links to affected files for traceability

---

## 6. `youtube.transcript_analyze`

**Purpose**: Analyze transcript text (local-first) with keyword extraction and optional RAG enrichment. Useful for processing YouTube transcripts, meeting notes, or any transcript-style text.

### Capabilities

- Analyzes transcript text or file
- Extracts key statistics (chars, words, tokens)
- Identifies top keywords (stop-word filtered)
- Optional RAG enrichment for context
- Local-first processing (no external APIs)

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.youtube_transcript_analyze import youtube_transcript_analyze
# registry.register(youtube_transcript_analyze)
```

### Code Context

```67:114:src/grid/skills/youtube_transcript_analyze.py
def _analyze(args: Mapping[str, Any]) -> Dict[str, Any]:
    transcript = _read_transcript(args)
    tokens = _tokenize(transcript)

    counter = Counter(tokens)
    top_n = int(args.get("top_n", 15) or 15)

    result: Dict[str, Any] = {
        "skill": "youtube.transcript_analyze",
        "chars": len(transcript),
        "words": len(transcript.split()),
        "tokens": len(tokens),
        "top_keywords": [{"token": t, "count": c} for t, c in counter.most_common(top_n)],
    }

    use_rag = bool(args.get("use_rag") or args.get("useRag"))
    if use_rag:
        try:
            from tools.rag.config import RAGConfig
            from tools.rag.rag_engine import RAGEngine

            config = RAGConfig.from_env()
            config.ensure_local_only()
            engine = RAGEngine(config=config)

            focus = ", ".join([t for t, _ in counter.most_common(8)])
            q = (
                "Given this transcript keyword focus: "
                f"{focus}\n\n"
                "What existing GRID modules/features should be used next, and which exact file paths are relevant?"
            )
            rag = engine.query(query_text=q, top_k=8, temperature=0.2)
            result["rag"] = {
                "answer": rag.get("answer"),
                "sources": rag.get("sources", []),
            }
        except Exception as e:
            result["rag_error"] = str(e)

    return result
```

### GRID Integration

- Optional RAG enrichment using `tools/rag/rag_engine.py`
- Uses local Ollama for RAG queries
- Provides keyword-focused RAG queries

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `transcript` | string | No | - | Transcript text (or use `transcript_file`) |
| `transcript_file` | string | No | - | Path to transcript file (or use `transcript`) |
| `top_n` | integer | No | `15` | Number of top keywords to extract |
| `use_rag` | boolean | No | `false` | Enable RAG enrichment |

### Usage Examples

#### Basic Analysis

```powershell
.\venv\Scripts\python.exe -m grid skills run youtube.transcript_analyze --args-json "{transcript:'[00:00] StepBloom activates a structured execution model. [00:10] IF-THEN checkpoints validate progress. [00:20] The framework ensures correctness at each step.', top_n:5, use_rag:false}"
```

**Output**:
```json
{
  "skill": "youtube.transcript_analyze",
  "chars": 150,
  "words": 25,
  "tokens": 18,
  "top_keywords": [
    {"token": "stepbloom", "count": 1},
    {"token": "activates", "count": 1},
    {"token": "structured", "count": 1},
    {"token": "execution", "count": 1},
    {"token": "model", "count": 1}
  ]
}
```

#### With RAG Enrichment

```powershell
.\venv\Scripts\python.exe -m grid skills run youtube.transcript_analyze --args-json "{transcript:'[00:00] GRID framework provides geometric resonance intelligence. [00:10] Pattern engine uses regex matching. [00:20] RAG system enables local-first retrieval.', top_n:8, use_rag:true}"
```

**Output**:
```json
{
  "skill": "youtube.transcript_analyze",
  "chars": 120,
  "words": 20,
  "tokens": 15,
  "top_keywords": [
    {"token": "grid", "count": 1},
    {"token": "framework", "count": 1},
    {"token": "pattern", "count": 1},
    {"token": "engine", "count": 1},
    {"token": "rag", "count": 1},
    {"token": "system", "count": 1}
  ],
  "rag": {
    "answer": "Based on the transcript keywords, relevant GRID modules include: pattern engine (src/grid/patterns/), RAG system (tools/rag/), and framework core (src/grid/).",
    "sources": [
      {
        "path": "docs/architecture.md",
        "distance": 0.18
      },
      {
        "path": "src/grid/patterns/pattern_engine.py",
        "distance": 0.22
      }
    ]
  }
}
```

#### From File

```powershell
.\venv\Scripts\python.exe -m grid skills run youtube.transcript_analyze --args-json "{transcript_file:'transcript.txt', top_n:10, use_rag:false}"
```

### Dependencies

- **RAG Engine** (optional): `tools/rag/rag_engine.py` - Only if `use_rag=true`
- **Ollama** (optional): Local Ollama instance - Only if `use_rag=true`
- **No external services required** for basic analysis

### Error Handling

- Returns error if neither transcript nor transcript_file provided
- Handles file read errors gracefully
- RAG errors are included in output (non-fatal)

### Performance Notes

- **Basic analysis**: < 50ms (local tokenization and counting)
- **With RAG**: 500ms - 2s (includes RAG query time)
- **Keyword extraction**: Stop-word filtered, minimum 3 characters
- **Token counting**: Case-insensitive, alphanumeric tokens only

---

## Skills Registry

All skills are dynamically imported and registered in `src/grid/skills/registry.py`:

```24:62:src/grid/skills/registry.py
def _load_builtin_skills(registry: SkillRegistry) -> None:
    import importlib
    import logging
    import traceback

    logger = logging.getLogger(__name__)

    skills_to_load = [
        ("youtube_transcript_analyze", ".youtube_transcript_analyze"),
        ("intelligence_git_analyze", ".intelligence_git_analyze"),
        ("rag_query_knowledge", ".rag_query_knowledge"),
        ("patterns_detect_entities", ".patterns_detect_entities"),
        ("analysis_process_context", ".analysis_process_context"),
        ("cross_reference_explain", ".cross_reference_explain"),
        ("compress_articulate", ".compress_articulate"),
        ("context_refine", ".context_refine"),
        ("transform_schema_map", ".transform_schema_map"),
        ("topic_extractor", ".topic_extractor"),
        ("knowledge_capture", ".knowledge_capture"),
    ]

    for name, relative_path in skills_to_load:
        try:
            # Use importlib for cleaner dynamic relative imports
            module = importlib.import_module(relative_path, package="grid.skills")
            skill = getattr(module, name)
            registry.register(skill)
        except Exception as e:
            error_msg = f"Failed to load skill '{name}' from '{relative_path}': {type(e).__name__}: {e}"
            logger.error(error_msg)


default_registry = SkillRegistry()
_load_builtin_skills(default_registry)
```

### Project-Specific Skills Registration

The following project-specific skills are loaded from their respective modules:

| Skill ID | Module Path | Variable Name |
|----------|-------------|---------------|
| `rag.query_knowledge` | `grid.skills.rag_query_knowledge` | `rag_query_knowledge` |
| `patterns.detect_entities` | `grid.skills.patterns_detect_entities` | `patterns_detect_entities` |
| `analysis.process_context` | `grid.skills.analysis_process_context` | `analysis_process_context` |
| `intelligence.git_analyze` | `grid.skills.intelligence_git_analyze` | `intelligence_git_analyze` |
| `knowledge.capture` | `grid.skills.knowledge_capture` | `knowledge_capture` |
| `youtube.transcript_analyze` | `grid.skills.youtube_transcript_analyze` | `youtube_transcript_analyze` |

### Registry Usage

Skills are accessed through the default registry:

```python
from grid.skills.registry import default_registry

# List all skills
skills = default_registry.list()

# Get a specific skill
skill = default_registry.get("rag.query_knowledge")

# Run a skill
result = skill.run({"query": "What is GRID?"})
```

## CLI Integration

Skills are accessed through the CLI via the registry:

```163:178:src/grid/__main__.py
def skills_list_command(args: argparse.Namespace) -> int:
    from grid.skills.registry import default_registry

    payload = {
        "skills": [
            {
                "id": s.id,
                "name": s.name,
                "description": s.description,
            }
            for s in default_registry.list()
        ]
    }

    sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False))
    sys.stdout.write("\n")
    return 0
```

```181:195:src/grid/__main__.py
def skills_run_command(args: argparse.Namespace) -> int:
    from grid.skills.registry import default_registry

    skill = default_registry.get(args.skill_id)
    if skill is None:
        raise SystemExit(f"Unknown skill: {args.skill_id}")

    skill_args: Dict[str, Any] = {}
    if args.args_json or args.args_file:
        # ... parse args ...

    result = skill.run(skill_args)
    # ... output result ...
```

## Base Skill Protocol

All skills implement the `Skill` protocol defined in `src/grid/skills/base.py`:

```7:29:src/grid/skills/base.py
class Skill(Protocol):
    """Protocol defining the skill interface."""

    id: str
    name: str
    description: str
    version: str  # Semantic version for contract stability

    def run(self, args: Mapping[str, Any]) -> Dict[str, Any]: ...


@dataclass(frozen=True)
class SimpleSkill:
    """Simple skill implementation with handler function."""

    id: str
    name: str
    description: str
    handler: Any
    version: str = "1.0.0"  # Default version for backwards compatibility

    def run(self, args: Mapping[str, Any]) -> Dict[str, Any]:
        return self.handler(args)
```

## GRID Integration Points

### RAG System
- **Skills**: `rag.query_knowledge`, `youtube.transcript_analyze` (optional)
- **Location**: `tools/rag/`
- **Models**: `nomic-embed-text-v2-moe:latest` (embeddings), `ministral` or `gpt-oss-safeguard` (LLM)
- **Vector Store**: ChromaDB (`.rag_db/`)

### NER Service
- **Skills**: `patterns.detect_entities`, `analysis.process_context`
- **Location**: `application/mothership/ner_service.py`
- **Fallback**: Heuristic entity detection (always available)

### Knowledge Graph
- **Skills**: `knowledge.capture`
- **Location**: `grid/knowledge/studio.py`
- **Purpose**: Structured knowledge artifacts with file mappings

### Git Intelligence
- **Skills**: `intelligence.git_analyze`
- **Location**: `scripts/git_intelligence.py`
- **Purpose**: AI-powered git change analysis

## Performance Summary

| Skill | Processing Time | Dependencies | Use Case |
|-------|----------------|--------------|----------|
| `rag.query_knowledge` | 500ms-2s | RAG, Ollama | Knowledge retrieval |
| `patterns.detect_entities` | 100-500ms | NER (optional) | Entity extraction |
| `analysis.process_context` | 100-500ms | NER (optional) | Full text analysis |
| `intelligence.git_analyze` | 2-5s | Git, Ollama | Git change analysis |
| `knowledge.capture` | 100-500ms | Knowledge Studio | Knowledge artifact creation |
| `youtube.transcript_analyze` | < 50ms (basic), 500ms-2s (RAG) | RAG (optional) | Transcript analysis |

## Design Philosophy

Project-specific skills are designed to:
- **Leverage GRID infrastructure**: Integrate with RAG, NER, knowledge graph
- **Provide fallbacks**: Heuristic modes when services unavailable
- **Maintain local-first**: No external APIs, use local Ollama
- **Enable composability**: Can chain with global skills
- **Support traceability**: Link to files, artifacts, and knowledge entries
