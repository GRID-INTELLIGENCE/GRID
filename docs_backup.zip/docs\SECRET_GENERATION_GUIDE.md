# 🔐 SECRET GENERATION GUIDE - OWASP Compliant

**Priority:** 🔴 CRITICAL
**Purpose:** Generate secure secrets for GRID project following industry best practices

---

## 🚨 CRITICAL: Before Production Deployment

**The application will FAIL to start in production if secrets are missing or weak.**

---

## 📋 QUICK START

### Generate JWT Secret (Python)

```python
from application.mothership.security.secret_validation import generate_secure_secret

# Generate 64-character secure secret (recommended)
secret = generate_secure_secret(64)
print(f"MOTHERSHIP_SECRET_KEY={secret}")
```

### Generate JWT Secret (CLI)

```bash
# Using Python one-liner
python -c "from application.mothership.security.secret_validation import generate_secure_secret; print(generate_secure_secret(64))"
```

---

## 🔒 SECRET REQUIREMENTS

### Minimum Requirements (OWASP)
- **Length:** Minimum 32 characters
- **Entropy:** Character diversity ≥ 30%
- **Algorithm:** Cryptographically secure random (Python `secrets` module)

### Recommended (Production)
- **Length:** 64+ characters
- **Entropy:** Character diversity ≥ 50%
- **Patterns:** No weak patterns (password, secret, default, etc.)

---

## ✅ VALIDATION

### Validate Secret Strength

```python
from application.mothership.security.secret_validation import (
    validate_secret_strength,
    SecretValidationError,
)

try:
    strength = validate_secret_strength(my_secret, "production")
    print(f"Secret strength: {strength.value}")
except SecretValidationError as e:
    print(f"Validation failed: {e}")
```

### Test Secret (Before Deployment)

```bash
# Set secret
export MOTHERSHIP_SECRET_KEY="<your-generated-secret>"
export MOTHERSHIP_ENVIRONMENT=production

# Test validation
python -c "from application.mothership.security.secret_validation import validate_secret_strength; print(validate_secret_strength('$MOTHERSHIP_SECRET_KEY', 'production'))"
```

---

## 🚀 DEPLOYMENT CHECKLIST

### Before Production

- [ ] Generate secure secret (64+ characters)
- [ ] Validate secret strength
- [ ] Store secret in secure secret manager (AWS Secrets Manager, HashiCorp Vault, etc.)
- [ ] Set `MOTHERSHIP_SECRET_KEY` environment variable
- [ ] Verify application starts without warnings
- [ ] Test authentication endpoints

### Environment Variables

```bash
# Required for production
export MOTHERSHIP_SECRET_KEY="<64-character-secure-secret>"
export MOTHERSHIP_ENVIRONMENT=production

# Optional (for development)
export MOTHERSHIP_ENVIRONMENT=development  # Allows temporary secrets
```

---

## 🔧 TROUBLESHOOTING

### Error: "JWT secret key is required in production"

**Solution:** Set `MOTHERSHIP_SECRET_KEY` environment variable

```bash
export MOTHERSHIP_SECRET_KEY="<your-secure-secret>"
```

### Error: "Secret key is too weak for production"

**Solution:** Generate a stronger secret

```python
from application.mothership.security.secret_validation import generate_secure_secret
secret = generate_secure_secret(64)  # Use 64+ characters
```

### Warning: "Secret key is weak (development mode)"

**Action:** Fix before production. Generate secure secret and set environment variable.

---

## 📚 ADDITIONAL RESOURCES

- **OWASP Guidelines:** https://cheatsheetseries.owasp.org/cheatsheets/JWT_Cheat_Sheet.html
- **Python Secrets Module:** https://docs.python.org/3/library/secrets.html
- **Security Best Practices:** See `SECURITY_HARDENING_REPORT.md`

---

**Generated:** 2026-01-08
**Maintainer:** AI Assistant (Cascade)
