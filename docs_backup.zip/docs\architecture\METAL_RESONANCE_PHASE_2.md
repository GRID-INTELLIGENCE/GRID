# Metal Resonance Enhancement Plan - Iterative Implementation

**Phase**: 2.0
**Status**: Planned
**Created**: 2026-01-18
**Baseline Captured**: ✅ `tests/performance/earth_resonance_baseline.json`

---

## 🌍 Earth Resonance Baseline (Pre-Enhancement)

| Component | Avg (ms) | p50 (ms) | p95 (ms) | p99 (ms) |
|-----------|----------|----------|----------|----------|
| **ADSREnvelope** | 0.014 | 0.013 | 0.021 | 0.030 |
| **ContextProvider.assess_metrics** | 0.002 | 0.002 | 0.004 | 0.009 |
| **ContextProvider.provide_context** | 0.002 | 0.000 | 0.001 | 0.076 |
| **PathVisualizer.triage_paths** | 0.001 | 0.000 | 0.010 | 0.027 |

**Observation**: Core components are extremely fast (sub-millisecond). Performance is not the issue.

---

## 🔧 Critical Issue: Tight Coupling

### Problem Statement
The `application/__init__.py` imports `mothership` first, which triggers a configuration cascade requiring all 9+ settings to be present. This makes the resonance components **impossible to import** without the full Mothership context.

### Evidence
```
from application.resonance import ActivityResonance
  → triggers application/__init__.py
    → imports mothership
      → imports mothership/main.py
        → imports mothership/config/__init__.py
          → calls get_settings()
            → MothershipSettings.from_env()
              → TypeError: missing 9 required arguments
```

### Root Cause
- `application/__init__.py` line 11: `from .mothership import (...)`
- This is **eager** loading - imports happen at module load time
- No lazy loading or conditional imports

---

## 📋 Iterative Implementation Plan

### Sprint 0: Decoupling Foundation (CURRENT)
**Goal**: Make resonance components importable without Mothership

| Task | Status | Description |
|------|--------|-------------|
| 0.1 | ✅ | Create baseline capture script with direct loading |
| 0.2 | ✅ | Document coupling chain |
| 0.3 | 🔲 | Refactor `application/__init__.py` to use lazy imports |
| 0.4 | 🔲 | Add `resonance.standalone` module for isolated use |
| 0.5 | 🔲 | Verify standard imports work without Mothership |

### Sprint 1: Metal Structure Detection
**Goal**: Add detection for tightly-coupled, accelerated data patterns

| Task | Status | Description |
|------|--------|-------------|
| 1.1 | 🔲 | Define `CouplingMetrics` dataclass |
| 1.2 | 🔲 | Add `coupling_density` to ContextMetrics |
| 1.3 | 🔲 | Add `acceleration_factor` metric |
| 1.4 | 🔲 | Implement `_calculate_coupling_density()` |
| 1.5 | 🔲 | Unit tests for new metrics |

### Sprint 2: Stress Point Analysis
**Goal**: Identify and flag areas of high structural tension

| Task | Status | Description |
|------|--------|-------------|
| 2.1 | 🔲 | Add `StressPoint` dataclass |
| 2.2 | 🔲 | Implement stress detection in context provider |
| 2.3 | 🔲 | Add warning thresholds for import chains |
| 2.4 | 🔲 | Flag circular dependencies |
| 2.5 | 🔲 | Integration tests |

### Sprint 3: Visual Enhancement
**Goal**: Add metal sheen effects to visualization

| Task | Status | Description |
|------|--------|-------------|
| 3.1 | 🔲 | Define metal visual tokens (colors, icons) |
| 3.2 | 🔲 | Add `MetalSheenEffect` to PathOption |
| 3.3 | 🔲 | Implement heat map coloring for coupling density |
| 3.4 | 🔲 | Add sparkline indicators for stress points |
| 3.5 | 🔲 | Update CLI formatter for metal visuals |

### Sprint 4: Performance Guards
**Goal**: Prevent runaway analysis on deeply coupled structures

| Task | Status | Description |
|------|--------|-------------|
| 4.1 | 🔲 | Add `max_depth` parameter to analysis |
| 4.2 | 🔲 | Implement early exit on depth limit |
| 4.3 | 🔲 | Add momentum decay to prevent hangs |
| 4.4 | 🔲 | Memory cleanup after deep analysis |
| 4.5 | 🔲 | Benchmark comparison (pre/post) |

---

## 🔑 Sprint 0.3 Implementation Details

### Current `application/__init__.py` (Problematic)
```python
# Line 10-16: Eager imports
from .mothership import (
    CockpitService,
    MothershipSettings,
    create_app,
    get_settings,
)
```

### Proposed Fix: Lazy Imports
```python
# Lazy import pattern
_mothership = None

def get_mothership():
    global _mothership
    if _mothership is None:
        from .mothership import (
            CockpitService,
            MothershipSettings,
            create_app,
            get_settings,
        )
        _mothership = {
            "CockpitService": CockpitService,
            "MothershipSettings": MothershipSettings,
            "create_app": create_app,
            "get_settings": get_settings,
        }
    return _mothership
```

### Alternative: Import Order Fix
Move resonance imports BEFORE mothership:
```python
# Import resonance first (no external deps)
from .resonance import (
    ActivityResonance,
    ADSREnvelope,
    ContextProvider,
    PathVisualizer,
    ResonanceState,
)

# Import mothership last (has config deps)
try:
    from .mothership import (...)
except ImportError:
    pass  # Mothership optional
```

---

## 📊 Success Criteria

| Metric | Baseline | Target | Verification |
|--------|----------|--------|--------------|
| Resonance importable standalone | ❌ No | ✅ Yes | `from application.resonance import ActivityResonance` works |
| ADSR Envelope p99 | 0.030ms | < 0.050ms | Benchmark comparison |
| Context Provider p99 | 0.076ms | < 0.100ms | Benchmark comparison |
| Test coverage | TBD | ≥80% | pytest --cov |
| Metal metrics added | 0 | 3+ | `coupling_density`, `acceleration_factor`, `stress_score` |

---

## 🚀 Next Action

**Recommended**: Proceed with Sprint 0.3 - Refactor `application/__init__.py` to fix the import order.

Shall I implement this fix now?
