"""
Databricks SDK Integration - GRID Architectural Analysis

This document explains how the Databricks integration fits logically into GRID's layered
architecture, runtime systems, and workflow orchestration.
"""

# GRID Architecture Overview

GRID follows a **layered, domain-driven architecture** with clear separation of concerns:

```
┌─────────────────────────────────────────────────────────────┐
│           Entry Points Layer (CLI, API, Service)            │
│         (grid-api, grid-cli, grid-service, CLI tools)       │
├─────────────────────────────────────────────────────────────┤
│              Application Layer (FastAPI Apps)               │
│      (mothership, resonance, skills, agentic services)      │
├─────────────────────────────────────────────────────────────┤
│      Service & Orchestration Layer (Business Logic)         │
│    (skills, context, workflow, agentic, rag, pattern)       │
├─────────────────────────────────────────────────────────────┤
│       Core Intelligence Layer (grid/ - Essence)             │
│   (patterns, awareness, evolution, interfaces, skills)      │
├─────────────────────────────────────────────────────────────┤
│  Infrastructure Layer (Database, Cache, Vector Store, ...)  │
│  (SQLAlchemy ORM, Redis, ChromaDB, Ollama, **Databricks**)  │
├─────────────────────────────────────────────────────────────┤
│               Cognitive Layer (Decision Support)            │
│  (light_of_the_seven/cognitive_layer/ - mental models)      │
└─────────────────────────────────────────────────────────────┘
```

---

## Databricks Integration Placement

### **Primary Layer: Infrastructure (External Compute)**

The Databricks SDK integration resides in the **Infrastructure Layer** as an external compute
connector, similar to how Redis, PostgreSQL, and ChromaDB are integrated.

**Location**: `src/integration/databricks/`

**Components**:

- `client.py` - DatabricksClient (auth, workspace connection)
- `jobs.py` - DatabricksJobsManager (job orchestration)
- `clusters.py` - DatabricksClustersManager (cluster lifecycle)
- `notebooks.py` - DatabricksNotebooksManager (notebook operations)
- `cli.py` - CLI entry point for Databricks operations

### **Secondary Layer: Service & Orchestration**

Databricks is used by services that need **distributed compute** for:

1. **Data processing workflows** - Large-scale data transformations
2. **ML pipeline orchestration** - Training, inference at scale
3. **Async job execution** - Long-running background tasks
4. **Analytics & reporting** - Complex SQL queries on data lakes

---

## How Databricks Fits the GRID Runtime

### 1. **Active Runtime Pattern**

GRID's runtime consists of:

- **Local runtime**: Single-process Python execution (development, small tasks)
- **Distributed runtime**: Databricks for large-scale compute (production workloads)

```
Local Context (GRID core)
    ↓
Service Layer Decision (is this > X GB data? > Y seconds?)
    ↓
Route to Databricks via DatabricksClient if distributed execution needed
    ↓
Submit Job → Monitor Run Status → Retrieve Results
    ↓
Return to service layer with results
```

### 2. **Workflow Integration**

The `grid.workflow` module can orchestrate Databricks jobs:

```python
from src.grid.workflow import WorkflowOrchestrator
from src.integration.databricks import DatabricksJobsManager

# Workflow submits job to Databricks
orchestrator = WorkflowOrchestrator()
jobs_manager = DatabricksJobsManager(client)

job_id = jobs_manager.create_notebook_job(
    job_name="grid-data-processing",
    notebook_path="/Repos/grid/data_processing.ipynb",
    cluster_id="cluster-1"
)
run_id = jobs_manager.run_job(job_id)

# Monitor and sync results back
status = jobs_manager.get_run_status(run_id)
```

### 3. **Agentic System Integration**

GRID's agentic layer (`grid.agentic`) can delegate heavy computation to Databricks:

```python
from src.grid.agentic.agent import Agent
from src.integration.databricks import DatabricksClient

class DataProcessingAgent(Agent):
    def __init__(self, client: DatabricksClient):
        self.databricks = DatabricksClient()

    async def process_large_dataset(self, path: str):
        """Delegate to Databricks for distributed processing."""
        # 1. Create Databricks job
        # 2. Run it with parameters (path, etc.)
        # 3. Monitor completion
        # 4. Fetch results to local context
        # 5. Continue with local inference/reasoning
```

---

## Integration Points with GRID Routines

### **Routine 1: Skill Execution with Databricks Backend**

Skills can use Databricks for compute-intensive transformations:

```python
# src/grid/skills/
class DistributedDataSkill(Skill):
    """Skill that uses Databricks for heavy lifting."""

    def run(self, args: Mapping[str, Any]) -> Dict[str, Any]:
        # Local preprocessing
        preprocessed = self.preprocess(args)

        # Submit to Databricks for parallel processing
        jobs_manager = DatabricksJobsManager(self.databricks_client)
        job_id = jobs_manager.create_notebook_job(
            job_name=f"skill-{self.name}",
            notebook_path=f"/Repos/grid/skills/{self.name}.ipynb",
            base_parameters={"data": preprocessed}
        )

        # Monitor and collect results
        run_id = jobs_manager.run_job(job_id)
        results = self.wait_for_results(run_id)

        # Local post-processing
        return self.postprocess(results)
```

### **Routine 2: RAG Context Preparation at Scale**

Large document indexing can leverage Databricks:

```python
# Databricks notebook for parallel document chunking
from src.tools.rag.rag_engine import RAGEngine

def index_documents_at_scale(documents: list[str], chunk_size: int):
    """Chunked in parallel on Databricks, results merged locally."""
    # Parallel processing on Databricks
    chunked = spark.parallelize(documents).map(chunk_fn).collect()
    # Sync back to local ChromaDB
    rag_engine.index_chunks(chunked)
```

### **Routine 3: Workflow Checkpointing**

Jobs can checkpoint to Databricks and resume:

```python
class ResumeableWorkflow:
    def execute_with_checkpoint(self):
        # Step 1: Local processing
        context = self.prepare_context()

        # Step 2: Submit to Databricks with checkpoint
        job_id = self.submit_to_databricks(context)

        # Step 3: Resume if interrupted
        if job_exists(job_id):
            result = self.monitor_and_resume(job_id)
        else:
            result = self.rerun(context)
```

---

## Authentication Strategy

### **Environment Variable Priority**

The Databricks client supports flexible authentication:

```
Priority Order:
1. Explicit parameters: host, token
2. Environment variables: DATABRICKS_HOST, DATABRICKS_TOKEN
3. Databricks CLI profile: configured via `databricks configure`
```

### **Supporting 'databricks' Environment Variable**

For your use case (API key in 'databricks' env var), we can extend authentication:

```python
# Enhanced client.py to support 'databricks' env var
def __init__(self, host: str | None = None, token: str | None = None, ...):
    # ...existing code...

    # Add support for generic 'databricks' env var
    if not token and os.getenv("databricks"):
        self.token = os.getenv("databricks")
        logger.info("Using 'databricks' environment variable for token")
```

---

## Testing & Validation

### **Unit Tests** (Located in `tests/unit/test_databricks_integration.py`)

✅ **22 tests covering**:

- Client authentication (env vars, explicit args, profiles)
- Connection verification
- Cluster operations (list, get, start, stop)
- Job management (create, run, status)
- Notebook operations (read, write, list)
- Architecture alignment (dependency injection, statelessness)

### **Test Patterns**

```python
# Mock the WorkspaceClient to test without Databricks credentials
with patch("src.integration.databricks.client.WorkspaceClient") as mock_ws:
    client = DatabricksClient()
    # Test without hitting actual Databricks API
```

---

## Design Patterns Used

### **1. Dependency Injection**

```python
# Service receives client via constructor (testable, loose coupling)
class DatabricksJobsManager:
    def __init__(self, client: DatabricksClient):
        self.client = client
```

### **2. Facade Pattern**

DatabricksClient wraps the raw WorkspaceClient with GRID-specific logic:

- Connection verification
- Logging
- Error handling
- Environment variable handling

### **3. Manager Pattern**

Separate managers for different domains:

- `DatabricksJobsManager` - Job orchestration
- `DatabricksClustersManager` - Cluster lifecycle
- `DatabricksNotebooksManager` - Notebook operations

### **4. Stateless Compute**

Each manager instance is stateless:

- No mutable state beyond the client reference
- Same instance can handle multiple concurrent operations
- Follows GRID's architecture principle

---

## Performance Implications

### **Latency**

- **Local**: ~1-10ms (single process)
- **Databricks**: ~100ms-10s (job submission + cluster startup + execution)
- **Decision point**: Use local for <10GB data, Databricks for >100GB

### **Throughput**

- **Local**: Limited by single machine (8-64 cores)
- **Databricks**: Scales to 1000+ cores (via cluster scaling)

### **Cost**

- **Local**: Only server costs
- **Databricks**: Per-DBU (Databricks Unit) billing
  - Notebook jobs: ~0.4 DBU/hour
  - Production clusters: ~0.3-1 DBU/hour per worker

---

## Integration Checklist

- [x] DatabricksClient created with flexible auth
- [x] Job, Cluster, Notebook managers implemented
- [x] CLI entry point added (`databricks-cli` command)
- [x] 22 comprehensive unit tests
- [x] Example script provided
- [x] Environment variable support (DATABRICKS_HOST, DATABRICKS_TOKEN)
- [ ] Support for 'databricks' env var (user's requirement)
- [ ] Integration with grid.skills registry
- [ ] Integration with grid.workflow orchestration
- [ ] Integration with grid.agentic delegation
- [ ] Production error handling & retries
- [ ] Monitoring & observability
- [ ] Cost tracking

---

## Next Steps

1. **Extend auth to support 'databricks' env var** - Modify `client.py`
2. **Create a Databricks-backed skill** - Example in `src/grid/skills/`
3. **Integrate with workflow system** - Update `src/grid/workflow/`
4. **Add monitoring** - Integrate with observability layer
5. **Production hardening** - Retry logic, timeout handling

---

## References

- **GRID Architecture**: `docs/ARCHITECTURE.md`
- **Skills System**: `docs/SKILLS_RAG_QUICKSTART.md`
- **Workflow System**: `src/grid/workflow/`
- **Databricks Documentation**: https://docs.databricks.com/
- **Databricks SDK**: https://github.com/databricks/databricks-sdk-py
