# Code of Conduct

This project expects respectful, constructive collaboration.

## Our standards

- Be respectful and inclusive.
- Assume good intent; ask clarifying questions.
- Provide actionable feedback.

## Enforcement

If an issue arises, open a GitHub issue (or contact the maintainers privately if appropriate).
