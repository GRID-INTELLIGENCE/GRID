# GRID Module Spec Template: Path Normalization (Windows)

> **Purpose:** reusable template for any module/directory to enforce Windows‑safe path handling, normalization, and routing.

## 1) Module Metadata
- **Module name:** `<name>`
- **Root path (absolute):** `E:\grid\<module>`
- **Owner:** `<team/person>`
- **Primary runtime:** `<python/node/etc>`
- **OS targets:** `Windows` (primary), `WSL` (optional)

## 2) Path Normalization Rules (Windows)
Based on Microsoft documentation:
- Windows normalizes paths by **canonicalizing separators**, **applying current directory** to relative paths, **evaluating `.` and `..`**, and **trimming trailing spaces/periods**.
  Source: https://learn.microsoft.com/en-us/dotnet/standard/io/file-path-formats
- **Relative paths are risky in multithreaded apps** (current directory is process‑wide). Resolve against a known base.
  Source: https://learn.microsoft.com/en-us/dotnet/standard/io/file-path-formats
- Long paths require **opt‑in**: set `LongPathsEnabled=1` and ensure apps are long‑path‑aware.
  Source: https://learn.microsoft.com/en-us/windows/win32/fileio/maximum-file-path-limitation
- Normalization background: https://learn.microsoft.com/en-us/archive/blogs/jeremykuhne/path-normalization

### Required conventions
- **Always store/emit absolute paths** in configs and scripts.
- **Windows separator:** use `\` for paths intended for Windows tooling.
- **Avoid trailing spaces/periods** in names.
- **Avoid drive‑relative paths** like `D:folder` (ambiguous).
- **Do not rely on CWD** in any threaded process; resolve against explicit base.

## 3) Examples
**Normalize relative path → absolute**
```powershell
# Good
$Root = "E:\grid\module"
$Full = [System.IO.Path]::GetFullPath(".\data\file.json", $Root)
```

**Avoid drive‑relative**
```
# Bad
D:logs\run.txt

# Good
D:\logs\run.txt
```

**Handle UNC/device paths**
```
# UNC
\\server\share\path\file.txt

# Device
\\?\C:\long\path\file.txt
```

## 4) Module‑specific routing rules
- **Base path:** `E:\grid\<module>`
- **Config path:** `E:\grid\<module>\config`
- **Data path:** `E:\grid\<module>\data`
- **Logs path:** `E:\grid\<module>\logs`

> Replace these with actual module paths and keep them absolute.

## 5) Audit Checklist (per module)
- [ ] All paths resolved against explicit base
- [ ] No `D:folder` drive‑relative usage
- [ ] No trailing spaces/periods in file/dir names
- [ ] No path lengths > 260 unless long‑paths enabled
- [ ] No relative paths in multithreaded sections

## 6) Optional: Long path enablement (Admin PowerShell)
```powershell
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -Value 1 -PropertyType DWORD -Force
```

---
**Usage:** Copy this file into any module directory and fill in sections 1, 4, and 5.
