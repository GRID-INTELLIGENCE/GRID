# GRID-MCP Integration Guide

## Overview
The GRID system is now deeply integrated with the Model Context Protocol (MCP). This allows AI agents to interact with GRID's knowledge base, skill store, and diagnostic tools directly through the MCP interface.

## 🌉 Connection Architecture
- **MCP Server**: Located at `E:\grid\mcp-setup\server\mcp_server.py`.
- **Logic Modules**: `grid_knowledge.py` (fetching data) and `grid_integration.py` (execution and compliance).

## 🛠️ GRID-Specific Tools
| Tool | Description |
| :--- | :--- |
| `grid_health_check` | Runs the full environment diagnostic script. |
| `grid_query_knowledge` | Keyword search across skills, docs, and knowledge entries. |
| `grid_analyze_code` | Checks code against the **Mastication Protocol** (Stickiness standards). |
| `grid_check_feature` | Provides the mandated implementation checklist for new features. |
| `grid_get_architecture` | Returns a summary of the Sovereign Tier layers. |

## 📦 GRID Resources
Access GRID resources using these URI schemes:
- `grid://skill/{name}`: Contents of a skill's `SKILL.md`.
- `grid://knowledge/{entry}`: Metadata from the global Antigravity knowledge base.
- `grid://health`: Real-time diagnostic output from the health check.

## 📝 Integrated Prompts
- **`grid_development_prompt`**: Injects the Mastication Layer requirements into the task context.
- **`grid_feature_implementation_prompt`**: Orchestrates a feature build following Sovereign Tier standards.

## 🧪 Compliance Checklist (Mastication Protocol)
When writing code for GRID, ensure:
1. **Flavor Density**: Deep context awareness (checked via `grid_query_knowledge`).
2. **Stickiness**: 
   - Python 3.13.11 parity.
   - 100% type hints (with `TypeIs`/`ReadOnly`).
   - Google-style docstrings.
   - 120 char line limit.
3. **Safety**: No hardcoded secrets; use `SecretManager`.
