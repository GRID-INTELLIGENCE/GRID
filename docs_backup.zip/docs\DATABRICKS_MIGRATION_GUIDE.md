# Databricks Migration Guide

## Overview

This guide walks you through migrating your GRID database from SQLite to Databricks.

## Prerequisites

1. **Databricks Workspace Access**
   - Active Databricks workspace
   - SQL Warehouse running
   - Access token with appropriate permissions

2. **Environment Variables Set**
   - `DATABRICKS_SERVER_HOSTNAME` - Your Databricks workspace hostname
   - `DATABRICKS_HTTP_PATH` - SQL warehouse HTTP path
   - `DATABRICKS_ACCESS_TOKEN` - Personal access token

3. **Network Connectivity**
   - Access to Databricks workspace (may require VPN)
   - Port 443 open for HTTPS connections

4. **Dependencies Installed**
   ```bash
   pip install databricks-sql-connector
   ```

## Migration Steps

### Step 1: Verify Environment Variables

Check that your environment variables are set:

```bash
# Windows PowerShell
$env:DATABRICKS_SERVER_HOSTNAME
$env:DATABRICKS_HTTP_PATH
$env:DATABRICKS_ACCESS_TOKEN
```

### Step 2: Test Databricks Connection

```bash
python -c "from application.mothership.db.databricks_connector import validate_databricks_connection; print('SUCCESS' if validate_databricks_connection() else 'FAILED')"
```

**If connection fails:**
- Check network connectivity (may need VPN)
- Verify Databricks warehouse is running
- Confirm environment variables are correct
- Check firewall/proxy settings

### Step 3: Run Migration

**Option A: Full Migration (with SQLite data)**
```bash
python scripts/migrate_databricks_simple.py
```

**Option B: Fresh Database (no SQLite data)**
If you don't have existing SQLite data, the script will create tables in Databricks only.

### Step 4: Verify Migration

After migration completes:
1. Check Databricks workspace for tables
2. Verify row counts match
3. Test application with Databricks

### Step 5: Update Configuration

Set environment variable to use Databricks:
```bash
# Windows PowerShell
$env:USE_DATABRICKS = "true"
```

Or add to your `.env` file:
```env
USE_DATABRICKS=true
```

### Step 6: Cleanup Old Database

**After verifying migration is successful:**

```bash
python scripts/cleanup_old_database.py
```

This will:
- Find all SQLite database files
- Create backups (.backup extension)
- Delete original files
- Report cleanup statistics

## Troubleshooting

### Connection Issues

**DNS Resolution Failure:**
- Check network connectivity
- Verify hostname is correct
- May require VPN connection

**Authentication Failure:**
- Verify access token is valid
- Check token hasn't expired
- Ensure token has SQL warehouse permissions

**Warehouse Not Running:**
- Start SQL warehouse in Databricks workspace
- Wait for warehouse to be ready

### Migration Issues

**Table Creation Fails:**
- Check Databricks permissions
- Verify warehouse has CREATE TABLE permission
- Review error messages for specific issues

**Data Migration Fails:**
- Check data types compatibility
- Review error logs for specific rows
- May need manual data type conversion

## Post-Migration

### Configuration Updates

1. **Environment Variables:**
   - Set `USE_DATABRICKS=true`
   - Remove or comment out SQLite database URL

2. **Application Restart:**
   - Restart application to use new database
   - Verify all operations work correctly

3. **Monitoring:**
   - Monitor Databricks warehouse usage
   - Check query performance
   - Review connection pooling

## Rollback Plan

If migration fails or issues occur:

1. **Restore from Backup:**
   - SQLite backups have `.backup` extension
   - Restore: `copy mothership.db.backup mothership.db`

2. **Revert Configuration:**
   - Set `USE_DATABRICKS=false`
   - Restore original database URL

3. **Verify Application:**
   - Test with SQLite database
   - Ensure all functionality works

## Files Created

- `application/mothership/db/databricks_connector.py` - Databricks connector
- `scripts/migrate_databricks_simple.py` - Migration script
- `scripts/cleanup_old_database.py` - Cleanup script
- `docs/DATABRICKS_MIGRATION_GUIDE.md` - This guide

## Next Steps

After successful migration:
1. Continue with Phase 1 remaining components
2. Test embedded agentic knowledge system
3. Proceed with dynamic knowledge base implementation
