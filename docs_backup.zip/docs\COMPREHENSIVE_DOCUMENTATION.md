# GRID Comprehensive Documentation

## Table of Contents

1. [Overview](#overview)
2. [Quick Start](#quick-start)
3. [Development Setup](#development-setup)
4. [Architecture](#architecture)
5. [Core Components](#core-components)
6. [API Documentation](#api-documentation)
7. [CLI Reference](#cli-reference)
8. [Security Configuration](#security-configuration)
9. [Testing](#testing)
10. [Deployment](#deployment)
11. [Troubleshooting](#troubleshooting)
12. [Contributing](#contributing)

---

## Overview

GRID (Geometric Resonance Intelligence Driver) is a framework for exploring complex systems through geometric resonance patterns, cognitive decision support, and local-first AI.

### Key Features
- **Entity Recognition:** Advanced NER with rule-based and ML-based extraction
- **Security Hardening:** Production-ready safety controls and secrets management
- **Modular Architecture:** Extensible skill system and plugin architecture
- **Local-First Design:** Privacy-focused with optional cloud integration
- **Virtual Environment:** Unified uv-managed environment strategy

---

## Quick Start

### Prerequisites
- Python 3.13+
- uv (Python package manager)
- Git

### Installation

```bash
# Clone the repository
git clone <repository-url>
cd grid

# Install dependencies
uv sync --all-extras

# Verify installation
uv run python -m grid analyze "OpenAI and NVIDIA are working in London." --output table
```

### First Run
```bash
# Test entity extraction
uv run python -m grid analyze "Apple Inc. is located in Cupertino, California." --output json

# Test skills system
uv run python -m grid skills list

# Test security configuration
uv run python -c "from grid.security import get_security_status; print(get_security_status())"
```

---

## Development Setup

### Environment Configuration

#### 1. Virtual Environment
```bash
# Unified root environment strategy
uv sync --all-extras

# Development dependencies
uv run --group dev ruff check grid/
uv run --group dev mypy grid/

# Test dependencies
uv run --group test pytest tests/
```

#### 2. Environment Variables
```bash
# Development configuration
cp .env.development .env

# Production configuration
cp .env.production .env

# Set environment
export GRID_ENV=development
```

#### 3. IDE Configuration
- **VS Code:** Use `grid.code-workspace`
- **Python Interpreter:** `.venv/bin/python`
- **Linting:** Ruff with configuration in `pyproject.toml`

### Code Quality Tools

#### Linting and Formatting
```bash
# Check code quality
uv run --group dev ruff check grid/

# Auto-fix issues
uv run --group dev ruff check grid/ --fix

# Format code
uv run --group dev black grid/
uv run --group dev isort grid/
```

#### Type Checking
```bash
# Run type checker
uv run --group dev mypy grid/

# Check specific module
uv run --group dev mypy grid/safety/
```

---

## Architecture

### System Overview
```
┌─────────────────────────────────────────────────────────────┐
│                    GRID Architecture                        │
├─────────────────────────────────────────────────────────────┤
│  CLI Layer                                                  │
│  ├── Command Parser                                        │
│  ├── Safety Guardrails                                      │
│  └── Output Formatting                                      │
├─────────────────────────────────────────────────────────────┤
│  Core Intelligence                                           │
│  ├── Entity Recognition (NER)                               │
│  ├── Relationship Extraction                                 │
│  ├── Skills System                                          │
│  └── Pattern Matching                                       │
├─────────────────────────────────────────────────────────────┤
│  Security Layer                                             │
│  ├── Production Security Manager                             │
│  ├── Secrets Management                                      │
│  ├── Environment Validation                                   │
│  └── Audit Logging                                           │
├─────────────────────────────────────────────────────────────┤
│  Data Layer                                                 │
│  ├── Configuration Store                                     │
│  ├── Cache Layer                                             │
│  └── Persistence                                              │
└─────────────────────────────────────────────────────────────┘
```

### Module Structure
```
grid/
├── __main__.py              # CLI entry point
├── safety/                  # Security and guardrails
│   ├── guardrails.py        # Command validation
│   ├── config.py           # Configuration management
│   └── production.py       # Production security
├── security/               # Advanced security features
│   ├── production.py       # Security manager
│   ├── secrets.py          # Secrets management
│   └── templates.py        # Deployment configs
├── intelligence/           # Core AI components
│   ├── influence.py        # Entity influence calculation
│   └── patterns/           # Pattern matching
├── skills/                 # Skill system
│   ├── base.py            # Base skill classes
│   └── registry.py        # Skill registry
├── prompts/                # Prompt management
├── organization/          # Multi-org support
├── tracing/               # Action tracing
└── senses/                # Sensory input processing
```

---

## Core Components

### 1. Entity Recognition (NER)

#### Rule-Based NER
```python
from grid.skills.patterns_detect_entities import _detect_entities

# Basic entity detection
result = _detect_entities({
    "text": "Apple Inc. is in Cupertino",
    "entity_types": ["ORG", "LOCATION"]
})
```

#### Advanced NER Service
```python
from circuits.services.ner_api.api import extract_entities

# Production NER
entities = extract_entities(
    text="OpenAI and NVIDIA collaborate in San Francisco",
    entity_types=["ORG", "LOCATION", "MONEY", "VERSION"]
)
```

### 2. Skills System

#### Creating a Custom Skill
```python
from grid.skills.base import SimpleSkill

skill = Skill(
    skill_id="my_custom_skill",
    name="My Custom Skill",
    description="Custom skill for specific task",
    handler=my_handler_function,
    entity_influence={
        "required_entities": ["ORG"],
        "optional_entities": ["LOCATION"],
        "confidence_threshold": 0.7
    }
)
```

#### Skill Registry
```python
from grid.skills.registry import SkillRegistry

registry = SkillRegistry()
registry.register_skill(skill)
selected_skill = registry.select_skill_with_entity_influence(entities)
```

### 3. Security System

#### Production Security Manager
```python
from grid.security.production import security_manager

# Validate environment
validation = security_manager.validate_environment()

# Check command authorization
allowed, reason = security_manager.is_command_allowed("analyze")

# Get security status
status = security_manager.get_environment_config()
```

#### Secrets Management
```python
from grid.security.secrets import get_api_key

# Secure API key retrieval
openai_key = await get_api_key("openai")
gemini_key = await get_api_key("gemini")
```

---

## API Documentation

### REST API Endpoints

#### Entity Extraction
```http
POST /api/v1/extract
Content-Type: application/json

{
    "text": "Apple Inc. is located in Cupertino, California.",
    "entity_types": ["ORG", "LOCATION"],
    "confidence_threshold": 0.7
}
```

#### Skills Management
```http
GET /api/v1/skills
POST /api/v1/skills/{skill_id}/execute
PUT /api/v1/skills/{skill_id}
DELETE /api/v1/skills/{skill_id}
```

#### Health Check
```http
GET /api/v1/health
GET /api/v1/health/live
GET /api/v1/health/ready
```

### WebSocket API

#### Real-time Entity Processing
```javascript
const ws = new WebSocket('ws://localhost:8000/ws/entities');

ws.send(JSON.stringify({
    "type": "extract_entities",
    "text": "Real-time entity extraction",
    "entity_types": ["ORG", "PERSON"]
}));
```

---

## CLI Reference

### Basic Commands

#### Analyze Text
```bash
# Basic analysis
uv run python -m grid analyze "Your text here"

# Output formats
uv run python -m grid analyze "Text" --output table
uv run python -m grid analyze "Text" --output json
uv run python -m grid analyze "Text" --output yaml

# Advanced options
uv run python -m grid analyze "Text" \
    --confidence 0.8 \
    --max-entities 10 \
    --use-rag
```

#### Skills Management
```bash
# List available skills
uv run python -m grid skills list

# Execute specific skill
uv run python -m grid skills execute rag.query_knowledge \
    --query "machine learning basics"

# Register new skill
uv run python -m grid skills register my_skill.py
```

#### System Commands
```bash
# Health check
uv run python -m grid health

# Security status
uv run python -m grid security status

# Configuration
uv run python -m grid config show
uv run python -m grid config set GRID_ENV production
```

### Advanced Options

#### Environment Configuration
```bash
# Set environment
export GRID_ENV=production
export GRID_MIN_CONTRIBUTION=0.8
export GRID_COMMAND_DENYLIST="analyze,serve"

# Use secrets manager
export VAULT_ADDR=https://vault.example.com
export VAULT_TOKEN=your-token
```

#### Debug Mode
```bash
# Enable debug logging
uv run python -m grid analyze "Text" --debug

# Show timings
uv run python -m grid analyze "Text" --timings

# Verbose output
uv run python -m grid analyze "Text" --verbose
```

---

## Security Configuration

### Environment Variables

#### Development Environment
```bash
# .env.development
GRID_ENV=development
GRID_DEBUG=true
GRID_COMMAND_DENYLIST=""
GRID_MIN_CONTRIBUTION=0.0
GRID_CHECK_CONTRIBUTION=false
USE_SECRETS_MANAGER=false
```

#### Production Environment
```bash
# .env.production
GRID_ENV=production
GRID_DEBUG=false
GRID_COMMAND_DENYLIST=analyze,serve
GRID_MIN_CONTRIBUTION=0.8
GRID_CHECK_CONTRIBUTION=true
USE_SECRETS_MANAGER=true
VAULT_ADDR=https://vault.production.example.com
```

### Security Levels

#### Permissive (Development)
- No command blocking
- No contribution scoring
- Environment variables for secrets
- Full debugging enabled

#### Standard (Staging)
- Some commands blocked
- Moderate contribution threshold (0.6)
- Vault integration enabled
- Limited debugging

#### Restrictive (Production)
- Most commands blocked
- High contribution threshold (0.8)
- Vault required
- Minimal logging

### Secrets Management

#### Vault Integration
```python
from grid.security.secrets import initialize_secrets_manager

# Initialize with Vault
secrets_mgr = initialize_secrets_manager("production")

# Retrieve secrets
api_key = await secrets_mgr.get_api_key("openai")
```

#### Environment Fallback
```python
# Development uses environment variables
import os
api_key = os.getenv("OPENAI_API_KEY")
```

---

## Testing

### Test Structure
```
tests/
├── unit/                   # Unit tests
├── integration/           # Integration tests
├── api/                   # API tests
├── scratch/               # Experimental tests
└── e2e/                   # End-to-end tests
```

### Running Tests

#### All Tests
```bash
# Run full test suite
uv run pytest

# With coverage
uv run pytest --cov=grid --cov-report=html
```

#### Specific Test Categories
```bash
# Unit tests only
uv run pytest tests/unit/

# Integration tests
uv run pytest tests/integration/

# API tests
uv run pytest tests/api/
```

#### Individual Tests
```bash
# Specific test file
uv run pytest tests/unit/test_ner.py

# Specific test function
uv run pytest tests/unit/test_ner.py::test_entity_extraction
```

### Test Configuration

#### pytest.ini
```ini
[tool:pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = --verbose --tb=short
asyncio_mode = auto
```

### Writing Tests

#### Unit Test Example
```python
import pytest
from grid.intelligence.influence import EntityInfluenceCalculator

def test_entity_influence_calculation():
    calc = EntityInfluenceCalculator()
    entities = [
        MockEntity("OpenAI", "ORG", 0.9),
        MockEntity("San Francisco", "LOCATION", 0.8)
    ]

    score = calc.calculate_influence_score(
        entities,
        {"entity_influence": {"required_entities": ["ORG"]}}
    )

    assert score > 0.5
```

#### Integration Test Example
```python
import pytest
from grid.__main__ import analyze_command

def test_analyze_command_integration():
    args = MockArgs(
        text="OpenAI is in San Francisco",
        output="json",
        confidence=0.7,
        max_entities=10
    )

    result = analyze_command(args)
    assert result == 0
```

---

## Deployment

### Local Development

#### Quick Start
```bash
# Clone and setup
git clone <repo>
cd grid
uv sync --all-extras

# Run development server
uv run python -m grid serve --port 8000
```

```bash
# Build image

# Run container
```

### Production Deployment

```bash
# Use production configuration
cp .env.production .env

# Build production image

```

#### Kubernetes Deployment
```bash
# Generate manifests
uv run python -c "from grid.security import generate_deployment_configs; generate_deployment_configs()"

# Apply to cluster
kubectl apply -f k8s/

# Check deployment
kubectl get pods -l app=grid
```

### Environment Configuration

#### Production Checklist
- [ ] Environment variables configured
- [ ] Vault accessible and configured
- [ ] SSL certificates installed
- [ ] Resource limits set
- [ ] Monitoring enabled
- [ ] Backup strategy implemented

#### Security Hardening
- [ ] Firewall configured
- [ ] Access controls implemented
- [ ] Audit logging enabled
- [ ] Secrets rotated regularly
- [ ] Network policies applied

---

## Troubleshooting

### Common Issues

#### 1. Import Errors
```bash
# Problem: ModuleNotFoundError
# Solution: Ensure unified virtual environment
uv sync --all-extras
uv run python -c "import grid; print('OK')"
```

#### 2. Permission Errors
```bash
# Problem: Permission denied
# Solution: Check file permissions
chmod +x scripts/*.sh
# On Windows: run as Administrator
```

#### 3. Dependency Conflicts
```bash
# Problem: Dependency conflicts
# Solution: Clean and reinstall
uv cache clean
uv sync --refresh
```

#### 4. NER Service Issues
```bash
# Problem: Empty entity results
# Solution: Check NER service
uv run python -c "from circuits.services.ner_api.api import extract_entities; print(extract_entities('test', ['ORG']))"
```

### Debug Mode

#### Enable Debugging
```bash
# Set debug environment
export GRID_DEBUG=true

# Run with debug output
uv run python -m grid analyze "test" --debug --verbose
```

#### Log Analysis
```bash
# Check application logs
tail -f logs/grid.log

# Check security logs
tail -f logs/security.log
```

### Performance Issues

#### Memory Usage
```bash
# Monitor memory usage
uv run python -c "import psutil; print(psutil.virtual_memory())"

# Optimize for low memory
export GRID_CACHE_SIZE=100
export GRID_MAX_WORKERS=2
```

#### CPU Usage
```bash
# Monitor CPU
uv run python -c "import psutil; print(psutil.cpu_percent())"

# Optimize for low CPU
export GRID_MAX_WORKERS=1
export GRID_BATCH_SIZE=10
```

---

## Contributing

### Development Workflow

#### 1. Setup Development Environment
```bash
# Fork and clone
git clone <your-fork>
cd grid

# Setup development environment
uv sync --all-extras

# Create feature branch
git checkout -b feature/my-feature
```

#### 2. Make Changes
```bash
# Run tests
uv run pytest

# Check code quality
uv run --group dev ruff check grid/
uv run --group dev mypy grid/

# Format code
uv run --group dev black grid/
uv run --group dev isort grid/
```

#### 3. Submit Changes
```bash
# Commit changes
git add .
git commit -m "feat: add my new feature"

# Push to fork
git push origin feature/my-feature

# Create pull request
```

### Code Standards

#### Python Style
- Use Black for formatting
- Follow PEP 8 guidelines
- Use type hints where appropriate
- Document all public functions and classes

#### Testing Requirements
- Unit tests for all new features
- Integration tests for API changes
- Maintain >90% code coverage
- All tests must pass before merge

#### Documentation
- Update docstrings for new functions
- Add examples to CLI help
- Update README for breaking changes
- Document new configuration options

### Review Process

#### Pull Request Checklist
- [ ] Code follows style guidelines
- [ ] Tests pass for all changes
- [ ] Documentation is updated
- [ ] Security implications considered
- [ ] Performance impact assessed
- [ ] Breaking changes documented

#### Code Review Guidelines
- Focus on logic and security
- Suggest improvements, don't just point out issues
- Be constructive and respectful
- Test the changes before approving

---

## Additional Resources

### Documentation
- [API Reference](docs/api.md)
- [Architecture Guide](docs/architecture.md)
- [Security Guide](docs/security.md)
- [Deployment Guide](docs/deployment.md)

### Community
- [GitHub Issues](https://github.com/irfankabir02/grid/issues)
- [Discussions](https://github.com/irfankabir02/grid/discussions)
- [Wiki](https://github.com/irfankabir02/grid/wiki)

### Support
- [Bug Reports](https://github.com/irfankabir02/grid/issues/new?template=bug_report.md)
- [Feature Requests](https://github.com/irfankabir02/grid/issues/new?template=feature_request.md)
- [Security Issues](security@grid.com)

---

## Quick Reference

### Essential Commands
```bash
# Setup
uv sync --all-extras

# Test
uv run pytest

# Run CLI
uv run python -m grid analyze "text"

# Development
uv run --group dev ruff check grid/
uv run --group dev mypy grid/

# Production
uv run python -m grid serve --port 8000
```

### Key Files
- `pyproject.toml` - Dependencies and configuration
- `.env.production` - Production environment variables
- `grid/__main__.py` - CLI entry point
- `grid/safety/guardrails.py` - Security controls
- `grid/security/production.py` - Production security

### Environment Variables
- `GRID_ENV` - Environment (development/staging/production)
- `GRID_DEBUG` - Enable debug mode
- `GRID_MIN_CONTRIBUTION` - Command contribution threshold
- `VAULT_ADDR` - Vault server URL
- `VAULT_TOKEN` - Vault authentication token

---

*This documentation is maintained alongside the codebase. For the most up-to-date information, always check the latest version in the repository.*
