# GRID Git Configuration - Complete System

## Overview

GRID's tailored Git configuration system provides a comprehensive Git workflow with Unix-first defaults, topic branch management, commit message templates, and terminal profile enhancements.

## System Structure

### Configuration Files

All files located in: `config/git/`

1. **`grid_gitconfig`** (371 lines)
   - Main GRID Git configuration
   - Core settings (line endings, editor, branch defaults)
   - Merge/rebase configuration
   - Color and UI preferences
   - Core aliases and workflow commands

2. **`grid_gitconfig.defaults`** (87 lines)
   - Recommended defaults for all repositories
   - Minimal essential settings
   - Safe to include in every repository

3. **`grid_gitconfig.aliases`** (270+ lines)
   - Extended aliases for GRID workflow
   - Topic branch management aliases
   - Intelligence operation aliases
   - Utility aliases for common tasks

4. **`grid_gitconfig.hooks`** (31 lines)
   - Hook configuration (not hooks themselves)
   - Pre-commit and pre-push check configurations
   - Hook-related aliases

5. **`grid_git_commit_template`** (90+ lines)
   - Structured commit message template
   - Type conventions documentation
   - Format guidelines
   - Examples

6. **`grid_git_management.json`** (200+ lines)
   - Structured management settings
   - Branch defaults and patterns
   - Commit validation rules
   - Workflow definitions
   - Quality gates

### Terminal Profiles

7. **`terminal_profiles_powershell.ps1`** (350+ lines)
   - PowerShell profile with GRID Git functions
   - Enhanced Git commands
   - Prompt enhancements (optional)
   - Auto-completion

8. **`terminal_profiles_bash.sh`** (350+ lines)
   - Bash/Zsh profile with GRID Git functions
   - Enhanced Git commands
   - Prompt enhancements (optional)
   - Git branch completion

### Setup Scripts

9. **`setup.ps1`** (90+ lines)
   - PowerShell setup script
   - Copies configs to `~/.grid/git/`
   - Adds includes to global Git config
   - Sets up PowerShell profile

10. **`setup.sh`** (100+ lines)
    - Bash setup script
    - Copies configs to `~/.grid/git/`
    - Adds includes to global Git config
    - Sets up Bash/Zsh profile

11. **`scripts/setup_git_config.py`** (200+ lines)
    - Cross-platform Python setup script
    - Works on Windows, Linux, macOS
    - Auto-detects shell and configures appropriately

## Key Features

### 1. Unix-First Line Endings

**Configuration**:
```ini
[core]
	autocrlf = input    # Convert CRLF to LF on commit
	safecrlf = true     # Warn on irreversible conversions
	eol = lf            # Enforce LF line endings
```

**Result**: All files stored with LF endings in Git, regardless of OS

### 2. Topic Branch Convention

**Format**: `topic/{theme}-{description}-{issue_id}`

**Examples**:
- `topic/research-entity-clustering-123`
- `topic/infra-add-logging`
- `topic/security-encryption-refactor`

**Validation**: Regex pattern `^topic/[a-z0-9]+(?:-[a-z0-9]+)*(?:-\d+)?$`

**Workflow**:
```bash
# Create topic branch
git-tcreate research-entity-clustering 123

# Validate
git-topic-check
git-topic-clean

# Finish (merge and delete)
git checkout main
git merge topic/research-entity-clustering-123
git branch -d topic/research-entity-clustering-123
```

### 3. Commit Message Template

**Format**: `<type>(<scope>): <subject>`

**Types**:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Code style (no logic change)
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `test`: Tests
- `chore`: Maintenance
- `skill`: Skill-related
- `agentic`: Agentic system
- `rag`: RAG system
- `security`: Security-related

**Template Location**: `~/.grid/git/grid_git_commit_template`

**Auto-loaded**: Via `git config --global commit.template`

### 4. Management Settings Structure

**File**: `grid_git_management.json`

**Structure**:
- Branch defaults and naming patterns
- Commit validation rules
- Workflow definitions
- Quality gates
- Integration settings

**Usage**: Referenced by Git Manager for validation and enforcement

### 5. Terminal Profile Enhancements

**PowerShell Functions**:
- `git-grid` - Main GRID Git Manager
- `git-current-branch` - Current branch name
- `git-branch-info` - Detailed branch info
- `git-topic-check` - Validate topic branch
- `git-sync` - Fetch and rebase
- `git-repo-info` - Repository information
- `git-wip` - WIP commit
- `git-help-grid` - Show all commands

**Bash Functions**: Same as PowerShell, with Bash-specific enhancements

## Installation

### Automatic Setup

**Windows (PowerShell)**:
```powershell
cd e:\grid
python scripts\setup_git_config.py
```

**Unix/Linux/macOS (Bash)**:
```bash
cd /path/to/grid
python scripts/setup_git_config.py
```

### Manual Setup

1. **Copy configuration files**:
   ```bash
   mkdir -p ~/.grid/git
   cp config/git/grid_gitconfig ~/.grid/git/
   cp config/git/grid_gitconfig.aliases ~/.grid/git/
   cp config/git/grid_gitconfig.hooks ~/.grid/git/
   cp config/git/grid_git_commit_template ~/.grid/git/
   ```

2. **Include in global Git config**:
   ```bash
   git config --global include.path ~/.grid/git/grid_gitconfig
   git config --global commit.template ~/.grid/git/grid_git_commit_template
   ```

3. **Source terminal profile**:
   ```bash
   # Bash
   echo 'source ~/grid/config/git/terminal_profiles_bash.sh' >> ~/.bashrc
   source ~/.bashrc
   
   # PowerShell
   . $PSScriptRoot\config\git\terminal_profiles_powershell.ps1
   Add-Content $PROFILE ". `"$HOME\grid\config\git\terminal_profiles_powershell.ps1`""
   ```

## Verification

After setup, verify configuration:

```bash
# Check configuration
git config --global --list | grep grid

# Test GRID commands
git-grid status
git-topic-check
git-help-grid

# Check aliases
git config --global --get-regexp alias | grep grid
```

## Usage Examples

### Topic Branch Workflow

```bash
# Create topic branch
git-tcreate research-entity-clustering 123
# Creates: topic/research-entity-clustering-123

# Work on branch
git add .
git commit -m "feat(skills): Add entity clustering analysis"

# Validate before push
git-topic-check    # Must be on topic branch
git-topic-clean    # Must have clean working tree

# Push
git push origin topic/research-entity-clustering-123

# Merge and cleanup
git checkout main
git pull --rebase
git merge topic/research-entity-clustering-123
git branch -d topic/research-entity-clustering-123
git push origin --delete topic/research-entity-clustering-123
```

### Intelligence Operations

```bash
# Analyze git changes
git-analyze

# Get commit message suggestions
git-suggest

# Organize workspace
git-organize-intel
```

### Git Management

```bash
# Show GRID Git status
git-grid status

# Repair misconfigurations
git-repair

# Switch integration context
git-locomote platform_id

# Exercise platform contracts
git-exercise platform_id

# Git logic operations
git-logic reason    # Reason about branch state
git-logic mitigate  # Safeguard against risky states
git-logic prosper   # Identify growth opportunities

# Workspace organization
git-organize [--dry-run]
```

## Configuration Customization

### Local Overrides

Edit `~/.grid/git/grid_gitconfig.local` for personal preferences:

```ini
[user]
	name = Your Name
	email = your.email@example.com

[core]
	editor = nano  # Your preferred editor
```

This file is included but not tracked in Git.

### Repository-Specific Settings

For repository-specific settings, use local Git config:

```bash
git config --local user.name "Repository Name"
git config --local user.email "repo@example.com"
```

## Best Practices

1. **Use Topic Branches**: Always create topic branches for features/fixes
2. **Follow Naming Convention**: Use `topic/{theme}-{description}-{issue_id}` format
3. **Use Commit Template**: Follow commit message format
4. **Validate Before Push**: Use `git-topic-check` and `git-topic-clean`
5. **Keep Main Linear**: Use fast-forward only for main branch
6. **Rebase Topic Branches**: Rebase topic branches for clean history

## Troubleshooting

### Configuration Not Loading

1. Check include path: `git config --global --get-all include.path`
2. Verify file exists: `ls ~/.grid/git/grid_gitconfig`
3. Re-run setup: `python scripts/setup_git_config.py`

### Aliases Not Working

1. Restart terminal
2. Source profile: `. ~/.bashrc` or `. $PROFILE`
3. Check function: `type git-grid` or `which git-grid`

### Topic Branch Validation Failing

1. Ensure branch starts with `topic/`
2. Check format: `git-topic-check`
3. Review naming: See `git-help-grid`

## Integration with GRID

The Git configuration integrates with:

- **Git Manager** (`tools/scripts/git_manager.py`): Governance and management
- **Git Intelligence** (`tools/scripts/git_intelligence.py`): AI-powered analysis
- **Git Topic Utils** (`tools/scripts/git_topic_utils.py`): Branch name generation
- **Pattern Analyzer**: Code quality checks before commit

## File Locations

**Configuration Files**:
- Source: `config/git/*`
- Installed: `~/.grid/git/*`
- Global Git Config: Includes via `include.path`

**Terminal Profiles**:
- Source: `config/git/terminal_profiles_*.{ps1,sh}`
- User Profile: `~/.bashrc`, `~/.zshrc`, or `$PROFILE`

**Setup Scripts**:
- `config/git/setup.ps1` (PowerShell)
- `config/git/setup.sh` (Bash)
- `scripts/setup_git_config.py` (Cross-platform Python)
