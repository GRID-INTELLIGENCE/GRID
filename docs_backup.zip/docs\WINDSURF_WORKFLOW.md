# Windsurf Workflow Guide

This guide explains when and how to use Windsurf effectively for GRID development.

## When to Use Windsurf

Windsurf is best for:
- **Context-aware coding** with file references
- **Quick refactors** and code changes
- **Pattern matching** using Cascade skills
- **Documentation queries** with DeepWiki
- **"Vibe coding"** - high-level direction with AI leading

## Key Features

### File References (`@file.py`)
- Use `@filename.py` to include file context
- Chain multiple files: `@file1.py @file2.py`
- Windsurf automatically includes related code
- Maintains context across conversation

**Example:**
```
@src/grid/core/essence.py @src/grid/services/essence_service.py
```

### DeepWiki
- Query project documentation: "How are similar features implemented?"
- Find patterns and conventions
- Understand architecture decisions
- Access indexed project knowledge

**Example Queries:**
- "What patterns exist for error handling?"
- "How are services structured in GRID?"
- "What is the cognitive layer integration pattern?"

### Cascade Skills
- **Cognitive**: Decision support and cognitive load management
- **Narrow**: Focused, precise code analysis
- **Grid-Integration**: GRID-specific patterns and conventions
- **Local-First-Guard**: Enforce local-only operations

### Codemaps
- Visualize relationships between modules
- Understand code dependencies
- Navigate complex codebases

## Workflow Patterns

### Adding a Feature
1. **DeepWiki Query**: "How are similar features implemented?"
2. **File References**: Include related modules: `@src/grid/core/ @src/grid/services/`
3. **Cascade Analysis**: Use `grid-integration` skill for patterns
4. **Implementation**: Provide high-level direction, let Cascade guide
5. **Validation**: Use file references to check consistency

### Fixing Bugs
1. **File References**: Include error location and related code
2. **DeepWiki**: Query "What error handling patterns exist?"
3. **Cascade**: Use `narrow` skill for focused debugging
4. **Fix**: Implement fix with context from references
5. **Test**: Verify fix with related test files

### Code Review
1. **File References**: Include all changed files and tests
2. **Cascade**: Use `code-review` skill for automated checks
3. **DeepWiki**: Query "What are the code review standards?"
4. **Review**: Check architecture, patterns, and quality
5. **Feedback**: Provide clear, actionable feedback

### Generating Tests
1. **File References**: Include implementation and existing tests
2. **Cascade**: Use `test-generation` skill
3. **DeepWiki**: Query "What testing patterns are used?"
4. **Generate**: Let Cascade create test structure
5. **Validate**: Ensure coverage and quality

## Available Workflows

Workflows in `.windsurf/workflows/`:
- `add_feature.md` - Feature implementation
- `fix_bug.md` - Bug fixing with DeepWiki
- `generate_tests.md` - Test generation
- `code_review.md` - Code review workflow

## Best Practices

1. **Use File References Liberally**: Include all relevant files
2. **Leverage DeepWiki**: Query before making assumptions
3. **Use Cascade Skills**: Let skills guide implementation
4. **"Vibe Coding"**: Provide direction, let AI lead execution
5. **Maintain Context**: Chain file references for full context

## Integration with Other Tools

### From Cursor
- Import Cursor plan context
- Use file references to implement plan
- Maintain architectural consistency

### To Antigravity
- Export file references as paths
- Convert Windsurf context to Antigravity format
- Use `scripts/handoff_task.py` for conversion

## Examples

### Example: Quick Refactor
```
@src/grid/core/essence.py
Refactor the Essence class to use dependency injection.
Use the grid-integration skill for patterns.
```

### Example: Adding Error Handling
```
@src/grid/services/error_handler.py @src/grid/core/exceptions.py
Add error handling for the new service.
Query DeepWiki for error handling patterns.
Use local-first-guard skill to ensure no external APIs.
```

### Example: Pattern Matching
```
@src/grid/core/ @src/grid/services/
Find all services that need cognitive layer integration.
Use cognitive skill to identify integration points.
```

## Notes

- Windsurf excels at context-aware coding
- Use for quick changes and refactors
- Leverage file references for full context
- Let Cascade skills guide implementation
- DeepWiki provides project knowledge quickly
