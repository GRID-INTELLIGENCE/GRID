# GRID CLI Navigation & Terminal Configuration Map

**Generated:** 2026-01-10  
**Purpose:** Reduce terminal errors, optimize workflow paths, establish muscle memory

---

## 📍 SECTION 1: PATH TOPOLOGY

### 1.1 Inward Navigation (Root → Leaf)

```
E:\grid\                              # PROJECT ROOT
├── alembic.ini                       # DB migration config
├── pyproject.toml                    # Python project config (MAIN)
├── uv.lock                           # Dependency lockfile
├── config/                           # APPLICATION CONFIG
│   ├── arena_config.yaml             # Runtime rules engine
│   ├── delegation_spec.json          # Task delegation
│   ├── qualityGates.json             # Quality thresholds
│   ├── env/                          # Environment templates
│   └── tool-configs/                 # Linter/formatter configs
├── src/
│   └── application/
│       └── mothership/
│           ├── main.py               # FastAPI entry point
│           ├── config/               # App settings (913 LoC!)
│           │   └── __init__.py       # MothershipSettings
│           ├── db/migrations/        # Alembic migrations
│           └── utils/cpu_executor.py # CPU-bound task runner
├── tests/                            # Test suite
├── scripts/                          # Utility scripts
│   └── instrumentation_metrics.py    # Codebase analysis
└── docs/                             # Documentation
    └── FASTAPI_GAP_ANALYSIS.md       # This analysis
```

### 1.2 Outward Navigation (System Paths)

```
C:\Users\irfan\
├── .local\bin\                       # uv installation (PRIMARY)
│   └── uv.exe                        # Fast Python package manager
├── .gemini\                          # Antigravity IDE config
│   ├── settings.json                 # Model selection, MCP servers
│   ├── oauth_creds.json              # Authentication
│   └── antigravity\                  # IDE cache/extensions
├── AppData\Local\
│   └── Programs\Python\Python313\    # Python installation
│       ├── python.exe                # Python interpreter
│       └── Scripts\                  # pip, uv, etc.
├── AppData\Roaming\
│   ├── Antigravity\                  # IDE user data
│   ├── Code\                         # VS Code user data
│   └── Python\                       # Python user packages
├── Documents\PowerShell\
│   └── Microsoft.PowerShell_profile.ps1  # Shell startup
└── Documents\WindowsPowerShell\
    └── Microsoft.PowerShell_profile.ps1  # Legacy PS profile
```

---

## ⚠️ SECTION 2: RECURRING TERMINAL ERRORS

### 2.1 PowerShell-Specific Errors

| Error | Cause | Solution |
|-------|-------|----------|
| `An empty pipe element is not allowed` | Multiline commands with `@{}` or newlines | Use single-line or save to `.ps1` file |
| `The term 'X' is not recognized` | Missing PATH entry | Use `python -m <module>` pattern |
| `= : The term '=' is not recognized` | Newline before `=` in variable assignment | Keep assignment on single line |
| `ParameterBindingException` | Linux-style flags (`-p`) on Windows | Use PowerShell equivalents (`-Force`) |

### 2.2 Python/uv Errors

| Error | Cause | Solution |
|-------|-------|----------|
| `Workspace member missing pyproject.toml` | uv workspace config issue | Use `python -m pip` instead |
| `ModuleNotFoundError: 'application'` | Wrong CWD or PYTHONPATH | Run from `e:\grid\src` |
| `pip not recognized` | Not in PATH | Use `python -m pip install` |

---

## 🛠️ SECTION 3: RECOMMENDED COMMANDS

### 3.1 Python Commands (Always Work)

```powershell
# Use python -m pattern to avoid PATH issues
python -m pip install <package>           # Install package
python -m pytest tests/                   # Run tests
python -m alembic upgrade head            # Run migrations
python -c "from application.mothership.main import create_app"  # Quick syntax check
```

### 3.2 Navigation Shortcuts

```powershell
# Quick CWD changes (add to PowerShell profile)
function grid { Set-Location E:\grid }
function gridsrc { Set-Location E:\grid\src }
function gridtest { Set-Location E:\grid\tests }
function gridcfg { Set-Location E:\grid\config }
```

### 3.3 Safe PowerShell Patterns

```powershell
# AVOID multiline @ hashtables - use this instead:
$data = @{ Key1 = "Value1"; Key2 = "Value2" }

# AVOID: foreach statement piped (causes empty pipe error)
# USE: ForEach-Object cmdlet
Get-ChildItem | ForEach-Object { $_.Name }

# AVOID: mkdir -p (Linux syntax)
# USE: PowerShell equivalent
New-Item -ItemType Directory -Path "path\to\dir" -Force
```

---

## 📋 SECTION 4: IMPLEMENTATION PLAN

### Phase 1: Update PowerShell Profile

Add the following to `$PROFILE` (Documents\PowerShell\Microsoft.PowerShell_profile.ps1):

```powershell
# ============================================================
# GRID Development Profile Enhancement
# ============================================================

# Project navigation shortcuts
function grid { Set-Location E:\grid }
function gridsrc { Set-Location E:\grid\src }

# Ensure Python uses correct interpreter
function gpython { python -m $args }
function gpip { python -m pip $args }
function gtest { python -m pytest $args }
function galembic { Set-Location E:\grid; python -m alembic $args }

# Safe command wrapper for multi-step operations
function Invoke-GridScript {
    param([string]$Script)
    Push-Location E:\grid\src
    try { python $Script }
    finally { Pop-Location }
}

# Auto-complete for common GRID paths
$GridPaths = @(
    "E:\grid",
    "E:\grid\src",
    "E:\grid\src\application\mothership",
    "E:\grid\tests",
    "E:\grid\config"
)
```

### Phase 2: Create CLI Helper Script

```powershell
# File: e:\grid\scripts\cli_helpers.ps1

# Run Python analysis scripts safely
function Run-GridMetrics {
    Push-Location E:\grid
    python scripts/instrumentation_metrics.py
    Pop-Location
}

# Run FastAPI server
function Start-GridServer {
    Push-Location E:\grid\src
    python -m uvicorn application.mothership.main:app --reload --port 8080
    Pop-Location
}

# Run tests with coverage
function Test-Grid {
    param([string]$Path = "tests/")
    Push-Location E:\grid
    python -m pytest $Path -v --tb=short
    Pop-Location
}
```

### Phase 3: Environment Variable Consolidation

Create `e:\grid\config\env\development.env`:

```env
# GRID Development Environment
PYTHONPATH=E:\grid\src
MOTHERSHIP_ENVIRONMENT=development
MOTHERSHIP_DEBUG=true
MOTHERSHIP_LOG_LEVEL=DEBUG
MOTHERSHIP_ALLOW_UNAUTHENTICATED_DEV=1
MOTHERSHIP_SECRET_KEY=dev-secret-key-for-local-development-only-32chars
```

---

## 🎯 SECTION 5: KEY TAKEAWAYS

### ✅ DO:
1. **Always use `python -m`** instead of bare commands (`pip`, `pytest`, `alembic`)
2. **Keep PowerShell commands on single lines** when using hashtables
3. **Set PYTHONPATH** when running from outside `src/`
4. **Use `Push-Location`/`Pop-Location`** for temporary directory changes
5. **Save complex commands as `.ps1` scripts** instead of inline

### ❌ AVOID:
1. Multiline `@{}` hashtable definitions in terminal
2. Linux-style command flags (`mkdir -p`, `rm -rf`)
3. Bare `pip` or `alembic` commands (use `python -m`)
4. Running `uv add` (workspace config issue) - use `python -m pip install`
5. Piping `foreach` statements (use `ForEach-Object`)

---

## 📊 SECTION 6: PATH VERIFICATION CHECKLIST

Run this to verify your environment:

```powershell
# Verification script
Write-Host "=== Python Environment ===" -ForegroundColor Cyan
python --version
Write-Host "Python Path: $(where.exe python | Select-Object -First 1)"

Write-Host "`n=== uv Package Manager ===" -ForegroundColor Cyan  
where.exe uv 2>$null | Select-Object -First 1

Write-Host "`n=== PYTHONPATH ===" -ForegroundColor Cyan
$env:PYTHONPATH

Write-Host "`n=== Current Profile ===" -ForegroundColor Cyan
Write-Host $PROFILE
Test-Path $PROFILE
```

---

*This map was created from analyzing terminal error patterns and community best practices for Windows PowerShell + Python development.*
