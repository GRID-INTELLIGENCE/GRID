# 🔄 Masterclass IDE Synchronization Guide

We have integrated the **GRID Mastermind** enhancements across your primary development environments. This guide explains how to leverage them in action.

## 🌊 Windsurf (Proactive Agentic Dev)
**Configuration**: `c:\Users\irfan\.codeium\windsurf\mcp_config.json`
- **MCP Server**: `grid-mastermind` (Active)
- **Usage**: Windsurf will automatically suggest using `grid_health_check` or `grid_query_knowledge` when you ask architectural questions in the chat.
- **Benefit**: Real-time access to the **GRID Intelligence Library** and automated environment validation.

## 🖱️ Cursor (High-Fidelity Code Editing)
**Configuration**: `E:\grid\.cursorrules`
- **Protocol Enforced**: The **Mastication Protocol** is now part of Cursor's core instructions for this project.
- **Usage**: When you ask Cursor to "Add a new feature," it is now mandated to check for "Flavor Density" and adhere to "Stickiness" (120 char lines, Python 3.13 typing).
- **Benefit**: Ensures that logic generated in Cursor remains consistent with our Sovereign Tier architecture.

## 🤖 Antigravity (Advanced Agentic Orchestration)
**Configuration**: `.agent/workflows/masticate_feature.md`
- **Usage**: Use the command `/masticate_feature` to trigger a multi-step protocol analysis.
- **Tools**: Directly invokes MCP tools in a structured sequence of checks.
- **Benefit**: Best for complex refactoring or new system components where deep logic traces are required.

## 🧠 Shared Knowledge Library
**Location**: `c:\Users\irfan\.gemini\antigravity\knowledge`
- 所有 IDEs reference this synchronized memory via the `grid-mastermind` bridge.
- The **Taxonomy-based search** ensures that context from EUFLE (e.g., model routing failures) informs decisions in GRID.

---
*Blueprint reference: `c:\Users\irfan\.gemini\antigravity\playground\velvet-hubble\masterclass_blueprint.md`*
