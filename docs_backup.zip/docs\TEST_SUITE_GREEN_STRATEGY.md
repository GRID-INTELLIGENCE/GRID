# Test Suite Green Strategy

## Overview

This document outlines the strategy for maintaining a green test suite in the GRID codebase, specifically focusing on critical path validation while managing experimental (scratch) and integration-heavy tests.

## Test Categorization

1.  **Critical Tests** (`markers: critical`): Tests that verify core business logic and security. MUST PASS for any deployment or merge.
2.  **API Tests** (`markers: api`, path: `tests/api/`): Tests verifying endpoint behavior, routing, and response schemas.
3.  **Unit Tests** (`markers: unit`): Fast tests for individual functions and classes.
4.  **Integration Tests** (`markers: integration`): Tests involving interactions between modules or external services (mocked where possible).
5.  **Scratch Tests** (path: `tests/scratch/`): Experimental validation scripts and one-off debugging tests. These are **excluded from CI**.

## Execution Strategy

### Standard CI Run (Green Baseline)
The standard run executes all tests EXCEPT scratch tests. This validates the stable application state.

```bash
# Run all stable tests
pytest tests/ --ignore=tests/scratch -v
```

### Coverage Run
For verifying code coverage on source files:

```bash
pytest tests/ --ignore=tests/scratch --cov=src --cov-report=term-missing -v
```

### Targeted Runs

*   **Critical Security Only**: `pytest tests/ -m critical -v`
*   **API Tests**: `pytest tests/api/ -v`
*   **Unit Tests**: `pytest tests/ -m unit -v`

### Scratch Tests
Scratch tests are run explicitly when developing new features or validating specific edge cases.

```bash
pytest tests/scratch/ -v
```

## Handling Integration Tests

Integration tests requiring external services (e.g., Databases, LLM APIs) should be:
1.  Marked with `@pytest.mark.skip(reason="...")` if the infrastructure is effectively unavailable in the test environment.
2.  Or use robust mocks (e.g., `mock_processing_unit`, `mock_settings`) to simulate the external interaction.

## Pydantic Deprecation Warnings

We actively filter deprecation warnings in `pyproject.toml` to keep output clean, but future refactoring should monitor `PydanticDeprecatedSince20` warnings for eventual logic updates.

---
**Status**: The test suite is currently GREEN for all non-scratch paths.
