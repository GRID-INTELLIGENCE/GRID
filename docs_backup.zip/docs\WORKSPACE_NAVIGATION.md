# GRID Workspace Navigation Guide

**Purpose**: Quick reference for starting a work session - only frequently used fundamentals visible, everything else properly organized.

## 🎯 Quick Start - What You See at Root

When you start a work session, the root directory shows only **essentials for daily navigation**:

```
grid/
├── LICENSE             # License
├── Makefile            # Build automation (frequent use)
├── README.md           # Project overview
├── pyproject.toml      # Project configuration (frequent use)
├── uv.lock             # Dependency lock
│
├── src/                # ⭐ ALL PRODUCTION CODE (primary workspace)
├── tests/              # Test suite
├── docs/               # Documentation
├── config/             # ⭐ Configuration files (organized)
└── [other directories]
```

**Focus Areas**: `src/` (code) and `config/` (configuration)

## 📁 Directory Organization by Frequency of Use

### 🔥 High Frequency (Visible at Root)
- **`src/`** - All production code (primary workspace)
- **`tests/`** - Test suite (daily development)
- **`config/`** - Configuration files (organized)
- **`Makefile`** - Build automation (frequent commands)
- **`pyproject.toml`** - Project configuration (dependency management)

### 📚 Medium Frequency (Organized in `docs/`)
- Documentation files
- Guides and references
- Historical documentation

### 🔧 Low Frequency (Organized in `config/`)
- **`config/dotfiles/`** - All dotfiles and ignore files (reference)
- **`config/env/`** - Environment-specific configurations
- **`config/workspace/`** - IDE workspace files

### 🗄️ Archive (Organized in `archive/`)
- Legacy code
- Experimental code
- Deprecated files

## 🎨 Workspace Philosophy

### Visible at Root (Daily Navigation)
Only items you interact with **daily** or **frequently**:
- Source code (`src/`)
- Tests (`tests/`)
- Build automation (`Makefile`)
- Project configuration (`pyproject.toml`)

### Organized in `config/` (Reference When Needed)
Items you reference **periodically** but don't need visible:
- Dotfiles (`config/dotfiles/`)
- Environment configs (`config/env/`)
- Workspace files (`config/workspace/`)

### Organized in `docs/` (Documentation)
Items you reference **occasionally** for guidance:
- Guides and documentation
- Reference materials
- Historical records

## 🗂️ Configuration Files Organization

### At Root (Required by Tools)
These **MUST** stay at root because tools require them there:
- `.gitignore` - Git version control
- `.cursorignore` - Cursor IDE
- `.agentignore` - Agent tools
- `.cursorrules` - Cursor IDE rules
- `.env` - Runtime environment (convenience)

### In `config/dotfiles/` (Organized Reference)
Copies stored for **easy reference** and **version control**:
- All dotfiles and ignore files
- Configuration templates
- Documentation about each file

### In `config/env/` (Environment-Specific)
Environment files organized by **purpose**:
- `.env.development` - Development environment
- `.env.staging` - Staging environment
- `.env.production` - Production environment
- `.env.venv` - Virtual environment configuration

**Note**: `.env` and `.env.example` stay at root for convenience and visibility.

## 🚀 Starting a Work Session

### 1. Navigate to Root
```bash
cd grid/
```

### 2. Quick Check - Essential Files
- ✅ `src/` exists (your code)
- ✅ `Makefile` exists (build commands)
- ✅ `pyproject.toml` exists (dependencies)

### 3. Common Tasks

**Run Development Server:**
```bash
make run  # or: python -m src.application.mothership.main
```

**Run Tests:**
```bash
make test  # or: pytest tests/
```

**Check Configuration:**
```bash
# View dotfiles
ls config/dotfiles/

# View environment configs
ls config/env/
```

**Reference Documentation:**
```bash
# View documentation
ls docs/

# Quick reference
cat docs/WORKSPACE_NAVIGATION.md  # This file!
```

## 📋 Frequently Used Commands

### Build & Development
```bash
make run              # Start development server
make test             # Run tests
make lint             # Run linters
make format           # Format code
```

### Configuration
```bash
# View dotfiles
cat config/dotfiles/.gitignore

# View environment configs
cat config/env/.env.development
```

### Navigation
```bash
# Primary workspace
cd src/

# Configuration reference
cd config/dotfiles/

# Documentation
cd docs/
```

## 🎯 File Locations Quick Reference

### Configuration Files
| File | Location | Purpose | Frequency |
|------|----------|---------|-----------|
| `.gitignore` | Root | Git exclusions | Daily (Git operations) |
| `.cursorignore` | Root | Cursor exclusions | Daily (IDE usage) |
| `.agentignore` | Root | Agent exclusions | Periodic (agent tasks) |
| `.cursorrules` | Root | Cursor rules | Daily (IDE behavior) |
| `.env` | Root | Runtime config | Daily (development) |
| `.env.*` | `config/env/` | Environment configs | Periodic (deployment) |
| Dotfiles (copies) | `config/dotfiles/` | Reference | Periodic (maintenance) |

### Source Code
| Location | Purpose | Frequency |
|----------|---------|-----------|
| `src/` | All production code | Daily (primary workspace) |
| `tests/` | Test suite | Daily (test-driven development) |

### Documentation
| Location | Purpose | Frequency |
|----------|---------|-----------|
| `docs/` | Documentation | Periodic (reference) |
| `README.md` | Project overview | Daily (onboarding) |

## 🔍 Finding Things

### Need to Find a Configuration File?
```bash
# All dotfiles
ls config/dotfiles/

# All environment configs
ls config/env/

# All workspace configs
ls config/workspace/
```

### Need to Find Source Code?
```bash
# All production code
find src/ -name "*.py" | head -20

# Specific module
find src/ -name "*resonance*"
```

### Need to Find Documentation?
```bash
# All documentation
ls docs/

# Search documentation
grep -r "keyword" docs/
```

## ✨ Benefits of This Organization

### Clean Root Directory
✅ Only essentials visible
✅ Less visual clutter
✅ Faster navigation
✅ Clear focus on code

### Organized Configuration
✅ All configs in one place
✅ Easy to find and reference
✅ Version controlled
✅ Documented

### Workspace Focus
✅ Start session with clear view
✅ Navigate quickly to essentials
✅ Reference configs when needed
✅ Reduced cognitive load

## 📝 Notes

- **Dotfiles in `config/dotfiles/`**: Organized copies for reference
- **Environment files**: Organized by environment type
- **Workspace files**: Stored in `config/workspace/`

This structure ensures you start each work session with **only the fundamentals you need**, while everything else is **properly organized and easily accessible** when needed.
