# Slash Command Specification

## Overview

Slash commands provide quick access to common workflows and system operations. Each command has a specific mode, trigger, and integration pattern with the agent system.

## Core Commands

### /ci - Pipeline Simulation

**Mode**: Pipeline
**Trigger**: Local development before commits
**Integration**: Links to `fix_bug.md`, `code_review.md`, `testing.md` workflows

**Usage Examples**:

```bash
/ci                    # Run full pipeline
/ci --fast            # Skip RAG contracts (quick check)
/ci --verbose         # Detailed output
```

**Workflow Steps**:

1. Execute pre-commit hooks (ruff, mypy, formatting)
2. Run unit tests with coverage
3. Validate RAG contracts (if RAG files changed)
4. Generate quality report
5. Provide actionable recommendations

**Success Criteria**:

- All hooks pass
- Unit tests ≥ 95% pass rate
- RAG contracts validate
- Clear actionable feedback

**Integration Points**:

- Pre-commit hook results → `fix_bug.md` for failures
- Test coverage analysis → `code_review.md` for quality
- Performance metrics → `testing.md` for optimization

### /sync - Knowledge Refresh

**Mode**: Knowledge
**Trigger**: After major changes, daily maintenance
**Integration**: Updates knowledge graph, RAG index, system metrics

**Usage Examples**:

```bash
/sync                 # Full sync
/sync --rag-only      # RAG index only
/sync --graph-only    # Knowledge graph only
/sync --quick         # Skip quality checks
```

**Workflow Steps**:

1. Scan for new/modified documents
2. Update RAG vector database
3. Refresh knowledge graph connections
4. Rebuild search indices
5. Run quality checks
6. Generate sync report

**Success Criteria**:

- New documents indexed successfully
- Knowledge graph updated with new connections
- Quality metrics within acceptable ranges
- No critical errors in any component

**Integration Points**:

- Document indexing → `rag-query` skill for search
- Graph updates → `cognitive-integration` skill for reasoning
- Quality metrics → `ai_behavior.md` rule adjustments

### /audit - Quality Review

**Mode**: Review
**Trigger**: Weekly health check, before releases
**Integration**: Comprehensive system analysis and reporting

**Usage Examples**:

```bash
/audit                # Full system audit
/audit --code         # Code quality only
/audit --performance  # Performance metrics only
/audit --security     # Security assessment only
```

**Workflow Steps**:

1. Code quality analysis (ruff, mypy, complexity)
2. Performance metrics review
3. Security vulnerability scan
4. Test coverage analysis
5. Documentation completeness check
6. Dependency security audit
7. Generate comprehensive report

**Success Criteria**:

- Code quality score ≥ 80%
- No critical security vulnerabilities
- Test coverage ≥ 70%
- Documentation completeness ≥ 85%

**Integration Points**:

- Code analysis → `code-review` skill for automated fixes
- Performance data → `cognitive_layer.md` for system optimization
- Security findings → `local_first.md` for remediation

### /deploy - Release Pipeline

**Mode**: Release
**Trigger**: Production readiness, feature completion
**Integration**: Executes `deploy_staging.md` workflow

**Usage Examples**:

```bash
/deploy staging       # Deploy to staging environment
/deploy production    # Deploy to production (requires approval)
/deploy --dry-run     # Simulate deployment without changes
```

**Workflow Steps**:

1. Pre-deployment checks (tests, security, quality)
2. Environment preparation
3. Application deployment
4. Health verification
5. Rollback capability verification
6. Post-deployment monitoring setup

**Success Criteria**:

- All pre-deployment checks pass
- Deployment completes successfully
- Health checks pass
- Rollback capability verified

**Integration Points**:

- Pre-deployment → `ci` command for validation
- Environment setup → `deploy-check` skill for verification
- Monitoring → `api-testing` skill for health checks

## Advanced Commands

### /trace - Recursive Debug Analysis

**Mode**: Debug
**Trigger**: Error investigation, performance issues
**Integration**: Pattern analysis in logs and system behavior

**Usage Examples**:

```bash
/trace "error message"     # Trace specific error
/trace --performance       # Analyze performance bottlenecks
/trace --recent            # Analyze recent system activity
```

**Workflow Steps**:

1. Parse error or performance issue
2. Search relevant logs and metrics
3. Identify patterns and correlations
4. Generate diagnostic report
5. Recommend remediation steps

### /codify - Knowledge Evolution

**Mode**: Knowledge
**Trigger**: Breakthrough insights, pattern discovery
**Integration**: Turns insights into persistent knowledge artifacts

**Usage Examples**:

```bash
/codify "insight description"    # Convert insight to knowledge
/codify --pattern "pattern"       # Document discovered pattern
/codify --solution "solution"     # Capture solution approach
```

**Workflow Steps**:

1. Analyze insight or pattern
2. Extract key principles
3. Create structured knowledge artifact
4. Link to existing knowledge graph
5. Update relevant documentation

## Command Implementation Architecture

### Core Components

```
src/tools/slash_commands/
├── __init__.py
├── base.py              # Base command class
├── ci.py                 # /ci implementation
├── sync.py               # /sync implementation
├── audit.py              # /audit implementation
├── deploy.py             # /deploy implementation
├── trace.py              # /trace implementation
├── codify.py             # /codify implementation
└── utils.py              # Shared utilities
```

### Integration Points

```
.agent/
├── workflows/
│   ├── ci_simulation.md
│   ├── sync_workflow.md
│   ├── audit_review.md
│   └── deploy_pipeline.md
├── skills/
│   ├── code-review/
│   ├── rag-query/
│   ├── api-testing/
│   └── deploy-check/
└── rules/
    ├── ai_behavior.md
    ├── testing.md
    └── local_first.md
```

## Command Registration System

### Command Discovery

Commands are automatically discovered and registered through the command registry:

```python
# src/tools/slash_commands/registry.py
class CommandRegistry:
    def __init__(self):
        self.commands = {}
        self._discover_commands()

    def _discover_commands(self):
        """Auto-discover command implementations"""
        commands_dir = Path(__file__).parent
        for cmd_file in commands_dir.glob("*.py"):
            if cmd_file.name not in ["__init__.py", "base.py", "utils.py", "registry.py"]:
                module_name = cmd_file.stem
                try:
                    module = importlib.import_module(f"tools.slash_commands.{module_name}")
                    if hasattr(module, "Command"):
                        self.commands[f"/{module_name}"] = module.Command()
                except ImportError as e:
                    logger.warning(f"Failed to load command {module_name}: {e}")
```

### Command Interface

All commands implement the base interface:

```python
# src/tools/slash_commands/base.py
from abc import ABC, abstractmethod
from typing import Dict, Any, List
from dataclasses import dataclass

@dataclass
class CommandResult:
    success: bool
    message: str
    data: Dict[str, Any]
    recommendations: List[str]
    execution_time: float

class BaseCommand(ABC):
    def __init__(self):
        self.name = self.__class__.__name__.lower()

    @abstractmethod
    async def execute(self, args: List[str], kwargs: Dict[str, Any]) -> CommandResult:
        """Execute the command with given arguments"""
        pass

    @abstractmethod
    def get_help(self) -> str:
        """Return help text for the command"""
        pass

    def validate_args(self, args: List[str], kwargs: Dict[str, Any]) -> bool:
        """Validate command arguments"""
        return True
```

## Usage Patterns

### Development Workflow

```bash
# Before committing changes
/ci

# After major feature addition
/sync

# Weekly health check
/audit

# Before deployment
/deploy staging
```

### Debugging Workflow

```bash
# When errors occur
/trace "error message"

# After discovering patterns
/codify "discovered pattern"

# Performance investigation
/trace --performance
```

### Maintenance Workflow

```bash
# Daily knowledge refresh
/sync --quick

# Weekly comprehensive check
/audit

# Monthly deep analysis
/audit --performance && /audit --security
```

## Error Handling and Recovery

### Command Failure Modes

1. **Validation Errors**: Invalid arguments or preconditions
2. **Execution Errors**: Runtime failures during command execution
3. **Integration Errors**: Failures in dependent systems
4. **Permission Errors**: Insufficient permissions for operations

### Recovery Strategies

1. **Retry Logic**: Automatic retry for transient failures
2. **Fallback Modes**: Reduced functionality when components unavailable
3. **Rollback Support**: Ability to undo changes when possible
4. **Error Reporting**: Detailed error information for debugging

## Performance Considerations

### Execution Time Targets

- `/ci`: < 2 minutes for full pipeline
- `/sync`: < 5 minutes for full sync
- `/audit`: < 10 minutes for comprehensive audit
- `/deploy`: < 15 minutes for staging deployment

### Resource Usage

- **Memory**: Commands should use < 500MB RAM
- **CPU**: Intensive operations should be async/await
- **Disk**: Temporary files cleaned up automatically
- **Network**: External API calls with timeouts and retries

## Security Considerations

### Command Permissions

- **Safe Commands**: Can be executed by any user (`/ci`, `/sync`, `/audit`)
- **Restricted Commands**: Require approval (`/deploy production`)
- **Admin Commands**: Require elevated privileges (`/audit --security`)

### Input Validation

- All user inputs sanitized and validated
- File path operations restricted to allowed directories
- Command injection prevention through argument parsing
- Rate limiting for expensive operations

## Monitoring and Observability

### Metrics Collection

- Command execution frequency and duration
- Success/failure rates by command
- Resource usage patterns
- User interaction analytics

### Logging Standards

- Structured logging with correlation IDs
- Performance metrics at key checkpoints
- Error details with stack traces
- Integration point status updates

## Future Enhancements

### Planned Commands

- `/optimize` - System performance optimization
- `/migrate` - Database and configuration migration
- `/backup` - System backup and restore
- `/scale` - Resource scaling operations

### Advanced Features

- Command composition and chaining
- Conditional execution based on results
- Parallel execution for independent operations
- Interactive command modes with user prompts
