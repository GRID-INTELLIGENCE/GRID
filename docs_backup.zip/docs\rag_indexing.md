# RAG Indexing Documentation

## Comprehensive Indexing

Use the `--comprehensive` flag to index more file types and directories:

```bash
python -m tools.rag.cli index --comprehensive
```

## Progress Bar

The indexing process now displays a progress bar using `tqdm`.

## Default Embedding Model

The default embedding model is now `sentence-transformers/all-MiniLM-L6-v2`.

## Using a Different Model

To use a different model, set the `RAG_EMBEDDING_MODEL` environment variable:

```bash
export RAG_EMBEDDING_MODEL="Snowflake/snowflake-arctic-embed-m"
python -m tools.rag.cli index
```
