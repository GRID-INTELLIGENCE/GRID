# User Engagement & Tailored Experience Guide

**Comprehensive Summary, Overview, Usage Instructions, and Navigation Guide**

**Version**: 1.0.0
**Last Updated**: January 7, 2026
**Status**: ✅ Complete

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Overview](#overview)
3. [Core Features](#core-features)
4. [Quick Start](#quick-start)
5. [Usage Instructions](#usage-instructions)
6. [Navigation Guide](#navigation-guide)
7. [API Reference](#api-reference)
8. [Advanced Topics](#advanced-topics)
9. [Best Practices](#best-practices)
10. [Troubleshooting](#troubleshooting)

---

## Executive Summary

The GRID project provides a comprehensive **tailored user engagement system** that adapts to individual user needs through:

- **Cognitive Decision Support Layer**: Adapts processing based on user expertise, cognitive load, and decision-making preferences
- **Personalized Navigation System**: Learning-enabled path optimization that suggests optimal workflows based on user patterns
- **Context-Aware Resonance API**: Real-time activity processing with adaptive feedback and path visualization
- **User Cognitive Profiles**: Rich user modeling that tracks expertise, learning style, and preferences

### Key Benefits

- ✅ **Reduced Cognitive Load**: Automatic complexity management and information chunking
- ✅ **Personalized Recommendations**: Adaptive suggestions based on user patterns and preferences
- ✅ **Faster Decision Making**: Dual-process routing (System 1/System 2) for optimal response speed
- ✅ **Mental Model Alignment**: Detects and explains discrepancies between user expectations and system behavior
- ✅ **Learning-Enabled Navigation**: Path selection improves over time (>95% accuracy target)

---

## Overview

### What is Tailored User Engagement?

Tailored user engagement in GRID means the system **adapts its behavior, presentation, and recommendations** to match individual user characteristics:

1. **Cognitive Characteristics**: Expertise level, working memory capacity, cognitive load tolerance
2. **Decision Preferences**: Decision style (quick/deliberate/balanced), risk tolerance, satisficing tendency
3. **Learning Preferences**: Preferred learning style (code examples, analogies, visual diagrams, hands-on)
4. **Behavioral Patterns**: Interaction history, decision patterns, feature usage

### How It Works

```
User Interaction
    ↓
Cognitive Profile Assessment
    ├─→ Expertise Level Detection
    ├─→ Decision Style Analysis
    └─→ Cognitive Load Estimation
    ↓
Adaptive Processing
    ├─→ Dual-Process Routing (System 1/2)
    ├─→ Bounded Rationality Application
    ├─→ Choice Architecture (Framing/Defaults/Nudges)
    └─→ Cognitive Load Management (Chunking/Scaffolding)
    ↓
Personalized Output
    ├─→ Complexity-Adjusted Content
    ├─→ Learning-Style Matched Explanations
    ├─→ Risk-Appropriate Recommendations
    └─→ Cognitive Load Optimized Presentation
    ↓
Learning Feedback Loop
    └─→ Pattern Recognition & Model Updates
```

### Core Components

| Component | Location | Purpose |
|-----------|----------|---------|
| **Cognitive Layer** | `light_of_the_seven/cognitive_layer/` | Decision support, cognitive load, mental models |
| **Navigation System** | `light_of_the_seven/cognitive_layer/navigation/` | Path optimization and learning |
| **Resonance API** | `application/resonance/` | Real-time activity processing with feedback |
| **User Profiles** | `light_of_the_seven/cognitive_layer/schemas/user_cognitive_profile.py` | User modeling and preferences |

---

## Core Features

### 1. Cognitive Decision Support

**Purpose**: Adapts decision-making processes to user cognitive characteristics.

**Features**:
- **Dual-Process Routing**: Automatically routes to System 1 (fast, intuitive) or System 2 (deliberate, analytical)
- **Bounded Rationality Engine**: Applies satisficing and heuristics for efficient decision-making
- **Choice Architecture**: Frames options, suggests defaults, provides nudges
- **Decision Matrices**: Weighted criteria evaluation for complex decisions

**Use Cases**:
- Selecting optimal implementation paths
- Choosing between multiple API design options
- Deciding on refactoring strategies

### 2. Cognitive Load Management

**Purpose**: Prevents information overload and optimizes presentation.

**Features**:
- **Load Estimation**: Calculates cognitive load (0-10 scale) based on complexity, novelty, information density
- **Information Chunking**: Organizes content into working-memory-friendly groups (Miller's 7±2)
- **Progressive Disclosure**: Scaffolding that adapts to user expertise level
- **Load Reduction**: Suggests ways to reduce cognitive load

**Use Cases**:
- Simplifying complex API responses for novices
- Providing detailed explanations for experts
- Chunking large result sets

### 3. Mental Model Management

**Purpose**: Tracks and aligns user expectations with system behavior.

**Features**:
- **Model Tracking**: Infers and tracks user mental models over time
- **Alignment Checking**: Compares user expectations with actual behavior
- **Mismatch Detection**: Flags discrepancies and suggests explanations
- **Model Evolution**: Tracks how mental models change

**Use Cases**:
- Detecting when users misunderstand system behavior
- Providing contextual explanations
- Preventing user confusion

### 4. Personalized Navigation

**Purpose**: Learning-enabled path optimization for optimal workflow suggestions.

**Features**:
- **Adaptive Path Scoring**: Multi-factor scoring with learned weights
- **Context Extraction**: Synthesizes context from goals and environment
- **Multi-Path Generation**: Provides 3-4 path options with confidence scores
- **Learning Integration**: Improves recommendations over time

**Use Cases**:
- Suggesting optimal development workflows
- Recommending code organization strategies
- Guiding feature implementation paths

### 5. Resonance API

**Purpose**: Real-time activity processing with adaptive feedback.

**Features**:
- **Fast Context**: Quick context from `application/` directory
- **Path Visualization**: Vivid path options from `light_of_the_seven/`
- **ADSR Envelope**: Haptic-like feedback (attack, decay, sustain, release)
- **WebSocket Support**: Real-time updates for interactive experiences

**Use Cases**:
- Interactive development assistance
- Real-time workflow guidance
- Context-aware tool recommendations

---

## Quick Start

### For Developers

#### 1. Basic Cognitive Decision Support

```python
from light_of_the_seven.cognitive_layer import (
    UserCognitiveProfile,
    DecisionContext,
    DualProcessRouter,
    BoundedRationalityEngine,
)

# Create user profile
user = UserCognitiveProfile(
    user_id="dev_123",
    expertise_level="intermediate",
    decision_style="balanced"
)

# Create decision context
decision = DecisionContext(
    decision_id="choose_api_design",
    description="Select API design pattern",
    options=[
        {"id": "rest", "risk": 0.2, "potential": 0.8},
        {"id": "graphql", "risk": 0.4, "potential": 0.9},
    ],
    complexity=0.6,
    stakes=0.7
)

# Route decision
router = DualProcessRouter()
mode = router.get_processing_mode(decision, user)

# Apply bounded rationality
engine = BoundedRationalityEngine()
selection = engine.evaluate_with_bounded_rationality(
    decision, decision.options,
    lambda o: float(o.get("potential", 0.0))
)
```

#### 2. Personalized Navigation

```python
from light_of_the_seven.cognitive_layer.navigation import (
    EnhancedPathNavigator,
    NavigationRequest,
    NavigationGoal,
    GoalType,
)

# Create navigator
navigator = EnhancedPathNavigator()

# Simple usage (string input)
plan = navigator.navigate_simple("Create a new API endpoint for authentication")
print(f"Recommended: {plan.recommended_path.name}")
print(f"Confidence: {plan.confidence_scores[plan.recommended_path.id]:.1%}")

# Structured usage
goal = NavigationGoal(
    goal_type=GoalType.DEVELOPMENT,
    primary_objective="Implement user authentication API",
    success_criteria=["JWT token generation", "Password validation"]
)
request = NavigationRequest(goal=goal)
plan = navigator.navigate(request)
```

#### 3. Resonance API

```bash
# Start the server
python -m application.mothership.main

# Process activity
curl -X POST http://localhost:8080/api/v1/resonance/process \
  -H "Content-Type: application/json" \
  -d '{
    "query": "create a new service",
    "activity_type": "code",
    "context": {"urgency": true}
  }'

# Get definitive step (canvas flip)
curl -X POST http://localhost:8080/api/v1/resonance/definitive \
  -H "Content-Type: application/json" \
  -d '{
    "query": "implement authentication",
    "progress": 0.65,
    "target_schema": "resonance"
  }'
```

---

## Usage Instructions

### Section 1: Setting Up User Profiles

#### Creating a Basic Profile

```python
from light_of_the_seven.cognitive_layer.schemas.user_cognitive_profile import (
    UserCognitiveProfile,
    ExpertiseLevel,
    LearningStyle,
    DecisionStyle,
)

profile = UserCognitiveProfile(
    user_id="user_001",
    username="alice",
    expertise_level=ExpertiseLevel.INTERMEDIATE,
    learning_style=LearningStyle.CODE_EXAMPLES,
    decision_style=DecisionStyle.BALANCED,
    preferred_complexity=0.6,
    risk_tolerance=0.5,
    working_memory_capacity=0.7,
    cognitive_load_tolerance=0.6
)
```

#### Advanced Profile Configuration

```python
# Domain-specific expertise
profile.domain_expertise = {
    "api_design": ExpertiseLevel.ADVANCED,
    "database": ExpertiseLevel.INTERMEDIATE,
    "frontend": ExpertiseLevel.BEGINNER,
}

# Custom preferences
profile.preferences = {
    "show_examples": True,
    "detailed_explanations": False,
    "recommendation_count": 3,
}

# Update timestamp when modified
profile.update_timestamp()
```

### Section 2: Using Cognitive Decision Support

#### Dual-Process Routing

```python
from light_of_the_seven.cognitive_layer.decision_support.dual_process_router import (
    DualProcessRouter,
)

router = DualProcessRouter()

# Determine processing mode
mode = router.get_processing_mode(decision_context, user_profile)

if mode == "system_1":
    # Fast, pattern-based response
    result = fast_path_processor(decision)
else:
    # Deliberate, analytical response
    result = deep_analysis_processor(decision)
```

#### Bounded Rationality

```python
from light_of_the_seven.cognitive_layer.decision_support.bounded_rationality_engine import (
    BoundedRationalityEngine,
)

engine = BoundedRationalityEngine(
    default_satisficing_threshold=0.7,
    max_search_depth=5
)

# Evaluate options
selection = engine.evaluate_with_bounded_rationality(
    decision_context,
    options_list,
    scoring_function=lambda opt: opt["score"]
)

print(f"Selected: {selection['selected_option']}")
print(f"Method: {selection['method']}")  # 'satisficing' or 'best_available'
```

#### Choice Architecture

```python
from light_of_the_seven.cognitive_layer.decision_support.choice_architecture import (
    ChoiceArchitecture,
)

choice = ChoiceArchitecture()

# Reduce cognitive load
reduced = choice.reduce_cognitive_load(decision_context, user_profile)

# Suggest default
default = choice.suggest_default(reduced.options, reduced, user_profile)

# Apply framing
framed = choice.frame_decision(
    reduced,
    framing="gain",  # or "loss", "neutral"
    user_profile=user_profile
)
```

### Section 3: Managing Cognitive Load

#### Load Estimation

```python
from light_of_the_seven.cognitive_layer.cognitive_load.cognitive_load_estimator import (
    CognitiveLoadEstimator,
)

estimator = CognitiveLoadEstimator()

# Estimate load
operation_characteristics = {
    "complexity": 0.8,
    "novelty": 0.7,
    "information_density": 0.6,
    "time_pressure": 0.4,
}

load = estimator.estimate_load(operation_characteristics, user_profile)

print(f"Estimated Load: {load.estimated_load}/10")
print(f"Load Type: {load.load_type}")  # INTRINSIC, EXTRANEOUS, GERMANE
print(f"Working Memory: {load.working_memory_usage:.1%}")

# Get reduction suggestions
suggestions = estimator.suggest_load_reduction(load, user_profile)
```

#### Information Chunking

```python
from light_of_the_seven.cognitive_layer.cognitive_load.information_chunker import (
    InformationChunker,
)

chunker = InformationChunker()

# Chunk a large list
large_list = [f"item_{i}" for i in range(50)]
chunks = chunker.chunk_by_working_memory(
    large_list,
    user_profile.working_memory_capacity,
    max_items_per_chunk=7
)

for i, chunk in enumerate(chunks):
    print(f"Chunk {i+1}: {chunk}")
```

#### Progressive Disclosure (Scaffolding)

```python
from light_of_the_seven.cognitive_layer.cognitive_load.scaffolding_manager import (
    ScaffoldingManager,
)

scaffold = ScaffoldingManager()

# Get scaffolded explanation
explanation = scaffold.scaffold_explanation(
    concept="API authentication",
    user_profile=user_profile,
    include_examples=True,
    include_analogies=(user_profile.learning_style == "analogies")
)

print(explanation.text)
print(f"Complexity Level: {explanation.complexity_level}")
print(f"Components: {explanation.components}")  # examples, analogies, steps, etc.
```

### Section 4: Mental Model Management

#### Tracking Mental Models

```python
from light_of_the_seven.cognitive_layer.mental_models.model_tracker import (
    MentalModelTracker,
)

tracker = MentalModelTracker()

# Infer model from interaction
interaction = {
    "action": "expect API to return JSON",
    "question": "How does authentication work?",
}

inferred = tracker.infer_model_from_interaction(interaction, user_profile)

print(f"Expectations: {inferred['expectations']}")
print(f"Assumptions: {inferred['assumptions']}")
print(f"Knowledge Gaps: {inferred['knowledge_gaps']}")

# Track evolution
evolution = tracker.track_model_evolution(user_profile.user_id, inferred)
```

#### Checking Alignment

```python
from light_of_the_seven.cognitive_layer.mental_models.alignment_checker import (
    AlignmentChecker,
)

checker = AlignmentChecker()

# Check alignment
expected = {"behavior": "API returns JSON"}
actual = {"behavior": "API returns JSON"}

alignment = checker.check_alignment(
    expected_behavior=expected,
    actual_behavior=actual,
    user_profile=user_profile
)

print(f"Alignment Score: {alignment.alignment_score:.1%}")
print(f"Is Aligned: {alignment.is_aligned}")
if alignment.mismatches:
    print(f"Mismatches: {alignment.mismatches}")
    print(f"Explanations: {alignment.suggested_explanations}")
```

### Section 5: Navigation System

#### Basic Navigation

```python
from light_of_the_seven.cognitive_layer.navigation import (
    EnhancedPathNavigator,
    NavigationRequest,
    NavigationGoal,
    NavigationContext,
    GoalType,
    UrgencyLevel,
)

navigator = EnhancedPathNavigator()

# Simple string input
plan = navigator.navigate_simple("Fix memory leak in data processing")
print(f"Paths: {plan.path_count}")
print(f"Recommended: {plan.recommended_path.name}")

# Structured input
goal = NavigationGoal(
    goal_type=GoalType.DEBUGGING,
    primary_objective="Fix memory leak in module X",
    success_criteria=["Memory usage stable", "Tests passing"]
)

context = NavigationContext(
    urgency=UrgencyLevel.HIGH,
    time_constraint_hours=2.0
)

request = NavigationRequest(goal=goal, context=context)
plan = navigator.navigate(request)

# Explore paths
for path in plan.paths:
    print(f"\n{path.name}:")
    print(f"  Complexity: {path.complexity}")
    print(f"  Time: {path.estimated_total_time}s")
    print(f"  Confidence: {path.confidence:.1%}")
    print(f"  Steps: {path.step_count}")
```

#### Using Navigation Agent

```python
from light_of_the_seven.cognitive_layer.navigation import (
    PathOptimizationAgent,
    AgentRegistry,
)

# Create registry
registry = AgentRegistry()

# Create and register agent
agent = PathOptimizationAgent()
registry.register(agent, auto_start=True)

# Process request (async)
import asyncio

async def process():
    result = await agent.execute(request)
    print(f"Recommended Path ID: {result.recommended_path_id}")
    print(f"Confidence: {result.confidence:.1%}")
    return result

result = asyncio.run(process())

# Learn from outcome
agent.learn({
    "request_id": request.request_id,
    "success": True,
    "selected_path_id": result.recommended_path_id,
    "execution_time_ms": 1500.0,
    "user_rating": 5,
})
```

### Section 6: Resonance API Usage

#### Python Client

```python
from application.resonance import ActivityResonance, ResonanceFeedback

def feedback_handler(feedback: ResonanceFeedback) -> None:
    print(f"State: {feedback.state} | {feedback.message}")

# Initialize
resonance = ActivityResonance(feedback_callback=feedback_handler)

# Start feedback loop
resonance.start_feedback_loop(interval=0.05)

# Process activity
feedback = resonance.process_activity(
    activity_type="code",
    query="create a new service",
    context={"urgency": True}
)

# Complete activity
resonance.complete_activity()
```

#### CLI Usage

```bash
# Basic usage
python -m application.resonance.cli "create a new service"

# With type
python -m application.resonance.cli "add authentication endpoint" --type code

# JSON output
python -m application.resonance.cli "implement feature" --json

# Show only paths
python -m application.resonance.cli "implement feature" --no-context

# Show only context
python -m application.resonance.cli "implement feature" --no-paths
```

#### PowerShell

```powershell
# Basic usage
.\application\resonance\resonance.ps1 "create a new service"

# With type
.\application\resonance\resonance.ps1 "add endpoint" -Type code

# JSON output
.\application\resonance\resonance.ps1 "configure" -Json

# With context
.\application\resonance\resonance.ps1 "implement" -Context '{"urgency": true}'
```

---

## Navigation Guide

### Finding User Engagement Features

#### Directory Structure

```
light_of_the_seven/
└── cognitive_layer/
    ├── __init__.py                  # Main exports
    ├── README.md                     # Overview
    ├── schemas/                      # Pydantic models
    │   ├── cognitive_state.py       # Cognitive state schema
    │   ├── decision_context.py      # Decision context schema
    │   └── user_cognitive_profile.py # User profile schema
    ├── decision_support/            # Decision-making tools
    │   ├── bounded_rationality_engine.py
    │   ├── choice_architecture.py
    │   ├── decision_matrix_generator.py
    │   └── dual_process_router.py
    ├── cognitive_load/              # Cognitive load management
    │   ├── cognitive_load_estimator.py
    │   ├── information_chunker.py
    │   └── scaffolding_manager.py
    ├── mental_models/               # Mental model tracking
    │   ├── alignment_checker.py
    │   ├── model_builder.py
    │   └── model_tracker.py
    ├── navigation/                  # Navigation system
    │   ├── enhanced_path_navigator.py
    │   ├── input_processor.py
    │   ├── agents/
    │   │   ├── path_optimization_agent.py
    │   │   └── agent_registry.py
    │   ├── learning/
    │   │   ├── adaptive_scorer.py
    │   │   └── learning_storage.py
    │   └── schemas/
    │       └── navigation_input.py
    └── integration/                 # Integration utilities
        ├── context_enricher.py
        ├── grid_bridge.py
        └── pipeline_adapter.py

application/
└── resonance/                       # Resonance API
    ├── README.md                    # API documentation
    ├── api/
    │   ├── router.py                # FastAPI endpoints
    │   ├── schemas.py               # Request/response schemas
    │   └── websocket.py             # WebSocket handlers
    ├── services/                    # Service layer
    └── repositories/                # Data access layer
```

### Key Files to Know

| File | Purpose | When to Use |
|------|---------|-------------|
| `user_cognitive_profile.py` | User profile schema | Creating user profiles |
| `cognitive_state.py` | Cognitive state snapshot | Tracking user cognitive state |
| `decision_context.py` | Decision context schema | Setting up decision scenarios |
| `dual_process_router.py` | System 1/2 routing | Choosing processing mode |
| `bounded_rationality_engine.py` | Bounded rationality | Efficient decision-making |
| `cognitive_load_estimator.py` | Load estimation | Preventing information overload |
| `enhanced_path_navigator.py` | Path navigation | Getting workflow recommendations |
| `alignment_checker.py` | Mental model alignment | Detecting user confusion |
| `resonance/api/router.py` | Resonance API | Real-time activity processing |

### Common Import Paths

```python
# Main cognitive layer imports
from light_of_the_seven.cognitive_layer import (
    UserCognitiveProfile,
    DecisionContext,
    CognitiveState,
    BoundedRationalityEngine,
    DualProcessRouter,
    CognitiveLoadEstimator,
    MentalModelTracker,
)

# Navigation system
from light_of_the_seven.cognitive_layer.navigation import (
    EnhancedPathNavigator,
    NavigationRequest,
    NavigationGoal,
    PathOptimizationAgent,
)

# Resonance API
from application.resonance import ActivityResonance
from application.resonance.services import ResonanceService
```

### Finding Documentation

| Topic | Location |
|-------|----------|
| Cognitive Layer Overview | `docs/COGNITIVE_LAYER.md` |
| Resonance API Guide | `docs/RESONANCE_API.md` |
| Navigation System | `light_of_the_seven/cognitive_layer/README.md` |
| User Profiles | `light_of_the_seven/cognitive_layer/schemas/user_cognitive_profile.py` |
| Architecture | `docs/architecture.md` |
| Quick Reference | `docs/GRID_QUICK_REFERENCE.md` |

### Search Tips

1. **Finding Examples**: Search for `test_` files in `tests/` directory
2. **API Usage**: Check `application/resonance/api/router.py` for endpoint examples
3. **Schema Definitions**: All Pydantic models are in `schemas/` directories
4. **Integration Patterns**: See `integration/` directories for adapters

---

## API Reference

### Resonance API Endpoints

#### POST `/api/v1/resonance/process`

Process an activity with left-to-right communication.

**Request**:
```json
{
  "query": "create a new service",
  "activity_type": "code",
  "context": {
    "urgency": true
  }
}
```

**Response**:
```json
{
  "activity_id": "act_123",
  "state": "active",
  "context": {
    "content": "Service context...",
    "metrics": {
      "sparsity": 0.3,
      "attention_tension": 0.5,
      "decision_pressure": 0.4
    }
  },
  "paths": {
    "goal": "create a new service",
    "total_options": 4,
    "recommended": {
      "id": "incremental",
      "name": "Incremental Build",
      "complexity": "moderate",
      "estimated_time": 10.0,
      "confidence": 0.9
    }
  }
}
```

#### POST `/api/v1/resonance/definitive`

Definitive (canvas flip) step for mid-process alignment.

**Request**:
```json
{
  "query": "implement authentication",
  "progress": 0.65,
  "target_schema": "resonance",
  "use_rag": true,
  "use_llm": true
}
```

#### GET `/api/v1/resonance/context`

Get fast context snapshot.

#### GET `/api/v1/resonance/paths`

Get path triage options.

#### WebSocket `/api/v1/resonance/ws`

Real-time activity updates.

### Navigation API

#### `EnhancedPathNavigator.navigate_simple(query: str) -> NavigationPlan`

Simple string-based navigation.

```python
navigator = EnhancedPathNavigator()
plan = navigator.navigate_simple("Fix memory leak")
```

#### `EnhancedPathNavigator.navigate(request: NavigationRequest) -> NavigationPlan`

Structured navigation request.

```python
request = NavigationRequest(
    goal=NavigationGoal(
        goal_type=GoalType.DEBUGGING,
        primary_objective="Fix memory leak"
    )
)
plan = navigator.navigate(request)
```

---

## Advanced Topics

### Custom Cognitive Profiles

```python
# Extend UserCognitiveProfile
from light_of_the_seven.cognitive_layer.schemas.user_cognitive_profile import (
    UserCognitiveProfile,
    ExpertiseLevel,
)

class CustomProfile(UserCognitiveProfile):
    custom_field: str = "default"

    def get_expertise_for_domain(self, domain: str) -> ExpertiseLevel:
        return self.domain_expertise.get(domain, self.expertise_level)
```

### Integration with GRID Pipeline

```python
from light_of_the_seven.cognitive_layer.integration.pipeline_adapter import (
    PipelineAdapter,
)

adapter = PipelineAdapter()
adapter.set_user_profile(user_profile)

# Wrap a pipeline stage
def ner_stage(text: str, max_entities: int = 50) -> dict:
    # ... NER implementation
    return {"entities": []}

cognitive_ner = adapter.wrap_pipeline_stage("ner", ner_stage)
result = cognitive_ner("Hello world")  # Automatically adapts parameters
```

### Learning System Customization

```python
from light_of_the_seven.cognitive_layer.navigation.learning.adaptive_scorer import (
    AdaptiveScorer,
)

scorer = AdaptiveScorer(
    initial_weights={
        "complexity": 0.3,
        "confidence": 0.4,
        "time": 0.2,
        "user_feedback": 0.1,
    }
)

# Custom scoring function
def custom_score(path, context):
    base_score = scorer.score(path, context)
    # Add custom logic
    return base_score * custom_factor
```

---

## Best Practices

### 1. User Profile Management

- ✅ **Create profiles early**: Initialize user profiles at the start of sessions
- ✅ **Update regularly**: Keep profiles current with user interactions
- ✅ **Respect privacy**: Only store necessary information
- ✅ **Provide defaults**: Have sensible defaults for new users

### 2. Cognitive Load Management

- ✅ **Monitor load**: Regularly estimate cognitive load
- ✅ **Chunk information**: Break large results into manageable pieces
- ✅ **Progressive disclosure**: Show details based on expertise
- ✅ **Provide scaffolding**: Offer help for novices, shortcuts for experts

### 3. Decision Support

- ✅ **Route appropriately**: Use dual-process routing for optimal speed
- ✅ **Apply bounded rationality**: Don't over-optimize simple decisions
- ✅ **Frame choices well**: Use appropriate framing (gain/loss/neutral)
- ✅ **Suggest defaults**: Provide sensible defaults

### 4. Mental Model Alignment

- ✅ **Track interactions**: Monitor user interactions for patterns
- ✅ **Check alignment**: Regularly verify user understanding
- ✅ **Explain mismatches**: Provide clear explanations when misalignments occur
- ✅ **Update models**: Evolve mental models as users learn

### 5. Navigation System

- ✅ **Learn from feedback**: Collect and incorporate user feedback
- ✅ **Provide multiple paths**: Offer 3-4 path options
- ✅ **Show confidence**: Display confidence scores
- ✅ **Explain reasoning**: Provide reasoning for recommendations

---

## Troubleshooting

### Common Issues

#### Issue: User profile not being applied

**Solution**:
- Verify profile is correctly initialized
- Check that profile is passed to cognitive functions
- Ensure profile has required fields set

```python
# Debug profile
print(f"Profile: {user_profile}")
print(f"Expertise: {user_profile.expertise_level}")
print(f"Decision Style: {user_profile.decision_style}")
```

#### Issue: Navigation recommendations not improving

**Solution**:
- Ensure learning is enabled: `navigator = EnhancedPathNavigator(enable_learning=True)`
- Provide feedback after path selection
- Check learning storage is configured correctly

```python
# Check learning status
print(f"Learning enabled: {navigator.enable_learning}")
print(f"Learning storage: {navigator.learning_storage}")
```

#### Issue: High cognitive load warnings

**Solution**:
- Reduce information density
- Use chunking for large results
- Apply progressive disclosure
- Simplify language for novices

```python
# Debug load
load = estimator.estimate_load(characteristics, user_profile)
print(f"Load: {load.estimated_load}/10")
print(f"Suggestions: {estimator.suggest_load_reduction(load, user_profile)}")
```

#### Issue: Mental model misalignments

**Solution**:
- Check alignment regularly
- Provide clear explanations
- Update user's mental model
- Use examples and analogies

```python
# Check alignment
alignment = checker.check_alignment(expected, actual, user_profile)
if not alignment.is_aligned:
    print(f"Mismatches: {alignment.mismatches}")
    print(f"Explanations: {alignment.suggested_explanations}")
```

### Getting Help

- **Documentation**: Check `docs/COGNITIVE_LAYER.md` and `docs/RESONANCE_API.md`
- **Code Examples**: See `tests/` directory for usage examples
- **API Documentation**: Run server and visit `/docs` for interactive API docs
- **Issues**: Check project issue tracker

---

## Quick Reference Card

### Essential Imports

```python
from light_of_the_seven.cognitive_layer import (
    UserCognitiveProfile, DecisionContext, DualProcessRouter,
    BoundedRationalityEngine, CognitiveLoadEstimator
)
from light_of_the_seven.cognitive_layer.navigation import (
    EnhancedPathNavigator, NavigationRequest
)
from application.resonance import ActivityResonance
```

### Common Patterns

```python
# 1. Create user profile
user = UserCognitiveProfile(user_id="user_123")

# 2. Route decision
router = DualProcessRouter()
mode = router.get_processing_mode(decision, user)

# 3. Estimate load
load = CognitiveLoadEstimator().estimate_load(op, user)

# 4. Navigate path
navigator = EnhancedPathNavigator()
plan = navigator.navigate_simple("your goal")
```

### Key Metrics

- **Cognitive Load**: 0-10 scale (target < 7)
- **Confidence**: 0-1 scale (target > 0.8)
- **Alignment**: 0-1 scale (target > 0.9)
- **Path Accuracy**: >95% (learning system)

---

## Conclusion

The GRID user engagement system provides powerful tools for creating tailored, adaptive user experiences. By leveraging cognitive decision support, personalized navigation, and real-time resonance feedback, you can build systems that adapt to individual user needs while maintaining high performance and user satisfaction.

For more information, see:
- `docs/COGNITIVE_LAYER.md` - Detailed cognitive layer guide
- `docs/RESONANCE_API.md` - Resonance API documentation
- `light_of_the_seven/cognitive_layer/README.md` - Navigation system overview

---

**Document Version**: 1.0.0
**Last Updated**: January 7, 2026
**Maintainer**: GRID Development Team
