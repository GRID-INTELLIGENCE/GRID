"""
DATABRICKS INTEGRATION - QUICK REFERENCE GUIDE

For GRID developers - minimal setup and usage guide.
"""

# ┌─────────────────────────────────────────────────────────────────────────────┐

# │ QUICK START (5 MINUTES) │

# └─────────────────────────────────────────────────────────────────────────────┘

# Step 1: Set Environment Variables

export DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
export DATABRICKS_TOKEN=dapi1234567890abcdef

# OR use custom 'databricks' variable (also supported):

export databricks=dapi1234567890abcdef

# Step 2: Import and Use

from src.integration.databricks import DatabricksClient, DatabricksJobsManager

# Step 3: Initialize

client = DatabricksClient() # Reads env vars automatically

# Step 4: Use the client

jobs_mgr = DatabricksJobsManager(client)
run_id = jobs_mgr.run_job(job_id="12345")
status = jobs_mgr.get_run_status(run_id)

# ┌─────────────────────────────────────────────────────────────────────────────┐

# │ COMMON OPERATIONS │

# └─────────────────────────────────────────────────────────────────────────────┘

from src.integration.databricks import (
DatabricksClient,
DatabricksJobsManager,
DatabricksClustersManager,
DatabricksNotebooksManager
)

# Initialize

client = DatabricksClient()
jobs_mgr = DatabricksJobsManager(client)
clusters_mgr = DatabricksClustersManager(client)
notebooks_mgr = DatabricksNotebooksManager(client)

# ─────────────────────────────────────────────────────────────────────────────

# CLUSTERS

# ─────────────────────────────────────────────────────────────────────────────

# List all clusters

clusters = client.list_clusters()
for c in clusters:
print(f"{c['cluster_name']}: {c['state']}")

# Get specific cluster

cluster = client.get_cluster("cluster-id-123")

# Start/stop cluster

clusters_mgr.start_cluster("cluster-id-123")
clusters_mgr.stop_cluster("cluster-id-123")

# ─────────────────────────────────────────────────────────────────────────────

# JOBS

# ─────────────────────────────────────────────────────────────────────────────

# Create a notebook job

job_id = jobs_mgr.create_notebook_job(
job_name="my-job",
notebook_path="/Repos/user/repo/notebook.ipynb",
cluster_id="cluster-123",
base_parameters={"param1": "value1"}
)

# Run the job

run_id = jobs_mgr.run_job(job_id, notebook_params={"param1": "new_value"})

# Get job status

status = jobs_mgr.get_run_status(run_id)
print(f"State: {status['state']}")
print(f"Result: {status['result_state']}")

# List all jobs

jobs = jobs_mgr.list_jobs()

# Delete job

jobs_mgr.delete_job(job_id)

# ─────────────────────────────────────────────────────────────────────────────

# NOTEBOOKS

# ─────────────────────────────────────────────────────────────────────────────

# List directory

items = notebooks_mgr.list_directory("/Repos")

# Read notebook

content = notebooks_mgr.read_notebook("/Repos/user/repo/notebook.ipynb")

# Write notebook

notebooks_mgr.write_notebook(
"/Repos/user/repo/new.ipynb",
"# Code here\nprint('hello')"
)

# Delete notebook

notebooks_mgr.delete_notebook("/Repos/user/repo/notebook.ipynb")

# ┌─────────────────────────────────────────────────────────────────────────────┐

# │ AUTHENTICATION OPTIONS │

# └─────────────────────────────────────────────────────────────────────────────┘

# Option 1: Environment variables (RECOMMENDED)

# DATABRICKS_HOST=https://...

# DATABRICKS_TOKEN=dapi...

client = DatabricksClient()

# Option 2: Custom 'databricks' env var

# DATABRICKS_HOST=https://...

# databricks=dapi...

client = DatabricksClient() # Still works!

# Option 3: Explicit parameters (for scripts)

client = DatabricksClient(
host="https://your-workspace.cloud.databricks.com",
token="dapi1234567890abcdef"
)

# Option 4: Databricks CLI profile

# Run: databricks configure --token

# Then:

client = DatabricksClient(profile="my-profile")

# ┌─────────────────────────────────────────────────────────────────────────────┐

# │ ERROR HANDLING PATTERNS │

# └─────────────────────────────────────────────────────────────────────────────┘

import logging
from src.integration.databricks import DatabricksClient

logger = logging.getLogger(**name**)

try:
client = DatabricksClient()
except ValueError as e:
logger.error(f"Configuration error: {e}") # Check DATABRICKS_HOST and databricks env vars

try:
cluster = client.get_cluster("invalid-id")
if cluster is None:
logger.warning("Cluster not found")
except Exception as e:
logger.error(f"Failed to get cluster: {e}")

# ┌─────────────────────────────────────────────────────────────────────────────┐

# │ TESTING WITH MOCKS │

# └─────────────────────────────────────────────────────────────────────────────┘

from unittest.mock import patch, Mock

# Mock the WorkspaceClient to test without credentials

with patch("src.integration.databricks.client.WorkspaceClient") as mock_ws:
mock_client = Mock()
mock_ws.return_value = mock_client
mock_client.workspaces.get_status.return_value = Mock(
workspace_name="test-workspace"
)

    # Now DatabricksClient() won't hit real Databricks API
    client = DatabricksClient()
    assert client is not None

# ┌─────────────────────────────────────────────────────────────────────────────┐

# │ IN GRID CONTEXT (ARCHITECTURE) │

# └─────────────────────────────────────────────────────────────────────────────┘

# As a Skill

from src.grid.skills import Skill

class DataProcessingSkill(Skill):
def run(self, args: dict) -> dict:
from src.integration.databricks import DatabricksJobsManager

        client = DatabricksClient()
        jobs_mgr = DatabricksJobsManager(client)

        # Submit to Databricks
        run_id = jobs_mgr.run_job("job-123")

        # Monitor
        status = jobs_mgr.get_run_status(run_id)

        return {"run_id": run_id, "status": status}

# In a Service

from src.grid.agentic.agent import Agent

class AnalyticsAgent(Agent):
def analyze_large_dataset(self, path: str):
client = DatabricksClient()
jobs_mgr = DatabricksJobsManager(client)

        # Create job for this task
        job_id = jobs_mgr.create_notebook_job(
            job_name="analytics-task",
            notebook_path="/Repos/grid/analytics.ipynb",
            cluster_id="cluster-prod",
            base_parameters={"input": path}
        )

        # Run and wait
        run_id = jobs_mgr.run_job(job_id)
        return self.wait_for_completion(run_id)

# ┌─────────────────────────────────────────────────────────────────────────────┐

# │ RUNNING TESTS │

# └─────────────────────────────────────────────────────────────────────────────┘

# Run all Databricks tests

python -m pytest tests/unit/test_databricks_integration.py -v

# Run specific test class

python -m pytest tests/unit/test_databricks_integration.py::TestDatabricksClientAuthentication -v

# Run specific test

python -m pytest tests/unit/test_databricks_integration.py::TestDatabricksClientAuthentication::test_client_uses_databricks_env_var -v

# Run with coverage

python -m pytest tests/unit/test_databricks_integration.py --cov=src.integration.databricks --cov-report=html

# ┌─────────────────────────────────────────────────────────────────────────────┐

# │ DOCUMENTATION │

# └─────────────────────────────────────────────────────────────────────────────┘

"""
Detailed Docs:

- docs/integration/DATABRICKS_ARCHITECTURE.md - Full architectural analysis
- docs/integration/DATABRICKS_TESTING_SUMMARY.md - Testing & validation
- examples/databricks_sdk_example.py - Complete example script
- tests/unit/test_databricks_integration.py - Test examples

API Reference:

- src/integration/databricks/client.py - DatabricksClient
- src/integration/databricks/jobs.py - DatabricksJobsManager
- src/integration/databricks/clusters.py - DatabricksClustersManager
- src/integration/databricks/notebooks.py - DatabricksNotebooksManager
- src/integration/databricks/cli.py - CLI commands
  """

# ┌─────────────────────────────────────────────────────────────────────────────┐

# │ KEY POINTS │

# └─────────────────────────────────────────────────────────────────────────────┘

"""
✅ Environment Variables:

- DATABRICKS_HOST: Workspace URL (required)
- DATABRICKS_TOKEN: API token (standard)
- databricks: API token (custom, also supported)
- Priority: explicit arg > DATABRICKS_TOKEN > databricks > profile

✅ Managers:

- DatabricksJobsManager: Job creation and execution
- DatabricksClustersManager: Cluster lifecycle
- DatabricksNotebooksManager: Notebook operations

✅ Design:

- Stateless instances (safe for concurrent use)
- Dependency injection (easy to test)
- Comprehensive logging
- Error handling with proper exceptions

✅ Testing:

- 24 unit tests covering all major operations
- Mock patterns for testing without credentials
- Environment variable handling tested

✅ Integration:

- Works with grid.skills
- Works with grid.agentic
- Works with grid.workflow
- CLI commands available via databricks-cli

Performance:

- Use local for <10GB data
- Use Databricks for >100GB data
- Setup time: ~100ms-10s
- Job submit latency: ~100-500ms
  """
