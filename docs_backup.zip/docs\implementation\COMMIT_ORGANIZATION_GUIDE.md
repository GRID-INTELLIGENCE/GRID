# Commit Organization Guide

This guide helps organize the 300+ unstaged files into logical, focused commits.

## Current Status

**Total unstaged files**: 302

**Breakdown by category**:
- **Python code**: 102 files
- **Documentation**: 43 files
- **Config**: 11 files
- **Deleted**: 13 files
- **Tests**: 3 files
- **Other**: 1 file

## Commit Strategy

### Phase 1: Cleanup (Low Risk)
1. **Deleted files** (13 files)
   ```powershell
   git add -u  # Stage all deletions
   git commit -m "chore: remove deleted files"
   ```

2. **Generated files** (if any tracked)
   - Already handled by .gitignore
   - No action needed

### Phase 2: Documentation (Single Commit)
3. **Documentation** (43 files)
   ```powershell
   git add docs/ archive/legacy/pipeline/README.md config/*/README.md
   git commit -m "docs: update documentation across project"
   ```

### Phase 3: Configuration (Separate Commit)
4. **Config files** (11 files)
   ```powershell
   git add config/ data/*.json archive/*/data/*.json
   git commit -m "chore: update configuration files"
   ```

### Phase 4: Code Changes (Grouped by Module)
5. **Python code** (102 files) - Split into logical groups:

   **Group A: Core application** (~20 files)
   ```powershell
   git add src/application/
   git commit -m "refactor: update application layer code"
   ```

   **Group B: Grid core** (~20 files)
   ```powershell
   git add src/grid/
   git commit -m "refactor: update grid core modules"
   ```

   **Group C: Cognitive layer** (~10 files)
   ```powershell
   git add src/cognitive/
   git commit -m "refactor: update cognitive layer"
   ```

   **Group D: Archive/legacy** (~52 files)
   ```powershell
   git add archive/
   git commit -m "chore: update archive and legacy code"
   ```

### Phase 5: Tests
6. **Test files** (3 files)
   ```powershell
   git add tests/ **/test_*.py
   git commit -m "test: update test files"
   ```

## Using the Helper Script

The `scripts/organize_commits.ps1` script automates this process:

```powershell
# List categories only
.\scripts\organize_commits.ps1 -ListOnly

# Dry run (shows what would be committed)
.\scripts\organize_commits.ps1 -DryRun

# Process specific category
.\scripts\organize_commits.ps1 -Category "documentation" -DryRun:$false

# Process all categories (interactive)
.\scripts\organize_commits.ps1 -DryRun:$false
```

## Commit Message Format

Follow conventional commits:
- `chore:` - Maintenance tasks, config changes
- `docs:` - Documentation updates
- `refactor:` - Code refactoring
- `fix:` - Bug fixes
- `test:` - Test updates
- `feat:` - New features (if applicable)

## Best Practices

1. **Review before committing**: Use `git diff --cached` to review staged changes
2. **Small batches**: Max 10-20 files per commit
3. **Logical grouping**: Related changes together
4. **Separate concerns**: Don't mix lint fixes with feature work
5. **Clear messages**: Describe what changed and why

## Verification

After organizing commits:
```powershell
# Check remaining unstaged files
git status --short | Measure-Object -Line

# Review commit history
git log --oneline -10

# Verify no large commits
git log --stat --oneline -5
```

## Notes

- Archive files may be candidates for separate branch or stashing
- Deleted files should be reviewed to ensure they're intentionally removed
- Config files with secrets should be carefully reviewed before committing
- Documentation commits are safe and can be done in one batch
