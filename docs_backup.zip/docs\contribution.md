# Contribution Guidelines

We welcome contributions! Here's how you can help:

- Fork the repository
- Create a new branch
- Make your changes
- Submit a pull request

![Figure 1](file:///C:/Users/irfan/OneDrive/Pictures/Figure_1.png)
