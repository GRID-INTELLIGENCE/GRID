# Complete RAG Flow Documentation

## Overview

GRID implements a multi-layered RAG (Retrieval Augmented Generation) system that spans from low-level retrieval (`tools/rag/`) through knowledge orchestration (`grid/knowledge/`) to skill execution (`grid/skills/`). This document traces the complete flow from indexing to query execution.

## Architecture Layers

```
┌─────────────────────────────────────────────────────────────┐
│                    Skills Layer                              │
│  (grid/skills/rag_query_knowledge.py)                       │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│               Integration Bridge Layer                       │
│  (grid/integration/tools_bridge.py)                         │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              Knowledge Orchestration Layer                   │
│  (grid/knowledge/*)                                         │
│  - multi_model_orchestrator.py                              │
│  - reasoning_orchestrator.py                                │
│  - structural_learning.py                                   │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                    RAG Engine Layer                          │
│  (tools/rag/rag_engine.py)                                  │
│  - indexer.py                                                │
│  - retriever.py                                              │
│  - hybrid_retriever.py                                       │
│  - reranker.py                                               │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              Component Providers Layer                       │
│  - embeddings/factory.py                                     │
│  - llm/factory.py                                            │
│  - vector_store/*                                            │
└─────────────────────────────────────────────────────────────┘
```

## Flow 1: Indexing (Repository → Vector Store)

### Entry Point
- **CLI**: `python -m tools.rag.cli index <repo_path>`
- **Programmatic**: `RAGEngine.index(repo_path, rebuild=False)`

### Steps

1. **Configuration Load** (`tools/rag/config.py`)
   - Load `RAGConfig` from environment variables
   - Default: Local-only mode (Ollama for embeddings and LLM)
   - Validate Ollama connection
   - Auto-detect available models

2. **Embedding Provider Initialization** (`tools/rag/embeddings/factory.py`)
   - Factory pattern for embedding providers
   - Options:
     - **Ollama**: Local embeddings via Ollama API (Nomic Embed Text v2)
     - **HuggingFace**: Sentence transformers
     - **Custom**: Custom embedding providers
   - Returns: `BaseEmbeddingProvider` instance

3. **Vector Store Initialization** (`tools/rag/vector_store/*`)
   - Options:
     - **ChromaDB**: Local vector database (default)
     - **Databricks**: Cloud vector store
     - **In-Memory**: Ephemeral storage for testing
   - Creates/loads collection with dimension validation

4. **Indexing** (`tools/rag/indexer.py`)
   - **File Discovery**: Walk repository, apply filters (exclude_dirs, include_patterns)
   - **File Reading**: Read source files with encoding detection
   - **Quality Assessment**: Filter files by quality threshold (optional)
   - **Chunking**: 
     - Split text into chunks (default: 512 tokens, 50 overlap)
     - Preserve code structure (language-aware splitting)
     - Maintain metadata (file path, line numbers)
   - **Embedding Generation**: 
     - Generate embeddings for each chunk via embedding provider
     - Dimension validation (ensure consistency)
   - **Vector Storage**: 
     - Store chunks + embeddings + metadata in vector store
     - Batch operations for efficiency
   - **Progress Tracking**: MLflow integration for indexing metrics

5. **Metadata Storage**
   - Document-level metadata: file path, size, last modified
   - Chunk-level metadata: start line, end line, chunk index
   - Index-level metadata: embedding model, dimension, timestamp

### Output
- Vector store populated with embeddings and metadata
- Index ready for querying

## Flow 2: Query Execution (Query → Answer)

### Entry Point Options

#### Option A: Via Skill (`grid/skills/rag_query_knowledge.py`)
```python
skill = default_registry.get("rag.query_knowledge")
result = skill.run({"query": "How does X work?", "top_k": 5})
```

#### Option B: Via Tools Bridge (`grid/integration/tools_bridge.py`)
```python
bridge = get_tools_bridge()
engine = bridge.get_rag_engine()
result = engine.query(query_text="...", top_k=5)
```

#### Option C: Direct RAG Engine (`tools/rag/rag_engine.py`)
```python
engine = RAGEngine(config=RAGConfig.from_env())
result = engine.query(query_text="...", top_k=5, include_sources=True)
```

### Steps

1. **Query Preparation**
   - Validate query input
   - Check cache (if enabled)
   - Extract query intent (optional)

2. **Embedding Generation**
   - Generate embedding for query text
   - Use same embedding model as indexing
   - Dimension validation

3. **Retrieval** (`tools/rag/retriever.py` or `hybrid_retriever.py`)

   **Option A: Vector Retrieval (Default)**
   - Search vector store for similar chunks
   - Cosine similarity search
   - Return top-k results

   **Option B: Hybrid Retrieval** (if enabled)
   - Combine vector search + keyword search (BM25)
   - Weighted combination of results
   - Better recall for technical queries

4. **Reranking** (`tools/rag/reranker.py`) - Optional
   - Cross-encoder reranking for precision
   - Reorder results by relevance score
   - Filter low-confidence results

5. **Context Assembly**
   - Combine top-k retrieved chunks
   - Add metadata (file paths, line numbers)
   - Build context window for LLM

6. **Generation** (`tools/rag/llm/factory.py`)
   - **LLM Provider Selection**:
     - **Ollama**: Local LLM (default, e.g., mistral-nemo)
     - **OpenAI**: Cloud LLM (optional)
     - **Custom**: Custom LLM providers
   - **Prompt Construction**:
     - System prompt: Role definition
     - Context: Retrieved chunks with citations
     - Query: User question
   - **Generation**:
     - Stream completion from LLM
     - Temperature control (default: 0.7)
     - Max tokens limit

7. **Response Assembly**
   - Extract answer from LLM output
   - Include source citations
   - Calculate confidence scores
   - Add metadata (latency, token counts)

### Output
```python
{
    "answer": "Generated answer text",
    "sources": [
        {
            "path": "src/grid/knowledge/rag_engine.py",
            "distance": 0.15,
            "confidence": 0.93,
            "chunk": "Retrieved text chunk",
            "metadata": {...}
        }
    ],
    "retrieval_count": 5,
    "context_quality": 0.89,
    "latency_ms": 1234
}
```

## Flow 3: Knowledge Orchestration (`grid/knowledge/`)

### Multi-Model Orchestrator (`multi_model_orchestrator.py`)

Advanced orchestration using multiple LLM models as an expert panel.

**Process**:

1. **Navigation Insight**
   - Analyze query using territory map
   - Determine zone (Sovereign, Expert, Cognitive, Tools)
   - Identify relevant codebase areas

2. **Expert Selection**
   - Match available Ollama models to expertise profiles
   - Default profiles:
     - **mistral-nemo**: Primary Generalist (Sovereign Tier)
     - **codestral**: Expert Architect (Infrastructure Tier)
     - **llama3.1:8b**: Reasoning Specialist (Cognitive Tier)
     - **qwen2.5-coder**: Implementation Specialist (Tools Tier)
     - **deepseek-coder**: Code Analysis Expert (Infrastructure Tier)

3. **Parallel Inquiry**
   - Tailor prompts for each expert's specialty
   - Dispatch parallel LLM calls
   - Gather expert responses

4. **Synthesis**
   - Combine expert insights
   - Resolve conflicts
   - Generate consensus answer

**Use Case**: Complex queries requiring multiple perspectives

### Reasoning Orchestrator (`reasoning_orchestrator.py`)

Structured reasoning workflow with step-by-step analysis.

**Modes**:
- **SEQUENTIAL**: Step-by-step reasoning
- **PARALLEL**: Parallel exploration of reasoning paths
- **HYBRID**: Combination of sequential and parallel

**Process**:
1. Decompose query into reasoning steps
2. Execute steps (sequential or parallel)
3. Synthesize intermediate results
4. Generate final answer

**Use Case**: Multi-step reasoning tasks

### Structural Learning (`structural_learning.py`)

Pattern recognition and learning from codebase structure.

**Process**:
1. Extract structural patterns from codebase
2. Learn relationships between modules
3. Use patterns to guide retrieval
4. Improve query routing

**Use Case**: Understanding codebase architecture

## Flow 4: Skill Integration (`grid/skills/rag_query_knowledge.py`)

### Skill Definition

```python
rag_query_knowledge = SimpleSkill(
    id="rag.query_knowledge",
    name="RAG Knowledge Query",
    description="Query GRID's project knowledge base for documentation and context",
    handler=_query_knowledge,
)
```

### Skill Execution

1. **Bridge Access**
   ```python
   bridge = get_tools_bridge()  # grid/integration/tools_bridge.py
   engine = bridge.get_rag_engine()
   ```

2. **Query Execution**
   ```python
   result = engine.query(
       query_text=query,
       top_k=top_k,
       temperature=temperature,
       include_sources=True,
   )
   ```

3. **Response Normalization**
   - Convert RAG engine output to skill response format
   - Extract sources with confidence scores
   - Calculate context quality metrics

4. **Execution Tracking**
   - Track execution via `SkillExecutionTracker`
   - Persist to SQLite (batched)
   - Performance monitoring via `PerformanceGuard`

### Error Handling

- **Bridge Unavailable**: Returns error response
- **RAG Unavailable**: Returns error response
- **Query Missing**: Returns validation error
- **LLM Failure**: Returns error with details

## Configuration

### Environment Variables

**Core Configuration**:
- `RAG_EMBEDDING_PROVIDER`: `ollama` | `huggingface` (default: `ollama`)
- `RAG_EMBEDDING_MODEL`: Embedding model name (default: `nomic-embed-text-v2`)
- `RAG_LLM_MODE`: `local` | `openai` (default: `local`)
- `RAG_LLM_MODEL_LOCAL`: Local LLM model (default: `mistral-nemo:latest`)
- `RAG_LLM_MODEL_OPENAI`: OpenAI model (default: `gpt-4`)
- `RAG_VECTOR_STORE_PROVIDER`: `chromadb` | `databricks` | `in_memory` (default: `chromadb`)
- `RAG_COLLECTION_NAME`: Collection name (default: `grid_knowledge`)
- `RAG_VECTOR_STORE_PATH`: ChromaDB persistence path
- `OLLAMA_BASE_URL`: Ollama server URL (default: `http://localhost:11434`)

**Advanced Configuration**:
- `RAG_CHUNK_SIZE`: Chunk size in tokens (default: `512`)
- `RAG_CHUNK_OVERLAP`: Overlap size (default: `50`)
- `RAG_USE_HYBRID`: Enable hybrid retrieval (default: `false`)
- `RAG_USE_RERANKER`: Enable reranking (default: `false`)
- `RAG_CACHE_ENABLED`: Enable query cache (default: `true`)
- `RAG_CACHE_SIZE`: Cache size (default: `1000`)
- `RAG_CACHE_TTL`: Cache TTL in seconds (default: `3600`)

**Quality Thresholds**:
- `RAG_QUALITY_THRESHOLD`: Minimum file quality (0.0-1.0, default: `0.0`)

## Vector Store Providers

### ChromaDB (Default)

**Features**:
- Local persistence
- Fast similarity search
- Metadata filtering
- Collection management

**Configuration**:
```python
vector_store = ChromaDBVectorStore(
    collection_name="grid_knowledge",
    persist_directory="./.rag_db"
)
```

### Databricks

**Features**:
- Cloud-based storage
- Scalable to large codebases
- Integration with Databricks ecosystem

**Configuration**:
```python
vector_store = DatabricksVectorStore(
    chunk_table="rag_chunks",
    document_table="rag_documents",
    schema="default"
)
```

### In-Memory

**Features**:
- Ephemeral storage
- Fast for testing
- No persistence

**Configuration**:
```python
vector_store = InMemoryDenseVectorStore()
```

## Embedding Providers

### Ollama (Default)

**Model**: Nomic Embed Text v2 (768 dimensions)

**Advantages**:
- Local execution
- No API costs
- Privacy-preserving

**Requirements**:
- Ollama server running
- Model pulled: `ollama pull nomic-embed-text-v2`

### HuggingFace

**Models**: Sentence transformers (various)

**Advantages**:
- Wide model selection
- Offline operation possible

**Usage**:
```python
config.embedding_provider = "huggingface"
config.embedding_model = "sentence-transformers/all-MiniLM-L6-v2"
```

## LLM Providers

### Ollama (Default)

**Models**: mistral-nemo, codestral, llama3.1, qwen2.5, etc.

**Advantages**:
- Local execution
- Multiple model support
- No API costs

**Requirements**:
- Ollama server running
- Model pulled: `ollama pull mistral-nemo`

### OpenAI

**Models**: gpt-4, gpt-3.5-turbo

**Advantages**:
- High-quality responses
- Fast inference

**Requirements**:
- OpenAI API key
- Network connectivity

**Usage**:
```python
config.llm_mode = ModelMode.OPENAI
config.openai_api_key = "sk-..."
config.llm_model_openai = "gpt-4"
```

## Performance Optimization

### Caching

**Query Cache**: 
- Caches query → answer mappings
- Configurable TTL (default: 1 hour)
- Size limit (default: 1000 entries)

**Usage**: Automatic when `RAG_CACHE_ENABLED=true`

### Batch Operations

**Indexing**:
- Batch embedding generation
- Batch vector store inserts
- Progress tracking

### Hybrid Retrieval

**Combination**:
- Vector search (semantic similarity)
- Keyword search (BM25)
- Weighted combination

**Use Case**: Better recall for technical queries with specific terms

### Reranking

**Method**: Cross-encoder reranking

**Purpose**: Improve precision by reranking initial results

**Trade-off**: Slower but more accurate

## Observability

### MLflow Tracking

**Metrics Tracked**:
- Indexing: Files processed, chunks created, duration
- Querying: Latency, token counts, retrieval counts
- Model routing: Model selection, usage patterns

**Integration**: Automatic when MLflow available

### Logging

**Levels**:
- DEBUG: Detailed operation logs
- INFO: High-level progress
- WARNING: Issues (e.g., missing models)
- ERROR: Failures

### Metrics

**Prometheus** (when available):
- Query latency
- Cache hit rate
- Retrieval quality scores

## Error Handling

### Common Errors

1. **Ollama Not Running**
   - Error: "Ollama is not running or not accessible"
   - Solution: Start Ollama server (`ollama serve`)

2. **Model Not Found**
   - Error: "Model not found"
   - Solution: Pull model (`ollama pull <model>`)

3. **Dimension Mismatch**
   - Error: "Dimension mismatch between index and model"
   - Solution: Rebuild index with correct model

4. **Vector Store Unavailable**
   - Error: "Vector store not available"
   - Solution: Check configuration and permissions

5. **Empty Results**
   - Warning: "No results found"
   - Solution: Expand query or check index completeness

## Best Practices

1. **Indexing**:
   - Rebuild index when embedding model changes
   - Use quality thresholds to filter low-quality files
   - Exclude generated files (node_modules, __pycache__)

2. **Querying**:
   - Use specific, focused queries
   - Adjust top_k based on query complexity
   - Monitor cache hit rates

3. **Configuration**:
   - Use local models for privacy
   - Enable hybrid retrieval for technical queries
   - Use reranking for high-precision needs

4. **Performance**:
   - Enable caching for repeated queries
   - Use batch operations for bulk indexing
   - Monitor latency and adjust accordingly
