# Clean Git Workflow for Docker Fixes

## Current Situation
Your `fix/docker-mcp-stack-health-checks` branch has the Docker fixes but also includes many unrelated commits from other work. This is causing push issues due to large files.

## Recommended Solution: Create a Clean Branch

### Option 1: Cherry-Pick Only Docker Commits (RECOMMENDED)

```bash
# 1. Go back to main
git checkout main
git pull origin main

# 2. Create a fresh clean branch
git checkout -b fix/docker-stack-clean

# 3. Cherry-pick ONLY the Docker-related commits
git cherry-pick 0eb612bd  # fix(docker): resolve Nginx Windows bind-mount issue
git cherry-pick ad60509c  # feat(mcp): add HTTP health endpoints to all MCP servers
git cherry-pick 46b9edd3  # chore(docker): add development requirements file
git cherry-pick 5c247962  # test(outputs): fix JSON formatting test

# 4. Add the git workflow documentation
git add docs/GIT_WORKFLOW_DOCKER_FIXES.md
git commit -m "docs: add git workflow guide for Docker fixes"

# 5. Push the clean branch
git push -u origin fix/docker-stack-clean
```

### Option 2: Interactive Rebase (Advanced)

```bash
# WARNING: This rewrites history
git checkout fix/docker-mcp-stack-health-checks
git rebase -i origin/main

# In the editor, keep only these commits:
# - 0eb612bd fix(docker): resolve Nginx Windows bind-mount issue
# - ad60509c feat(mcp): add HTTP health endpoints to all MCP servers
# - 46b9edd3 chore(docker): add development requirements file
# - 5c247962 test(outputs): fix JSON formatting test
# Mark all others as 'drop' or delete those lines

# Then force push
git push --force-with-lease origin fix/docker-mcp-stack-health-checks
```

### Option 3: Reset and Re-commit (Simplest)

```bash
# 1. Create a backup branch
git branch backup/docker-fixes-attempt

# 2. Go to main
git checkout main
git pull origin main

# 3. Create fresh branch
git checkout -b fix/docker-stack-v2

# 4. Copy the changed files from your working directory
# (Make sure you have the Docker fixes in your working tree)

# 5. Stage only Docker-related files
git add docker/security/Dockerfile.nginx
git add docker/security/nginx-security.conf
git add docker/security/docker-compose-secure.yml
git commit -m "fix(docker): resolve Nginx Windows bind-mount issue

- Create Dockerfile.nginx to embed nginx-security.conf
- Update upstream names to use -secure suffix
- Remove problematic volume mount

Resolves: Nginx restart loop on Windows"

git add workspace/mcp/servers/filesystem/production_server.py
git add workspace/mcp/servers/memory/production_server.py
git add workspace/mcp/servers/postgres/production_server.py
git add workspace/mcp/servers/database/server.py
git add workspace/mcp/servers/playwright/server.py
git commit -m "feat(mcp): add HTTP health endpoints to all MCP servers

- Implement aiohttp health server on port 8080
- Add /health endpoint for Docker health checks
- Keep processes alive with asyncio.Event().wait()

Resolves: Container restart loops in daemon mode"

git add docker/requirements-dev.txt
git commit -m "chore(docker): add development requirements file

Resolves: Missing file in Dockerfile.dev"

git add tests/unit/test_outputs.py
git commit -m "test(outputs): fix JSON formatting test to match pretty-printed output"

git add docs/GIT_WORKFLOW_DOCKER_FIXES.md
git commit -m "docs: add git workflow guide for Docker fixes"

# 6. Push clean branch
git push -u origin fix/docker-stack-v2
```

## Quick Fix for Current Branch

If you want to try pushing the current branch one more time:

```bash
# 1. Make sure large files are excluded
echo "EUFLE/rag/vector_store/faiss_index_docs.json" >> .gitignore
git add .gitignore
git commit -m "chore: exclude large vector store files"

# 2. Try pushing with increased buffer
git config http.postBuffer 524288000
git push -u origin fix/docker-mcp-stack-health-checks
```

## Recommended Next Steps

1. **Use Option 1 (Cherry-Pick)** - This is the cleanest and safest approach
2. Create a PR from the clean branch
3. Keep your original branch for other work
4. After the Docker fixes are merged, you can rebase your other work on top of main

## Files Changed in Docker Fixes

The Docker fixes only touch these files:
- `docker/security/Dockerfile.nginx` (new)
- `docker/security/nginx-security.conf` (modified)
- `docker/security/docker-compose-secure.yml` (modified)
- `docker/requirements-dev.txt` (new)
- `workspace/mcp/servers/filesystem/production_server.py` (modified)
- `workspace/mcp/servers/memory/production_server.py` (modified)
- `workspace/mcp/servers/postgres/production_server.py` (modified)
- `workspace/mcp/servers/database/server.py` (modified)
- `workspace/mcp/servers/playwright/server.py` (modified)
- `tests/unit/test_outputs.py` (modified)
- `docs/GIT_WORKFLOW_DOCKER_FIXES.md` (new)

Everything else is unrelated and should be in a separate PR.
