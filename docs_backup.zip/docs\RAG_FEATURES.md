# GRID RAG System - New Features Documentation

## Overview

The GRID RAG (Retrieval-Augmented Generation) system has been enhanced with several new features for improved performance, flexibility, and local-only operation.

## New Features

### 1. On-Demand RAG Engine

**Location**: `src/tools/rag/on_demand_engine.py`

**Description**: Query-time RAG engine that builds ephemeral indexes from docs/ (and optional codebase) per query, eliminating the need for persistent indexing.

**Key Features**:
- **Hooks System**: Extensible hooks for monitoring and debugging
  - `on_route`: Called when model routing decision is made
  - `on_seed_files`: Called when initial file scope is determined
  - `on_expand_files`: Called during recursive scope expansion
  - `on_chunked`: Called after chunking is complete
  - `on_embedded`: Called after embeddings are generated
  - `on_retrieved`: Called after retrieval is complete
  - `on_prompt`: Called before LLM prompt is sent

- **Recursive Scope Expansion**: Automatically expands search scope based on retrieved content
  - Starts with docs/ directory
  - Optionally includes codebase with `--include-codebase`
  - Pattern-based expansion for related files
  - Configurable depth levels (default: 0)

- **Prefiltering**: Efficient file selection before expensive embedding
  - Scans first 64KB of files for relevance
  - Selects top K candidates (default: 50)
  - Reduces embedding overhead

**Usage**:
```bash
# Basic query
python -m tools.rag.cli ondemand "How does the cognitive layer work?"

# With recursive expansion
python -m tools.rag.cli ondemand "Query" --depth 2

# Include codebase in search
python -m tools.rag.cli ondemand "Query" --include-codebase

# Custom parameters
python -m tools.rag.cli ondemand "Query" \
  --prefilter-k-files 100 \
  --max-chunks 3000 \
  --max-files 800
```

**Python API**:
```python
from tools.rag.on_demand_engine import OnDemandRAGEngine, RAGHooks

# Define hooks
hooks = RAGHooks(
    on_route=lambda query, routing: print(f"Routing: {routing}"),
    on_retrieved=lambda results: print(f"Retrieved {len(results)} chunks")
)

engine = OnDemandRAGEngine(
    docs_root="docs",
    repo_root=".",
    hooks=hooks
)

result = engine.query(
    query_text="Your question",
    depth=1,
    top_k=10
)

print(result.answer)
print(result.routing)
print(result.stats)
```

### 2. Cross-Encoder Reranking

**Location**: `src/tools/rag/cross_encoder_reranker.py`

**Description**: Uses sentence-transformers cross-encoder for more accurate and faster reranking compared to LLM-based methods.

**Key Features**:
- **Fast Batch Processing**: Scores multiple documents in parallel
- **Model**: Uses `ms-marco-MiniLM-L6-v2` by default (fast and accurate)
- **Configurable**: Supports custom models and candidate limits
- **Optional**: Gracefully degrades if sentence-transformers not installed

**Configuration**:
```bash
# Environment variables
export RAG_USE_RERANKER=true
export RAG_RERANKER_TYPE=cross_encoder
export RAG_CROSS_ENCODER_MODEL=cross-encoder/ms-marco-MiniLM-L6-v2
export RAG_RERANKER_TOP_K=20
```

**Python API**:
```python
from tools.rag.cross_encoder_reranker import CrossEncoderReranker

reranker = CrossEncoderReranker(
    model_name="cross-encoder/ms-marco-MiniLM-L6-v2",
    max_candidates=20
)

# Rerank documents
results = reranker.rerank(
    query="Your query",
    documents=["doc1", "doc2", ...],
    top_k=5
)
```

### 3. Hybrid Search

**Location**: `src/tools/rag/enhanced/embeddings.py`

**Description**: Combines semantic vector search with keyword-based BM25 search for improved recall.

**Key Features**:
- **Semantic Search**: Vector-based similarity using embeddings
- **Keyword Search**: BM25-style keyword matching
- **Combined Scoring**: Weighted combination (70% semantic, 30% keyword)
- **Reranking Boost**: Additional boost based on query relevance factors

**Reranking Factors**:
- Exact query matches: 1.2x boost
- Code chunks for technical queries: 1.1x boost
- High semantic density: 1.05x boost
- Recent documents: 1.05x boost

**Usage**:
```bash
# Enable hybrid search
export RAG_USE_HYBRID=true

# Query with hybrid search
python -m tools.rag.cli query "Your question" --hybrid
```

### 4. Enhanced Embeddings with Metadata

**Location**: `src/tools/rag/enhanced/embeddings.py`

**Description**: Creates embeddings enriched with semantic features for better retrieval.

**Key Features**:
- **Semantic Chunking**: Intelligently splits text based on semantic boundaries
  - Detects sections, paragraphs, code blocks, lists
  - Preserves context and meaning

- **Chunk Metadata**: Rich metadata for each chunk
  - `chunk_index`: Position in document
  - `total_chunks`: Total number of chunks
  - `chunk_type`: paragraph, code, list, etc.
  - `semantic_density`: Information density score
  - `technical_terms_count`: Number of technical terms
  - `position_ratio`: Relative position in document

- **Enhanced Embeddings**: Combines base embeddings with semantic features
  - 90% base embedding + 10% semantic features
  - Improves retrieval for technical content

**Chunk Types**:
- `paragraph`: Standard text paragraphs
- `code`: Code blocks and examples
- `list`: Bulleted or numbered lists

**Python API**:
```python
from tools.rag.enhanced.embeddings import EnhancedRAG, RetrievalConfig

config = RetrievalConfig(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    chunk_size=512,
    chunk_overlap=50,
    enable_semantic_chunking=True,
    enable_hybrid_search=True
)

rag = EnhancedRAG(config=config)

# Index document
ids = rag.index_document(
    text="Document content",
    metadata={"doc_id": "doc1", "title": "My Document"}
)

# Search
results = rag.hybrid_search("Your query", top_k=10)
```

### 5. Model Routing and Fallback

**Location**: `src/tools/rag/model_router.py`

**Description**: Intelligent model routing with automatic fallback for reliability.

**Key Features**:
- **Automatic Model Selection**: Chooses best available models
- **Ollama Detection**: Checks if Ollama is accessible
- **Graceful Degradation**: Falls back to simpler models if needed
- **Local-Only Enforcement**: Ensures no cloud dependencies

**Routing Logic**:
1. Check Ollama connection
2. Find available embedding models
3. Find available LLM models
4. Route to appropriate providers
5. Fall back to SimpleLLM if Ollama unavailable

**Usage**:
```python
from tools.rag.model_router import route_models

routing = route_models(
    query_text="Your query",
    base_config=config,
    prefer_ollama=True
)

print(f"Embedding: {routing.embedding_provider}")
print(f"LLM: {routing.llm_provider}")
print(f"Reason: {routing.reason}")
```

### 6. Query Caching

**Location**: `src/tools/rag/cache.py`

**Description**: Caches query results to improve performance for repeated queries.

**Key Features**:
- **TTL Support**: Configurable time-to-live
- **Size Limits**: Maximum cache size
- **Cache Keys**: Based on query, top_k, source_ids, chunk_count
- **Automatic Expiration**: Old entries removed

**Configuration**:
```bash
export RAG_CACHE_ENABLED=true
export RAG_CACHE_SIZE=100
export RAG_CACHE_TTL=3600
```

**Python API**:
```python
from tools.rag.cache import QueryCache

cache = QueryCache(
    max_size=100,
    ttl_seconds=3600,
    collection_name="grid_knowledge_base"
)

# Check cache
cached = cache.get(
    query="Your query",
    top_k=10,
    source_ids=["id1", "id2"],
    chunk_count=100
)

if cached:
    return cached

# Set cache
cache.set(
    query="Your query",
    top_k=10,
    source_ids=["id1", "id2"],
    chunk_count=100,
    answer="Generated answer",
    sources=[...]
)
```

### 7. Evaluation Metrics

**Location**: `src/tools/rag/evaluation.py`

**Description**: Comprehensive evaluation framework for RAG performance.

**Key Metrics**:
- **Retrieval Quality**: Measures relevance of retrieved documents
- **Answer Quality**: Evaluates generated responses
- **Latency**: Tracks query processing time
- **Cache Hit Rate**: Measures cache effectiveness

**Usage**:
```bash
# Evaluate RAG performance
python -m tools.rag.cli evaluate --config eval_config.json

# Evaluate specific queries
python -m tools.rag.cli evaluate --queries "query1" "query2" "query3"
```

## Configuration Reference

### Environment Variables

```bash
# Embedding Configuration
RAG_EMBEDDING_MODEL=nomic-embed-text:latest
RAG_EMBEDDING_MODE=local
RAG_EMBEDDING_PROVIDER=ollama

# LLM Configuration
RAG_LLM_MODEL_LOCAL=ministral-3:3b
RAG_LLM_MODE=local

# Vector Store Configuration
RAG_VECTOR_STORE_PROVIDER=chromadb
RAG_VECTOR_STORE_PATH=.rag_db
RAG_COLLECTION_NAME=grid_knowledge_base

# Chunking Configuration
RAG_CHUNK_SIZE=1000
RAG_CHUNK_OVERLAP=100

# Retrieval Configuration
RAG_TOP_K=10
RAG_SIMILARITY_THRESHOLD=0.0

# Hybrid Search
RAG_USE_HYBRID=true

# Reranking
RAG_USE_RERANKER=true
RAG_RERANKER_TYPE=cross_encoder
RAG_CROSS_ENCODER_MODEL=cross-encoder/ms-marco-MiniLM-L6-v2
RAG_RERANKER_TOP_K=20

# Cache Configuration
RAG_CACHE_ENABLED=true
RAG_CACHE_SIZE=100
RAG_CACHE_TTL=3600

# Concurrency
RAG_MAX_CONCURRENT_EMBEDDINGS=4
RAG_EMBEDDING_BATCH_SIZE=20

# Ollama Configuration
OLLAMA_BASE_URL=http://localhost:11434
```

## Performance Optimization

### 1. Use On-Demand RAG for Small Queries
```bash
# Faster for single queries
python -m tools.rag.cli ondemand "Your question"
```

### 2. Enable Hybrid Search for Better Recall
```bash
export RAG_USE_HYBRID=true
```

### 3. Use Cross-Encoder Reranking for Precision
```bash
export RAG_USE_RERANKER=true
export RAG_RERANKER_TYPE=cross_encoder
```

### 4. Enable Caching for Repeated Queries
```bash
export RAG_CACHE_ENABLED=true
export RAG_CACHE_SIZE=100
```

### 5. Adjust Chunk Size for Your Content
```bash
# Code: 500-800
# Documentation: 800-1200
# Mixed: 1000
export RAG_CHUNK_SIZE=1000
```

## Troubleshooting

### "sentence-transformers not installed"
```bash
pip install sentence-transformers
```

### "Cross-encoder reranker requested but not installed"
```bash
# Install sentence-transformers
pip install sentence-transformers

# Or disable reranking
export RAG_USE_RERANKER=false
```

### Low-quality results
1. Rebuild index: `--rebuild`
2. Increase `top_k`: `export RAG_TOP_K=15`
3. Enable hybrid search: `export RAG_USE_HYBRID=true`
4. Enable reranking: `export RAG_USE_RERANKER=true`

### Slow queries
1. Enable caching: `export RAG_CACHE_ENABLED=true`
2. Reduce chunk size: `export RAG_CHUNK_SIZE=500`
3. Use on-demand RAG for single queries
4. Increase concurrency: `export RAG_MAX_CONCURRENT_EMBEDDINGS=8`

## Migration Guide

### From Old RAG System

The new RAG system is not backward compatible. To migrate:

1. **Rebuild Index**:
   ```bash
   python -m tools.rag.cli index /path/to/repo --rebuild
   ```

2. **Update Configuration**:
   - Set `RAG_EMBEDDING_PROVIDER=ollama`
   - Set `RAG_LLM_MODE=local`
   - Ensure Ollama is running

3. **Update Code**:
   ```python
   # Old
   from tools.rag import VectorStore

   # New
   from tools.rag import RAGEngine, RAGConfig

   config = RAGConfig.from_env()
   engine = RAGEngine(config=config)
   result = engine.query("Your question")
   ```

4. **Update Embedding Usage**:
   - Embeddings are now dense vectors (lists), not sparse dicts
   - Use `embedding_provider.embed()` instead of direct access

## Best Practices

1. **Local-Only Operation**: Always use `config.ensure_local_only()` to enforce local mode
2. **Regular Indexing**: Rebuild index when codebase changes significantly
3. **Chunk Size Tuning**: Adjust based on your document types
4. **Top-K Selection**: Use 3-5 for factual queries, 10-15 for complex questions
5. **Temperature Control**: Lower (0.3-0.5) for factual, higher (0.7-0.9) for creative
6. **Enable Caching**: For repeated queries in production
7. **Use Hybrid Search**: For better recall on diverse queries
8. **Monitor Performance**: Use evaluation metrics to track quality

## Future Enhancements

- [ ] Distributed indexing for large repositories
- [ ] Multi-modal RAG (images, diagrams)
- [ ] Advanced reranking models
- [ ] Real-time index updates
- [ ] Query expansion techniques
- [ ] Context window optimization
- [ ] Streaming responses
- [ ] Multi-language support
