# Entry Points Analysis

## Overview

GRID provides three entry points (API, CLI, Service) that share common infrastructure while serving different use cases. This document compares and contrasts their initialization paths and functionality.

## Entry Point Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Shared Infrastructure                      │
│  - TraceManager (tracing)                                    │
│  - OrganizationManager (multi-org/multi-user)                │
│  - Common initialization                                      │
└────┬────────────────┬──────────────────┬─────────────────────┘
     │                │                  │
     ▼                ▼                  ▼
┌──────────┐   ┌──────────────┐   ┌──────────────┐
│   API    │   │     CLI      │   │   Service    │
│ Entry    │   │   Entry      │   │   Entry      │
│          │   │              │   │              │
└──────────┘   └──────────────┘   └──────────────┘
```

## Entry Point Comparison

### 1. API Entry Point (`grid/entry_points/api_entry.py`)

**Purpose**: FastAPI application entry point with full request context.

**File**: `grid/entry_points/api_entry.py`

**Class**: `APIEntryPoint`

**Initialization**:
```python
entry_point = APIEntryPoint(
    trace_manager=optional_trace_manager,
    org_manager=optional_org_manager
)
```

**Key Features**:
- FastAPI `Request` object integration
- HTTP headers extraction (X-Request-ID)
- Full request context (user_id, org_id, session_id)
- Trace origin: `TraceOrigin.API_REQUEST`

**Main Method**:
```python
async def handle_request(
    request: Request,
    operation: str,
    data: Dict[str, Any]
) -> Dict[str, Any]
```

**Context Extraction**:
- `user_id`: From `request.state.user_id`
- `org_id`: From `request.state.org_id`
- `session_id`: From `request.state.session_id`
- `request_id`: From `X-Request-ID` header or `request.state.request_id`

**Tracing**:
- Action type: `"api_request"`
- Origin: `TraceOrigin.API_REQUEST`
- Includes full request context

**Usage**:
- Integrated into FastAPI application
- Used by Mothership API endpoints
- Supports async operations

**CLI Wrapper**:
```bash
python -m grid.entry_points.api_entry <operation> --data '{"key": "value"}'
```
Note: CLI wrapper is minimal (requires FastAPI context for full functionality)

### 2. CLI Entry Point (`grid/entry_points/cli_entry.py`)

**Purpose**: Command-line interface entry point.

**File**: `grid/entry_points/cli_entry.py`

**Class**: `CLIEntryPoint`

**Initialization**:
```python
entry_point = CLIEntryPoint(
    trace_manager=optional_trace_manager,
    org_manager=optional_org_manager
)
```

**Key Features**:
- Command-line argument parsing
- Optional user/org context
- Trace origin: `TraceOrigin.USER_INPUT`
- Synchronous operations (can call async internally)

**Main Method**:
```python
def handle_command(
    command: str,
    args: Dict[str, Any],
    user_id: Optional[str] = None,
    org_id: Optional[str] = None
) -> Dict[str, Any]
```

**Context**:
- `user_id`: Optional, from CLI argument `--user`
- `org_id`: Optional, from CLI argument `--org`
- `session_id`: Not applicable (CLI context)
- `request_id`: Generated per command execution

**Tracing**:
- Action type: `"cli_command"`
- Origin: `TraceOrigin.USER_INPUT`
- Includes command and arguments

**Usage**:
```bash
python -m grid.entry_points.cli_entry <command> --args '{"key": "value"}' --user user_123 --org org_456
```

**Integration**:
- Used by `grid/__main__.py` CLI commands
- Supports all GRID CLI operations
- Full command execution with tracing

### 3. Service Entry Point (`grid/entry_points/service_entry.py`)

**Purpose**: Service/daemon entry point for background operations.

**File**: `grid/entry_points/service_entry.py`

**Class**: `ServiceEntryPoint`

**Initialization**:
```python
entry_point = ServiceEntryPoint(
    trace_manager=optional_trace_manager,
    org_manager=optional_org_manager
)
```

**Key Features**:
- Service/method invocation pattern
- Internal pipeline operations
- Trace origin: `TraceOrigin.INTERNAL_PIPELINE`
- Supports background jobs and daemons

**Main Method**:
```python
def handle_service_call(
    service: str,
    method: str,
    params: Dict[str, Any],
    user_id: Optional[str] = None,
    org_id: Optional[str] = None
) -> Dict[str, Any]
```

**Context**:
- `user_id`: Optional, from service context
- `org_id`: Optional, from service context
- `session_id`: Not applicable (service context)
- `request_id`: Generated per service call

**Tracing**:
- Action type: `"service_call"`
- Action name: `"{service}.{method}"`
- Origin: `TraceOrigin.INTERNAL_PIPELINE`
- Includes service and method information

**Usage**:
```bash
python -m grid.entry_points.service_entry <service> <method> --params '{"key": "value"}' --user user_123 --org org_456
```

**Integration**:
- Used by background services
- Scheduled jobs
- Daemon processes
- Internal pipeline operations

## Shared Infrastructure

### 1. Trace Manager

**Purpose**: Comprehensive action tracing.

**Location**: `grid/tracing/trace_manager.py`

**Features**:
- Action-level tracing
- Trace context management
- Trace storage (persistent)
- Trace correlation (request_id, session_id)

**Shared by**: All three entry points

**Usage**:
```python
trace_manager = get_trace_manager()
with trace_manager.trace_action(...) as trace:
    # Operation
    trace.complete(success=True)
```

### 2. Organization Manager

**Purpose**: Multi-org/multi-user management.

**Location**: `grid/organization/org_manager.py`

**Features**:
- User permission checking
- Organization management
- Activity tracking
- Role management

**Shared by**: All three entry points

**Usage**:
```python
org_manager = OrganizationManager()
has_permission = org_manager.check_user_permission(user_id, operation, org_id)
org_manager.record_user_activity(user_id)
```

## Initialization Flow

### API Entry Point Flow

1. **FastAPI Request Arrives**
   - FastAPI middleware extracts context
   - Request ID generated/stored

2. **Entry Point Initialization**
   - `APIEntryPoint` created (or reused)
   - Trace manager retrieved
   - Organization manager initialized

3. **Request Handling**
   - Context extracted from `Request` object
   - Trace created with API origin
   - Permission check via org manager
   - Operation processing
   - Trace completion

4. **Response**
   - Result with trace_id returned
   - FastAPI serializes response

### CLI Entry Point Flow

1. **CLI Arguments Parsed**
   - Command and arguments extracted
   - User/org context from options

2. **Entry Point Initialization**
   - `CLIEntryPoint` created
   - Trace manager retrieved
   - Organization manager initialized

3. **Command Handling**
   - Context from CLI arguments
   - Trace created with USER_INPUT origin
   - Permission check via org manager
   - Command processing (synchronous)
   - Trace completion

4. **Output**
   - Result printed as JSON
   - Exit code based on success/failure

### Service Entry Point Flow

1. **Service Call Invoked**
   - Service and method extracted
   - Parameters parsed

2. **Entry Point Initialization**
   - `ServiceEntryPoint` created
   - Trace manager retrieved
   - Organization manager initialized

3. **Service Call Handling**
   - Context from service context
   - Trace created with INTERNAL_PIPELINE origin
   - Permission check via org manager
   - Service method invocation
   - Trace completion

4. **Result**
   - Result returned
   - Logged/stored as needed

## Common Patterns

### 1. Permission Checking

**Pattern**: All entry points check permissions before processing.

```python
if user_id and not self.org_manager.check_user_permission(user_id, operation, org_id):
    trace.complete(success=False, error="Permission denied")
    return {"success": False, "error": "Permission denied"}
```

### 2. Activity Tracking

**Pattern**: All entry points record user activity.

```python
if user_id:
    self.org_manager.record_user_activity(user_id)
```

### 3. Trace Completion

**Pattern**: All entry points complete traces with success/failure.

```python
try:
    result = process_operation(...)
    trace.complete(success=True, output_data=result)
    return {"success": True, "data": result, "trace_id": trace.trace_id}
except Exception as e:
    trace.complete(success=False, error=str(e))
    raise
```

### 4. Error Handling

**Pattern**: Consistent error handling across entry points.

- Traces capture errors
- Errors logged appropriately
- Consistent error response format

## Differences

### Context Sources

| Entry Point | user_id | org_id | session_id | request_id |
|-------------|---------|--------|------------|------------|
| **API** | `request.state.user_id` | `request.state.org_id` | `request.state.session_id` | `X-Request-ID` header |
| **CLI** | `--user` argument | `--org` argument | N/A | Generated |
| **Service** | Service context | Service context | N/A | Generated |

### Trace Origins

| Entry Point | Trace Origin |
|-------------|--------------|
| **API** | `TraceOrigin.API_REQUEST` |
| **CLI** | `TraceOrigin.USER_INPUT` |
| **Service** | `TraceOrigin.INTERNAL_PIPELINE` |

### Operation Model

| Entry Point | Operation Model |
|-------------|-----------------|
| **API** | HTTP request/response (async) |
| **CLI** | Command execution (sync) |
| **Service** | Service method invocation (sync) |

### Execution Context

| Entry Point | Context |
|-------------|---------|
| **API** | FastAPI request context |
| **CLI** | Command-line arguments |
| **Service** | Service/method parameters |

## Integration Examples

### API Integration

```python
from fastapi import FastAPI, Request
from grid.entry_points.api_entry import APIEntryPoint

app = FastAPI()
entry_point = APIEntryPoint()

@app.post("/api/operation")
async def handle_operation(request: Request, data: dict):
    return await entry_point.handle_request(
        request=request,
        operation="my_operation",
        data=data
    )
```

### CLI Integration

```python
from grid.entry_points.cli_entry import CLIEntryPoint

entry_point = CLIEntryPoint()
result = entry_point.handle_command(
    command="skills.list",
    args={},
    user_id="user_123"
)
print(result)
```

### Service Integration

```python
from grid.entry_points.service_entry import ServiceEntryPoint

entry_point = ServiceEntryPoint()
result = entry_point.handle_service_call(
    service="processing",
    method="process_batch",
    params={"batch_id": "batch_123"},
    user_id="system"
)
```

## Configuration

All entry points support:
- Optional trace manager override
- Optional organization manager override
- Environment-based configuration
- Default managers via singletons

## Best Practices

1. **Use Appropriate Entry Point**:
   - API: For HTTP endpoints
   - CLI: For command-line operations
   - Service: For background jobs

2. **Consistent Tracing**:
   - Always use trace manager
   - Complete traces with success/failure
   - Include relevant context

3. **Permission Checking**:
   - Always check permissions before processing
   - Use organization manager
   - Record user activity

4. **Error Handling**:
   - Capture errors in traces
   - Return consistent error format
   - Log appropriately

## Future Extensions

1. **GraphQL Entry Point**: GraphQL API support
2. **WebSocket Entry Point**: Real-time communication
3. **gRPC Entry Point**: High-performance RPC
4. **Message Queue Entry Point**: Event-driven processing
