# GRID MCP Servers

This document describes the custom MCP (Model Context Protocol) servers implemented for the GRID project.

## Overview

GRID provides two custom MCP servers:

1. **grid-mastermind**: Intelligent code analysis and project navigation
2. **grid-rag**: Retrieval Augmented Generation for knowledge management

## Prerequisites

1. Python 3.13+ installed
2. Ollama installed and running (`ollama serve`)
3. Required Python packages (automatically installed with uv):
   - mcp[cli] (Model Context Protocol with CLI tools)
   - chromadb
   - sentence-transformers
   - httpx

## Installation

1. Install Ollama:

   ```bash
   curl -fsSL https://ollama.ai/install.sh | sh
   ```

2. Start Ollama:

   ```bash
   ollama serve
   ```

3. Download required models:

   ```bash
   ollama pull nomic-embed-text:latest
   ollama pull ministral-3:3b
   ```

4. Install dependencies (GRID already has MCP configured):

   ```bash
   # MCP is already added to pyproject.toml
   # To update or reinstall:
   uv add "mcp[cli]"

   # Install other dependencies if needed:
   uv add chromadb sentence-transformers httpx
   ```

## Configuration

The MCP servers are configured in `c:\Users\irfan\.codeium\windsurf\mcp_config.json`:

### grid-mastermind

Provides intelligent code analysis capabilities:

- **Project Information**: File counts, languages, project structure
- **Code Analysis**: Complexity metrics, quality scoring
- **Dependency Analysis**: Internal and external dependencies
- **Test Coverage**: Test file analysis and coverage metrics
- **Code Search**: Pattern-based code search
- **File Analysis**: Individual file metrics

**Tools**:

- `analyze_file`: Analyze a specific file
- `search_code`: Search for patterns across the project
- `find_dependencies`: Find dependencies for a module
- `get_project_structure`: Get project tree structure

**Resources**:

- `mastermind://project-info`: General project information
- `mastermind://code-analysis`: Code quality and complexity
- `mastermind://dependencies`: Project dependencies
- `mastermind://test-coverage`: Test coverage information

### grid-rag

Provides RAG (Retrieval Augmented Generation) capabilities:

- **Document Indexing**: Automatic indexing of project files
- **Semantic Search**: Context-aware document retrieval
- **Knowledge Base**: Persistent vector storage
- **Query Processing**: Natural language queries

**Configuration**:

- Uses Ollama for embeddings (`nomic-embed-text:latest`)
- ChromaDB for vector storage
- Local-only operation (no cloud dependencies)

## Usage

### In IDE

The servers are automatically available when configured in `mcp_config.json`. They will appear as available tools/resources in your MCP-compatible IDE.

### Direct Testing

You can test the servers directly:

```bash
# Test mastermind
python -c "from grid.mcp.mastermind_server import get_project_info; import asyncio; print(asyncio.run(get_project_info()))"

# Test RAG
python -c "from tools.rag.rag_engine import RAGEngine; engine = RAGEngine(); print('RAG engine initialized')"
```

## Architecture

### grid-mastermind

```
mastermind_server.py
├── Project Analysis
│   ├── File counting and categorization
│   ├── Language detection
│   └── Size metrics
├── Code Quality
│   ├── Complexity estimation
│   ├── Test coverage analysis
│   └── Dependency tracking
└── Navigation
    ├── Project structure tree
    ├── File search
    └── Cross-references
```

### grid-rag

```
grid_rag_mcp_server.py
├── RAG Engine
│   ├── Embedding provider (Ollama/HuggingFace)
│   ├── Vector store (ChromaDB)
│   └── LLM provider (Ollama)
├── Indexing
│   ├── Document chunking
│   ├── Embedding generation
│   └── Vector storage
└── Query Processing
    ├── Semantic search
    ├── Context retrieval
    └── Response generation
```

## Troubleshooting

### Common Issues

1. **"MCP library not found"**
   - Ensure MCP is installed: `pip install mcp`
   - Check Python path in configuration

2. **"Ollama not accessible"**
   - Start Ollama: `ollama serve`
   - Check if running on port 11434
   - Verify model is downloaded

3. **"Vector store initialization failed"**
   - Ensure ChromaDB is installed: `pip install chromadb`
   - Check directory permissions for `.rag_db`

4. **"Import errors"**
   - Verify PYTHONPATH includes `E:\grid\src`
   - Check if using correct Python executable

### Debug Mode

Enable debug logging by setting `LOG_LEVEL=DEBUG` in the environment variables.

## Development

### Adding New Tools

1. Define the tool in the `list_tools()` function
2. Implement the handler function
3. Add the tool to the `call_tool()` dispatcher
4. Update documentation

### Adding New Resources

1. Define the resource in `list_resources()`
2. Implement the handler in `read_resource()`
3. Update documentation

## Future Enhancements

### grid-mastermind

- [ ] Code smell detection
- [ ] Performance profiling
- [ ] Security vulnerability scanning
- [ ] Automated refactoring suggestions

### grid-rag

- [ ] Multi-modal indexing (images, diagrams)
- [ ] Hybrid search (keyword + semantic)
- [ ] Real-time indexing
- [ ] Cross-repository search

## Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Submit a pull request

## License

This project is part of the GRID framework. See the main project license for details.
