# GRID API Documentation

## Overview

GRID provides a comprehensive REST API and WebSocket interface for entity recognition, skills execution, and system management.

## Base URL
- **Development:** `http://localhost:8000`
- **Production:** `https://api.grid.example.com`

## Authentication

### API Key Authentication
```http
Authorization: Bearer your-api-key-here
X-API-Key: your-api-key-here
```

### Environment Variables
```bash
# Development
export GRID_API_KEY=dev-key-123

# Production
export GRID_API_KEY=prod-key-456
```

## REST API Endpoints

### Entity Recognition

#### Extract Entities
```http
POST /api/v1/extract
Content-Type: application/json
Authorization: Bearer your-api-key

{
    "text": "Apple Inc. is located in Cupertino, California.",
    "entity_types": ["ORG", "LOCATION", "MONEY", "VERSION"],
    "confidence_threshold": 0.7,
    "max_entities": 10
}
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "text": "Apple Inc. is located in Cupertino, California.",
        "entities": [
            {
                "text": "Apple Inc.",
                "type": "ORG",
                "confidence": 0.95,
                "start": 0,
                "end": 10
            },
            {
                "text": "Cupertino",
                "type": "LOCATION",
                "confidence": 0.92,
                "start": 25,
                "end": 34
            },
            {
                "text": "California",
                "type": "LOCATION",
                "confidence": 0.88,
                "start": 36,
                "end": 46
            }
        ],
        "relationships": [],
        "processing_time_ms": 45
    }
}
```

#### Batch Entity Extraction
```http
POST /api/v1/extract/batch
Content-Type: application/json

{
    "texts": [
        "OpenAI is in San Francisco",
        "Google is in Mountain View"
    ],
    "entity_types": ["ORG", "LOCATION"],
    "confidence_threshold": 0.8
}
```

### Skills Management

#### List Skills
```http
GET /api/v1/skills
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "skills": [
            {
                "skill_id": "rag.query_knowledge",
                "name": "RAG Knowledge Query",
                "description": "Query GRID's project knowledge base",
                "entity_influence": {
                    "required_entities": ["SCOPE_KEYWORD"],
                    "optional_entities": ["COMPONENT", "RAILWAY_TERM"],
                    "confidence_threshold": 0.5
                }
            },
            {
                "skill_id": "patterns.detect_entities",
                "name": "Entity Detection",
                "description": "Detect entities in text using patterns",
                "entity_influence": {
                    "required_entities": [],
                    "optional_entities": ["PERSON", "ORG", "LOCATION"],
                    "confidence_threshold": 0.7
                }
            }
        ]
    }
}
```

#### Execute Skill
```http
POST /api/v1/skills/{skill_id}/execute
Content-Type: application/json
Authorization: Bearer your-api-key

{
    "query": "machine learning basics",
    "context": "educational content",
    "max_results": 5
}
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "skill_id": "rag.query_knowledge",
        "result": {
            "answer": "Machine learning is a subset of artificial intelligence...",
            "sources": [
                {
                    "title": "Introduction to ML",
                    "url": "docs/ml-intro.md",
                    "relevance": 0.95
                }
            ],
            "confidence": 0.88
        },
        "processing_time_ms": 120
    }
}
```

#### Register Custom Skill
```http
POST /api/v1/skills
Content-Type: application/json
Authorization: Bearer your-api-key

{
    "skill_id": "my_custom_skill",
    "name": "My Custom Skill",
    "description": "Custom skill for specific task",
    "handler_code": "def my_handler(args): return {'result': 'success'}",
    "entity_influence": {
        "required_entities": ["ORG"],
        "optional_entities": ["LOCATION"],
        "confidence_threshold": 0.7
    }
}
```

### System Management

#### Health Check
```http
GET /api/v1/health
```

**Response:**
```json
{
    "status": "healthy",
    "timestamp": "2026-01-08T12:00:00Z",
    "version": "2.1.0",
    "environment": "production",
    "components": {
        "ner_service": "healthy",
        "skills_registry": "healthy",
        "security_manager": "healthy",
        "secrets_manager": "healthy"
    },
    "metrics": {
        "uptime_seconds": 86400,
        "requests_total": 1000,
        "requests_per_second": 0.5,
        "error_rate": 0.01
    }
}
```

#### Detailed Health
```http
GET /api/v1/health/detailed
Authorization: Bearer your-api-key
```

#### System Status
```http
GET /api/v1/status
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "status": "operational",
    "security": {
        "environment": "production",
        "security_level": "restrictive",
        "denylisted_commands": ["analyze", "serve"],
        "failed_attempts": 0,
        "max_failed_attempts": 3
    },
    "performance": {
        "cpu_usage": 0.25,
        "memory_usage": 0.60,
        "cache_hit_rate": 0.85,
        "average_response_time_ms": 150
    },
    "configuration": {
        "entity_types_supported": ["ORG", "LOCATION", "PERSON", "MONEY", "VERSION"],
        "max_entities_per_request": 50,
        "default_confidence_threshold": 0.7
    }
}
```

### Configuration

#### Get Configuration
```http
GET /api/v1/config
Authorization: Bearer your-api-key
```

#### Update Configuration
```http
PUT /api/v1/config
Content-Type: application/json
Authorization: Bearer your-api-key

{
    "default_confidence_threshold": 0.8,
    "max_entities_per_request": 25,
    "enable_audit_logging": true
}
```

## WebSocket API

### Connection
```javascript
const ws = new WebSocket('ws://localhost:8000/ws');
ws.onopen = function() {
    console.log('Connected to GRID WebSocket');
};
```

### Real-time Entity Extraction
```javascript
// Send extraction request
ws.send(JSON.stringify({
    "type": "extract_entities",
    "data": {
        "text": "OpenAI and NVIDIA are collaborating",
        "entity_types": ["ORG"],
        "confidence_threshold": 0.8
    }
}));

// Receive response
ws.onmessage = function(event) {
    const response = JSON.parse(event.data);
    console.log('Entities:', response.data.entities);
};
```

### Real-time Skill Execution
```javascript
// Execute skill
ws.send(JSON.stringify({
    "type": "execute_skill",
    "data": {
        "skill_id": "rag.query_knowledge",
        "query": "artificial intelligence trends"
    }
}));
```

### Streaming Entity Extraction
```javascript
// Stream processing for large texts
ws.send(JSON.stringify({
    "type": "stream_extract",
    "data": {
        "text": "Large document text...",
        "chunk_size": 1000,
        "entity_types": ["ORG", "PERSON"]
    }
}));

// Receive streaming results
ws.onmessage = function(event) {
    const chunk = JSON.parse(event.data);
    if (chunk.type === 'entity_chunk') {
        console.log('Chunk entities:', chunk.data.entities);
    }
};
```

## Error Handling

### Error Response Format
```json
{
    "status": "error",
    "error": {
        "code": "INVALID_REQUEST",
        "message": "Invalid request parameters",
        "details": {
            "field": "text",
            "issue": "Text cannot be empty"
        },
        "timestamp": "2026-01-08T12:00:00Z",
        "request_id": "req_123456"
    }
}
```

### Common Error Codes

| Code | HTTP Status | Description |
|------|------------|-------------|
| `INVALID_REQUEST` | 400 | Request parameters invalid |
| `UNAUTHORIZED` | 401 | API key invalid or missing |
| `FORBIDDEN` | 403 | Insufficient permissions |
| `NOT_FOUND` | 404 | Resource not found |
| `RATE_LIMITED` | 429 | Too many requests |
| `INTERNAL_ERROR` | 500 | Server error |
| `SERVICE_UNAVAILABLE` | 503 | Service temporarily unavailable |

### Rate Limiting

| Plan | Requests/Minute | Burst Limit |
|------|-----------------|-------------|
| Development | 100 | 200 |
| Standard | 1000 | 2000 |
| Enterprise | 10000 | 20000 |

## SDK Examples

### Python SDK
```python
from grid_client import GRIDClient

# Initialize client
client = GRIDClient(
    api_key="your-api-key",
    base_url="http://localhost:8000"
)

# Extract entities
result = client.extract_entities(
    text="Apple Inc. is in Cupertino",
    entity_types=["ORG", "LOCATION"]
)
print(result.entities)

# Execute skill
skill_result = client.execute_skill(
    skill_id="rag.query_knowledge",
    query="machine learning basics"
)
print(skill_result.result)
```

### JavaScript SDK
```javascript
import { GRIDClient } from '@grid/sdk';

const client = new GRIDClient({
    apiKey: 'your-api-key',
    baseUrl: 'http://localhost:8000'
});

// Extract entities
const result = await client.extractEntities({
    text: 'Apple Inc. is in Cupertino',
    entityTypes: ['ORG', 'LOCATION']
});
console.log(result.entities);

// Execute skill
const skillResult = await client.executeSkill({
    skillId: 'rag.query_knowledge',
    query: 'machine learning basics'
});
console.log(skillResult.result);
```

### cURL Examples
```bash
# Extract entities
curl -X POST http://localhost:8000/api/v1/extract \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer your-api-key" \
  -d '{
    "text": "OpenAI is in San Francisco",
    "entity_types": ["ORG", "LOCATION"]
  }'

# List skills
curl -X GET http://localhost:8000/api/v1/skills \
  -H "Authorization: Bearer your-api-key"

# Health check
curl -X GET http://localhost:8000/api/v1/health
```

## Monitoring and Metrics

### Metrics Endpoint
```http
GET /api/v1/metrics
Authorization: Bearer your-api-key
```

**Response:**
```json
{
    "status": "success",
    "data": {
        "requests": {
            "total": 10000,
            "per_second": 5.2,
            "error_rate": 0.01
        },
        "performance": {
            "average_response_time_ms": 150,
            "p95_response_time_ms": 300,
            "p99_response_time_ms": 500
        },
        "entities": {
            "extracted_total": 50000,
            "by_type": {
                "ORG": 20000,
                "LOCATION": 15000,
                "PERSON": 10000,
                "MONEY": 3000,
                "VERSION": 2000
            }
        },
        "skills": {
            "executions_total": 5000,
            "by_skill": {
                "rag.query_knowledge": 3000,
                "patterns.detect_entities": 2000
            }
        }
    }
}
```

### Prometheus Metrics
```
# HELP grid_requests_total Total number of API requests
# TYPE grid_requests_total counter
grid_requests_total{method="POST",endpoint="/api/v1/extract"} 5000

# HELP grid_request_duration_seconds Request duration in seconds
# TYPE grid_request_duration_seconds histogram
grid_request_duration_seconds_bucket{le="0.1"} 1000
grid_request_duration_seconds_bucket{le="0.5"} 4500
grid_request_duration_seconds_bucket{le="1.0"} 4900
grid_request_duration_seconds_bucket{le="+Inf"} 5000

# HELP grid_entities_extracted_total Total entities extracted
# TYPE grid_entities_extracted_total counter
grid_entities_extracted_total{type="ORG"} 2000
grid_entities_extracted_total{type="LOCATION"} 1500
```

## Testing the API

### Using the Test Suite
```bash
# Run API tests
uv run pytest tests/api/ -v

# Run specific test
uv run pytest tests/api/test_extract.py::test_extract_entities

# Run with coverage
uv run pytest tests/api/ --cov=grid.api --cov-report=html
```

### Manual Testing
```bash
# Test health endpoint
curl http://localhost:8000/api/v1/health

# Test entity extraction
curl -X POST http://localhost:8000/api/v1/extract \
  -H "Content-Type: application/json" \
  -d '{"text": "Apple Inc. is in Cupertino", "entity_types": ["ORG", "LOCATION"]}'

# Test WebSocket
wscat -c ws://localhost:8000/ws
# Then send: {"type": "extract_entities", "data": {"text": "OpenAI", "entity_types": ["ORG"]}}
```

## Deployment Considerations

### Environment Variables
```bash
# API Configuration
export GRID_API_HOST=0.0.0.0
export GRID_API_PORT=8000
export GRID_API_WORKERS=4

# Security
export GRID_API_KEY_REQUIRED=true
export GRID_RATE_LIMIT_ENABLED=true
export GRID_CORS_ORIGINS=https://app.example.com

# Performance
export GRID_CACHE_TTL=300
export GRID_MAX_REQUEST_SIZE=1048576
export GRID_REQUEST_TIMEOUT=30
```

FROM python:3.13-slim

WORKDIR /app
COPY . .
RUN uv sync --frozen

EXPOSE 8000
CMD ["uv", "run", "python", "-m", "grid", "serve", "--host", "0.0.0.0", "--port", "8000"]
```

### Kubernetes Configuration
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: grid-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: grid-api
  template:
    metadata:
      labels:
        app: grid-api
    spec:
      containers:
      - name: grid-api
        image: grid:latest
        ports:
        - containerPort: 8000
        env:
        - name: GRID_ENV
          value: "production"
        - name: GRID_API_KEY
          valueFrom:
            secretKeyRef:
              name: grid-secrets
              key: api-key
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
```

---

*For more detailed information about specific endpoints or advanced usage, see the comprehensive documentation.*
