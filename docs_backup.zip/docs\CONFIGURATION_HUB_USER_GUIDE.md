# Configuration Hub User Guide

## Overview

The Configuration Hub is a unified system for managing IDE configurations across multiple development environments (VS Code, Cursor, Windsurf) with context-aware settings and automatic synchronization between your project directory (`E:\grid`) and user configuration directory (`C:\Users\irfan`).

## Architecture

```
e:\grid\config\hub\
├── core.yaml              # Base settings for all IDEs
├── profiles\              # IDE-specific configurations
│   ├── vscode.yaml       # VS Code settings
│   ├── cursor.yaml       # Cursor settings
│   └── windsurf.yaml     # Windsurf settings
├── contexts\              # Environment-specific overrides
│   ├── development.yaml  # Development environment
│   ├── production.yaml   # Production environment
│   └── testing.yaml      # Testing environment
├── dynamic\               # Dynamic loading system
│   └── loader.py         # Configuration loader
└── sync\                  # Synchronization system
    └── to_user.py        # Sync to user directories
```

## Quick Start

### 1. Load Configuration

```python
from config.hub.dynamic.loader import ConfigLoader

# Initialize loader
loader = ConfigLoader()

# Load VS Code development configuration
result = loader.load_config('vscode', 'development')
if result.success:
    config = result.config
    print(f"Loaded config with {len(config)} sections")
```

### 2. Sync to User Directories

```python
from config.hub.sync.to_user import UserConfigSync

# Initialize sync manager
sync_manager = UserConfigSync()

# Sync VS Code configuration
result = sync_manager.sync_vscode('development', backup=True)
if result.success:
    print(f"Synced {len(result.synced_files)} files")
```

### 3. Command Line Usage

```bash
# Test configuration hub
cd e:\grid
python test_config_hub.py

# Test validation
python test_config_validation.py
```

## Configuration Structure

### Core Configuration (`core.yaml`)

Contains base settings that apply across all IDEs and contexts:

- **Version**: Configuration version
- **MCP**: Base MCP server configuration
- **Development**: Base development settings
- **UI**: Base UI settings
- **Security**: Base security settings
- **Performance**: Base performance settings
- **Logging**: Base logging configuration
- **Backup**: Base backup settings

### IDE Profiles (`profiles/`)

IDE-specific configurations that override core settings:

#### VS Code (`vscode.yaml`)

- VS Code-specific settings
- MCP server configuration for VS Code
- Extensions, keybindings, tasks, launch configurations
- Workspace settings

#### Cursor (`cursor.yaml`)

- Cursor-specific settings
- MCP server configuration for Cursor
- Skills configuration
- AI settings and prompts

#### Windsurf (`windsurf.yaml`)

- Windsurf-specific settings
- MCP server configuration for Windsurf
- Extensions and tasks

### Contexts (`contexts/`)

Environment-specific overrides:

#### Development (`development.yaml`)

- Debug settings enabled
- Verbose logging
- Extended MCP server timeouts
- Development-specific tools

#### Production (`production.yaml`)

- Debug settings disabled
- Minimal logging
- Optimized performance
- Restricted MCP servers

#### Testing (`testing.yaml`)

- Comprehensive testing configuration
- Benchmarking enabled
- Mock servers
- Test-specific tools

## Environment Variables

The system supports environment variable substitution using `${VARIABLE_NAME}` syntax:

### Common Variables

- `${workspaceFolder}`: Current workspace directory
- `${GRID_ENV}`: Environment (development/production/testing)
- `${LOG_LEVEL}`: Logging level
- `${MCP_DEBUG}`: MCP debug flag
- `${GITHUB_PAT}`: GitHub personal access token

### Example Usage

```yaml
mcp:
  vscode:
    servers:
      git-mcp:
        env:
          GIT_MCP_REPO: "${workspaceFolder}"
          GIT_MCP_MAX_LOG: "50"
```

## MCP Server Configuration

### Supported Servers

1. **Git MCP Server**: Git operations
2. **SQLite MCP Server**: Database operations
3. **Filesystem MCP Server**: File operations
4. **Memory MCP Server**: Memory operations
5. **Playwright MCP Server**: Browser automation

### Server Configuration

```yaml
servers:
  git-mcp:
    name: "Git MCP Server"
    description: "Read-only Git operations"
    command: "python"
    args: ["scripts/git_mcp_server.py"]
    env:
      GIT_MCP_REPO: "${workspaceFolder}"
      GIT_MCP_MAX_LOG: "50"
```

## Synchronization

### Automatic Sync

The system automatically synchronizes configurations from the hub to user directories:

- **VS Code**: `C:\Users\irfan\.vscode\settings.json`
- **Cursor**: `C:\Users\irfan\.cursor\settings.json` + `mcp.json`
- **Windsurf**: `C:\Users\irfan\.windsurf\settings.json`

### Backup System

Before syncing, the system creates backups in:

- `C:\Users\irfan\.grid\backups\`
- `e:\grid\backups\`

### Manual Sync

```python
# Sync all IDEs
result = sync_manager.sync_all(['development'], backup=True)

# Sync specific IDE
result = sync_manager.sync_vscode('development', backup=True)

# Restore from backup
result = sync_manager.restore_backup(backup_file, 'vscode')
```

## Context Switching

Switch between different environments:

```python
# Development context
dev_config = loader.load_config('vscode', 'development')

# Production context
prod_config = loader.load_config('vscode', 'production')

# Testing context
test_config = loader.load_config('vscode', 'testing')
```

### Context Differences

| Setting     | Development | Production | Testing |
| ----------- | ----------- | ---------- | ------- |
| Debug       | Enabled     | Disabled   | Enabled |
| Log Level   | DEBUG       | INFO       | DEBUG   |
| MCP Timeout | 60s         | 30s        | 60s     |
| Testing     | Disabled    | Disabled   | Enabled |
| Performance | Relaxed     | Strict     | Relaxed |

## Validation

The system includes comprehensive validation:

### Configuration Validation

- Required sections check
- Type validation
- MCP server validation
- Schema validation

### Example Validation

```python
result = loader._validate_config(config)
if result.success:
    print("Configuration is valid")
else:
    print("Validation errors:", result.errors)
    print("Warnings:", result.warnings)
```

## Performance Optimization

### Caching

- Configuration results cached for performance
- Cache invalidation on file changes
- Manual cache clearing available

### Lazy Loading

- Configurations loaded on-demand
- Context-specific loading
- Memory-efficient merging

### Optimization Tips

1. Use appropriate contexts for different environments
2. Enable caching for frequently used configurations
3. Use environment variables for dynamic values
4. Regularly clear cache when configurations change

## Troubleshooting

### Common Issues

#### Import Errors

```python
# Ensure paths are added correctly
sys.path.append('config/hub/dynamic')
sys.path.append('config/hub/sync')
```

#### Unicode Escape Errors

- Use double backslashes in Windows paths: `C:\\Users\\irfan`
- Use raw strings: `r"C:\Users\irfan"`

#### Configuration Not Found

- Check file paths and permissions
- Verify YAML syntax
- Ensure required sections exist

#### Sync Failures

- Check user directory permissions
- Verify backup directory exists
- Check for file locks

### Debug Mode

Enable debug logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Test Suite

Run comprehensive tests:

```bash
# Test basic functionality
python test_config_hub.py

# Test validation
python test_config_validation.py
```

## Best Practices

### 1. Configuration Organization

- Keep core configuration minimal
- Use profiles for IDE-specific settings
- Use contexts for environment differences
- Document custom configurations

### 2. Environment Variables

- Use descriptive variable names
- Provide default values
- Document required variables
- Use secure storage for sensitive data

### 3. MCP Servers

- Keep server configurations minimal
- Use appropriate timeouts
- Implement proper error handling
- Monitor server performance

### 4. Synchronization

- Always enable backups
- Test sync in safe environment
- Monitor sync performance
- Handle conflicts gracefully

### 5. Validation

- Validate all configurations
- Handle validation errors gracefully
- Provide clear error messages
- Test edge cases

## Advanced Usage

### Custom Contexts

Create custom contexts for specific needs:

```yaml
# config/hub/contexts/custom.yaml
version: "1.0"
context: "custom"
description: "Custom environment configuration"

environment:
  name: "custom"
  variables:
    CUSTOM_VAR: "value"
```

### Custom Profiles

Create custom profiles for new IDEs:

```yaml
# config/hub/profiles/new_ide.yaml
version: "1.0"
ide: "new_ide"
description: "New IDE configuration"

settings:
  # IDE-specific settings
```

### Programmatic Configuration

Create configurations programmatically:

```python
# Create custom config
custom_config = {
    'version': '1.0',
    'mcp': {
        'servers': {
            'custom_server': {
                'command': 'python',
                'args': ['custom_server.py']
            }
        }
    }
}

# Validate and use
result = loader._validate_config(custom_config)
if result.success:
    # Use configuration
    pass
```

## Migration Guide

### From Existing Configurations

1. **Backup existing configurations**
2. **Identify common settings** → Move to `core.yaml`
3. **Identify IDE-specific settings** → Move to appropriate profile
4. **Identify environment differences** → Move to appropriate context
5. **Test new configuration**
6. **Sync to user directories**

### Example Migration

```python
# Load existing VS Code settings
with open('C:\\Users\\irfan\\.vscode\\settings.json') as f:
    existing_settings = json.load(f)

# Create profile from existing settings
profile_config = {
    'version': '1.0',
    'ide': 'vscode',
    'settings': existing_settings
}

# Save to new location
with open('config/hub/profiles/vscode.yaml', 'w') as f:
    yaml.dump(profile_config, f)
```

## API Reference

### ConfigLoader

```python
class ConfigLoader:
    def __init__(self, hub_path: Optional[Path] = None)
    def load_config(self, ide: str, context: str, environment: Optional[Dict[str, str]] = None, force_reload: bool = False) -> ConfigLoadResult
    def list_available_profiles(self) -> List[str]
    def list_available_contexts(self) -> List[str]
    def get_cache_info(self) -> Dict[str, Any]
    def clear_cache(self) -> None
    def reload_core_config(self) -> None
```

### UserConfigSync

```python
class UserConfigSync:
    def __init__(self, hub_path: Optional[Path] = None)
    def sync_all(self, contexts: List[str], backup: bool, force: bool) -> SyncResult
    def sync_vscode(self, context: str, backup: bool, force: bool) -> SyncResult
    def sync_cursor(self, context: str, backup: bool, force: bool) -> SyncResult
    def sync_windsurf(self, context: str, backup: bool, force: bool) -> SyncResult
    def list_backups(self) -> List[str]
    def restore_backup(self, backup_file: str, ide: str) -> SyncResult
```

### ConfigLoadResult

```python
@dataclass
class ConfigLoadResult:
    success: bool
    config: Dict[str, Any]
    errors: List[str]
    warnings: List[str]
    metadata: Dict[str, Any]
```

### SyncResult

```python
@dataclass
class SyncResult:
    success: bool
    synced_files: List[str]
    errors: List[str]
    warnings: List[str]
    metadata: Dict[str, Any]
```

## Contributing

### Adding New Features

1. **Update core configuration** if needed
2. **Create/update profiles** for new IDEs
3. **Create/update contexts** for new environments
4. **Add tests** for new functionality
5. **Update documentation**

### Testing

1. **Run test suite** before changes
2. **Add new tests** for new features
3. **Test edge cases**
4. **Validate configurations**

### Documentation

1. **Update this guide** for new features
2. **Add examples** for complex use cases
3. **Document breaking changes**
4. **Keep API reference current**

## Support

For issues and questions:

1. **Check troubleshooting section**
2. **Run test suite** to identify issues
3. **Check configuration validation**
4. **Review log files** for detailed errors

## License

This configuration hub system is part of the GRID project and follows the same licensing terms.
