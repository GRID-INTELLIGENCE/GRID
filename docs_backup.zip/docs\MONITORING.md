# Monitoring Guide for Enhanced RAG Server

## Overview

This guide covers monitoring, logging, and alerting for the Enhanced RAG Server deployment.

## Components to Monitor

### MCP Servers

1. **grid-rag-enhanced** (port 8002)
   - Query latency
   - Success rate
   - Concurrent sessions
   - Memory usage

2. **memory** (port 8003)
   - Storage operations
   - Memory usage
   - Request rate

3. **grid-agentic** (port 8004)
   - Case execution
   - Skill retrieval
   - Memo generation

### Ghost Registry Handlers

- `rag.query.conversational`
- `rag.session.create`
- `rag.session.get`
- `rag.session.delete`
- `rag.stats`
- `rag.index`

## Health Checks

### Manual Health Checks

```bash
# Check all servers
curl http://localhost:8002/health
curl http://localhost:8003/health
curl http://localhost:8004/health

# Expected response: {"status": "healthy", "timestamp": "..."}
```

### Automated Health Checks

Health checks run every 30 seconds (configurable in `config/production.yaml`):

```yaml
health_checks:
  enabled: true
  interval_seconds: 30
  timeout_seconds: 5
```

## Metrics

### Available Metrics

Metrics are available at `http://localhost:9090/metrics` (Prometheus format):

```prometheus
# Query latency histogram
rag_query_latency_seconds_bucket{le="0.1"} 0
rag_query_latency_seconds_bucket{le="0.5"} 10
rag_query_latency_seconds_bucket{le="1.0"} 50

# Session operations
rag_session_operations_total{operation="create"} 100
rag_session_operations_total{operation="get"} 500
rag_session_operations_total{operation="delete"} 100

# Error rates
rag_errors_total{type="query"} 5
rag_errors_total{type="session"} 2

# Concurrent sessions
rag_concurrent_sessions 50
```

### Key Metrics to Monitor

1. **Query Latency**
   - P50: < 300ms
   - P95: < 500ms
   - P99: < 1000ms

2. **Success Rate**
   - Target: > 99.9%
   - Warning: < 99%
   - Critical: < 95%

3. **Concurrent Sessions**
   - Target: < 100
   - Warning: > 80
   - Critical: > 95

4. **Memory Usage**
   - Target: < 2GB
   - Warning: > 1.5GB
   - Critical: > 2GB

5. **Error Rate**
   - Target: < 0.1%
   - Warning: > 0.5%
   - Critical: > 1%

## Logging

### Log Locations

```
/var/log/grid-rag-enhanced/
├── grid-rag-enhanced.log
├── memory-mcp.log
├── grid-agentic.log
└── ghost-registry.log
```

### Log Format

```
2026-01-26 05:00:00,000 - grid.mcp.enhanced_rag_server - INFO - Query processed successfully
2026-01-26 05:00:01,000 - tools.rag.conversational_rag - WARNING - Session not found
2026-01-26 05:00:02,000 - application.mothership.api_core - ERROR - Handler failed
```

### Log Levels

- **DEBUG**: Detailed diagnostic information
- **INFO**: General informational messages
- **WARNING**: Warning messages
- **ERROR**: Error messages
- **CRITICAL**: Critical errors

### Viewing Logs

```bash
# Follow logs in real-time
tail -f /var/log/grid-rag-enhanced/grid-rag-enhanced.log

# View last 100 lines
tail -n 100 /var/log/grid-rag-enhanced/grid-rag-enhanced.log

# Search for errors
grep -i error /var/log/grid-rag-enhanced/*.log

# Search for warnings
grep -i warning /var/log/grid-rag-enhanced/*.log
```

### Log Rotation

Logs are automatically rotated by logrotate:

```bash
# Configuration: /etc/logrotate.d/grid-rag-enhanced

/var/log/grid-rag-enhanced/*.log {
    daily
    rotate 7
    compress
    delaycompress
    missingok
    notifempty
    create 0640 grid grid
}
```

Manual rotation:

```bash
sudo logrotate -f /etc/logrotate.d/grid-rag-enhanced
```

## System Monitoring

### CPU Usage

```bash
# Check CPU usage
top
htop

# Check CPU cores
nproc
```

### Memory Usage

```bash
# Check memory usage
free -h

# Check process memory
ps aux --sort=-%mem | head
```

### Disk Usage

```bash
# Check disk usage
df -h

# Check directory size
du -sh /opt/grid-rag-enhanced
```

### Network Monitoring

```bash
# Check network connections
netstat -tulpn | grep -E '8002|8003|8004'

# Check port availability
lsof -i :8002
lsof -i :8003
lsof -i :8004
```

## Service Monitoring

### Systemd Service Status

```bash
# Check all services
systemctl status grid-rag-enhanced
systemctl status memory-mcp
systemctl status grid-agentic

# Check service logs
journalctl -u grid-rag-enhanced -f
journalctl -u memory-mcp -f
journalctl -u grid-agentic -f

# Restart services
systemctl restart grid-rag-enhanced
systemctl restart memory-mcp
systemctl restart grid-agentic
```

### Service Health

```bash
# Check if service is running
systemctl is-active grid-rag-enhanced

# Check if service is enabled
systemctl is-enabled grid-rag-enhanced

# Check service failure
systemctl is-failed grid-rag-enhanced
```

## Performance Monitoring

### Running Benchmarks

```bash
# Run performance benchmarks
python tests/performance/benchmark_rag_performance.py

# Run load tests
python tests/performance/load_test_rag.py
```

### Expected Results

**Query Latency:**
- Mean: < 300ms
- P95: < 500ms
- P99: < 1000ms

**Session Operations:**
- Create: < 10ms
- Get: < 5ms
- Delete: < 5ms

**Concurrent Queries:**
- 50+ concurrent queries
- Success rate: > 99%

## Alerting

### Alert Configuration

Alerts can be configured in `config/production.yaml`:

```yaml
monitoring:
  alerts:
    enabled: true
    webhook_url: "https://your-alert-webhook.com/alert"
    rules:
      - name: "high_latency"
        condition: "p95_latency > 500ms"
        severity: "warning"

      - name: "low_success_rate"
        condition: "success_rate < 99%"
        severity: "critical"

      - name: "high_memory"
        condition: "memory_usage > 2GB"
        severity: "warning"
```

### Alert Types

1. **High Latency**: P95 latency > 500ms
2. **Low Success Rate**: Success rate < 99%
3. **High Memory Usage**: Memory > 2GB
4. **Service Down**: Service not responding
5. **High Error Rate**: Error rate > 1%

### Alert Channels

- Webhook (configure URL in config)
- Email (if configured)
- Slack (if configured)

## Troubleshooting

### High Latency

**Symptoms:**
- Slow query responses
- P95 latency > 500ms

**Solutions:**
```bash
# Check system resources
free -h
top

# Check concurrent sessions
curl http://localhost:8002/stats

# Restart service
systemctl restart grid-rag-enhanced
```

### High Memory Usage

**Symptoms:**
- Memory > 2GB
- System slowdown

**Solutions:**
```bash
# Check memory usage
ps aux --sort=-%mem | head

# Clear old sessions
curl -X POST http://localhost:8002/sessions/cleanup

# Restart service
systemctl restart grid-rag-enhanced
```

### Service Not Responding

**Symptoms:**
- Health check fails
- Service down

**Solutions:**
```bash
# Check service status
systemctl status grid-rag-enhanced

# View logs
journalctl -u grid-rag-enhanced -n 100

# Restart service
systemctl restart grid-rag-enhanced

# Check for errors
journalctl -u grid-rag-enhanced | grep -i error
```

### High Error Rate

**Symptoms:**
- Error rate > 1%
- Failed queries

**Solutions:**
```bash
# Check error logs
grep -i error /var/log/grid-rag-enhanced/*.log

# Check service status
systemctl status grid-rag-enhanced

# Restart service
systemctl restart grid-rag-enhanced
```

## Monitoring Dashboard

### Quick Status Check

```bash
#!/bin/bash
# Quick monitoring script

echo "=== GRID Enhanced RAG Server Status ==="
echo ""

# Service status
echo "Services:"
systemctl is-active grid-rag-enhanced && echo "  ✅ grid-rag-enhanced" || echo "  ❌ grid-rag-enhanced"
systemctl is-active memory-mcp && echo "  ✅ memory-mcp" || echo "  ❌ memory-mcp"
systemctl is-active grid-agentic && echo "  ✅ grid-agentic" || echo "  ❌ grid-agentic"

echo ""

# Health checks
echo "Health Checks:"
curl -s http://localhost:8002/health | grep -q "healthy" && echo "  ✅ grid-rag-enhanced" || echo "  ❌ grid-rag-enhanced"
curl -s http://localhost:8003/health | grep -q "healthy" && echo "  ✅ memory-mcp" || echo "  ❌ memory-mcp"
curl -s http://localhost:8004/health | grep -q "healthy" && echo "  ✅ grid-agentic" || echo "  ❌ grid-agentic"

echo ""

# System resources
echo "System Resources:"
echo "  Memory: $(free -h | grep Mem | awk '{print $3 "/" $2}')"
echo "  Disk: $(df -h /opt/grid-rag-enhanced | tail -1 | awk '{print $3 "/" $2}')"
echo ""

# Recent errors
echo "Recent Errors (last 10):"
grep -i error /var/log/grid-rag-enhanced/*.log | tail -n 10
```

## Best Practices

1. **Monitor Continuously**: Set up automated monitoring for all critical metrics
2. **Log Everything**: Enable comprehensive logging for troubleshooting
3. **Set Alerts**: Configure alerts for critical failures
4. **Regular Health Checks**: Run health checks every 30 seconds
5. **Performance Benchmarks**: Run benchmarks weekly to track performance
6. **Log Rotation**: Ensure logs are rotated to prevent disk space issues
7. **Monitor Resources**: Keep an eye on CPU, memory, and disk usage
8. **Document Issues**: Document common issues and solutions

## Support

For monitoring issues:

1. Check logs: `/var/log/grid-rag-enhanced/`
2. Run diagnostics: `python tests/performance/benchmark_rag_performance.py`
3. Check documentation: `docs/MONITORING.md`
4. Open issue: https://github.com/irfankabir02/GRID/issues
