# Cursor 2.0 Migration Guide

This guide helps you migrate from the old `.cursorrules` file to the new modular `.cursor/rules/*.mdc` system.

## What Changed

### Before (Cursor 1.0)
- Single monolithic `.cursorrules` file
- All rules applied globally
- No scoping or prioritization

### After (Cursor 2.0)
- Modular `.cursor/rules/*.mdc` files with YAML frontmatter
- Scoped rules via glob patterns
- Priority-based rule application

## Migration Status

✅ **Completed**: All rules have been migrated to the new format.

The following rule files are now available in `.cursor/rules/`:

1. `project_identity.mdc` - Project overview and principles
2. `local_first.mdc` - Local-only operation constraints
3. `architecture.mdc` - Architecture rules (scoped to `src/**/*.py`)
4. `python_standards.mdc` - Python coding standards (scoped to `**/*.py`)
5. `typescript_standards.mdc` - TypeScript standards (scoped to `web-client/**/*.ts*`)
6. `api_patterns.mdc` - FastAPI patterns (scoped to `src/application/**/*.py`)
7. `testing.mdc` - Testing standards (scoped to `tests/**/*.py`)
8. `cognitive_layer.mdc` - Cognitive layer integration
9. `rag_usage.mdc` - RAG system usage guidelines
10. `code_generation.mdc` - AI code generation guidelines
11. `ai_behavior.mdc` - General AI behavior rules

## What This Means for You

### Rules Still Work
- All existing rules are preserved and continue to work
- Cursor automatically loads rules from `.cursor/rules/*.mdc`
- The old `.cursorrules` file is kept as backup but not actively used

### Improved Performance
- Rules are now scoped to relevant files only
- `.cursorignore` reduces indexing overhead
- Faster AI responses due to better context management

### New Features Available
- **Plan Mode**: Use templates in `.cursor/templates/plan/`
- **Memory**: Project patterns stored in `.cursor/memories.json`
- **Background Agents**: Configured via `.cursor/environment.json`
- **Command Templates**: Standard workflows in `.cursor/commands/`

## Using the New System

### Plan Mode
For complex tasks, use Plan Mode:
1. Press `Cmd+I` (Mac) or `Ctrl+I` (Win)
2. Select "Plan" mode
3. Reference templates in `.cursor/templates/plan/`

### Rule Scoping
Rules now apply only to matching files:
- Python rules only affect `**/*.py` files
- TypeScript rules only affect `web-client/**/*.ts*` files
- API rules only affect `src/application/**/*.py` files

### Updating Rules
To modify a rule:
1. Edit the relevant `.cursor/rules/*.mdc` file
2. Update the YAML frontmatter if needed (globs, priority)
3. Rules are automatically reloaded by Cursor

## Validation

Validate your rules:
```bash
python scripts/validate_cursor_rules.py
```

This checks:
- YAML frontmatter format
- Glob pattern syntax
- File size (< 500 lines)
- Required fields (name, description, globs)

## Regenerating .cursorignore

Keep `.cursorignore` in sync with `.gitignore`:
```bash
python scripts/generate_cursorignore.py
```

## Creating New Rules

Generate a new rule template:
```bash
python scripts/generate_cursor_rules.py --create "my-new-rule"
```

Then edit `.cursor/rules/my_new_rule.mdc` to add your rules.

## Troubleshooting

### Rules Not Applying
1. Check glob patterns match your files
2. Verify rule file format (run validator)
3. Ensure rules are in `.cursor/rules/` directory

### Performance Issues
1. Review `.cursorignore` for exclusions
2. Check rule file sizes (< 500 lines)
3. Use specific file mentions with `@Files`

## Next Steps

1. ✅ Rules migrated - Done
2. ✅ `.cursorignore` created - Done
3. ✅ Templates created - Done
4. ✅ Documentation written - Done
5. ⏭️ Test rules with Composer - Ready for testing

## Resources

- **Cursor Setup Guide**: [`docs/CURSOR_SETUP.md`](CURSOR_SETUP.md)
- **Cursor Documentation**: https://docs.cursor.com/
- **Validation Script**: `scripts/validate_cursor_rules.py`
