# Tool Integration Guide

This guide explains how to effectively use Cursor, Windsurf, and Antigravity together for maximum productivity.

## Tool Selection Decision Tree

```
Start → Task Complexity?
│
├─ Simple/Quick (< 5 min)
│  └─ → Windsurf
│     - Use file references (@file.py)
│     - "Vibe coding" with Cascade
│     - DeepWiki for quick context
│
├─ Medium/Multi-step (5-30 min)
│  └─ → Cursor (Plan Mode)
│     - Create structured plan
│     - Use plan templates
│     - Background agents for async work
│     - Multi-agent orchestration
│
└─ Complex/Autonomous (> 30 min)
   └─ → Antigravity (Agent Manager)
      - Planning Mode for complex tasks
      - Fast Mode for quick execution
      - Browser testing
      - Terminal operations
```

## Tool Strengths Matrix

| Task Type | Best Tool | Key Features |
|-----------|-----------|--------------|
| **Quick Refactor** | Windsurf | File refs, vibe coding |
| **Feature Planning** | Cursor | Plan Mode, templates |
| **Feature Implementation** | Windsurf → Antigravity | Context → Execution |
| **Bug Fixing** | Windsurf | DeepWiki, file refs |
| **Complex Debugging** | Cursor | Plan Mode, systematic approach |
| **Code Review** | Antigravity | Code-review skill |
| **Test Generation** | Antigravity | Test-generation skill |
| **Deployment** | Antigravity | Autonomous execution |
| **Database Migration** | Antigravity | Database-migration skill |
| **Architecture Planning** | Cursor | Plan Mode, impact analysis |

## Handoff Patterns

### Cursor → Windsurf

**When**: After planning, ready for implementation

**Process**:
1. Export plan context: `scripts/handoff_task.py export --plan <plan.md>`
2. Open Windsurf
3. Import context or reference plan
4. Use file references for implementation
5. Let Cascade guide execution

**Example**:
```bash
# In Cursor: Create plan for new feature
# Export: handoff_task.py export --plan .cursor/plans/new_feature.md
# In Windsurf: Reference plan, use @src/grid/core/ for context
```

### Cursor → Antigravity

**When**: Plan is ready for autonomous execution

**Process**:
1. Convert plan to workflow: `scripts/handoff_task.py convert --plan <plan.md>`
2. Open Antigravity
3. Load generated workflow
4. Execute in Planning Mode
5. Monitor execution

**Example**:
```bash
# In Cursor: Create deployment plan
# Convert: handoff_task.py convert --plan .cursor/plans/deploy.md
# In Antigravity: Load .agent/workflows/deploy.md, execute
```

### Windsurf → Antigravity

**When**: Implementation context ready for execution

**Process**:
1. Export file references: `scripts/handoff_task.py export --refs @file1.py @file2.py`
2. Convert to Antigravity format
3. Load in Antigravity
4. Execute workflow

**Example**:
```bash
# In Windsurf: Gather context with @src/grid/core/essence.py
# Export: handoff_task.py export --refs @src/grid/core/essence.py
# In Antigravity: Use resolved paths in workflow
```

## Synchronization

### Rules Sync
Keep rules consistent across tools:
```bash
# Sync rules between all tools
python scripts/sync_tools_config.py

# Dry run to see what would change
python scripts/sync_tools_config.py --dry-run

# Only sync rules (not workflows)
python scripts/sync_tools_config.py --rules-only
```

### Workflows Sync
Sync workflows between tools:
```bash
# Sync workflows
python scripts/sync_tools_config.py --workflows-only

# Validate consistency
python scripts/sync_tools_config.py --validate
```

## Common Workflows

### Feature Development
1. **Cursor**: Plan feature with `feature_implementation.md` template
2. **Windsurf**: Implement with file references and Cascade
3. **Antigravity**: Generate tests and run code review
4. **Cursor**: Final review with multi-agent chat

### Bug Fixing
1. **Windsurf**: Investigate with DeepWiki and file references
2. **Cursor**: Create debugging plan if complex
3. **Windsurf**: Implement fix with context
4. **Antigravity**: Run tests and validation

### Refactoring
1. **Cursor**: Create refactoring plan with impact analysis
2. **Windsurf**: Implement changes with file references
3. **Antigravity**: Run tests and validate
4. **Cursor**: Review architecture alignment

### Deployment
1. **Cursor**: Plan deployment steps
2. **Antigravity**: Execute deployment workflow
3. **Antigravity**: Use browser to verify
4. **Antigravity**: Monitor logs via terminal

## Context Management

### Exporting Context
```bash
# Export Cursor plan
handoff_task.py export --plan .cursor/plans/feature.md --output context.json

# Export Windsurf references
handoff_task.py export --refs @file1.py @file2.py --output context.json
```

### Importing Context
```bash
# Import context
handoff_task.py import --context context.json
```

## Best Practices

1. **Start with Planning**: Use Cursor Plan Mode for complex tasks
2. **Context is Key**: Maintain context across tool switches
3. **Sync Regularly**: Keep rules/workflows in sync
4. **Use Right Tool**: Match tool to task complexity
5. **Document Handoffs**: Note context when switching tools

## Troubleshooting

### Context Lost Between Tools
- Use `handoff_task.py export` before switching
- Import context in new tool
- Verify file paths are resolved

### Rules Out of Sync
- Run `sync_tools_config.py --validate` to check
- Use `sync_tools_config.py` to sync
- Review differences with `--dry-run`

### Workflow Not Working
- Check workflow format matches tool expectations
- Verify all referenced files exist
- Check tool-specific requirements

## Notes

- Each tool has unique strengths
- Handoffs maintain context and productivity
- Synchronization keeps configurations consistent
- Choose tool based on task complexity
- Document handoffs for future reference
