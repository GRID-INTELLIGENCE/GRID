# Git Workflow: GRID MCP Docker Stack Fixes

## Overview
This guide documents the git workflow for committing the Docker stack fixes with proper branch management and commit hygiene.

## Branch Strategy

### 1. Create Feature Branch
```bash
# Ensure you're on main/master and up to date
git checkout main
git pull origin main

# Create a descriptive feature branch
git checkout -b fix/docker-mcp-stack-health-checks

# Alternative naming conventions:
# - fix/docker-nginx-bind-mount
# - feat/mcp-health-endpoints
# - chore/docker-stack-improvements
```

### 2. Branch Naming Convention
- **fix/** - Bug fixes and corrections
- **feat/** - New features
- **chore/** - Maintenance tasks (dependencies, configs)
- **refactor/** - Code restructuring without behavior change
- **docs/** - Documentation only changes

## Commit Sequence

### Stage 1: Nginx Configuration Fix
```bash
# Stage the Nginx-related changes
git add docker/security/Dockerfile.nginx
git add docker/security/nginx-security.conf
git add docker/security/docker-compose-secure.yml

# Commit with descriptive message
git commit -m "fix(docker): resolve Nginx Windows bind-mount issue

- Create Dockerfile.nginx to embed nginx-security.conf in image
- Update docker-compose-secure.yml to build from custom Dockerfile
- Fix upstream server names to use -secure suffix for container discovery
- Remove problematic volume mount that caused directory interpretation on Windows

Resolves: Nginx container restart loop due to bind-mount ambiguity
Impact: Nginx gateway now starts successfully and remains stable"
```

### Stage 2: MCP Health Endpoints
```bash
# Stage all MCP server changes
git add workspace/mcp/servers/filesystem/production_server.py
git add workspace/mcp/servers/memory/production_server.py
git add workspace/mcp/servers/postgres/production_server.py
git add workspace/mcp/servers/database/server.py
git add workspace/mcp/servers/playwright/server.py

# Commit with detailed explanation
git commit -m "feat(mcp): add HTTP health endpoints to all MCP servers

- Implement aiohttp-based health server on port 8080 for each MCP service
- Add /health endpoint responding with 200 OK and 'healthy' text
- Use asyncio.Event().wait() to keep processes alive in daemon mode
- Modify main() to run health server only (stdio transport requires interactive mode)

Changes apply to:
- filesystem/production_server.py
- memory/production_server.py
- postgres/production_server.py
- database/server.py
- playwright/server.py

Resolves: Container restart loops due to stdio_server exiting in daemon mode
Impact: All MCP containers now pass Docker health checks and remain stable"
```

### Stage 3: Dev Stack Requirements
```bash
# Stage the requirements file
git add docker/requirements-dev.txt

# Commit with context
git commit -m "chore(docker): add development requirements file

- Create docker/requirements-dev.txt with testing and dev tools
- Includes pytest, black, ruff, mypy, jupyter, and debugging utilities
- Resolves missing file reference in Dockerfile.dev

Impact: Dev stack can now build successfully"
```

### Stage 4: Documentation (Optional but Recommended)
```bash
# If you created any documentation
git add docs/DOCKER_STACK_FIXES.md  # or similar

git commit -m "docs: document Docker stack fixes and health check implementation

- Add comprehensive guide for MCP health endpoint architecture
- Document Nginx configuration changes and rationale
- Include troubleshooting steps for common issues"
```

## Commit Message Best Practices

### Format
```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types
- **feat**: New feature
- **fix**: Bug fix
- **docs**: Documentation only
- **style**: Formatting, missing semicolons, etc.
- **refactor**: Code change that neither fixes a bug nor adds a feature
- **perf**: Performance improvement
- **test**: Adding missing tests
- **chore**: Maintain, dependencies, configs

### Subject Line Rules
- Use imperative mood ("add" not "added" or "adds")
- Don't capitalize first letter
- No period at the end
- Limit to 50 characters
- Be specific and descriptive

### Body Guidelines
- Wrap at 72 characters
- Explain **what** and **why**, not **how**
- Use bullet points for multiple changes
- Reference issue numbers if applicable

### Example Good Commit
```
fix(docker): resolve MCP container health check failures

- Add aiohttp health server to each MCP production server
- Implement /health endpoint on port 8080
- Use asyncio.Event().wait() to prevent premature exit
- Update all 5 MCP servers: filesystem, memory, postgres, database, playwright

The stdio_server transport exits immediately in daemon mode because
there's no interactive stdin/stdout. This caused containers to restart
continuously. The health server keeps the process alive and provides
Docker/Nginx with a reliable health check endpoint.

Resolves: #123
Impact: All MCP containers now stable with passing health checks
```

## Pre-Push Checklist

### 1. Review Changes
```bash
# Review all staged changes
git diff --staged

# Check commit history
git log --oneline -5

# Verify no unintended files
git status
```

### 2. Verify Build
```bash
# Ensure Docker images build successfully
docker-compose -f docker/security/docker-compose-secure.yml build

# Verify containers start and pass health checks
docker-compose -f docker/security/docker-compose-secure.yml up -d
docker ps --filter "name=grid-.*-secure"
```

### 3. Clean Commit History (if needed)
```bash
# Interactive rebase to squash/reword commits
git rebase -i HEAD~3

# Or amend the last commit
git commit --amend

# Force push if you've already pushed (use with caution)
git push --force-with-lease origin fix/docker-mcp-stack-health-checks
```

## Push and Pull Request

### 1. Push to Remote
```bash
# First time push
git push -u origin fix/docker-mcp-stack-health-checks

# Subsequent pushes
git push
```

### 2. Create Pull Request
**Title**: `Fix Docker MCP stack health checks and Nginx configuration`

**Description Template**:
```markdown
## Summary
Resolves critical issues in the GRID MCP Docker stack preventing stable operation.

## Changes
1. **Nginx Configuration Fix**
   - Created `Dockerfile.nginx` to embed config and avoid Windows bind-mount issues
   - Updated upstream server names to match `-secure` container naming
   - Removed problematic volume mount

2. **MCP Health Endpoints**
   - Added HTTP health servers to all 5 MCP production servers
   - Implemented `/health` endpoint on port 8080
   - Modified servers to run in health-only mode for daemon deployment

3. **Dev Stack Requirements**
   - Created `requirements-dev.txt` for development dependencies

## Testing
- ✅ All images build successfully
- ✅ All containers start and remain stable
- ✅ Health checks pass for all services
- ✅ Nginx gateway responds correctly

## Impact
- Eliminates container restart loops
- Enables proper Docker health monitoring
- Resolves Windows-specific bind-mount issues

## Screenshots
[Optional: Add screenshots of healthy container status]

## Related Issues
Fixes #[issue-number]
```

### 3. Code Review Preparation
```bash
# Ensure branch is up to date with main
git checkout main
git pull origin main
git checkout fix/docker-mcp-stack-health-checks
git rebase main

# Resolve any conflicts
# Then force push if needed
git push --force-with-lease
```

## Post-Merge Cleanup

### 1. Delete Local Branch
```bash
# After PR is merged
git checkout main
git pull origin main
git branch -d fix/docker-mcp-stack-health-checks
```

### 2. Delete Remote Branch
```bash
# If not auto-deleted by GitHub/GitLab
git push origin --delete fix/docker-mcp-stack-health-checks
```

## Advanced: Splitting Large Changes

If you want to split into multiple PRs for easier review:

### PR 1: Nginx Fix Only
```bash
git checkout -b fix/docker-nginx-bind-mount
# Cherry-pick or create commits for Nginx changes only
git push -u origin fix/docker-nginx-bind-mount
```

### PR 2: MCP Health Endpoints
```bash
git checkout main
git checkout -b feat/mcp-health-endpoints
# Cherry-pick or create commits for MCP changes only
git push -u origin feat/mcp-health-endpoints
```

### PR 3: Dev Stack
```bash
git checkout main
git checkout -b chore/docker-dev-requirements
# Cherry-pick or create commits for dev requirements only
git push -u origin chore/docker-dev-requirements
```

## Git Hygiene Tips

### DO ✅
- Write clear, descriptive commit messages
- Keep commits atomic (one logical change per commit)
- Test before committing
- Use feature branches
- Rebase to keep history clean
- Reference issues in commits
- Review your own changes before pushing

### DON'T ❌
- Commit directly to main/master
- Use vague messages like "fix stuff" or "WIP"
- Commit commented-out code
- Include unrelated changes in a commit
- Force push to shared branches without coordination
- Commit sensitive data (keys, passwords)
- Leave merge conflicts unresolved

## Troubleshooting

### Undo Last Commit (keep changes)
```bash
git reset --soft HEAD~1
```

### Undo Last Commit (discard changes)
```bash
git reset --hard HEAD~1
```

### Unstage Files
```bash
git reset HEAD <file>
```

### Discard Local Changes
```bash
git checkout -- <file>
```

### View Commit History
```bash
git log --oneline --graph --all --decorate
```

### Find What Changed
```bash
git diff main..fix/docker-mcp-stack-health-checks
```

## Summary

This workflow ensures:
- ✅ Clean, reviewable commit history
- ✅ Proper attribution and documentation
- ✅ Easy rollback if needed
- ✅ Clear communication of changes
- ✅ Professional git hygiene
