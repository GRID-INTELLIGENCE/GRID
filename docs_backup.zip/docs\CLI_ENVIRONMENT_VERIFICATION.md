# CLI Environment Verification

**Last Updated**: 2026-01-10  
**Status**: Verified

## Python Version Configuration

### Current Configuration

- **`.python-version`**: `3.13.11` ✅
- **`pyproject.toml`**: `requires-python = ">=3.13,<3.14"` ✅
- **Status**: Configuration matches requirements

### Verification

The project uses Python 3.13.11, which satisfies the `pyproject.toml` requirement of `>=3.13,<3.14`.

**To verify your environment**:
```bash
python --version
# Should output: Python 3.13.11
```

If using `pyenv` or similar version managers:
```bash
pyenv local 3.13.11
# This reads .python-version automatically
```

## CLI Command Registration

### Skills Commands

The `grid skills` command is properly registered in `src/grid/__main__.py`:

- **`skills list`** - Registered at line 272-273
  - Handler function: `skills_list_command()` (line 162)
  - Output: JSON format with skill metadata

- **`skills run`** - Registered at line 275-276
  - Handler function: `skills_run_command()` (line 181)
  - Supports `--args-json`, `--args-file`, and convenience flags

### Usage

```bash
# List all available skills
python -m grid skills list

# Run a specific skill
python -m grid skills run <skill_id> --args-json '{"param": "value"}'
```

### Command Structure

The CLI follows the `python -m grid` pattern:

```bash
python -m grid <command> <subcommand> [options]
```

Examples:
- `python -m grid skills list`
- `python -m grid skills run <skill_id>`
- `python -m grid analyze "text"`
- `python -m grid serve`

## Environment Setup Requirements

### Required

1. **Python 3.13.x** (specifically 3.13.11 recommended)
   - Must satisfy `>=3.13,<3.14` constraint
   - Verify with: `python --version`

2. **Virtual Environment**
   - Recommended: Use `uv` package manager
   ```bash
   uv venv --python 3.13
   .\.venv\Scripts\Activate.ps1  # Windows PowerShell
   source .venv/bin/activate     # Linux/Mac
   ```

3. **Dependencies Installed**
   ```bash
   uv sync --group dev --group test
   # or
   pip install -e ".[dev]"
   ```

### Optional

- **Version Managers**: `pyenv`, `asdf`, or similar
  - Automatically reads `.python-version` file
  - Ensures correct Python version per project

## Troubleshooting

### Issue: `python -m grid skills list` fails

**Possible causes**:

1. **Wrong Python version**
   ```bash
   # Check version
   python --version
   # Should be 3.13.x
   ```

2. **Not installed in editable mode**
   ```bash
   # Reinstall in editable mode
   pip install -e .
   ```

3. **Virtual environment not activated**
   ```bash
   # Activate virtual environment
   .\.venv\Scripts\Activate.ps1  # Windows
   source .venv/bin/activate     # Linux/Mac
   ```

4. **Module path issues**
   ```bash
   # Ensure you're in the project root
   cd e:\grid
   python -m grid skills list
   ```

### Issue: Command not found

If `python -m grid` doesn't work:

1. Verify installation:
   ```bash
   python -c "import grid; print(grid.__file__)"
   ```

2. Check `PYTHONPATH`:
   ```bash
   # Ensure src directory is in path
   export PYTHONPATH="${PYTHONPATH}:$(pwd)/src"
   ```

## Verification Checklist

- [x] `.python-version` file exists and contains `3.13.11`
- [x] `pyproject.toml` requires Python `>=3.13,<3.14`
- [x] `skills list` command registered in `src/grid/__main__.py`
- [x] `skills run` command registered in `src/grid/__main__.py`
- [x] CLI follows `python -m grid` pattern

## File References

- Python version: `.python-version`
- Project configuration: `pyproject.toml`
- CLI entry point: `src/grid/__main__.py`
- Skills list handler: `src/grid/__main__.py:162` (`skills_list_command`)
- Skills run handler: `src/grid/__main__.py:181` (`skills_run_command`)

## Notes

- The CLI uses the module execution pattern (`python -m grid`) rather than a direct `grid` executable
- All commands are registered via `argparse` in `build_parser()` function
- The skills system uses automated discovery via `SkillDiscoveryEngine`
- Skills registry is initialized from `grid.skills.registry.default_registry`
