# Skills System Comprehensive Catalog

## Overview

The GRID Skills System (ISS - Intelligent Skills System) is the core extensibility mechanism. This document catalogs all 35 skill files, their dependencies, execution patterns, and architectural components.

## Skills Infrastructure Components

### Core Infrastructure (14 files - not discoverable as skills)

1. **base.py**: Defines `Skill` protocol and `SimpleSkill` implementation
   - Protocol: `id`, `name`, `description`, `version`, `run()` method
   - `SimpleSkill`: Dataclass with handler function, automatic execution tracking

2. **registry.py**: `SkillRegistry` class with automated discovery
   - Singleton pattern via `default_registry`
   - Integrates with `SkillDiscoveryEngine` and `DependencyValidator`
   - Environment variable: `GRID_SKILLS_LEGACY_LOADER` for fallback

3. **discovery_engine.py**: `SkillDiscoveryEngine` for zero-config registration
   - Scans `grid.skills` package for skill objects
   - Skips infrastructure modules (base, registry, discovery_engine, etc.)
   - Categories skills as "high-level" or "low-level"
   - Returns `SkillMetadata` objects

4. **dependency_validator.py**: `DependencyValidator` for pre-registration validation
   - AST-based import extraction (doesn't execute code)
   - Module availability checking with 5-minute TTL cache
   - Skill-to-skill dependency detection
   - Circular dependency detection (DFS algorithm)
   - Topological ordering for load sequence

5. **execution_tracker.py**: `SkillExecutionTracker` for execution persistence
   - In-memory deque for recent history (max 1000)
   - Batch persistence to SQLite (10 records or 30s timer)
   - Config: `GRID_SKILLS_BATCH_SIZE`, `GRID_SKILLS_FLUSH_INTERVAL`, `GRID_SKILLS_PERSIST_MODE`
   - Integration with `IntelligenceInventory` for SQLite WAL storage
   - Signal classification integration

6. **performance_guard.py**: `PerformanceGuard` for regression detection
   - Real-time regression detection (>20% degradation threshold)
   - Prometheus metrics export (optional)
   - Alert deduplication window (5 minutes default)
   - Config: `GRID_SKILLS_REGRESSION_THRESHOLD` (default: 1.2), `GRID_SKILLS_ALERT_WINDOW`

7. **hot_reload_manager.py**: `HotReloadManager` for development hot-reload
   - 500ms debouncing to prevent race conditions
   - File watching via `watchdog` (optional dependency)
   - Rollback support on reload failure
   - Sequential processing to avoid conflicts

8. **ab_testing.py**: `ABTestManager` for statistical skill variant evaluation
   - A/B testing with gradual rollout (10% to 100% increments)
   - Statistical evaluation of variants

9. **version_manager.py**: `SkillVersionManager` for version tracking
   - Code snapshot versioning
   - Git SHA integration
   - Zero-latency rollback support

10. **intelligence_tracker.py**: `IntelligenceTracker` for decision tracking
    - Decision rationale capture
    - Confidence score tracking
    - Alternative evaluation

11. **intelligence_inventory.py**: `IntelligenceInventory` for SQLite persistence
    - SQLite WAL mode database (`data/skills_intelligence.db`)
    - Execution records storage
    - Intelligence records storage

12. **behavioral_analyzer.py**: `BehavioralAnalyzer` for pattern analysis
    - Behavioral pattern detection
    - Execution pattern analysis

13. **calling_engine.py**: `SkillCallingEngine` for skill invocation strategies
    - Multiple call strategies
    - Result normalization

14. **extraction_engine.py**: `SkillExtractionEngine` for metadata extraction
    - Extended skill metadata extraction

15. **decorators.py**: `@skill_function` decorator for skill registration
    - Decorator-based skill definition

16. **signal_classification.py**: Signal/noise classification
    - `SignalType`, `NoiseType` enums
    - `SignalClassifier` for classification
    - `NSRTracker` integration

17. **nsr_tracker.py**: Noise-to-Signal Ratio tracking
    - NSR calculation and monitoring

18. **signal_enhancer.py**: Signal enhancement
    - `SignalEnhancer` for threshold adjustment

19. **diagnostics.py**: `SkillsDiagnostics` for system health
    - Comprehensive diagnostic reporting

20. **persistence_verifier.py**: `PersistenceVerifier` for data integrity checks
    - Verifies SQLite persistence integrity

21. **test_skills_components.py**: Test utilities
    - Component testing helpers

22. **test_nsr_tracker.py**: NSR tracker tests
    - Test suite for NSR functionality

## Discoverable Skills (13+ files)

### RAG and Knowledge Skills

1. **rag_query_knowledge.py**: `rag.query_knowledge`
   - **Purpose**: Query GRID's project knowledge base using RAG system
   - **Dependencies**: 
     - `grid.integration.tools_bridge` (optional)
     - RAG engine via tools bridge
   - **Parameters**: `query` (required), `top_k` (default: 5), `temperature` (default: 0.7)
   - **Returns**: Answer, sources with paths/distances, confidence scores
   - **Execution Pattern**: Bridge pattern to tools/rag system

2. **knowledge_capture.py**: Knowledge capture skill
   - **Function**: `_capture_knowledge`
   - **Purpose**: Capture knowledge for storage

### Pattern Recognition Skills

3. **patterns_detect_entities.py**: `patterns.detect_entities`
   - **Purpose**: Extract named entities (PERSON, ORG, DOMAIN) from text
   - **Dependencies**: 
     - `application.mothership.ner_service` (optional, with fallback)
   - **Parameters**: `text` (required), `entity_types` (default: ["PERSON", "ORG", "DOMAIN"])
   - **Fallback**: Simple heuristic entity detection using regex patterns
   - **Returns**: Entities with type, text, position, confidence

4. **topic_extractor.py**: Topic extraction skill
   - **Function**: `_extract_topics`
   - **Purpose**: Extract topics from text

### Text Processing Skills

5. **compress_articulate.py**: `compress.articulate`
   - **Purpose**: Compress and articulate complex text using minimal characters
   - **Dependencies**: 
     - `tools.rag.config.RAGConfig` (optional, for LLM mode)
     - `tools.rag.llm.factory.get_llm_provider` (optional)
   - **Parameters**: `text`/`concept`/`input` (required), `max_chars` (default: 280), `use_llm` (optional)
   - **Execution Pattern**: 
     - LLM mode: Uses LLM for intelligent compression
     - Fallback: Heuristic trimming (first sentence + character limit)
   - **Returns**: Compressed output with character count

6. **compress_secure.py**: `compress.secure` (presumed)
   - **Function**: `_secure_compress`
   - **Purpose**: Secure compression with semantic preservation
   - **Helper Functions**: 
     - `_analyze_semantics`: Semantic analysis
     - `_calculate_semantic_preservation`: Preservation score calculation
   - **Execution Pattern**: Security-focused compression with semantic analysis

7. **context_refine.py**: `context.refine`
   - **Function**: `_refine`
   - **Purpose**: Refine context for better processing

8. **cross_reference_explain.py**: Cross-reference explanation skill
   - **Function**: `_explain`
   - **Purpose**: Cross-reference and explain concepts

### Analysis Skills

9. **analysis_process_context.py**: Context processing skill
   - **Function**: `_process_context`
   - **Helper**: `_simple_sentiment` for sentiment analysis
   - **Purpose**: Process context with sentiment analysis

10. **intelligence_git_analyze.py**: `intelligence.git_analyze`
    - **Function**: `_analyze_git`
    - **Purpose**: Analyze Git repositories for intelligence

11. **youtube_transcript_analyze.py**: YouTube transcript analysis
    - **Function**: `_analyze`
    - **Helpers**: `_read_transcript`, `_tokenize`
    - **Purpose**: Analyze YouTube transcripts

### Transformation Skills

12. **transform_schema_map.py**: Schema transformation skill
    - **Function**: `_transform`
    - **Helpers**: 
      - `_normalize_text`: Text normalization with pronoun minimization
      - `_extract_json_object`: JSON extraction
      - `_schema_spec`: Schema specification generation
      - `_split_sentences`: Sentence splitting
      - `_bucket_by_keywords`: Keyword-based bucketing
      - `_parse_sensory`: Sensory data parsing
      - `_heuristic_custom_schema`: Custom schema heuristic
      - `_heuristic_default_schema`: Default schema heuristic
      - `_render_markdown`: Markdown rendering
    - **Purpose**: Transform text into structured schemas
    - **Execution Pattern**: Complex multi-stage transformation pipeline

### Domain-Specific Skills

13. **wealth_management.py**: `WealthManagementSkill` class
    - **Purpose**: Wealth management domain-specific skill
    - **Type**: Class-based skill (not SimpleSkill)

## Skill Execution Patterns

### Pattern 1: Simple Function-Based Skills
```python
def _handler(args: Mapping[str, Any]) -> Dict[str, Any]:
    # Process args
    return {"status": "success", "result": ...}

skill = SimpleSkill(
    id="skill.id",
    name="Skill Name",
    description="Description",
    handler=_handler,
)
```

**Used by**: `compress_articulate.py`, `rag_query_knowledge.py`, `patterns_detect_entities.py`, etc.

### Pattern 2: Class-Based Skills
```python
class MySkill:
    id = "skill.id"
    name = "Skill Name"
    description = "Description"
    version = "1.0.0"
    
    def run(self, args: Mapping[str, Any]) -> Dict[str, Any]:
        # Process args
        return {"status": "success", "result": ...}
```

**Used by**: `wealth_management.py`

### Pattern 3: Skills with Optional Dependencies
Most skills use try/except blocks for optional dependencies:
- RAG skills: Bridge to `tools.rag`
- NER skills: Fallback to heuristic detection
- LLM skills: Graceful degradation when LLM unavailable

### Pattern 4: Multi-Stage Pipeline Skills
Complex skills like `transform_schema_map.py` use multiple helper functions:
1. Text normalization
2. Parsing/extraction
3. Schema generation
4. Formatting/rendering

## Dependency Graph

### External Dependencies (by skill category)

**RAG Skills**:
- `tools.rag.*` modules
- `grid.integration.tools_bridge`

**LLM Skills**:
- `tools.rag.config.RAGConfig`
- `tools.rag.llm.factory.get_llm_provider`

**NER Skills**:
- `application.mothership.ner_service.NERService` (optional)

**Analysis Skills**:
- Git libraries (for git analysis)
- YouTube transcript APIs (for transcript analysis)

### Internal Dependencies

All skills depend on:
- `grid.skills.base.SimpleSkill`
- Skill execution infrastructure (tracking, performance guard, etc.)

## Execution Flow

1. **Discovery Phase**:
   - `SkillDiscoveryEngine.discover_skills()` scans directory
   - Filters infrastructure modules
   - Extracts skill objects (instances or classes)

2. **Validation Phase**:
   - `DependencyValidator.validate_dependencies()` checks each skill
   - Validates module availability (with caching)
   - Detects circular dependencies
   - Creates dependency graph

3. **Registration Phase**:
   - Skills registered in topological order (dependencies first)
   - Only valid skills (no errors) are registered
   - Warnings logged but don't block registration

4. **Execution Phase**:
   - `SimpleSkill.run()` wraps handler execution
   - `SkillExecutionTracker` tracks execution metrics
   - `PerformanceGuard` monitors for regressions
   - Results persisted to SQLite (batched)

5. **Monitoring Phase**:
   - NSR tracking for signal quality
   - Performance metrics exported to Prometheus
   - Hot-reload watches for file changes (development)

## Configuration

### Environment Variables

- `GRID_SKILLS_PERSIST`: Enable/disable persistence (default: true)
- `GRID_SKILLS_BATCH_SIZE`: Records per batch (default: 10)
- `GRID_SKILLS_FLUSH_INTERVAL`: Seconds between flushes (default: 30)
- `GRID_SKILLS_REGRESSION_THRESHOLD`: Degradation threshold (default: 1.2 = 20%)
- `GRID_SKILLS_NSR_THRESHOLD`: Acceptable noise level (default: 0.10 = 10%)
- `GRID_SKILLS_DISCOVERY_TIMEOUT`: Discovery timeout seconds (default: 30)
- `GRID_SKILLS_SKIP_MODULES`: Comma-separated list of modules to skip
- `GRID_SKILLS_LEGACY_LOADER`: Use legacy loader (default: false)
- `GRID_SKILLS_ALERT_WINDOW`: Alert deduplication window (default: 300)

### Database Schema

SQLite database: `data/skills_intelligence.db` (WAL mode)

**Tables**:
- Execution records (skill_id, timestamp, status, input_args, output, error, execution_time_ms, confidence_score, fallback_used)
- Intelligence records (skill_id, decision_type, rationale, confidence_score, alternatives, timestamp)

## API Endpoints

Skills are exposed via Mothership API:

- `GET /api/v1/skills/health`: Health status of all skills
- `GET /api/v1/skills/intelligence/{id}`: Decision patterns for specific skill
- `GET /api/v1/skills/signal-quality`: Global NSR metrics
- `GET /api/v1/skills/diagnostics`: Full diagnostic report

## CLI Commands

- `grid skills list`: List all registered skills
- `grid skills run <skill_id> [--args-json <json>]`: Execute a skill

## Hot Reload Behavior

1. File change detected via `watchdog`
2. Change queued with timestamp
3. 500ms debounce timer starts
4. If no more changes, reload triggered:
   - Backup current version
   - Reload module via `importlib.reload()`
   - If failure, restore from backup
5. Sequential processing (one reload at a time)

## Performance Characteristics

- **Discovery**: O(n) where n = number of Python files
- **Validation**: O(n*m) where m = average imports per file (with caching)
- **Execution Tracking**: O(1) with batched persistence
- **Performance Guarding**: O(1) per execution with rolling window baseline

## Future Extensions

The skills system is designed for extensibility:
- Plugin architecture for custom skill types
- Skill composition/chaining
- Skill marketplace/distribution
- Skill versioning with backward compatibility
