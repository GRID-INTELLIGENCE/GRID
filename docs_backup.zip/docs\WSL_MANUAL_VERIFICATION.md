# WSL Manual Verification Guide

> **Quick manual checks to verify WSL optimization readiness**
> **Time**: 5 minutes

---

## Manual Verification Steps

### 1. Check if WSL is Installed

Open PowerShell and run:

```powershell
wsl --version
```

**Expected Output**: Version information for WSL
**If it fails**: Install WSL with `wsl --install`

---

### 2. Check if .wslconfig Exists

```powershell
Test-Path $env:USERPROFILE\.wslconfig
```

**Expected Output**: `True` if configured, `False` if not
**If False**: Run the setup script to create it

---

### 3. View Current .wslconfig Settings

```powershell
Get-Content $env:USERPROFILE\.wslconfig
```

**What to look for**:
- `memory=` setting (should be 4-8 GB)
- `processors=` setting (should be 4-8 cores)
- `[experimental]` section
- `autoMemoryReclaim=gradual`
- `sparseVhd=true`

**If missing**: Run setup script to create optimal configuration

---

### 4. Check Windows Defender Exclusions

```powershell
Get-MpPreference | Select-Object -ExpandProperty ExclusionPath | Where-Object { $_ -like "*wsl*" }
```

**Expected Output**: One or more paths containing "wsl" or "Ubuntu"
**If empty**: Need to add exclusions (requires Admin)

---

### 5. Check Project Location

```powershell
# Windows filesystem (current)
Test-Path E:\grid

# WSL filesystem (optimal)
wsl test -d ~/projects/grid && echo "EXISTS" || echo "NOT_FOUND"
```

**Current State**: Project at `E:\grid` (Windows FS - slower)
**Optimal State**: Project at `~/projects/grid` (WSL FS - faster)

---

### 6. Test Git Performance

```powershell
# Time a git status command
Measure-Command { wsl bash -c "cd /mnt/e/grid && git status > /dev/null 2>&1" }
```

**Performance Indicators**:
- **< 1 second**: Excellent
- **1-3 seconds**: Good
- **> 3 seconds**: Slow (needs optimization)

---

## Quick Status Check

Run these commands in sequence:

```powershell
# 1. WSL installed?
wsl echo "WSL is working"

# 2. .wslconfig exists?
if (Test-Path $env:USERPROFILE\.wslconfig) { 
    Write-Host "[OK] .wslconfig exists" -ForegroundColor Green 
} else { 
    Write-Host "[X] .wslconfig missing" -ForegroundColor Red 
}

# 3. Project location
if (Test-Path E:\grid) { 
    Write-Host "[OK] Project at E:\grid" -ForegroundColor Green 
}

# 4. WSL version
wsl --version 2>&1 | Select-Object -First 1
```

---

## Configuration Status Checklist

Mark each item as you verify:

- [ ] WSL2 is installed and working
- [ ] `.wslconfig` exists at `C:\Users\YourName\.wslconfig`
- [ ] Memory setting configured (4-8 GB)
- [ ] Processors setting configured (4-8 cores)
- [ ] Experimental features enabled
- [ ] Windows Defender exclusions added
- [ ] Project exists at `E:\grid`
- [ ] Git performance tested (record time: _____ seconds)

---

## Current Optimization Status

**Score yourself manually**:

| Item | Points | Status |
|------|--------|--------|
| WSL Installed | 10 | ☐ |
| .wslconfig exists | 10 | ☐ |
| Memory configured | 5 | ☐ |
| Processors configured | 5 | ☐ |
| Experimental features | 10 | ☐ |
| Defender exclusions | 20 | ☐ |
| Project in WSL FS | 20 | ☐ |
| **Total** | **80** | **___** |

**Rating**:
- 64-80: Excellent (80%+)
- 48-63: Good (60-79%)
- 32-47: Fair (40-59%)
- 0-31: Poor (<40%)

---

## Next Steps Based on Score

### If Score < 40 (Poor)
1. Run: `.\scripts\setup_wsl_optimization.ps1` (Admin)
2. Follow: `docs\WSL_OPTIMIZATION_CHECKLIST.md`

### If Score 40-60 (Fair)
1. Check which items are missing above
2. Focus on missing items first
3. Consider running setup script

### If Score 60-80 (Good)
1. Minor optimizations needed
2. Consider migrating to WSL filesystem if not done
3. Run benchmarks to verify

### If Score 80+ (Excellent)
1. Configuration is optimal
2. Monitor performance regularly
3. Consider fine-tuning based on workload

---

## Manual Setup (Without Scripts)

If scripts don't work, follow these manual steps:

### Step 1: Create .wslconfig

1. Open Notepad as Administrator
2. Create file at: `C:\Users\YourName\.wslconfig`
3. Add this content:

```ini
[wsl2]
processors=6
memory=8GB
swap=8GB
pageReporting=false
vmIdleTimeout=60000
localhostForwarding=true

[experimental]
autoMemoryReclaim=gradual
sparseVhd=true
```

4. Save and close

### Step 2: Add Defender Exclusions

Open PowerShell as Administrator:

```powershell
Add-MpPreference -ExclusionPath "\\wsl$\Ubuntu"
Add-MpPreference -ExclusionProcess "wsl.exe"
Add-MpPreference -ExclusionProcess "wslhost.exe"
```

### Step 3: Restart WSL

```powershell
wsl --shutdown
# Wait 10 seconds
wsl
```

### Step 4: Verify in WSL

```bash
# In WSL
free -h      # Check memory allocation
nproc        # Check CPU cores
```

---

## Troubleshooting

### "wsl: command not found"
- WSL not installed
- Install: `wsl --install` (Admin PowerShell)
- Restart computer

### "wsl --version" hangs
- WSL may need update
- Run: `wsl --update`
- Try: `wsl --shutdown` then `wsl`

### .wslconfig changes not applying
- Ensure file is at correct location
- Must restart WSL: `wsl --shutdown`
- Check for typos in config file

### Can't add Defender exclusions
- Requires Administrator privileges
- Run PowerShell as Admin
- Check if antivirus is group policy managed

---

## Performance Expectations

After full optimization:

| Operation | Before | After | Improvement |
|-----------|--------|-------|-------------|
| git status | 2-3s | <0.5s | 5-6x faster |
| Unit tests | 60s | 20-25s | 2.5-3x faster |
| Linting | 15s | 3-4s | 4-5x faster |

---

## Quick Commands Reference

```powershell
# Check WSL version
wsl --version

# List distributions
wsl --list --verbose

# Shutdown WSL
wsl --shutdown

# Update WSL
wsl --update

# Check .wslconfig location
echo $env:USERPROFILE\.wslconfig

# View .wslconfig
notepad $env:USERPROFILE\.wslconfig

# Test WSL connectivity
wsl echo "Hello from WSL"

# Check project location
wsl pwd
```

---

## Resources

- **Full Guide**: `docs\guides\WSL_PERFORMANCE_OPTIMIZATION.md`
- **Quick Reference**: `docs\WSL_QUICK_REFERENCE.md`
- **Checklist**: `docs\WSL_OPTIMIZATION_CHECKLIST.md`
- **Setup Script**: `scripts\setup_wsl_optimization.ps1`
- **Migration Script**: `scripts\migrate_to_wsl.sh`

---

## Summary

✅ **Manual verification complete when**:
- All checklist items are marked
- Score is 60+ points
- Git performance is < 2 seconds
- No red flags in verification

⚠️ **Run optimization if**:
- Score is < 60 points
- Git performance is > 3 seconds
- Multiple items unchecked
- .wslconfig doesn't exist

📝 **Record your results**:
- Date: __________________
- Score: _______ / 80
- Git time: _______ seconds
- Status: __________________

---

*Manual verification guide - Use when automated scripts have issues*
*Created: 2024*