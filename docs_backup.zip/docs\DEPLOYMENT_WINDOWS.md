# Windows Deployment Guide for Enhanced RAG Server

## Prerequisites

- Python 3.13
- uv package manager
- Windows 10+ (recommended)
- 2GB+ RAM
- 10GB+ disk space
- Administrator privileges

## Quick Start

### 1. Clone Repository

```powershell
git clone https://github.com/irfankabir02/GRID.git
cd GRID
```

### 2. Set Up Environment

```powershell
# Install uv if not present
powershell -ExecutionPolicy Bypass -c "irm https://astral.sh/uv/install.ps1 | iex"

# Create virtual environment
uv venv --python 3.13

# Install dependencies
uv sync --group dev --group test
```

### 3. Configure Environment

```powershell
# Copy production environment template
Copy-Item .env.production.template .env.production

# Edit configuration
notepad .env.production
```

Required environment variables:
- `RAG_EMBEDDING_PROVIDER`: huggingface, openai, or cohere
- `RAG_LLM_MODE`: ollama, openai, or cohere
- `OLLAMA_BASE_URL`: http://localhost:11434 (if using Ollama)
- `RAG_VECTOR_STORE_PATH`: Path to vector store

### 4. Run Deployment Script

```powershell
# Run deployment (requires administrator)
.\scripts\deploy.ps1
```

### 5. Verify Deployment

```powershell
# Check services
Get-Process python | Where-Object {$_.MainWindowTitle -like "*grid-rag-enhanced*"}
Get-Process python | Where-Object {$_.MainWindowTitle -like "*memory-mcp*"}
Get-Process python | Where-Object {$_.MainWindowTitle -like "*grid-agentic*"}

# Test endpoints
curl http://localhost:8002/health
curl http://localhost:8003/health
curl http://localhost:8004/health
```

## Manual Deployment

If the deployment script fails, follow these steps:

### 1. Create Deployment Directory

```powershell
New-Item -ItemType Directory -Force -Path "C:\grid-rag-enhanced"
```

### 2. Copy Files

```powershell
Copy-Item -Path "src\*" -Destination "C:\grid-rag-enhanced\src\" -Recurse -Force
Copy-Item -Path "tests\*" -Destination "C:\grid-rag-enhanced\tests\" -Recurse -Force
Copy-Item -Path "requirements.txt" -Destination "C:\grid-rag-enhanced\" -Force
Copy-Item -Path "pyproject.toml" -Destination "C:\grid-rag-enhanced\" -Force
Copy-Item -Path "mcp-setup\*" -Destination "C:\grid-rag-enhanced\mcp-setup\" -Recurse -Force
Copy-Item -Path "workspace\*" -Destination "C:\grid-rag-enhanced\workspace\" -Recurse -Force
```

### 3. Install Dependencies

```powershell
cd C:\grid-rag-enhanced
uv venv --python 3.13
.\.venv\Scripts\Activate.ps1
uv sync
```

### 4. Start Services

```powershell
# Start Enhanced RAG Server
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd C:\grid-rag-enhanced; .venv\Scripts\python.exe -m grid.mcp.enhanced_rag_server" -WindowStyle Normal -WindowTitle "grid-rag-enhanced"

# Start Memory Server
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd C:\grid-rag-enhanced; .venv\Scripts\python.exe workspace\mcp\servers\memory\server.py" -WindowStyle Normal -WindowTitle "memory-mcp"

# Start Agentic Server
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd C:\grid-rag-enhanced; .venv\Scripts\python.exe workspace\mcp\servers\agentic\server.py" -WindowStyle Normal -WindowTitle "grid-agentic"
```

## Configuration

### Environment Variables

Key environment variables (see `.env.production.template`):

- `RAG_EMBEDDING_PROVIDER`: Embedding model provider
- `RAG_LLM_MODE`: LLM provider mode
- `RAG_VECTOR_STORE_PATH`: Vector store location
- `LOG_LEVEL`: Logging verbosity
- `QUERY_TIMEOUT`: Query timeout in seconds

### Production Configuration

Edit `config\production.yaml` for advanced configuration:

- Server settings
- RAG parameters
- Performance targets
- Security settings
- Monitoring configuration

## Monitoring

### Logs

```powershell
# View logs in PowerShell windows
# Each service runs in its own PowerShell window with visible output
```

### Health Checks

```powershell
# Check server health
curl http://localhost:8002/health
curl http://localhost:8003/health
curl http://localhost:8004/health
```

### Performance Monitoring

```powershell
# Run benchmarks
python tests\performance\benchmark_rag_performance.py

# Run load tests
python tests\performance\load_test_rag.py
```

## Troubleshooting

### Service Won't Start

```powershell
# Check if process is running
Get-Process python | Where-Object {$_.MainWindowTitle -like "*grid-rag-enhanced*"}

# Check for errors
# View output in the service's PowerShell window
```

### Port Already in Use

```powershell
# Find process using port
netstat -ano | findstr :8002

# Kill process
taskkill /F /PID <PID>
```

### Import Errors

```powershell
# Verify Python path
$env:PYTHONPATH

# Test imports
python -c "from grid.mcp.enhanced_rag_server import EnhancedRAGMCPServer"
python -c "from tools.rag.conversational_rag import create_conversational_rag_engine"
```

### Performance Issues

```powershell
# Run performance benchmarks
python tests\performance\benchmark_rag_performance.py

# Check memory usage
Get-Process python | Sort-Object WorkingSet -Descending | Select-Object -First 5

# Check CPU usage
Get-Counter '\Processor(_Total)\% Processor Time'
```

## Rollback

If deployment fails:

```powershell
# Stop services
.\stop-services.bat

# Restore from backup
Remove-Item -Path "C:\grid-rag-enhanced\*" -Recurse -Force
Copy-Item -Path "C:\grid-rag-enhanced-backups\backup-<timestamp>\*" -Destination "C:\grid-rag-enhanced\" -Recurse -Force

# Restart services
.\start-rag-enhanced.bat
.\start-memory.bat
.\start-agentic.bat

# Verify
.\health-check.bat
```

## Performance Targets

After deployment, verify these targets:

- Query Latency (P95): < 500ms
- Session Operations: < 10ms
- Concurrent Queries: 50+
- Success Rate: > 99.9%

Run benchmarks to verify:

```powershell
python tests\performance\benchmark_rag_performance.py
```

## Security

### Authentication

Configure JWT authentication in `.env.production`:

```
REQUIRE_AUTH=true
AUTH_SECRET=your_secure_secret_here
```

### Rate Limiting

Enabled by default. Configure in `config\production.yaml`:

```yaml
security:
  rate_limiting:
    enabled: true
    queries_per_minute: 100
    burst_size: 10
```

### Input Sanitization

Enabled by default. All inputs are sanitized before processing.

## Support

For issues:

1. Check logs in service PowerShell windows
2. Run diagnostics: `python tests\performance\benchmark_rag_performance.py`
3. Check documentation: `docs\`
4. Open issue: https://github.com/irfankabir02/GRID/issues

## Windows-Specific Considerations

### PowerShell Execution Policy

If you encounter execution policy errors:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Firewall

Allow Python through Windows Firewall:

```powershell
New-NetFirewallRule -DisplayName "GRID Enhanced RAG" -Direction Inbound -LocalPort 8002,8003,8004 -Protocol TCP -Action Allow
```

### Scheduled Tasks

To start services automatically on boot:

```powershell
# Create scheduled task for grid-rag-enhanced
$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-NoExit -Command `"cd C:\grid-rag-enhanced; .venv\Scripts\python.exe -m grid.mcp.enhanced_rag_server`""
$trigger = New-ScheduledTaskTrigger -AtStartup
Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "GRID RAG Enhanced" -Description "GRID Enhanced RAG Server" -RunLevel Highest
```

## GitHub Actions Deployment

The `.github\workflows\deploy.yml` workflow automatically:

1. Runs tests
2. Verifies MCP servers
3. Verifies Ghost Registry handlers
4. Runs performance benchmarks
5. Creates deployment package
6. Uploads deployment artifact

To deploy manually:

```powershell
# Trigger workflow
gh workflow run deploy.yml

# Download artifact
gh run download <run-id>

# Extract and deploy
tar -xzf grid-rag-enhanced-*.tar.gz
cd deployment
.\scripts\deploy.ps1
```
