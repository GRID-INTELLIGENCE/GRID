# GRID Operations Playbook: Path Normalization + Optimization (Windows)

## Scope
- **Root analyzed:** `E:\grid`
- **Output goal:** Windows-safe path normalization guidance + actionable command sequence + optimization recommendations.

## Observed structure (top-level)
From `E:\grid`:
- Many **documentation/markdown** files and workflow docs.
- Nested folders such as `archive/`, `docs/`, `research/`, `workflows/`, `infrastructure/`, `web-client/`, `the process/`.

> This structure makes **path length** and **relative path ambiguity** the primary risks, especially under `archive/` and nested research snapshots.

## Microsoft path normalization facts (Windows)
- Windows normalizes most paths by **canonicalizing separators**, **applying current directory** to relative paths, **evaluating `.` and `..`**, and **trimming trailing spaces/periods**. The behavior depends on the **path type** (DOS, UNC, device, drive-relative).
  Source: https://learn.microsoft.com/en-us/dotnet/standard/io/file-path-formats
- **Relative paths are dangerous in multithreaded apps** because the current directory is **process‑wide** and can be changed by any thread. Prefer absolute paths or resolve against a known base.
  Source: https://learn.microsoft.com/en-us/dotnet/standard/io/file-path-formats
- **Long paths**: On Windows 10 (1607+) you can opt into long paths by setting `LongPathsEnabled=1` **and** making apps long‑path‑aware.
  Source: https://learn.microsoft.com/en-us/windows/win32/fileio/maximum-file-path-limitation
- **Normalization reference** (background & edge cases):
  https://learn.microsoft.com/en-us/archive/blogs/jeremykuhne/path-normalization

## Actionable command sequence (PowerShell)
> Use as‑is inside `E:\grid` to **audit**, **normalize**, and **flag risks**.

```powershell
# 0) Set root
$Root = "E:\grid"

$Files = Get-ChildItem -Path $Root -Recurse -File -Include $Patterns -ErrorAction SilentlyContinue

# 2) Flag long paths (> 240 chars is a practical early warning)
$Files | ForEach-Object {
  $len = $_.FullName.Length
  if ($len -gt 240) { [pscustomobject]@{ Length = $len; Path = $_.FullName } }
} | Sort-Object Length -Descending | Out-File "$Root\path-length-report.txt"

# 3) Normalize to absolute full paths (no relative ambiguity)
$Files | ForEach-Object {
  [System.IO.Path]::GetFullPath($_.FullName)
} | Out-File "$Root\normalized-paths.txt"

# 4) Detect trailing spaces/periods (often break tooling)
$Files | Where-Object { $_.Name -match '[\.\s]$' } |
  Select-Object FullName | Out-File "$Root\trailing-space-periods.txt"

# 5) Detect drive‑relative paths if any scripts embed them
# (basic scan for "D:folder" style in text files)
$TextFiles = $Files | Where-Object { $_.Extension -in '.md','.json','.yml','.yaml','.py','.toml','.ts','.tsx','.css','.html' }
$TextFiles | ForEach-Object {
  Select-String -Path $_.FullName -Pattern '^[A-Za-z]:(?!\\)' -AllMatches
} | Out-File "$Root\drive-relative-usage.txt"
```

## Optimization recommendations (based on E:\grid layout)
1. **Reduce deep nesting under `archive/` and snapshots** to avoid long‑path failures. Consider flattening or relocating archived snapshots.
2. **Prefer absolute paths in scripts/configs**, especially in workflows and Python/TS tooling. Resolve relative paths at runtime using a known base.
3. **Standardize separators**: always emit `\` in Windows‑specific config files.
4. **Avoid trailing spaces/periods** in file/directory names (Windows trims these during normalization, causing access issues).
5. **Long paths policy** (if needed): enable `LongPathsEnabled=1` and ensure tools are long‑path‑aware.

## Optional: enable long paths (Admin PowerShell)
```powershell
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -Value 1 -PropertyType DWORD -Force
```
> Requires restart for all processes to see it. Also ensure applications are long‑path‑aware.

## Thread‑safety note (routing paths in multi‑threaded tools)
- Because the **current directory is process‑wide**, do **not** rely on relative paths in multi‑threaded workloads. Always resolve against an explicit base (e.g., `Resolve-Path -Path $Root`).

---
**Next:** Use `GRID_MODULE_SPEC_TEMPLATE.md` to apply the same standards to any submodule or new directory.
