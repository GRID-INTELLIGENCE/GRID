# EUFLE Integration Documentation

## Overview

EUFLE (Enhanced Unified Framework for Learning and Execution) is an embedded system within GRID that provides model management, agent orchestration, and production runtime capabilities. This document catalogs the EUFLE structure and integration points with GRID.

## EUFLE Structure

### Directory Structure

**Location**: `grid/EUFLE/`

**Size**: ~2000+ files (large embedded system)

### Core Components

#### 1. Agents System (`EUFLE/agents/`)

**Purpose**: Agent orchestration and management.

**Files (26 files)**:
- `production_agent.py`: Production agent implementation
- `personal_agent.py`: Personal agent implementation
- `enhanced_personal_agent.py`: Enhanced agent with advanced features
- `agentic_orchestrator.py`: Agent orchestration logic

**Subdirectories**:

- **orchestrator/** (6 files):
  - `agent_router.py`: Agent routing logic
  - `orchestrator.py`: Main orchestrator
  - `pipeline_executor.py`: Pipeline execution
  - `session_manager.py`: Session management
  - `unified_orchestrator.py`: Unified orchestration

- **plugins/** (6 files):
  - `plugin_interface.py`: Plugin interface definition
  - `plugin_manager.py`: Plugin management
  - `builtin/`: Built-in plugins
    - `context_plugin.py`: Context management
    - `enhanced_memory_plugin.py`: Enhanced memory
    - `memory_plugin.py`: Basic memory
    - `reasoning_plugin.py`: Reasoning capabilities

- **context/** (4 files):
  - `context_manager.py`: Context management
  - `memory_system.py`: Memory system
  - `relevance_scorer.py`: Relevance scoring

- **quality/** (4 files):
  - `coherence_checker.py`: Coherence checking
  - `fact_verifier.py`: Fact verification
  - `response_evaluator.py`: Response evaluation

#### 2. Light of the Seven (`EUFLE/lightofthe7/`)

**Purpose**: Cognitive layer implementation.

**Size**: 556 files
- 223 Python files
- 137 Markdown files
- 79 JSON files
- Remaining: various formats

**Structure**: Complex nested structure with cognitive load management, decision support, mental models, and integration layers.

#### 3. llama.cpp Integration (`EUFLE/llama.cpp/`)

**Purpose**: Native model execution via llama.cpp.

**Size**: 1,527 files
- 220 C++ files
- 159 CUDA files
- 151 compilation files
- Remaining: headers, configs, tests

**Features**:
- Native model inference
- CUDA acceleration
- GGUF model support
- WSL integration (Windows Subsystem for Linux)

#### 4. Configuration (`EUFLE/config/`, `EUFLE/configs/`)

**Config Files**:
- `agent_config.py`: Agent configuration
- `model_registry.py`: Model registry
- `unified_config.py`: Unified configuration
- `unified_config.json`: JSON configuration

**Config Specifications**:
- `budget_rules.json`: Budget automation rules
- `eufle_defaults.json`: Default settings
- `model_specs.json`: Model specifications
- `processing_unit.json`: Processing unit config
- `qualityGates.json`: Quality gates
- `swing_report.json`: Swing analysis report
- `times.json`: Timing configuration

#### 5. Deployment (`EUFLE/deployment/`)

**Files** (4 files):
- `monitoring.py`: Monitoring integration
- `start_agent.py`: Agent startup script
- `start_production.py`: Production startup script

**Production Entry Point**:
```bash
python deployment/start_production.py --interactive
```

#### 6. Monitoring (`EUFLE/monitoring/`)

**Purpose**: Prometheus and Grafana integration.

**Files**:
- `prometheus.yml`: Prometheus configuration
- `grafana/`: Grafana dashboards and configs

#### 7. RAG (`EUFLE/rag/`)

**Purpose**: RAG implementation for EUFLE.

**Files** (2 files):
- `retriever.py`: RAG retriever
- `__init__.py`: RAG module initialization

#### 8. Training (`EUFLE/training/`)

**Purpose**: Model training utilities.

**Files** (4 files):
- `convert_to_gguf.py`: GGUF conversion
- `enhanced_trainer.py`: Enhanced training
- `finetune_hf_model.py`: HuggingFace fine-tuning
- `prepare_hf_dataset.py`: Dataset preparation

#### 9. Observability (`EUFLE/observability/`)

**Purpose**: Observability tools.

**Files** (4 files): Observability integrations

#### 10. Tracing (`EUFLE/tracing/`)

**Purpose**: Tracing system.

**Files** (2 files):
- `minimal_tracer.py`: Minimal tracing implementation

#### 11. Studio (`EUFLE/studio/`)

**Purpose**: Studio interface.

**Files** (4 files):
- `agentService.ts`: Agent service (TypeScript)
- `unified_api.py`: Unified API
- `web_ui.py`: Web UI

#### 12. Scripts (`EUFLE/scripts/`)

**Purpose**: Utility scripts.

**Files** (26 files):
- 18 Python files
- 7 Shell scripts
- 1 TOML config

**Examples**:
- Model validation
- Health checks
- Monitoring scripts

#### 13. Tests (`EUFLE/tests/`)

**Purpose**: Test suite.

**Files** (8 files):
- `test_budget_automation_refactored.py`
- `test_cli_inference.py`
- `test_flow_diffusion.py`
- `test_onboarding_gridstral.py`
- `test_plugin_system.py`
- `test_sessions_policy.py`
- `test_smoke.py`
- `test_swing_quantize.py`

#### 14. HF-Models (`EUFLE/hf-models/`)

**Purpose**: HuggingFace model storage.

**Files** (31 files):
- 11 JSON files (configs, tokenizers)
- 5 safetensors files (model weights)
- 5 no-extension files
- Remaining: various model files

**Default Model**: `ministral-14b` at `hf-models/ministral-14b`

## Integration Points with GRID

### 1. Distribution Bridge (`grid/distribution/eufle_bridge.py`)

**Purpose**: Bridge between GRID and EUFLE for settings synchronization.

**Features**:
- Synchronize models inventory
- Sync configuration settings
- Bridge between domains

**Configuration**: `config/eufle_sync.yaml`

**Usage**:
```python
from grid.distribution.eufle_bridge import EUFLEBridge

bridge = EUFLEBridge()
result = bridge.sync_settings()
```

### 2. Integration Methods

#### Settings Synchronization

**Source**: `EUFLE/models_inventory.yaml`  
**Target**: `grid/config/eufle_models.yaml`

**Process**:
1. Load EUFLE models inventory
2. Sync to GRID config
3. Update GRID model registry

#### Model Routing

**Integration**: EUFLE provides model routing capabilities to GRID.

**Usage**: GRID can route inference requests to EUFLE models.

#### Agent Processing

**Integration**: EUFLE processing unit can be used by GRID agentic system.

**Bridge**: `grid/distribution/` provides access to EUFLE processing unit.

### 3. Model Providers

**Supported Providers**:
1. **Ollama**: Local models via Ollama API
   - Default: `mistral-nemo:latest`
   - Configuration: `EUFLE_DEFAULT_PROVIDER=ollama`

2. **HuggingFace Transformers**: Local HF models
   - Default: `hf-models/ministral-14b`
   - Configuration: `EUFLE_DEFAULT_PROVIDER=transformers`

3. **llama.cpp**: Native GGUF models
   - Default: GGUF model via WSL llama-cli
   - Configuration: `EUFLE_DEFAULT_PROVIDER=llamacpp`

### 4. Configuration Flow

```
EUFLE/config/models_inventory.yaml
        ↓
EUFLEBridge.sync_settings()
        ↓
grid/config/eufle_models.yaml
        ↓
grid/distribution/model_router.py
```

## Production Runtime

### Entry Point

```bash
python deployment/start_production.py --interactive
```

### Interactive Commands

- `/health`: Overall status + component health
- `/metrics`: Recent request stats

### Model Governance

**Configuration**: `config/production.json`

```json
{
  "model_governance_enabled": true,
  "model_governance_mode": "warn",
  "models_inventory_path": "E:/EUFLE/models_inventory.yaml"
}
```

**Modes**:
- `warn`: Log warnings but continue
- `block`: Stop startup if inventory checks fail

## Architecture Patterns

### 1. Agent Orchestration

**Pattern**: Multi-agent system with orchestration

**Components**:
- Agent Router: Routes requests to appropriate agent
- Pipeline Executor: Executes agent pipelines
- Session Manager: Manages agent sessions

### 2. Plugin System

**Pattern**: Plugin-based architecture

**Features**:
- Plugin interface definition
- Plugin management
- Built-in plugins (context, memory, reasoning)

### 3. Model Routing

**Pattern**: Provider-based model routing

**Providers**:
- Ollama
- HuggingFace
- llama.cpp

### 4. Quality Gates

**Pattern**: Quality assurance pipeline

**Components**:
- Coherence checking
- Fact verification
- Response evaluation

## Configuration Files

### EUFLE Configuration

**Location**: `EUFLE/config/`, `EUFLE/configs/`

**Files**:
- `agent_config.py`: Agent configuration
- `unified_config.json`: Unified configuration
- `model_specs.json`: Model specifications
- `processing_unit.json`: Processing unit config
- `qualityGates.json`: Quality gates

### GRID-EUFLE Bridge

**Location**: `grid/config/eufle_sync.yaml`

**Purpose**: Synchronization configuration between GRID and EUFLE.

## Testing

### Smoke Tests

**Location**: `EUFLE/tests/`

**Files**:
- `test_smoke.py`: Basic smoke tests
- `test_cli_inference.py`: CLI inference tests
- `test_plugin_system.py`: Plugin system tests

### Validation

**Scripts**:
- `scripts/validate_models.py`: Model validation
- `scripts/monitor_eufle.py`: Monitoring validation

## Monitoring

### Prometheus

**Configuration**: `EUFLE/monitoring/prometheus.yml`

**Metrics**: System metrics, agent metrics, model metrics

### Grafana

**Location**: `EUFLE/monitoring/grafana/`

**Dashboards**: Custom dashboards for EUFLE monitoring

## Best Practices

1. **Model Governance**: Always validate models against inventory
2. **Settings Sync**: Use EUFLEBridge for configuration synchronization
3. **Production**: Use production entry point for production deployments
4. **Monitoring**: Enable Prometheus/Grafana for observability
5. **Testing**: Run smoke tests before deployment

## Future Extensions

1. **Full Integration**: Deeper integration between GRID and EUFLE
2. **Shared Models**: Shared model registry between systems
3. **Unified API**: Single API for both GRID and EUFLE
4. **Cross-System Learning**: Learning coordination between systems
