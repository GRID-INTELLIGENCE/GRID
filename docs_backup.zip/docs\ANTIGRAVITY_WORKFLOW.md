# Antigravity Workflow Guide

This guide explains when and how to use Antigravity effectively for GRID development.

## When to Use Antigravity

Antigravity is best for:
- **Autonomous execution** of well-defined tasks
- **Complex workflows** requiring multiple steps
- **Browser testing** without leaving IDE
- **Terminal operations** (git, tests, logs)
- **Background tasks** that run independently

## Key Features

### Planning Mode vs Fast Mode

**Planning Mode** (default):
- Requires upfront thought and planning
- Best for complex, multi-step tasks
- Creates structured execution plan
- Validates before execution

**Fast Mode**:
- Immediate execution
- Best for quick fixes and simple tasks
- Minimal planning overhead
- Fast feedback loop

### Agent Manager
- Orchestrates multiple agents
- Manages task execution
- Handles dependencies
- Monitors progress

### Built-in Browser
- Test web interfaces without leaving IDE
- Navigate documentation
- Verify deployments
- Interactive testing

### Terminal Access
- Run git commands
- Execute tests
- Check logs
- Manage processes

## Available Workflows

Workflows in `.agent/workflows/`:
- `add_feature.md` - Feature implementation
- `fix_bug.md` - Bug fixing
- `deploy_staging.md` - Deployment automation
- `run_linting.md` - Code quality checks
- `migrate_database.md` - Database migrations
- `generate_tests.md` - Test generation

## Available Skills

Skills in `.agent/skills/`:
- `code-review` - Code review and quality checks
- `test-generation` - Automated test creation
- `rag-query` - RAG system queries
- `database-migration` - Safe database operations
- `api-testing` - API endpoint testing
- `cognitive-integration` - Cognitive layer integration

## Workflow Patterns

### Feature Implementation
1. **Plan**: Use Planning Mode to create execution plan
2. **Execute**: Let Agent Manager orchestrate implementation
3. **Test**: Run tests using terminal access
4. **Validate**: Use browser to verify if web interface
5. **Review**: Use code-review skill for quality check

### Deployment
1. **Pre-checks**: Run linting and tests
2. **Build**: Create deployment package
3. **Deploy**: Execute deployment script
4. **Validate**: Use browser to verify deployment
5. **Monitor**: Check logs and health endpoints

### Database Migration
1. **Backup**: Create database backup
2. **Test**: Run migration on test database
3. **Execute**: Run migration script
4. **Validate**: Verify data integrity
5. **Rollback**: Test rollback procedure

## Best Practices

1. **Use Planning Mode for Complex Tasks**: Plan before execution
2. **Use Fast Mode for Quick Fixes**: Immediate execution
3. **Leverage Browser**: Test without leaving IDE
4. **Use Terminal**: Run commands directly
5. **Monitor Execution**: Watch progress and logs

## Integration with Other Tools

### From Cursor
- Convert Cursor plan to Antigravity workflow
- Use `scripts/handoff_task.py convert --plan <plan.md>`
- Maintain context from Cursor planning

### From Windsurf
- Export file references as paths
- Convert Windsurf context to Antigravity format
- Use resolved paths in Antigravity workflows

## Configuration

### GEMINI.md
- Project context and identity
- Core principles and values
- Critical paths and commands
- Recent memories and decisions

### Browser Allowlist
- Configured in `%USERPROFILE%\.gemini\antigravity\browserAllowlist.txt`
- Allows access to GitHub, PyPI, documentation sites
- Security control for browser access

## Examples

### Example: Autonomous Feature Implementation
```bash
# 1. Start Antigravity in Planning Mode
# 2. Load add_feature workflow
# 3. Agent Manager orchestrates:
#    - Code implementation
#    - Test generation
#    - Code review
#    - Documentation
# 4. Monitor progress in Antigravity UI
```

### Example: Deployment Automation
```bash
# 1. Load deploy_staging workflow
# 2. Agent Manager executes:
#    - Pre-deployment checks
#    - Build and package
#    - Deploy to staging
#    - Post-deployment validation
# 3. Use browser to verify deployment
# 4. Check logs via terminal
```

### Example: Database Migration
```bash
# 1. Load migrate_database workflow
# 2. Use database-migration skill
# 3. Agent Manager executes:
#    - Backup creation
#    - Migration execution
#    - Validation
# 4. Monitor via terminal
# 5. Rollback if needed
```

## Notes

- Antigravity excels at autonomous execution
- Use for well-defined, repeatable tasks
- Leverage browser for testing
- Use terminal for direct command execution
- Monitor execution progress carefully
