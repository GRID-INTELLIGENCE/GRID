# Configuration System Documentation

## Overview

GRID uses a multi-layered configuration system supporting YAML files, environment variables, and secrets management. This document maps the complete configuration architecture.

## Configuration Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│              Environment Variables (Highest Priority)        │
│  (.env files, system environment)                            │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              YAML Configuration Files                        │
│  (config/*.yaml, config/*.json)                             │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              Secrets Management                              │
│  (LocalSecretsManager, GCP Secret Manager)                  │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              Default Values (Lowest Priority)                │
│  (Hardcoded defaults in code)                                │
└──────────────────────────────────────────────────────────────┘
```

## Configuration Sources

### 1. Environment Variables

**Location**: System environment, `.env` files

**Loading**: Python `os.getenv()`, `os.environ.get()`

**Priority**: Highest (overrides all other sources)

**Common Patterns**:
```python
value = os.getenv("VAR_NAME", default_value)
value = os.environ.get("VAR_NAME", "default")
```

### 2. YAML Configuration Files

**Location**: `config/` directory

**Files**:
- `api_routes.yaml`: API route configuration
- `api_routes_factory_defaults.yaml`: API route defaults
- `arena_config.yaml`: Arena configuration
- `eufle_sync.yaml`: EUFLE synchronization
- `eufle_models.yaml`: EUFLE model inventory
- `qualityGates.json`: Quality gates
- `qualityGates.py`: Quality gates (Python)

**Loading**:
```python
import yaml
with open("config/file.yaml") as f:
    config = yaml.safe_load(f)
```

### 3. Secrets Management

**Location**: Multiple providers

**Providers**:
1. **Local Secrets Manager**: `~/.grid/secrets.db`
2. **GCP Secret Manager**: Cloud secrets
3. **Environment Variables**: Direct env vars
4. **Vault**: HashiCorp Vault (optional)

**Usage**:
```python
from grid.security.local_secrets_manager import get_local_secrets_manager

manager = get_local_secrets_manager()
secret = manager.get("api_key")
```

## Configuration Categories

### 1. API Configuration

**File**: `config/api_routes.yaml`

**Schema**: 2026.1

**Structure**:
```yaml
__schema__: 2026.1
prefix: "/api/v1"
routers:
  - module: "application.mothership.routers.auth:router"
    enabled: true
  - module: "application.mothership.routers.navigation_simple:router"
    enabled: true
    stream: false
    hooks:
      pre_import: "validate_streaming_capability"
```

**Environment Variables**:
- None (file-based configuration)

**Loading**: `application/mothership/routers/__init__.py` via `_load_api_routes_config()`

### 2. Skills Configuration

**Environment Variables**:
- `GRID_SKILLS_PERSIST`: Enable/disable persistence (default: true)
- `GRID_SKILLS_BATCH_SIZE`: Records per batch (default: 10)
- `GRID_SKILLS_FLUSH_INTERVAL`: Seconds between flushes (default: 30)
- `GRID_SKILLS_REGRESSION_THRESHOLD`: Degradation threshold (default: 1.2)
- `GRID_SKILLS_NSR_THRESHOLD`: Acceptable noise level (default: 0.10)
- `GRID_SKILLS_DISCOVERY_TIMEOUT`: Discovery timeout (default: 30)
- `GRID_SKILLS_SKIP_MODULES`: Comma-separated modules to skip
- `GRID_SKILLS_LEGACY_LOADER`: Use legacy loader (default: false)
- `GRID_SKILLS_ALERT_WINDOW`: Alert deduplication window (default: 300)
- `GRID_SKILLS_PERSIST_MODE`: batch|immediate|off (default: batch)

**Files**: None (environment-based)

**Location**: `grid/skills/` components

### 3. RAG Configuration

**Environment Variables**:
- `RAG_EMBEDDING_PROVIDER`: ollama|huggingface (default: ollama)
- `RAG_EMBEDDING_MODEL`: Embedding model name (default: nomic-embed-text-v2)
- `RAG_LLM_MODE`: local|openai (default: local)
- `RAG_LLM_MODEL_LOCAL`: Local LLM model (default: mistral-nemo:latest)
- `RAG_LLM_MODEL_OPENAI`: OpenAI model (default: gpt-4)
- `RAG_VECTOR_STORE_PROVIDER`: chromadb|databricks|in_memory (default: chromadb)
- `RAG_COLLECTION_NAME`: Collection name (default: grid_knowledge)
- `RAG_VECTOR_STORE_PATH`: ChromaDB persistence path
- `RAG_CHUNK_SIZE`: Chunk size in tokens (default: 512)
- `RAG_CHUNK_OVERLAP`: Overlap size (default: 50)
- `RAG_USE_HYBRID`: Enable hybrid retrieval (default: false)
- `RAG_USE_RERANKER`: Enable reranking (default: false)
- `RAG_CACHE_ENABLED`: Enable query cache (default: true)
- `RAG_CACHE_SIZE`: Cache size (default: 1000)
- `RAG_CACHE_TTL`: Cache TTL in seconds (default: 3600)
- `RAG_QUALITY_THRESHOLD`: Minimum file quality (0.0-1.0, default: 0.0)
- `OLLAMA_BASE_URL`: Ollama server URL (default: http://localhost:11434)

**Files**: None (environment-based)

**Location**: `tools/rag/config.py` via `RAGConfig.from_env()`

### 4. Security Configuration

**Environment Variables**:
- `MOTHERSHIP_SECRET_KEY`: JWT secret key (required in production)
- `GRID_ENCRYPTION_KEY`: Encryption key (base64 encoded)
- `GRID_SECURITY_ENABLED`: Enable security features (default: true)
- `GRID_AUDIT_LOG_ENABLED`: Enable audit logging (default: true)
- `GRID_PII_REDACTION_MODE`: PII redaction mode (none, partial, full)
- `JWT_ACCESS_TOKEN_EXPIRE_MINUTES`: Access token lifetime (default: 30)
- `JWT_REFRESH_TOKEN_EXPIRE_DAYS`: Refresh token lifetime (default: 7)
- `JWT_ALGORITHM`: Signing algorithm (default: HS256)

**Secrets**:
- Stored in LocalSecretsManager or GCP Secret Manager
- `~/.grid/secrets.db` for local storage

**Location**: `application/mothership/security/`, `grid/security/`

### 5. Database Configuration

**Environment Variables**:
- `MOTHERSHIP_DATABASE_URL`: Database connection string
- `DATABRICKS_HOST`: Databricks host
- `DATABRICKS_TOKEN`: Databricks token
- `DATABRICKS_HTTP_PATH`: Databricks HTTP path
- `DATABRICKS_CATALOG`: Databricks catalog
- `DATABRICKS_SCHEMA`: Databricks schema

**Files**: `alembic.ini` (migrations)

**Location**: `application/mothership/db/engine.py`

### 6. Mothership Configuration

**Environment Variables**:
- `MOTHERSHIP_APP_NAME`: Application name
- `MOTHERSHIP_APP_VERSION`: Application version
- `MOTHERSHIP_ENVIRONMENT`: Environment (production, development, testing)
- `MOTHERSHIP_DEBUG_ENABLED`: Enable debug mode (default: false)
- `MOTHERSHIP_HOST`: Server host (default: 0.0.0.0)
- `MOTHERSHIP_PORT`: Server port (default: 8080)
- `MOTHERSHIP_LOG_LEVEL`: Log level (default: INFO)

**Files**: `application/mothership/config/` (Pydantic settings)

**Location**: `application/mothership/config/` via `MothershipSettings`

### 7. Agentic System Configuration

**Environment Variables**:
- `GRID_SKILL_STORE_PATH`: Skill store path (default: C:/Users/irfan/.gemini/antigravity/knowledge)
- `GRID_EVENT_BUS_REDIS_ENABLED`: Enable Redis (default: false)
- `GRID_EVENT_BUS_REDIS_HOST`: Redis host (default: localhost)
- `GRID_EVENT_BUS_REDIS_PORT`: Redis port (default: 6379)
- `GRID_EVENT_BUS_MAX_HISTORY`: Max event history (default: 1000)

**Files**: None (environment-based)

**Location**: `grid/agentic/`

### 8. EUFLE Configuration

**Files**:
- `config/eufle_sync.yaml`: EUFLE synchronization
- `config/eufle_models.yaml`: EUFLE model inventory

**Structure**:
```yaml
sync:
  source_path: "e:/eufle"
  target_path: "e:/grid"
```

**Location**: `grid/distribution/eufle_bridge.py`

### 9. Resonance Configuration

**Environment Variables**:
- `RESONANCE_DEFINITIVE_ENABLED`: Enable definitive endpoint (default: true)

**Files**: None (environment-based)

**Location**: `application/resonance/api/router.py`

### 10. Quality Gates Configuration

**Files**:
- `config/qualityGates.json`: Quality gates (JSON)
- `config/qualityGates.py`: Quality gates (Python)

**Purpose**: Define quality thresholds and validation rules

**Location**: `config/` directory

## Configuration Loading Patterns

### Pattern 1: Environment Variable with Default

```python
value = os.getenv("VAR_NAME", "default_value")
```

**Used by**: Most components

**Example**: `grid/skills/execution_tracker.py`

### Pattern 2: Pydantic Settings

```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "mothership"
    environment: str = "production"
    
    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()
```

**Used by**: `application/mothership/config/`

**Example**: `MothershipSettings`

### Pattern 3: YAML File Loading

```python
import yaml

with open("config/file.yaml") as f:
    config = yaml.safe_load(f)
```

**Used by**: Router configuration, EUFLE sync

**Example**: `application/mothership/routers/__init__.py`

### Pattern 4: Secrets Manager

```python
from grid.security.local_secrets_manager import get_local_secrets_manager

manager = get_local_secrets_manager()
secret = manager.get("api_key")
```

**Used by**: API keys, encryption keys

**Example**: `grid/security/local_secrets_manager.py`

### Pattern 5: GCP Secret Manager

```python
from grid.security.gcp_secrets import get_gcp_provider

provider = get_gcp_provider()
secret = provider.get_secret("secret-name")
```

**Used by**: Production secrets

**Example**: `grid/security/gcp_secrets.py`

## Configuration Validation

### 1. Secret Validation

**Location**: `application/mothership/security/secret_validation.py`

**Features**:
- Secret strength validation
- Length requirements (32 chars dev, 64 chars prod)
- Pattern validation
- Environment-aware validation

**Usage**:
```python
from application.mothership.security.secret_validation import validate_secret_strength

strength = validate_secret_strength(secret, environment)
if strength == SecretStrength.WEAK:
    # Handle weak secret
    pass
```

### 2. Configuration Schema Validation

**Location**: Pydantic models for configuration

**Features**:
- Type validation
- Range validation
- Enum validation
- Required field validation

**Example**: `MothershipSettings` with Pydantic validation

## Configuration Files Reference

### YAML Files

| File | Purpose | Location |
|------|---------|----------|
| `api_routes.yaml` | API route configuration | `config/` |
| `api_routes_factory_defaults.yaml` | API route defaults | `config/` |
| `arena_config.yaml` | Arena configuration | `config/` |
| `eufle_sync.yaml` | EUFLE synchronization | `config/` |
| `eufle_models.yaml` | EUFLE model inventory | `config/` |
| `qualityGates.json` | Quality gates | `config/` |

### JSON Files

| File | Purpose | Location |
|------|---------|----------|
| `qualityGates.json` | Quality gates | `config/` |
| `delegation_spec.json` | Delegation specifications | `config/` |
| `staircase_intelligence_seed.json` | Seed data | `config/seeds/` |

### Python Config Files

| File | Purpose | Location |
|------|---------|----------|
| `qualityGates.py` | Quality gates (Python) | `config/` |

## Secrets Management

### Local Secrets Manager

**Storage**: `~/.grid/secrets.db` (SQLite)

**Encryption**: AES-256-GCM

**CLI**:
```bash
python -m grid.security.local_secrets_manager set MISTRAL_API_KEY "your-key"
python -m grid.security.local_secrets_manager get MISTRAL_API_KEY
python -m grid.security.local_secrets_manager list
python -m grid.security.local_secrets_manager delete MISTRAL_API_KEY
```

**API**:
```python
from grid.security.local_secrets_manager import get_local_secrets_manager

manager = get_local_secrets_manager()
manager.set("api_key", "value")
value = manager.get("api_key")
manager.delete("api_key")
```

### GCP Secret Manager

**Storage**: Google Cloud Secret Manager

**Usage**:
```python
from grid.security.gcp_secrets import get_gcp_provider

provider = get_gcp_provider()
secret = provider.get_secret("secret-name")
```

**Configuration**:
- `GOOGLE_APPLICATION_CREDENTIALS`: Path to GCP credentials JSON
- `GCP_PROJECT_ID`: GCP project ID

## Environment-Specific Configuration

### Development

**Default**: `.env` file (if present)

**Characteristics**:
- Debug mode enabled
- Verbose logging
- Weaker secret validation (warnings only)
- Local secrets manager

### Production

**Default**: Environment variables

**Characteristics**:
- Debug mode disabled
- Structured logging
- Strict secret validation (fail-fast)
- GCP Secret Manager preferred

### Testing

**Default**: Test-specific environment

**Characteristics**:
- Mock secrets
- In-memory databases
- Fast test execution
- Isolated configuration

## Configuration Best Practices

1. **Never Commit Secrets**:
   - Use `.env` files (gitignored)
   - Use secrets manager
   - Use environment variables

2. **Use Environment Variables for Deployment**:
   - Platform-specific configuration
   - Secret injection
   - Dynamic configuration

3. **Validate Configuration**:
   - Use Pydantic for validation
   - Validate secrets strength
   - Check required fields

4. **Document Configuration**:
   - Document all environment variables
   - Document configuration files
   - Document default values

5. **Use Configuration Hierarchy**:
   - Environment variables override files
   - Files override defaults
   - Clear precedence rules

## Configuration Loading Order

1. **Default Values**: Hardcoded in code
2. **YAML Files**: Loaded from `config/` directory
3. **Environment Variables**: Override files
4. **Secrets Manager**: For sensitive values
5. **Runtime Overrides**: Programmatic configuration

## Future Extensions

1. **Configuration Hot Reload**: Reload configuration without restart
2. **Configuration Versioning**: Track configuration changes
3. **Configuration Templates**: Template-based configuration
4. **Configuration Validation**: Schema-based validation
5. **Configuration Monitoring**: Track configuration usage
