# GRID Deployment Map

**Last Updated:** 2026-01-07
**Status:** ✅ All CI/CD jobs configured and passing

## Overview

This document provides a comprehensive map of the GRID project's deployment architecture, CI/CD pipeline configuration, and deployment strategies across different environments.

---

## CI/CD Pipeline Architecture

### Workflow Files

| Workflow File | Purpose | Triggers | Status |
|--------------|---------|----------|--------|
| `.github/workflows/main.yaml` | Main CI/CD pipeline | Push/PR to main, develop, feature branches | ✅ Active |
| `.github/workflows/release.yaml` | Release & PyPI publishing | Tag push (v*.*.*), manual dispatch | ✅ Active |

### Main CI/CD Pipeline Jobs

The main pipeline (`.github/workflows/main.yaml`) consists of the following jobs:

```
┌─────────────────────────────────────────────────────────┐
│              GRID CI/CD Pipeline Flow                   │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────┐    ┌──────────┐    ┌──────────┐          │
│  │  Push   │───▶│   Lint   │───▶│   Test   │          │
│  │   PR    │    └──────────┘    └──────────┘          │
│  └─────────┘    ┌──────────┐         │                │
│       │         │ Security │         ▼                │
│       └────────▶│   Scan   │    ┌──────────┐          │
│                 └──────────┘    │Integration│(main)   │
│                 ┌──────────┐    └──────────┘          │
│                 │   Docs   │         │                │
│                 │  Check   │         ▼                │
│                 └──────────┘    ┌──────────┐          │
│                                 │  Build   │          │
│                                 └──────────┘          │
│                                      │                │
│                                      ▼                │
│                                 ┌──────────┐          │
│                                 │CI Status │          │
│                                 └──────────┘          │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

#### 1. **Lint Job**
- **Purpose:** Code quality checks
- **Tools:** Ruff (linting), Black (format checking)
- **Dependencies:** None (runs in parallel)
- **Timeout:** 10 minutes
- **Status:** ✅ Required

#### 2. **Security Job**
- **Purpose:** Security scanning
- **Tools:** Bandit (security linting), pip-audit (dependency vulnerabilities)
- **Dependencies:** None (runs in parallel)
- **Timeout:** 10 minutes
- **Continue on Error:** Yes (non-blocking)
- **Status:** ⚠️ Non-blocking (warns only)

#### 3. **Test Job**
- **Purpose:** Unit tests with coverage
- **Dependencies:** Lint job must pass
- **Timeout:** 20 minutes
- **Coverage:** Codecov integration
- **Seed Validation:** Validates seed data (non-blocking)
- **Status:** ✅ Required

#### 4. **Integration Job**
- **Purpose:** Integration tests
- **Dependencies:** Test job must pass
- **Condition:** Only runs on `main`/`master` branch or manual dispatch with `run_slow_tests=true`
- **Timeout:** 30 minutes
- **Status:** ✅ Required (conditional)

#### 5. **Build Job**
- **Purpose:** Package building and verification
- **Dependencies:** Test job must pass
- **Timeout:** 15 minutes
- **Artifacts:** Uploads `dist/` packages (7 day retention)
- **Status:** ✅ Required

#### 6. **Docs Job**
- **Purpose:** Documentation checks
- **Dependencies:** None (runs in parallel)
- **Timeout:** 10 minutes
- **Continue on Error:** Yes (non-blocking)
- **Status:** ⚠️ Non-blocking

#### 7. **CI Status Job**
- **Purpose:** Pipeline summary and status aggregation
- **Dependencies:** All other jobs
- **Condition:** Always runs (even if previous jobs fail)
- **Timeout:** 5 minutes
- **Status:** ✅ Summary only (non-blocking)

---

## Deployment Environments

### 1. **Development**
- **Purpose:** Local development
- **Configuration:** `.env` file (git-ignored)
- **Database:** SQLite (default) or local PostgreSQL

**Services:**
- PostgreSQL: `127.0.0.1:5432`
- ChromaDB: `127.0.0.1:8000`
- Ollama: `127.0.0.1:11435`
- Redis: `127.0.0.1:6379`
- Mothership API: Not in default compose (manual start)

### 2. **Testing/CI**
- **Purpose:** Automated testing in CI
- **Configuration:** Environment variables in GitHub Actions
- **Database:** SQLite in-memory (`:memory:`)
- **Environment Variables:**
  - `GRID_ENVIRONMENT=testing`
  - `BLOCKER_DISABLED=1`
  - `PYTHONPATH=.`
  - `PYTHONUNBUFFERED=1`

### 3. **Staging**
- **Purpose:** Pre-production testing
- **Configuration:** Staging environment variables
- **Database:** PostgreSQL (managed)
- **Image:** `ghcr.io/{org}/grid:staging`

### 4. **Production**
- **Purpose:** Live production deployment
- **Configuration:** Production secrets (external secrets manager)
- **Database:** Managed PostgreSQL (external)
- **Image:** `ghcr.io/{org}/grid:latest` or `ghcr.io/{org}/grid:v*.*.*`
- **Resource Limits:** CPU: 2, Memory: 2GB (configurable)

---




#### Build Job
- **Platform:** `linux/amd64`
- **Registry:** GitHub Container Registry (`ghcr.io`)
- **Caching:** GitHub Actions cache (GHA)
- **Tags:**
  - Branch name tags
  - Semver tags (`v1.2.3`, `v1.2`, `v1`)
  - SHA-prefixed tags (`main-{sha}`)
  - `latest` (default branch only)

#### Security Scan Job
- **Tool:** Trivy vulnerability scanner
- **Format:** SARIF
- **Upload:** GitHub Security (Code Scanning)
- **Blocking:** No (continue-on-error: true)


```yaml
Services:
  - postgres:     PostgreSQL 16 (Alpine)
  - chroma:       ChromaDB (latest)
  - ollama:       Ollama LLM (latest)
  - redis:        Redis 7 (Alpine)
```

```yaml
Overrides:
  - Resource limits (CPU/Memory)
  - Restart policies (always)
  - Logging (JSON rotation)
  - Volumes (production data)
  - External database support
```

---

## Release Pipeline

**Workflow:** `.github/workflows/release.yaml`

### Release Process

1. **Prepare Job**
   - Determines version (from tag or manual bump)
   - Generates changelog from git commits
   - Outputs version and tag

2. **Test Job**
   - Runs unit tests before release
   - Validates package integrity

3. **Build Job**
   - Updates `pyproject.toml` version (if manual)
   - Builds distribution packages (wheel + sdist)
   - Verifies with `twine check`

4. **Publish PyPI Job** (optional)
   - Publishes to PyPI using trusted publishing
   - Requires `pypi` environment with OIDC
   - Respects `dry_run` input

5. **Release Job**
   - Creates git tag (if manual dispatch)
   - Creates GitHub Release with notes
   - Attaches distribution artifacts

6. **Summary Job**
   - Generates release summary

### Version Bumping
- **Patch:** Bug fixes (`2.1.0` → `2.1.1`)
- **Minor:** New features (`2.1.0` → `2.2.0`)
- **Major:** Breaking changes (`2.1.0` → `3.0.0`)

---

## Configuration Consistency

### Python Version
- **All Workflows:** Python 3.13
- **pyproject.toml:** `requires-python = ">=3.13,<3.14"`

### Environment Variables

| Variable | Development | Testing/CI | Production |
|----------|-------------|------------|------------|
| `GRID_ENVIRONMENT` | `dev` | `testing` | `production` |
| `BLOCKER_DISABLED` | `0` or `1` | `1` | `0` |
| `PYTHONPATH` | `.` | `.` | `.` |
| `PYTHONUNBUFFERED` | `1` | `1` | `1` |
| `DEBUG` | `true` | `false` | `false` |

### Dependencies Management
- **Tool:** `uv` (fast Python package installer)
- **Lock File:** `uv.lock` (committed)
- **Install Command:** `uv sync --frozen`

---

## Deployment Strategies

```bash
# Development

# Production
```

### 2. **Kubernetes Deployment** (Production)
- **Manifests:** `k8s/` directory (if exists)
- **Image:** `ghcr.io/{org}/grid:latest`
- **Configuration:** Kubernetes ConfigMaps and Secrets

### 3. **Direct Deployment** (Legacy/Testing)
```bash
# Install dependencies
uv sync --frozen

# Run application
python -m application.mothership.main
```

---

## CI/CD Quality Gates

### Required Checks (Blocking)
- ✅ **Lint:** Code formatting and style must pass
- ✅ **Test:** All unit tests must pass
- ✅ **Build:** Package must build successfully

### Non-Blocking Checks (Warnings Only)
- ⚠️ **Security:** Reports vulnerabilities but doesn't block
- ⚠️ **Docs:** Checks documentation structure but doesn't block

### Coverage Requirements
- **Project Coverage:** Minimum 25%
- **Patch Coverage:** Minimum 50% (new code)
- **Core Modules:** Minimum 30%

---

## Fine-Tuning & Optimizations

### Completed Optimizations

1. ✅ **Parallel Job Execution:** Lint, Security, Docs run in parallel
2. ✅ **Conditional Integration Tests:** Only run on main branch to save CI time
3. ✅ **Artifact Retention:** Build artifacts retained for 7 days
5. ✅ **Error Handling:** Seed validation and security scans are non-blocking
6. ✅ **Python Version Consistency:** All workflows use Python 3.13
7. ✅ **Dependency Locking:** Using `uv.lock` for reproducible builds

### Recommended Future Optimizations

1. **Matrix Testing:** Test on multiple Python versions (3.10, 3.11, 3.12, 3.13)
2. **Parallel Test Execution:** Split unit tests across multiple runners
3. **Incremental Testing:** Only test changed modules
4. **Caching:** Cache pip/uv dependencies between runs
5. **Pre-commit Hooks:** Run linting before commits

---

## Troubleshooting

### CI/CD Pipeline Failures

#### Lint Failures
```bash
# Fix locally
uv run ruff check --fix .
uv run black grid/ application/ tools/ tests/
```

#### Test Failures
```bash
# Run tests locally with same environment
export GRID_ENVIRONMENT=testing
export BLOCKER_DISABLED=1
export PYTHONPATH=.
uv run pytest tests/unit/ -v --tb=short
```

#### Build Failures
```bash
# Test build locally
uv tool install build twine
uv run python -m build
uv run twine check dist/*
```

```bash
# Build locally to debug
```

### Common Issues

1. **Seed Validation Fails:** Check `scripts/validate_seed.py` and `seed/topics_seed.json`
2. **Security Scan Warnings:** Review Bandit and pip-audit reports, update dependencies
3. **Coverage Drops:** Ensure new code has test coverage

---

## Deployment Checklist

### Before Deployment

- [ ] All CI/CD jobs passing
- [ ] Security scan reviewed (no critical vulnerabilities)
- [ ] Tests passing (unit + integration)
- [ ] Documentation updated
- [ ] Version bumped (if release)
- [ ] Changelog generated
- [ ] Environment variables configured
- [ ] Secrets configured (production)

### After Deployment

- [ ] Health checks passing (`/health` endpoint)
- [ ] Database migrations applied
- [ ] Logs reviewed for errors
- [ ] Performance metrics monitored
- [ ] Rollback plan ready

---

## References

- **CI/CD Guide:** `docs/CI_CD_GUIDE.md`
- **Configuration Guide:** `docs/CONFIGURATION.md`
- **GitHub Actions:** `.github/workflows/`

---

## Git Hooks

Git hooks are pre-commit and pre-push validation scripts that run locally before committing or pushing code. They are aligned with the CI/CD pipeline to catch issues early.

### Hook Files

| Hook File | Purpose | Location | Status |
|-----------|---------|----------|--------|
| `scripts/hooks/pre-push-evolved` | Pre-push validation (lint, test, seed validation) | `scripts/hooks/` | ✅ Active |
| `scripts/hooks/commit-msg` | Commit message validation | `scripts/hooks/` | ✅ Active |
| `.pre-commit-config.yaml` | Pre-commit framework configuration | Root | ✅ Active |

### Pre-Push Hook (aligned with CI/CD)

**File:** `scripts/hooks/pre-push-evolved`

**Checks (in order):**
1. **Lint Check** (Ruff) - Code quality linting
2. **Format Check** (Black) - Code formatting validation
3. **Seed Validation** - Validates seed data structure
4. **Unit Tests** - Runs unit tests before push
5. **Hygiene Check** (non-blocking) - Checks for large files (>10MB)

**Alignment with CI/CD:**
- Pre-push hook runs the same checks as CI/CD pipeline jobs
- Lint and format checks match `.github/workflows/main.yaml` lint job
- Test checks match CI/CD test job
- Seed validation matches CI/CD test job validation step

**Installation:**
```bash
# Linux/macOS/Git Bash
chmod +x scripts/install-hooks.sh
./scripts/install-hooks.sh

# Windows PowerShell
.\scripts\install-hooks.ps1
```

**Bypass (not recommended):**
```bash
# Skip pre-push hook
git push --no-verify
```

### Commit Message Hook

**File:** `scripts/hooks/commit-msg`

**Validations:**
- Branch naming conventions (main, master, develop, feature/*, release/*, hotfix/*, architecture/*, topic/*)
- Commit message length (minimum 3 characters)
- First line length warning (>72 characters)

**Features:**
- Non-blocking warnings for branch naming
- Flexible branch naming (allows multiple patterns)
- Warns about long commit messages but doesn't block

**Bypass (not recommended):**
```bash
# Skip commit message validation
SKIP_COMMIT_MSG_VALIDATION=1 git commit

# Windows PowerShell
$env:SKIP_COMMIT_MSG_VALIDATION=1; git commit
```

### Pre-Commit Framework

**File:** `.pre-commit-config.yaml`

**Hooks:**
- Trailing whitespace removal
- End of file fixing
- YAML/JSON validation
- Large file checks (>1MB)
- Merge conflict detection
- Ruff linting (with auto-fix)
- Black formatting
- isort import sorting

**Installation:**
```bash
pip install pre-commit
pre-commit install
```

**Manual Run:**
```bash
# Run on all files
pre-commit run --all-files

# Run on staged files only
pre-commit run
```

### Hook Alignment with CI/CD

| Local Hook | CI/CD Job | Alignment |
|------------|-----------|-----------|
| Pre-push: Ruff lint | Lint job: Ruff | ✅ Same command |
| Pre-push: Black format | Lint job: Black | ✅ Same command |
| Pre-push: Seed validation | Test job: Seed validation | ✅ Same script |
| Pre-push: Unit tests | Test job: Unit tests | ✅ Same command |
| Pre-commit: Ruff | Lint job: Ruff | ✅ Same command |
| Pre-commit: Black | Lint job: Black | ✅ Same command |

### Cross-Platform Compatibility

All hooks are designed to work on:
- ✅ **Linux** (Ubuntu, Debian, etc.)
- ✅ **macOS** (Intel and Apple Silicon)
- ✅ **Windows** (Git Bash, PowerShell, WSL)

**Windows-specific features:**
- Unicode-safe output (ASCII characters only)
- Path handling for Git Bash/MSYS
- PowerShell installation script
- Windows temp directory handling

---

## Summary

✅ **All CI/CD pipelines are configured and aligned with project documentation.**
✅ **Python 3.13 is consistently used across all workflows.**
✅ **Release pipeline is fully automated with versioning and publishing.**

The deployment architecture supports:
- **CI/CD testing** (GitHub Actions)

All jobs are properly configured to pass with appropriate error handling and quality gates.
