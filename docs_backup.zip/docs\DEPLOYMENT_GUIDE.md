# GRID Deployment Guide

## Overview

This guide covers deploying GRID in various environments, from local development to production Kubernetes clusters.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Local Development](#local-development)
4. [Kubernetes Deployment](#kubernetes-deployment)
5. [Cloud Deployment](#cloud-deployment)
6. [Environment Configuration](#environment-configuration)
7. [Monitoring and Logging](#monitoring-and-logging)
8. [Security Hardening](#security-hardening)
9. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### System Requirements
- **CPU:** 2+ cores recommended
- **Memory:** 4GB+ RAM recommended
- **Storage:** 10GB+ available space
- **Python:** 3.13+
- **Network:** Internet access for model downloads

### Software Requirements
- **uv:** Python package manager
- **kubectl:** Kubernetes CLI (for K8s deployment)
- **Git:** Version control

---

## Local Development

### Quick Setup
```bash
# Clone repository
git clone <repository-url>
cd grid

# Install dependencies
uv sync --all-extras

# Verify installation
uv run python -m grid health
```

### Development Server
```bash
# Start development server
uv run python -m grid serve --port 8000 --debug

# Test API
curl http://localhost:8000/api/v1/health
```

### Environment Configuration
```bash
# Development environment
export GRID_ENV=development
export GRID_DEBUG=true
export GRID_API_HOST=localhost
export GRID_API_PORT=8000

# Optional: Set API keys for testing
export OPENAI_API_KEY=your-openai-key
export GEMINI_API_KEY=your-gemini-key
```

---


```bash
# Development image

# Production image
```

```yaml
version: '3.8'

services:
  grid:
    build: .
    ports:
      - "8000:8000"
    environment:
      - GRID_ENV=development
      - GRID_DEBUG=true
    volumes:
      - ./logs:/app/logs
      - ./data:/app/data
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    restart: unless-stopped
```

```bash
# Start services

# View logs

# Stop services
```

```yaml
version: '3.8'

services:
  grid:
    image: grid:prod
    ports:
      - "8000:8000"
    environment:
      - GRID_ENV=production
      - GRID_DEBUG=false
      - VAULT_ADDR=https://vault.example.com
      - VAULT_TOKEN=${VAULT_TOKEN}
    volumes:
      - ./logs:/app/logs
      - ./config:/app/config
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/api/v1/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - grid
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    command: redis-server --appendonly yes
    volumes:
      - redis_data:/data
    restart: unless-stopped

volumes:
  redis_data:
```

```bash
# Deploy production

# Scale services
```

---

## Kubernetes Deployment

### Prerequisites
```bash
# Install kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/windows/amd64/kubectl.exe"

# Install helm (optional)
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# Verify cluster access
kubectl cluster-info
```

### Generate Kubernetes Manifests
```bash
# Generate all manifests
uv run python -c "from grid.security import generate_deployment_configs; generate_deployment_configs()"

# This creates:
# - k8s/configmap.yaml
# - k8s/secret.yaml
# - k8s/deployment.yaml
# - k8s/service.yaml
```

### Namespace and Configuration
```yaml
# k8s/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: grid
  labels:
    name: grid
```

```yaml
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: grid-config
  namespace: grid
data:
  GRID_ENV: "production"
  GRID_DEBUG: "false"
  GRID_API_HOST: "0.0.0.0"
  GRID_API_PORT: "8000"
  GRID_LOG_LEVEL: "INFO"
  GRID_CACHE_TTL: "300"
  GRID_MAX_WORKERS: "4"
```

### Secrets Management
```yaml
# k8s/secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: grid-secrets
  namespace: grid
type: Opaque
data:
  # Base64 encoded values
  VAULT_TOKEN: <base64-encoded-vault-token>
  OPENAI_API_KEY: <base64-encoded-openai-key>
  GEMINI_API_KEY: <base64-encoded-gemini-key>
  GRID_API_KEY: <base64-encoded-grid-api-key>
```

```bash
# Create secrets from environment variables
kubectl create secret generic grid-secrets \
  --from-literal=VAULT_TOKEN=$VAULT_TOKEN \
  --from-literal=OPENAI_API_KEY=$OPENAI_API_KEY \
  --from-literal=GEMINI_API_KEY=$GEMINI_API_KEY \
  --namespace=grid
```

### Deployment
```yaml
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: grid-api
  namespace: grid
  labels:
    app: grid-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: grid-api
  template:
    metadata:
      labels:
        app: grid-api
    spec:
      containers:
      - name: grid-api
        image: grid:prod
        ports:
        - containerPort: 8000
        envFrom:
        - configMapRef:
            name: grid-config
        - secretRef:
            name: grid-secrets
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /api/v1/health/live
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
          timeoutSeconds: 5
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /api/v1/health/ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
          timeoutSeconds: 3
          failureThreshold: 3
        volumeMounts:
        - name: logs-volume
          mountPath: /app/logs
        - name: config-volume
          mountPath: /app/config
      volumes:
      - name: logs-volume
        emptyDir: {}
      - name: config-volume
        configMap:
          name: grid-config
```

### Service and Ingress
```yaml
# k8s/service.yaml
apiVersion: v1
kind: Service
metadata:
  name: grid-service
  namespace: grid
spec:
  selector:
    app: grid-api
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8000
  type: ClusterIP
```

```yaml
# k8s/ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: grid-ingress
  namespace: grid
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/rate-limit: "100"
spec:
  tls:
  - hosts:
    - api.grid.example.com
    secretName: grid-tls
  rules:
  - host: api.grid.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: grid-service
            port:
              number: 80
```

### Horizontal Pod Autoscaler
```yaml
# k8s/hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: grid-hpa
  namespace: grid
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: grid-api
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

### Deploy to Kubernetes
```bash
# Apply all manifests
kubectl apply -f k8s/

# Check deployment status
kubectl get pods -n grid
kubectl get services -n grid
kubectl get ingress -n grid

# View logs
kubectl logs -f deployment/grid-api -n grid

# Scale deployment
kubectl scale deployment grid-api --replicas=5 -n grid
```

---

## Cloud Deployment

### AWS Deployment

#### ECS Task Definition
```json
{
  "family": "grid-api",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "executionRoleArn": "arn:aws:iam::account:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::account:role/ecsTaskRole",
  "containerDefinitions": [
    {
      "name": "grid-api",
      "image": "grid:prod",
      "portMappings": [
        {
          "containerPort": 8000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "GRID_ENV",
          "value": "production"
        }
      ],
      "secrets": [
        {
          "name": "VAULT_TOKEN",
          "valueFrom": "arn:aws:secretsmanager:region:account:secret:grid/vault-token"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/grid",
          "awslogs-region": "us-west-2",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
```

#### CloudFormation Template
```yaml
AWSTemplateFormatVersion: '2010-09-09'
Description: 'GRID API Deployment'

Parameters:
  Environment:
    Type: String
    Default: production
    AllowedValues: [development, staging, production]

Resources:
  ECSCluster:
    Type: AWS::ECS::Cluster
    Properties:
      ClusterName: !Sub 'grid-${Environment}'

  TaskDefinition:
    Type: AWS::ECS::TaskDefinition
    Properties:
      Family: !Sub 'grid-${Environment}'
      Cpu: 512
      Memory: 1024
      NetworkMode: awsvpc
      RequiresCompatibilities: [FARGATE]

  Service:
    Type: AWS::ECS::Service
    Properties:
      Cluster: !Ref ECSCluster
      TaskDefinition: !Ref TaskDefinition
      DesiredCount: 2
      LaunchType: FARGATE
```

### Google Cloud Deployment

#### Cloud Run Service
```yaml
# cloudbuild.yaml
steps:
  args: ['build', '-t', 'gcr.io/$PROJECT_ID/grid', '.']
  args: ['push', 'gcr.io/$PROJECT_ID/grid']
- name: 'gcr.io/google.com/cloudsdktool/cloud-sdk'
  entrypoint: 'gcloud'
  args:
  - 'run'
  - 'deploy'
  - 'grid'
  - '--image=gcr.io/$PROJECT_ID/grid'
  - '--region=us-central1'
  - '--platform=managed'
  - '--allow-unauthenticated'
```

### Azure Deployment

#### Container Instance
```bash
# Create resource group
az group create --name grid-rg --location eastus

# Deploy container
az container create \
  --resource-group grid-rg \
  --name grid-api \
  --image grid:prod \
  --cpu 1 \
  --memory 2 \
  --ports 8000 \
  --environment-variables GRID_ENV=production \
  --secure-environment-variables VAULT_TOKEN=$VAULT_TOKEN
```

---

## Environment Configuration

### Development Environment
```bash
# .env.development
GRID_ENV=development
GRID_DEBUG=true
GRID_API_HOST=localhost
GRID_API_PORT=8000
GRID_LOG_LEVEL=DEBUG
GRID_CACHE_TTL=60
GRID_MAX_WORKERS=4

# Security
GRID_COMMAND_DENYLIST=""
GRID_MIN_CONTRIBUTION=0.0
GRID_CHECK_CONTRIBUTION=false
USE_SECRETS_MANAGER=false

# API Keys (for testing)
OPENAI_API_KEY=your-dev-key
GEMINI_API_KEY=your-dev-key
```

### Staging Environment
```bash
# .env.staging
GRID_ENV=staging
GRID_DEBUG=false
GRID_API_HOST=0.0.0.0
GRID_API_PORT=8000
GRID_LOG_LEVEL=INFO
GRID_CACHE_TTL=300
GRID_MAX_WORKERS=8

# Security
GRID_COMMAND_DENYLIST=serve
GRID_MIN_CONTRIBUTION=0.6
GRID_CHECK_CONTRIBUTION=true
USE_SECRETS_MANAGER=true
VAULT_ADDR=https://vault.staging.example.com

# Monitoring
GRID_METRICS_ENABLED=true
GRID_HEALTH_CHECK_INTERVAL=30
```

### Production Environment
```bash
# .env.production
GRID_ENV=production
GRID_DEBUG=false
GRID_API_HOST=0.0.0.0
GRID_API_PORT=8000
GRID_LOG_LEVEL=WARNING
GRID_CACHE_TTL=600
GRID_MAX_WORKERS=16

# Security
GRID_COMMAND_DENYLIST=analyze,serve
GRID_MIN_CONTRIBUTION=0.8
GRID_CHECK_CONTRIBUTION=true
USE_SECRETS_MANAGER=true
VAULT_ADDR=https://vault.production.example.com

# Performance
GRID_RATE_LIMIT=100
GRID_SESSION_TIMEOUT=3600
GRID_MAX_REQUEST_SIZE=10485760

# Monitoring
GRID_METRICS_ENABLED=true
GRID_HEALTH_CHECK_INTERVAL=15
GRID_ALERT_WEBHOOK=https://alerts.example.com/webhook
```

---

## Monitoring and Logging

### Prometheus Monitoring
```yaml
# monitoring/prometheus.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: prometheus-config
data:
  prometheus.yml: |
    global:
      scrape_interval: 15s
    scrape_configs:
    - job_name: 'grid-api'
      static_configs:
      - targets: ['grid-service:80']
      metrics_path: /api/v1/metrics
```

### Grafana Dashboard
```json
{
  "dashboard": {
    "title": "GRID API Dashboard",
    "panels": [
      {
        "title": "Request Rate",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(grid_requests_total[5m])",
            "legendFormat": "{{method}} {{endpoint}}"
          }
        ]
      },
      {
        "title": "Response Time",
        "type": "graph",
        "targets": [
          {
            "expr": "histogram_quantile(0.95, rate(grid_request_duration_seconds_bucket[5m]))",
            "legendFormat": "95th percentile"
          }
        ]
      }
    ]
  }
}
```

### ELK Stack for Logging
```yaml
# logging/elasticsearch.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: elasticsearch
spec:
  serviceName: elasticsearch
  replicas: 3
  selector:
    matchLabels:
      app: elasticsearch
  template:
    metadata:
      labels:
        app: elasticsearch
    spec:
      containers:
      - name: elasticsearch
        env:
        - name: discovery.type
          value: single-node
        ports:
        - containerPort: 9200
        volumeMounts:
        - name: data
          mountPath: /usr/share/elasticsearch/data
  volumeClaimTemplates:
  - metadata:
      name: data
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 100Gi
```

### Health Checks
```bash
# Basic health check
curl http://localhost:8000/api/v1/health

# Detailed health check
curl -H "Authorization: Bearer $API_KEY" \
     http://localhost:8000/api/v1/health/detailed

# Kubernetes health check
kubectl get pods -n grid -l app=grid-api
kubectl describe pod <pod-name> -n grid
```

---

## Security Hardening

### Network Security
```yaml
# network-policy.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: grid-network-policy
  namespace: grid
spec:
  podSelector:
    matchLabels:
      app: grid-api
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: ingress-nginx
    ports:
    - protocol: TCP
      port: 8000
  egress:
  - to: []
    ports:
    - protocol: TCP
      port: 443  # HTTPS
    - protocol: TCP
      port: 53   # DNS
```

### Pod Security Policy
```yaml
# pod-security-policy.yaml
apiVersion: policy/v1beta1
kind: PodSecurityPolicy
metadata:
  name: grid-psp
spec:
  privileged: false
  allowPrivilegeEscalation: false
  requiredDropCapabilities:
    - ALL
  volumes:
    - 'configMap'
    - 'emptyDir'
    - 'projected'
    - 'secret'
    - 'downwardAPI'
    - 'persistentVolumeClaim'
  runAsUser:
    rule: 'MustRunAsNonRoot'
  seLinux:
    rule: 'RunAsAny'
  fsGroup:
    rule: 'RunAsAny'
```

### RBAC Configuration
```yaml
# rbac.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: grid-service-account
  namespace: grid
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: grid
  name: grid-role
rules:
- apiGroups: [""]
  resources: ["configmaps", "secrets"]
  verbs: ["get", "list", "watch"]
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: grid-role-binding
  namespace: grid
subjects:
- kind: ServiceAccount
  name: grid-service-account
  namespace: grid
roleRef:
  kind: Role
  name: grid-role
  apiGroup: rbac.authorization.k8s.io
```

---

## Troubleshooting

### Common Issues

#### 1. Container Startup Issues
```bash
# Check container logs
kubectl logs deployment/grid-api -n grid

# Check container status
kubectl get pods -n grid

# Debug container
kubectl exec -it <pod-name> -n grid -- bash
```

#### 2. Network Connectivity
```bash
# Test API endpoint
curl http://localhost:8000/api/v1/health

# Test service connectivity
kubectl port-forward service/grid-service 8000:80 -n grid

# Check network policies
kubectl get networkpolicy -n grid
```

#### 3. Resource Issues
```bash
# Check resource usage
kubectl top pods -n grid
kubectl top nodes

# Check resource limits
kubectl describe pod <pod-name> -n grid

# Scale resources
kubectl patch deployment grid-api -n grid -p '{"spec":{"template":{"spec":{"containers":[{"name":"grid-api","resources":{"limits":{"memory":"2Gi"}}}]}}}}'
```

#### 4. Secrets and Configuration
```bash
# Check secrets
kubectl get secrets -n grid
kubectl describe secret grid-secrets -n grid

# Check configmaps
kubectl get configmaps -n grid
kubectl describe configmap grid-config -n grid

# Update secrets
kubectl create secret generic grid-secrets \
  --from-literal=VAULT_TOKEN=new-token \
  --dry-run=client -o yaml | kubectl apply -f -
```

### Debug Commands

#### Local Debugging
```bash
# Enable debug mode
export GRID_DEBUG=true

# Run with verbose logging
uv run python -m grid serve --debug --verbose

# Check configuration
uv run python -c "from grid.security import get_security_status; print(get_security_status())"
```

#### Kubernetes Debugging
```bash
# Get detailed pod information
kubectl describe pod <pod-name> -n grid

# Check events
kubectl get events -n grid --sort-by='.lastTimestamp'

# Debug pod
kubectl debug <pod-name> -n grid --image=busybox --copy-to=debug-pod
```

### Performance Issues

#### Memory Leaks
```bash
# Monitor memory usage
kubectl top pods -n grid --containers

# Check for memory leaks
kubectl exec -it <pod-name> -n grid -- python -c "
import psutil
import time
while True:
    print(psutil.virtual_memory())
    time.sleep(5)
"
```

#### High CPU Usage
```bash
# Profile CPU usage
kubectl exec -it <pod-name> -n grid -- python -m cProfile -o profile.stats your_script.py

# Check thread usage
kubectl exec -it <pod-name> -n grid -- python -c "
import threading
import time
def monitor_threads():
    while True:
        print(f'Active threads: {threading.active_count()}')
        time.sleep(5)
monitor_threads()
"
```

### Recovery Procedures

#### Rolling Restart
```bash
# Kubernetes rolling restart
kubectl rollout restart deployment/grid-api -n grid

# Check rollout status
kubectl rollout status deployment/grid-api -n grid

```

#### Emergency Rollback
```bash
# Kubernetes rollback
kubectl rollout undo deployment/grid-api -n grid

```

---

*This deployment guide covers the most common deployment scenarios. For specific cloud provider configurations or advanced setups, refer to the cloud-specific documentation.*
