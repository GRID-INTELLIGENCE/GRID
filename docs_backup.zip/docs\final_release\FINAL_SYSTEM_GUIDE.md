# GRID Agentic Architecture: Final System Guide

Welcome to the synchronized GRID Agentic Architecture. This system handles recursive architectural reasoning, autonomous enforcement, and high-fidelity visual reporting.

---

## 🚀 1. Core Agentic Workflow
To initiate a recursive architectural analysis (Receptionist -> Lawyer -> Memo):

**Command**:
```powershell
$env:PYTHONPATH="E:\grid"; python e:\grid\scripts\process_recursive_history.py
```
**What happens**:
- **Phase 1**: Initial case filing from `e:\grid\data\agentic_history_intake.json`.
- **Phase 2**: Iterative reasoning (3 loops) to converge on architectural resonance.
- **Phase 3**: Synthesis of the **Final Enforcement Memo**.

---

## 🏛️ 2. Professional & Strategic UI
The Stratagem Intelligence Studio has been upgraded with three primary executive views:

### 👤 Architect Profile
- **Location**: Sidebar -> **Architect Profile**
- **Features**: Animated skill matrix, projected trajectory, and a "Golden Goal" deliverable.
- **Action**: Click **Download Resume** to export the synchronized executive sumary (PDF Simulated).

### 🌀 Strategic Dashboard
- **Location**: Sidebar -> **Strategic Dashboard**
- **Features**: Real-time resonance tracking (Score: 0.998), benchmark deltas (+94.2% SWE Lead), and threat monitoring.
- **Purpose**: High-level board transparency and outcome forecasting.

### 🛡️ Executive Review
- **Location**: Sidebar -> **Board Review**
- **Interactive**: Click **Initiate Handshake** to lock decision boundaries.
- **Data**: Live verification of repository artifacts (`manifest.json`, `candidates.json`).

---

## 📂 3. Parsing Artifacts
All system outputs are structured for easy integration:

| Artifact Type | Path | Description |
| :--- | :--- | :--- |
| **Enforcement Memo** | `.memos/MEMO-CASE-RES-*.json` | The boolean decision source of truth. |
| **Logic Summary** | `.memos/MEMO-CASE-RES-*.md` | Human-readable architectural brief. |
| **Comparison Report** | `e:/grid/outputs/comparison_report_2026.md` | GRID vs GPT / Claude benchmark delta. |
| **Terrain Map** | `e:/grid/data/terrain_state.json` | 32k+ node dependency graph for the UI. |
| **Metrics Harvest** | `e:/grid/docs/FINAL_METRICS_HARVEST.md` | Consolidated system health & intelligence. |

### How to parse the Memo:
The `.json` memo contains a `boolean_decisions` array. Each decision has a `feature`, `value` (bool), and `protocol`.
- **Logic**: If `value` is true, activate the feature's `protocol` layer (e.g., `GRID-ENFORCE`).

---

## 🌀 4. Benchmarking & Performance
Run the real-time benchmark evaluator to update the dashboard stats:

```powershell
python e:\grid\scripts\run_benchmarks.py
```
This updates `e:/grid/outputs/final_benchmark_report.json`, which feeds directly into the Strategic Dashboard's comparative charts.

---
**Status**: SYNCHRONIZED
**Resonance**: 0.992+
**Authority**: Architectural Core Verified
