# Agentic System Architecture

## Overview

The GRID agentic system is an event-driven architecture for case management, agent orchestration, and continuous learning. It implements a receptionist-lawyer-executor workflow with event-driven coordination.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                    API Layer                                  │
│  (application/mothership/routers/agentic.py)                 │
│  - POST /api/v1/agentic/cases                                 │
│  - POST /api/v1/agentic/cases/{id}/enrich                     │
│  - POST /api/v1/agentic/cases/{id}/execute                    │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│                 AgenticSystem                                 │
│  (grid/agentic/agentic_system.py)                            │
│  - Orchestrates case lifecycle                                │
│  - Coordinates event publishing                               │
│  - Manages agent execution                                    │
└────┬────────────────┬──────────────────┬─────────────────────┘
     │                │                  │
     ▼                ▼                  ▼
┌──────────┐   ┌──────────────┐   ┌──────────────┐
│ EventBus │   │ AgentExecutor│   │ SkillRetriever│
│          │   │              │   │               │
└────┬─────┘   └──────┬───────┘   └───────────────┘
     │                │
     │                ▼
     │         ┌──────────────┐
     │         │ EventHandlers│
     │         │              │
     │         └──────┬───────┘
     │                │
     ▼                ▼
┌─────────────────────────────────────────────┐
│            Event Handlers                     │
│  (grid/agentic/event_handlers.py)            │
│  - CaseCreatedHandler                        │
│  - CaseCategorizedHandler                    │
│  - CaseReferenceGeneratedHandler             │
│  - CaseExecutedHandler                       │
│  - CaseCompletedHandler                      │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│         Learning Coordinator                  │
│  (grid/agentic/learning_coordinator.py)      │
│  - Pattern recognition                       │
│  - Experience accumulation                   │
│  - Skill generation                          │
└──────────────────┬──────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────┐
│          Recovery Engine                      │
│  (grid/agentic/recovery_engine.py)           │
│  - Error recovery                            │
│  - Retry logic                               │
│  - Failure handling                          │
└──────────────────────────────────────────────┘
```

## Core Components

### 1. EventBus (`grid/agentic/event_bus.py`)

**Purpose**: Async event processing with Redis pub-sub support (optional).

**Features**:
- In-memory event queue (default)
- Redis pub-sub (optional, for distributed systems)
- Event history (deque, max 1000 events)
- Handler subscription system
- Event filtering and routing

**API**:
```python
# Publish event
await event_bus.publish({
    "event_type": "case.created",
    "case_id": "...",
    "raw_input": "..."
})

# Subscribe to event type
await event_bus.subscribe("case.created", handler_function)

# Subscribe to all events
await event_bus.subscribe_all(handler_function)

# Get event history
history = await event_bus.get_event_history(
    event_type="case.created",
    limit=100
)
```

**Configuration**:
- `use_redis`: Enable Redis (default: False)
- `redis_host`: Redis host (default: localhost)
- `redis_port`: Redis port (default: 6379)
- `redis_db`: Redis database (default: 0)
- `max_history`: Max events in history (default: 1000)

**Singleton Pattern**: `get_event_bus()` returns global instance.

### 2. EventHandlers (`grid/agentic/event_handlers.py`)

**Purpose**: Handle case lifecycle events.

**Handlers**:

1. **CaseCreatedHandler**
   - Handles `case.created` events
   - Creates case record in repository
   - Status: "created"

2. **CaseCategorizedHandler**
   - Handles `case.categorized` events
   - Updates case status to "categorized"
   - Stores category, priority, confidence
   - Stores structured data

3. **CaseReferenceGeneratedHandler**
   - Handles `case.reference_generated` events
   - Updates case with reference file path
   - Notifies agent system
   - Status: "reference_generated"

4. **CaseExecutedHandler**
   - Handles `case.executed` events
   - Updates case execution metadata
   - Stores agent role and task

5. **CaseCompletedHandler**
   - Handles `case.completed` events
   - Updates case outcome and solution
   - Stores execution time and experience

**Base Class**: `BaseEventHandler` with `handle()` method.

### 3. AgenticSystem (`grid/agentic/agentic_system.py`)

**Purpose**: Main orchestrator for agentic system.

**Components**:
- `AgentExecutor`: Executes agent tasks
- `SkillRetriever`: Retrieves historical skills
- `MemoGenerator`: Generates memos from cases
- `EventBus`: Publishes events
- `Repository`: Stores cases (optional)

**Methods**:

1. **execute_case()**
   - Execute case using agent executor
   - Emit `case.executed` event
   - Emit `case.completed` event
   - Returns execution result

2. **get_recommendations()**
   - Get recommendations from historical skills
   - Query repository for similar cases
   - Returns list of recommendations

3. **Other methods**: Case management, enrichment, etc.

**Initialization**:
```python
agentic_system = AgenticSystem(
    knowledge_base_path=Path("tools/agent_prompts"),
    event_bus=get_event_bus(),
    repository=AgenticRepository(session)
)
```

### 4. AgentExecutor (`grid/agentic/agent_executor.py`)

**Purpose**: Execute agent tasks.

**Features**:
- Role-based execution
- Task routing
- Reference file loading
- Agent workflow execution

**Workflow**:
1. Load reference file
2. Select agent role
3. Execute task
4. Return result

### 5. Event Types (`grid/agentic/events.py`)

**Event Classes**:

1. **CaseCreatedEvent**
   - `case_id`: Case identifier
   - `raw_input`: User input
   - `user_id`: User identifier
   - `examples`: Example scenarios
   - `scenarios`: Additional scenarios

2. **CaseCategorizedEvent**
   - `case_id`: Case identifier
   - `category`: Case category
   - `priority`: Priority level
   - `confidence`: Confidence score
   - `structured_data`: Structured data
   - `labels`: Labels
   - `keywords`: Keywords

3. **CaseReferenceGeneratedEvent**
   - `case_id`: Case identifier
   - `reference_file_path`: Path to reference file
   - `recommended_roles`: Recommended agent roles
   - `recommended_tasks`: Recommended tasks

4. **CaseExecutedEvent**
   - `case_id`: Case identifier
   - `agent_role`: Agent role used
   - `task`: Task executed

5. **CaseCompletedEvent**
   - `case_id`: Case identifier
   - `outcome`: Execution outcome (success/partial/failure)
   - `solution`: Solution text
   - `agent_experience`: Experience data
   - `execution_time_seconds`: Execution time

**Event Serialization**: All events have `to_dict()` method.

### 6. LearningCoordinator (`grid/agentic/learning_coordinator.py`)

**Purpose**: Continuous learning from cases.

**Features**:
- Pattern recognition from cases
- Experience accumulation
- Skill generation from patterns
- Knowledge base updates

**Workflow**:
1. Analyze completed cases
2. Extract patterns
3. Generate skills
4. Update knowledge base

### 7. RecoveryEngine (`grid/agentic/recovery_engine.py`)

**Purpose**: Error recovery and retry logic.

**Features**:
- Automatic retry on failure
- Error classification
- Recovery strategies
- Failure handling

**Recovery Strategies**:
- Retry with exponential backoff
- Fallback to alternative agent
- Escalation to human
- Case marking for review

### 8. SkillRetriever (`grid/agentic/skill_retriever.py`)

**Purpose**: Retrieve historical skills from skill store.

**Features**:
- Category-based search
- Keyword-based search
- Relevance scoring
- Limit results

**Skill Store**: Default path `C:/Users/irfan/.gemini/antigravity/knowledge` (configurable via `GRID_SKILL_STORE_PATH`).

### 9. MemoGenerator (`grid/agentic/memo_generator.py`)

**Purpose**: Generate memos from case execution.

**Features**:
- Summarize case execution
- Extract key insights
- Generate recommendations
- Store memos for future reference

## Event Flow

### Case Creation Flow

1. **API Request**: `POST /api/v1/agentic/cases`
   - Receives `CaseCreateRequest` with raw input

2. **Processing Unit**: Processes input through receptionist workflow
   - Categorizes case
   - Extracts structured data
   - Generates reference file

3. **Event Publishing**: Emits events
   - `case.created`: Case created
   - `case.categorized`: Case categorized
   - `case.reference_generated`: Reference file generated

4. **Event Handling**: Handlers process events
   - `CaseCreatedHandler`: Creates case record
   - `CaseCategorizedHandler`: Updates case status
   - `CaseReferenceGeneratedHandler`: Stores reference file

5. **Response**: Returns `CaseResponse` with case details

### Case Execution Flow

1. **API Request**: `POST /api/v1/agentic/cases/{id}/execute`
   - Receives `CaseExecuteRequest` with agent role and task

2. **AgenticSystem**: Orchestrates execution
   - Loads reference file
   - Selects agent role
   - Executes task via `AgentExecutor`

3. **Event Publishing**: Emits events
   - `case.executed`: Execution started
   - `case.completed`: Execution completed

4. **Event Handling**: Handlers process events
   - `CaseExecutedHandler`: Updates execution metadata
   - `CaseCompletedHandler`: Updates outcome and solution

5. **Learning**: `LearningCoordinator` analyzes execution
   - Extracts patterns
   - Updates knowledge base
   - Generates skills (optional)

6. **Response**: Returns execution result

### Error Flow

1. **Error Occurs**: Exception during execution

2. **Recovery Engine**: Attempts recovery
   - Classifies error
   - Applies recovery strategy
   - Retries if appropriate

3. **Event Publishing**: Emits failure event
   - `case.completed` with outcome="failure"

4. **Event Handling**: `CaseCompletedHandler` processes failure
   - Stores error details
   - Marks case for review

5. **Response**: Returns error response

## Integration Points

### Repository Integration

**Purpose**: Persist cases to database.

**Interface**: `AgenticRepository` (in `application/mothership/repositories/agentic.py`)

**Methods**:
- `create_case()`: Create case record
- `get_case()`: Get case by ID
- `update_case_status()`: Update case status
- `find_similar_cases()`: Find similar cases

### Processing Unit Integration

**Purpose**: Process input through receptionist workflow.

**Interface**: `ProcessingUnit` (in `tools/agent_prompts/processing_unit.py`)

**Methods**:
- `process_input()`: Process raw input
   - Returns: Categorized case with structured data

### Knowledge Base Integration

**Purpose**: Store agent prompts and cases.

**Path**: `tools/agent_prompts/` (configurable)

**Structure**:
- `.case_memory/`: Case memory storage
- `.case_references/`: Case reference files

## Configuration

### Environment Variables

- `GRID_SKILL_STORE_PATH`: Skill store path (default: `C:/Users/irfan/.gemini/antigravity/knowledge`)
- `GRID_EVENT_BUS_REDIS_ENABLED`: Enable Redis (default: false)
- `GRID_EVENT_BUS_REDIS_HOST`: Redis host (default: localhost)
- `GRID_EVENT_BUS_REDIS_PORT`: Redis port (default: 6379)
- `GRID_EVENT_BUS_MAX_HISTORY`: Max event history (default: 1000)

### Database Schema

**Tables** (via Alembic migrations):
- `cases`: Case records
- `case_events`: Event history
- `agent_experience`: Experience data

## Best Practices

1. **Event-Driven Design**: Use events for loose coupling
2. **Error Handling**: Implement recovery strategies
3. **Learning**: Accumulate experience from executions
4. **Repository Pattern**: Separate persistence logic
5. **Handler Isolation**: Keep handlers focused and independent

## Future Extensions

1. **Distributed Events**: Full Redis pub-sub support
2. **Event Sourcing**: Complete event history
3. **CQRS**: Separate read/write models
4. **Saga Pattern**: Multi-step transactions
5. **Event Replay**: Replay events for debugging
