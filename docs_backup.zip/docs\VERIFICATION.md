# GRID Verification Standards 🛡️

This document outlines the rigorous quality and verification standards for the GRID codebase. All contributions must adhere to these standards to ensure the stability and safety of the Sovereign Tier architecture.

## Core Principles

1.  **Local-First Verification**: All checks must be runnable on a local machine without external API dependencies (except for specific integration tests).
2.  **Zero Toleration for Type Errors**: The `grid` package must maintain 100% Mypy compliance with strict type hinting.
3.  **Convergent Styling**: Use `Ruff` for both formatting and linting.
4.  **High Test Coverage**: Core components should target ≥80% test coverage.

## Verification Suite

The `scripts/verify.py` script is the single source of truth for codebase health. It runs:

| Step | Tool | Command | Description |
| :--- | :--- | :--- | :--- |
| **Formatting** | Ruff | `uv run ruff format --check` | Ensures PEP 8 compliance and consistent style. |
| **Linting** | Ruff | `uv run ruff check` | Catches potential bugs, unused imports, and style violations. |
| **Typing** | Mypy | `uv run mypy -p grid` | Performs static type analysis on the core `grid` package. |
| **Tests** | Pytest | `uv run pytest src/grid` | Executes unit and integration tests. |

### Usage

Run the full verification suite:
```powershell
python scripts/verify.py
```

Run with auto-fix for formatting/linting:
```powershell
python scripts/verify.py --fix
```

## Type Safety Standards

-   **Explicit Exports**: Modules should use `__all__` to define their public API.
-   **No `Any`**: Minimize the use of `Any`. If unavoidable, document why.
-   **Lazy Loading**: When lazy-loading modules (e.g., in personas or bridge), use type hints like `Any | None` and cast to the proper type when used if possible.
-   **Protocol Implementation**: Use `typing.Protocol` for capability-based interfaces (e.g., `InferenceProvider`).

## Testing Standards

-   **Mock external calls**: Use `unittest.mock` or `pytest-mock` for network, filesystem, or hardware interactions.
-   **Fixture Reuse**: Define common setup logic in `conftest.py`.
-   **Deterministic Failures**: Ensure tests produce consistent results across environments.

## Sovereign Tier Safeguards

The GRID system operates in a "Sovereign Tier" (Local, Secure, Reliable). Verification must confirm:
-   No accidental leaks of private keys or environment variables.
-   Fallback mechanisms (e.g., RAG → Heuristic) are correctly typed and tested.
-   Memory limits and performance constraints are respected during inference.

---
*Created by Antigravity - Advanced Agentic Coding*
