# Moved

This file has been moved to `docs/architecture/RESONANCE_OPTIMIZATION_PLAN.md`.

Please update your bookmarks and links.
