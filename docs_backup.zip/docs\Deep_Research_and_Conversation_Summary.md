# **The Evolution of Computational Synthesis: From Cryptographic Foundations to the Software 3.0 Paradigm and Global Digital Shifts**

The historical trajectory of software engineering from 2021 to 2026 is defined by a fundamental transformation in the relationship between human intent and machine execution. This era, punctuated by the high-profile contributions of Andrej Karpathy and the emergence of "vibe coding," represents a departure from the deterministic logic of classical programming toward a stochastic, agentic model of system construction known as Software 3.0.1 This transition is not merely a technical shift but a socio-technical phenomenon that reflects broader changes in global media consumption—exemplified by the enduring demand for legacy content like *Friends*—and the strategic technological roadmaps of emerging economies, most notably the "Smart Bangladesh 2041" initiative.3 By analyzing the technical milestones of this period, from the "from-scratch" pedagogical approach of the cryptos repository to the raw performance optimizations of llm.c, we can discern the underlying patterns of a new computing paradigm.6

## **Technical Pedagogy and the Cryptos Repository: Deconstructing the Bitcoin Protocol**

In May 2021, the release of the cryptos repository by Andrej Karpathy served as a critical educational milestone, emphasizing the importance of first-principles understanding in complex systems.8 This project was designed as a "pedagogical deconstruction" of the Bitcoin protocol, implemented in pure Python to maximize legibility at the expense of performance.6 The implementation of SHA-256 within cryptos/sha256.py follows the NIST FIPS 180-4 specification with literal adherence, providing a line-by-line mapping of the cryptographic hash function that serves as the foundation of decentralized security.6 This approach allowed developers to bypass the "black box" nature of standard libraries and observe the bitwise operations, logical constants, and padding mechanisms that enable immutable data structures.6

The architectural focus of cryptos extended to the implementation of the Elliptic Curve Digital Signature Algorithm (ECDSA) and the handling of Bitcoin transaction objects.6 By providing a command-line interface via getnewaddress.py, the repository demonstrated the mathematical derivation of secret and public key pairs and the subsequent generation of base58check compressed addresses.6 The transaction logic within cryptos/transaction.py allowed for the parsing and validation of legacy transaction types, illustrating the cryptographic authenticity of the network through manual verification of signatures and outputs.6 While the implementation intentionally omitted modern SegWit enhancements to focus on core logical foundations, it established a blueprint for educational software that would later influence more complex projects like micrograd and nanoGPT.6

### **Core Components and Cryptographic Specifications in the Cryptos Framework**

| Component | Logic Source | Functional Implementation | Educational Objective |
| :---- | :---- | :---- | :---- |
| SHA-256 | NIST FIPS 180-4 | Bitwise logical operations in pure Python | Transparency of hashing constants.6 |
| ECDSA | Secp256k1 | Signature generation and verification loops | Understanding asymmetric encryption.6 |
| Key Management | Base58Check | CLI-based public/private key derivation | Mastering wallet address generation.6 |
| Transaction | P2PKH | Legacy transaction parsing and validation | Decoupling transaction field logic.6 |
| Block Logic | Header Spec | Chain-of-custody validation scripts | Visualizing blockchain continuity.6 |

The influence of the cryptos repository is observed in the broader developer community, where it has been utilized as a reference for "from-scratch" re-implementations.9 For instance, independent researchers have utilized Karpathy’s intellectual work to deepen their understanding of Bitcoin's technical background, eventually broadcasting functional transactions to the Bitcoin testnet.9 This cycle of "understanding through reconstruction" characterizes the Software 2.0 era, where developers focused on the underlying mathematics and neural architectures that would eventually lead to the massive scale of Large Language Models (LLMs).2 The transition from the granular control of cryptos to the massive abstractions of current AI models represents a pivotal shift in the engineering mindset.9

## **The Architecture of llm.c: Performance Optimization and the Removal of Abstraction**

As the industry pivoted toward LLMs, Karpathy’s llm.c project emerged as a stark counterpoint to the increasing complexity of AI frameworks.7 Launched with the goal of training production-grade LLMs in raw C and CUDA, the project seeks to eliminate the overhead of high-level abstractions like PyTorch (245MB) or cPython (107MB).7 This "simple-to-raw" approach focuses on reproducing the GPT-2 and GPT-3 series by implementing every layer of the Transformer architecture from scratch, providing a high-performance alternative to the standard Python-centric stack.7

### **LayerNorm Implementation and Manual Gradient Derivation**

One of the most technically significant aspects of llm.c is its implementation of LayerNorm, which serves as a case study in manual performance engineering.7 Unlike modern frameworks that abstract the backward pass through autograd systems, llm.c requires a manually derived backward pass to compute gradients for inputs, weights, and biases.7 The implementation follows the "pre-normalization" architecture used in GPT-2, where LayerNorm is applied at the beginning of each Transformer block to improve training stability.7 Mathematically, the forward pass is defined as:

![][image1]  
In the C implementation, this is achieved by iterating through batch and time dimensions, calculating the mean (![][image2]) and variance (![][image3]) via sequential loops over the channel dimension (![][image4]).7 To optimize for memory bandwidth, the implementation recomputes the normalized activations during the backward pass—a strategy known as "checkpointing"—which significantly reduces the storage requirements for large tensors.7 This meticulous attention to memory management and pointer arithmetic allows llm.c to achieve speeds approximately 7% faster than PyTorch Nightly.7

### **Repository Structure and Multi-Language Ports**

The llm.c repository is organized into core training files, unit tests, and development kernels, providing a modular framework for LLM research.7 The train\_gpt2.cu file serves as the "bleeding edge" mainline CUDA implementation, while train\_gpt2.py acts as a parallel PyTorch reference for verification.7 The project’s simplicity has inspired a global movement to port the architecture to other languages and hardware APIs.7

| Platform/API | Language Port | Development Focus | Hardware Target |
| :---- | :---- | :---- | :---- |
| CUDA | C / C++ | Mainline pretraining performance | NVIDIA GPUs.7 |
| Metal | Swift | Apple Silicon optimization | Mac M3/M4 Series.7 |
| ROCm | C++ | AMD 7900 XTX support | AMD GPUs.7 |
| WebGPU | JavaScript/TS | Browser-based inference and training | Cross-platform web.7 |
| Mojo | Mojo | High-level systems programming | Universal.7 |

The data handling within llm.c utilizes a custom binary format for tokenized datasets, where a 1024-byte header is followed by a stream of tokens in uint16 format.7 This eliminates the need for complex data loading libraries and allows for efficient, direct memory access during the training loop.7 This focus on the "material substrate" of computation aligns with the philosophy that understanding the underlying hardware constraints is essential for building the next generation of intelligent systems.7

## **Software 3.0 and the Vibe Coding Paradigm: The Rise of Natural Language Interfaces**

By February 2025, Andrej Karpathy introduced the concept of "vibe coding," marking the transition to Software 3.0.1 In this new paradigm, the primary interface for software development shifts from manual code entry to high-level conversational prompting with LLMs.10 Vibe coding represents a recognition of the increasing sophistication of AI tools like Cursor Composer and OpenAI's Sonnet, which allow developers to "fully give in to the vibes" and "forget that the code even exists".11 This method involves a descriptive, iterative loop: the user describes a goal in plain language, the AI generates the code, the user executes and observes the output, and subsequently provides feedback for refinement.1

### **The Implications of Material Disengagement in Programming**

The "Karpathy canon" of vibe coding posits that the material substrate of programming—the code itself—is no longer the primary focus of the human developer.13 This "material disengagement" has profound implications for the labor market and the definition of technical expertise.2 While advocates argue that vibe coding democratizes software creation, allowing non-technical individuals to build functional apps, critics point to the "70% problem".11 This phenomenon describes a pattern where rapid progress is made initially, but the final 30% of development—characterized by edge cases, security vulnerabilities, and maintenance—becomes extremely challenging without deep engineering knowledge.14

| Development Phase | Software 1.0 (Manual) | Software 3.0 (Vibe Coding) | Risk Profile |
| :---- | :---- | :---- | :---- |
| Architecture | Manual specification | Prompt-based generation | Lack of structured planning.12 |
| Implementation | Line-by-line coding | Iterative conversational loop | Unseen vulnerabilities.1 |
| Debugging | Systematic trace | Feedback-driven refinement | Two steps back pattern.10 |
| Maintenance | High (Code ownership) | Challenging (AI dependency) | Obsolescence and drift.12 |

Vibe coding is increasingly being categorized into "pure" form, where users trust the AI output for throwaway projects, and "responsible AI-assisted development," where the AI acts as a pair programmer under human oversight.1 Karpathy frames this transition using the "Iron Man suit" analogy, suggesting that AI should augment human strength and sensors while leaving the human at the center of intent and decision-making.10 This "centaur design" approach combines human judgment with AI speed and scale, providing a more sustainable model for professional engineering than fully autonomous agents.10

## **Global Media Consumption and the Milestone of Streaming Dominance**

The technical evolution of software has been mirrored by a dramatic shift in digital media consumption. By mid-2025, streaming reached a historic milestone, accounting for 44.8% of total television usage in the United States, surpassing the combined share of broadcast and cable for the first time.16 This trend continued through December 2025, where streaming share surged to 47.5%, driven by massive engagement on platforms like Netflix and YouTube.17

### **The Resilience of Legacy Sitcoms: The Friends Viewership Phenomenon**

Within this streaming-first landscape, legacy content continues to command exceptional demand. The sitcom *Friends* remains a global cultural touchstone, with its May 2021 reunion special on HBO Max serving as a pivotal moment for the platform’s growth.3 In the U.S., the special attracted 2 million households over its opening weekend, outperforming other high-profile finales.19 Globally, the reunion sparked a surge in demand for the original series, with Parrot Analytics reporting that *Friends* was the fourth most in-demand show in the world just prior to the special’s launch.20

| Region | Platform | Viewership Metric (2021) | Ranking / Significance |
| :---- | :---- | :---- | :---- |
| United States | HBO Max | 2.0M Households (Opening Weekend) | Bigger than *Mare of Easttown* finale.19 |
| United Kingdom | Sky One | 5.3M Viewers (Live/Recorded) | Sky's most-watched show in 2 years.22 |
| Global | Multiple | 58.1x Average Demand | 4th most in-demand show worldwide.20 |
| Australia | Netflix | Peak H1 2021 | 24% decline after April 2025 exit.23 |

Longitudinal data from 2021 to 2025 reveals that while original seasons of *Friends* saw a decline on platforms like Netflix—largely due to market exits in regions like Australia—certain seasons remained remarkably popular.23 Season 5, for example, lead in total hours viewed (38.1 million) in the first half of 2025, while Season 6 remained the most popular when adjusted for run time.23 This persistent engagement highlights the "long-tail" value of acquired series in a market increasingly dominated by high-cost original production.23

### **Comparative Streaming Market Share and Subscription Trends**

As of early 2026, Netflix reached 301.6 million global subscribers, maintaining its position as the leading streaming provider despite the cessation of quarterly subscriber reporting in 2025\.25 The platform’s ad-supported plan, which garnered over 94 million subscribers, has been a key driver of revenue growth, projected to reach over $50 billion in 2026\.25

| Platform | 2026 Global Subscribers (Est.) | 2025 Market Share (US TV Time) | Operating Margin |
| :---- | :---- | :---- | :---- |
| Netflix | 301.6M | 7-8% | 31-35%.24 |
| Amazon Prime Video | 220.0M | 22% (Market Share Tie) | Varied.24 |
| Disney+ / Hulu | 196.0M | Moderate | Emerging.24 |
| YouTube (Main) | \- | 12.5% (May 2025\) | High.16 |

The rise of live streaming is another critical factor in this evolution. Projections for 2026 suggest that the global live streaming market will reach nearly $100 billion, with platforms like Twitch and YouTube Gaming leading the charge.27 In Q2 2024 alone, viewers watched a total of 8.5 billion hours of live-streamed content, an increase of 10% year-over-year.28 This shift toward "appointment-based" digital viewing is increasingly being used by legacy media companies to bolster their streaming-first strategies.16

## **Smart Bangladesh 2041: A Strategic Roadmap for AI and Digital Inclusion**

In the context of global technological diffusion, Bangladesh has emerged as a leader in strategic national planning through its "Smart Bangladesh 2041" vision.4 This roadmap, which aims to transform the nation into a high-income, developed country by 2041, is built on four core pillars: Smart Citizen, Smart Government, Smart Society, and Smart Economy.5 Central to this transformation is the integration of Artificial Intelligence (AI) across all priority sectors, including healthcare, agriculture, and education.31

### **AI Readiness and the Educational Ecosystem in Dhaka**

The 2025 AI Readiness Assessment Report, unveiled in Dhaka, provides a comprehensive national picture of Bangladesh's preparedness to adopt ethical and inclusive AI.32 While the country has made significant progress in digital governance and has high public trust in government digital services, challenges remain, particularly in internet connectivity and power supply outside the Dhaka division.34 The "Smart Curriculum" initiative seeks to address these gaps by moving K-12 education toward a competency-driven, personalized model supported by AI-enabled adaptive tutors and continuous assessment.35

| Metric | Urban Bangladesh (2025) | Rural Bangladesh (2025) | Impact/Trend |
| :---- | :---- | :---- | :---- |
| Internet Connectivity | 71.4% | 36.5% | Persistent digital divide.35 |
| AI Access in Education | \~60% | \~10% | Equity gap priorities.35 |
| Student Engagement (AI) | 59% Improvement | \- | Positive pedagogical shift.35 |
| Study Ability (AI) | 65% Improvement | \- | Efficiency gains in higher-ed.35 |

The education landscape is being reshaped by startups like Shikho and 10 Minute School, which utilize AI to offer interactive video lessons and democratize access to quality materials.38 However, higher education studies flag concerns over-reliance on AI and data privacy, emphasizing the need for robust governance and teacher upskilling.35 The government-backed Bangladesh AI Institute is currently building courses and labs to train a new generation of practitioners, focusing on practical, localized AI tools that respect language and cultural nuances.35

### **Startup Investment and Industrial Diversification**

Bangladesh's startup scene has experienced a "strategic transition year" in 2025\.39 Total startup funding reached $124 million, although this was heavily concentrated in a single $110 million transaction—the ShopUp-Sary merger that formed SILQ Group.39 This concentration highlights the ecosystem's reliance on a small number of large deals and the need for broader early-stage engagement.39

| Sector | Funding Share (2025) | Key Players | Technological Focus |
| :---- | :---- | :---- | :---- |
| Financial Services | 89% | SILQ Group (ShopUp) | Logistics, Micro-credit.39 |
| Agriculture | Emerging | iFarmer, Krishok Bondhu | Precision agri, computer vision.41 |
| EdTech | Growth | Shikho, 10 Minute School | Personalized learning, AI tutoring.38 |
| IT Services | US$2.11B (2025 Rev) | Dream71, Gaze Tech | E-governance, Computer vision.42 |

By 2026, over 60% of new Bangladeshi agri-startups are projected to utilize AI and agricultural robots to address labor shortages and climate change.41 These technologies, including computer-vision enabled robotic weeders and satellite-based crop monitoring, are projected to increase field productivity by 40%.41 This shift from an agrarian to a services-driven and manufacturing-led economy is a central tenet of the Perspective Plan 2021-2041.4

## **Leadership Momentum and Historical Weight: A Reconciliation-Oriented Analysis**

The capacity of leaders to navigate periods of extreme chaos and cultural confrontation is a recurring theme in political history. A comparative analysis of Abraham Lincoln, Nelson Mandela, and Martin Luther King Jr. reveals that successful reconciliation requires emotional self-control, empathy, and cognitive complexity.43

### **Cognitive Complexity and the Team of Rivals Strategy**

Abraham Lincoln’s leadership during the American Civil War was characterized by strategic flexibility and a "team of rivals" approach, which integrated diverse and opposing views into his cabinet to create a solid consensus during a crisis.45 His gradual, educative strategy for the abolition of slavery utilized crucial momentum, such as the Emancipation Proclamation, to unite a divided nation.45 Similarly, Nelson Mandela’s leadership in post-apartheid South Africa prioritized reconciliation over retribution, as evidenced by his support for the Truth and Reconciliation Commission (TRC).44

| Leader | Primary Attribute | Strategic Mechanism | Outcome |
| :---- | :---- | :---- | :---- |
| Abraham Lincoln | Empathy / Forgiveness | Team of Rivals Cabinet | Preservation of the Union.44 |
| Nelson Mandela | Self-control | Truth and Reconciliation | South African integration.43 |
| Martin Luther King Jr. | Visionary / Non-violence | Peaceful Protests | Global Civil Rights momentum.43 |

Mandela’s ability to "keep your friends close and your rivals closer" was learned through 27 years of imprisonment, where he developed a theory of leadership that prioritized the common good over personal bitterness.44 Martin Luther King Jr.’s charisma and effectiveness as a voice of moral global conscience leadership emerged at a unique historical moment in the 1960s, a time of global political headwinds and colonial liberation.46 These leaders embodied the quality of "leading at the edge of chaos," transforming disagreement into unity through vision and tolerance.43

## **The Unix Philosophy: A Foundation for Modern AI Orchestration**

As software evolves toward the Software 3.0 paradigm, the foundational principles of the Unix philosophy remain remarkably relevant. The Unix approach favors small, composable programs that "do one thing well" and can be piped together to perform complex tasks.48 This philosophy is visible in the design of modern AI agents, which string together tool use and reasoning in a loopy, iterative way.15

### **Composability, Pipes, and Human-First Design**

The classic Unix pipeline mechanism—connecting standard output to standard input across a chain of processes—is a precursor to modern "context engineering".50 For instance, a complex query might involve multiple LLM calls orchestrated under the hood, carefully balancing performance and cost.50 The Unix principles of human-first design, simplicity, and consistency across programs are now being applied to the terminal interfaces and IDEs that power vibe coding.10

| Unix Principle | Software 1.0 Application | Software 3.0 (AI) Application |
| :---- | :---- | :---- |
| Composability | Pipes (grep, cat, sed) | Agentic tool-use and DAGs.49 |
| Modularity | Do one thing well | Specialized domain experts/models.15 |
| Hiding Internals | Anonymous pipes | LLM black-box reasoning.10 |
| Clarity | Saying (just) enough | Structured JSON outputs / prompts.49 |

The rise of "jagged intelligence" in LLMs—where they exhibit flashes of genius alongside grade-school lapses—requires a return to Unix-like rigor in validation and monitoring.10 Just as traditional Unix commands were designed to be consistent and predictable, Software 3.0 necessitates new approaches to engineering: heavy use of validation, monitoring of AI outputs, and iterative prompt tuning.10

## **Conclusion: Synthesis of Technological and Social Paradigms**

The period from 2021 to 2026 represents a convergence of computational rigor and stochastic intelligence. Andrej Karpathy’s transition from the from-scratch cryptographic pedagogy of cryptos to the raw optimization of llm.c and finally to the high-abstraction "vibe coding" of Software 3.0 encapsulates the trajectory of modern engineering.6 This technical evolution is deeply intertwined with global shifts in media consumption, where streaming has become the dominant platform for both new spectacles and the enduring nostalgia of legacy sitcoms like *Friends*.16 At a national level, the "Smart Bangladesh 2041" vision demonstrates how these technological advancements can be harnessed to drive inclusion and economic growth in emerging markets.4 Ultimately, the success of this new era depends on a leadership style that prioritizes reconciliation, empathy, and the enduring logic of simple parts that work together.43 As we move forward, the "Iron Man suit" model of human-AI collaboration remains the most viable path for augmenting human potential without surrendering human judgment.10

#### **Works cited**

1. Vibe Coding Explained: Tools and Guides | Google Cloud, accessed January 25, 2026, [https://cloud.google.com/discover/what-is-vibe-coding](https://cloud.google.com/discover/what-is-vibe-coding)  
2. Andrej Karpathy on the Rise of Software 3.0 \- Analytics Vidhya, accessed January 25, 2026, [https://www.analyticsvidhya.com/blog/2025/06/andrej-karpathy-on-the-rise-of-software-3-0/](https://www.analyticsvidhya.com/blog/2025/06/andrej-karpathy-on-the-rise-of-software-3-0/)  
3. A Global Viewing Guide and in-Depth Analysis of Friends \- Oreate AI Blog, accessed January 25, 2026, [https://www.oreateai.com/blog/a-global-viewing-guide-and-indepth-analysis-of-friends/fcfb27d9222e90adc83101899e59a93b](https://www.oreateai.com/blog/a-global-viewing-guide-and-indepth-analysis-of-friends/fcfb27d9222e90adc83101899e59a93b)  
4. Bangladesh's Vision 2041 and the Perspective Plan 2021-2041 are ..., accessed January 25, 2026, [https://uncrd.un.org/sites/uncrd.un.org/files/16th-est\_cr\_bangladesh.pdf](https://uncrd.un.org/sites/uncrd.un.org/files/16th-est_cr_bangladesh.pdf)  
5. (PDF) SMART Bangladesh Vision 2041: Concept of a Sustainable Developed Country, accessed January 25, 2026, [https://www.researchgate.net/publication/368723296\_SMART\_Bangladesh\_Vision\_2041\_Concept\_of\_a\_Sustainable\_Developed\_Country](https://www.researchgate.net/publication/368723296_SMART_Bangladesh_Vision_2041_Concept_of_a_Sustainable_Developed_Country)  
6. karpathy/cryptos: Pure Python from-scratch zero-dependency implementation of Bitcoin for educational purposes \- GitHub, accessed January 25, 2026, [https://github.com/karpathy/cryptos](https://github.com/karpathy/cryptos)  
7. karpathy/llm.c: LLM training in simple, raw C/CUDA \- GitHub, accessed January 25, 2026, [https://github.com/karpathy/llm.c](https://github.com/karpathy/llm.c)  
8. Andrej Karpathy \- GitHub, accessed January 25, 2026, [https://github.com/karpathy](https://github.com/karpathy)  
9. AysajanE/bitcoin-from-scratch-in-python \- GitHub, accessed January 25, 2026, [https://github.com/AysajanE/bitcoin-from-scratch-in-python](https://github.com/AysajanE/bitcoin-from-scratch-in-python)  
10. Andrej Karpathy on Software 3.0: Software in the Age of AI | by Ben Pouladian | Medium, accessed January 25, 2026, [https://medium.com/@ben\_pouladian/andrej-karpathy-on-software-3-0-software-in-the-age-of-ai-b25533da93b6](https://medium.com/@ben_pouladian/andrej-karpathy-on-software-3-0-software-in-the-age-of-ai-b25533da93b6)  
11. Vibe coding \- Wikipedia, accessed January 25, 2026, [https://en.wikipedia.org/wiki/Vibe\_coding](https://en.wikipedia.org/wiki/Vibe_coding)  
12. What is Vibe Coding? \- IBM, accessed January 25, 2026, [https://www.ibm.com/think/topics/vibe-coding](https://www.ibm.com/think/topics/vibe-coding)  
13. Vibe coding: programming through conversation with artificial intelligence \- arXiv, accessed January 25, 2026, [https://arxiv.org/html/2506.23253v1](https://arxiv.org/html/2506.23253v1)  
14. Beyond Vibe Coding \- A Guide To AI-Assisted Development, accessed January 25, 2026, [https://beyond.addy.ie/](https://beyond.addy.ie/)  
15. Software 3.0 is eating the stack: What's your moat?, accessed January 25, 2026, [https://www.kyndryl.com/ie/en/about-us/news/2025/10/rise-of-software-3-0](https://www.kyndryl.com/ie/en/about-us/news/2025/10/rise-of-software-3-0)  
16. Streaming Reaches Historic TV Milestone, Eclipses Combined Broadcast and Cable Viewing For First Time | Nielsen, accessed January 25, 2026, [https://www.nielsen.com/news-center/2025/streaming-reaches-historic-tv-milestone-eclipses-combined-broadcast-and-cable-viewing-for-first-time/](https://www.nielsen.com/news-center/2025/streaming-reaches-historic-tv-milestone-eclipses-combined-broadcast-and-cable-viewing-for-first-time/)  
17. Streaming Shatters Multiple Records in December 2025 with 47.5% of TV Viewing, according to Nielsen's The Gauge, accessed January 25, 2026, [https://www.nielsen.com/news-center/2026/streaming-shatters-multiple-records-in-december-2025-with-47-5-of-tv-viewing-according-to-nielsens-the-gauge/](https://www.nielsen.com/news-center/2026/streaming-shatters-multiple-records-in-december-2025-with-47-5-of-tv-viewing-according-to-nielsens-the-gauge/)  
18. Streaming hits record 47.5% of total TV usage in December 2025, Nielsen reports, accessed January 25, 2026, [https://mediabrief.com/streaming-hits-record-47-5-of-total-tv-usage-in-december-2025-nielsen-reports/](https://mediabrief.com/streaming-hits-record-47-5-of-total-tv-usage-in-december-2025-nielsen-reports/)  
19. 'Friends' Reunion Drew 2 Million Households Over Weekend | Next TV, accessed January 25, 2026, [https://www.nexttv.com/news/friends-reunion-drew-2-million-households-over-weekend](https://www.nexttv.com/news/friends-reunion-drew-2-million-households-over-weekend)  
20. “Friends” demand skyrockets globally ahead of the reunion \- Parrot Analytics, accessed January 25, 2026, [https://www.parrotanalytics.com/press/friends-demand-skyrockets-globally-ahead-of-the-reunion/](https://www.parrotanalytics.com/press/friends-demand-skyrockets-globally-ahead-of-the-reunion/)  
21. 'Friends' Reunion on HBO Max Drove a Huge Surge for the Original Show \- Observer, accessed January 25, 2026, [https://observer.com/2021/05/hbo-max-friends-the-reunion-special-viewership-interest/](https://observer.com/2021/05/hbo-max-friends-the-reunion-special-viewership-interest/)  
22. Friends: The Reunion breaks Sky One viewing record | Stirling News, accessed January 25, 2026, [https://www.stirlingnews.co.uk/leisure/national/19364732.friends-reunion-breaks-sky-one-viewing-record/](https://www.stirlingnews.co.uk/leisure/national/19364732.friends-reunion-breaks-sky-one-viewing-record/)  
23. Friend ratings on Netflix have tanked since it lost Australia – Angus ..., accessed January 25, 2026, [https://anguskidman.show/2025/07/31/friend-netflix-ratings-2025-h1/](https://anguskidman.show/2025/07/31/friend-netflix-ratings-2025-h1/)  
24. Netflix \- Company Analysis and Outlook Report (2026) \- Deep Research Global, accessed January 25, 2026, [https://www.deepresearchglobal.com/p/netflix-company-analysis-outlook-report](https://www.deepresearchglobal.com/p/netflix-company-analysis-outlook-report)  
25. Netflix Subscribers Statistics 2026 \[Latest Global Data\] \- DemandSage, accessed January 25, 2026, [https://www.demandsage.com/netflix-subscribers/](https://www.demandsage.com/netflix-subscribers/)  
26. Netflix eyes 1 billion viewers—how will regulators handle the beast? \- FREE TO READ, accessed January 25, 2026, [https://rethinkresearch.biz/articles/netflix-eyes-1-billion-viewers-how-will-regulators-handle-the-beast-free-to-read/](https://rethinkresearch.biz/articles/netflix-eyes-1-billion-viewers-how-will-regulators-handle-the-beast-free-to-read/)  
27. 33 Live Streaming Statistics 2026: Market Size & Trends \- DemandSage, accessed January 25, 2026, [https://www.demandsage.com/live-streaming-statistics/](https://www.demandsage.com/live-streaming-statistics/)  
28. 34 Live Streaming Statistics (2026 Data \+ Trends) \- Adam Connell, accessed January 25, 2026, [https://adamconnell.me/live-streaming-statistics/](https://adamconnell.me/live-streaming-statistics/)  
29. Global Live Streaming Statistics and Trends in 2025 \- Teleprompter.com, accessed January 25, 2026, [https://www.teleprompter.com/blog/live-streaming-statistics](https://www.teleprompter.com/blog/live-streaming-statistics)  
30. SMART Bangladesh Vision 2041: Concept of a Sustainable Developed Country, accessed January 25, 2026, [http://emrd.portal.gov.bd/sites/default/files/files/emrd.portal.gov.bd/page/b280d648\_d20e\_4021\_b949\_6fc5e25a7e9a/SMARTBangladeshVision2041ConceptofaSustainableDevelopedCountry.pdf](http://emrd.portal.gov.bd/sites/default/files/files/emrd.portal.gov.bd/page/b280d648_d20e_4021_b949_6fc5e25a7e9a/SMARTBangladeshVision2041ConceptofaSustainableDevelopedCountry.pdf)  
31. The Complete Guide to Using AI in the Government Industry in Bangladesh in 2025, accessed January 25, 2026, [https://www.nucamp.co/blog/coding-bootcamp-bangladesh-bgd-government-the-complete-guide-to-using-ai-in-the-government-industry-in-bangladesh-in-2025](https://www.nucamp.co/blog/coding-bootcamp-bangladesh-bgd-government-the-complete-guide-to-using-ai-in-the-government-industry-in-bangladesh-in-2025)  
32. Bangladesh unveils national roadmap for ethical AI development, accessed January 25, 2026, [https://dig.watch/updates/bangladesh-unveils-national-roadmap-for-ethical-ai-development](https://dig.watch/updates/bangladesh-unveils-national-roadmap-for-ethical-ai-development)  
33. Bangladesh advances responsible AI agenda through multi-partner cooperation \- UNESCO, accessed January 25, 2026, [https://www.unesco.org/en/articles/bangladesh-advances-responsible-ai-agenda-through-multi-partner-cooperation](https://www.unesco.org/en/articles/bangladesh-advances-responsible-ai-agenda-through-multi-partner-cooperation)  
34. First national AI readiness assessment report unveiled | News | Bangladesh Sangbad Sangstha (BSS), accessed January 25, 2026, [https://www.bssnews.net/news/334126](https://www.bssnews.net/news/334126)  
35. The Complete Guide to Using AI in the Education Industry in Bangladesh in 2025 \- Nucamp, accessed January 25, 2026, [https://www.nucamp.co/blog/coding-bootcamp-bangladesh-bgd-education-the-complete-guide-to-using-ai-in-the-education-industry-in-bangladesh-in-2025](https://www.nucamp.co/blog/coding-bootcamp-bangladesh-bgd-education-the-complete-guide-to-using-ai-in-the-education-industry-in-bangladesh-in-2025)  
36. AI and Educational Technology in K–12 Curriculum Reform: A Pathway Toward Smart Education in Bangladesh \- RSIS International, accessed January 25, 2026, [https://rsisinternational.org/journals/ijriss/articles/ai-and-educational-technology-in-k-12-curriculum-reform-a-pathway-toward-smart-education-in-bangladesh/](https://rsisinternational.org/journals/ijriss/articles/ai-and-educational-technology-in-k-12-curriculum-reform-a-pathway-toward-smart-education-in-bangladesh/)  
37. How AI might transform Bangladesh's education landscape \- Asia News Network, accessed January 25, 2026, [https://asianews.network/how-ai-might-transform-bangladeshs-education-landscape/](https://asianews.network/how-ai-might-transform-bangladeshs-education-landscape/)  
38. Ai Education Startups in Bangladesh \- Oreate AI Blog, accessed January 25, 2026, [https://www.oreateai.com/blog/ai-education-startups-in-bangladesh/811ee2688e24bcfab6aa8c0b9c9c7613](https://www.oreateai.com/blog/ai-education-startups-in-bangladesh/811ee2688e24bcfab6aa8c0b9c9c7613)  
39. Bangladesh Startup Investments Report 2025: Year in Review \- LightCastle Partners, accessed January 25, 2026, [https://lightcastlepartners.com/insights/2026/01/startup-investments-report-2025-yir/](https://lightcastlepartners.com/insights/2026/01/startup-investments-report-2025-yir/)  
40. Startup Investment Report \- Year In Review 2025, accessed January 25, 2026, [https://www.startupbangladesh.vc/wp-content/uploads/2026/01/Startup-Investment-Report-Year-In-Review-2025.pdf](https://www.startupbangladesh.vc/wp-content/uploads/2026/01/Startup-Investment-Report-Year-In-Review-2025.pdf)  
41. AI Agriculture Startups & Robots In Bangladesh: 2026 Trends \- Farmonaut, accessed January 25, 2026, [https://farmonaut.com/asia/ai-agriculture-startups-robots-in-bangladesh-2026-trends](https://farmonaut.com/asia/ai-agriculture-startups-robots-in-bangladesh-2026-trends)  
42. Top 10 Best IT Startups in Bangladesh (2026) | Vivasoft Ltd., accessed January 25, 2026, [https://vivasoftltd.com/best-it-startups-in-bangladesh/](https://vivasoftltd.com/best-it-startups-in-bangladesh/)  
43. Lincoln, Mandela, and Qualities of Reconciliation-oriented Leadership \- ResearchGate, accessed January 25, 2026, [https://www.researchgate.net/publication/233052496\_Lincoln\_Mandela\_and\_Qualities\_of\_Reconciliation-oriented\_Leadership](https://www.researchgate.net/publication/233052496_Lincoln_Mandela_and_Qualities_of_Reconciliation-oriented_Leadership)  
44. What Today's Leaders Can Learn from Lincoln and Mandela, accessed January 25, 2026, [https://www.psychologytoday.com/gb/blog/defining-memories/201612/what-todays-leaders-can-learn-from-lincoln-and-mandela](https://www.psychologytoday.com/gb/blog/defining-memories/201612/what-todays-leaders-can-learn-from-lincoln-and-mandela)  
45. (PDF) Analysis of Abraham Lincoln's Leadership Style in Managing the American Civil War Crisis \- ResearchGate, accessed January 25, 2026, [https://www.researchgate.net/publication/398830942\_Analysis\_of\_Abraham\_Lincoln's\_Leadership\_Style\_in\_Managing\_the\_American\_Civil\_War\_Crisis](https://www.researchgate.net/publication/398830942_Analysis_of_Abraham_Lincoln's_Leadership_Style_in_Managing_the_American_Civil_War_Crisis)  
46. The Tempests of Time, Rights, Race and Justice: Mandela and MLK Jr. as Transformational Leaders or Beneficiaries \- Semantic Scholar, accessed January 25, 2026, [https://pdfs.semanticscholar.org/cff2/6aa58a23c453045f2df941231952862a050a.pdf](https://pdfs.semanticscholar.org/cff2/6aa58a23c453045f2df941231952862a050a.pdf)  
47. Nelson Mandela Eight Lessons In Leadership Analysis \- 1857 Words | Cram, accessed January 25, 2026, [https://www.cram.com/essay/Mandela-His-Eight-Lessons-In-Leadership-Analysis/FKSBQ9H9C55W](https://www.cram.com/essay/Mandela-His-Eight-Lessons-In-Leadership-Analysis/FKSBQ9H9C55W)  
48. The Unix philosophy favors composability as opposed to monolithic design \- Reddit, accessed January 25, 2026, [https://www.reddit.com/r/linuxmasterrace/comments/t5du2e/the\_unix\_philosophy\_favors\_composability\_as/](https://www.reddit.com/r/linuxmasterrace/comments/t5du2e/the_unix_philosophy_favors_composability_as/)  
49. Command Line Interface Guidelines, accessed January 25, 2026, [https://clig.dev/](https://clig.dev/)  
50. 2025 LLM Year in Review | karpathy, accessed January 25, 2026, [https://karpathy.bearblog.dev/year-in-review-2025/](https://karpathy.bearblog.dev/year-in-review-2025/)  
51. Pipeline (Unix) \- Wikipedia, accessed January 25, 2026, [https://en.wikipedia.org/wiki/Pipeline\_(Unix)](https://en.wikipedia.org/wiki/Pipeline_\(Unix\))  
52. Andrej Karpathy: Software in the era of AI \[video\] \- Hacker News, accessed January 25, 2026, [https://news.ycombinator.com/item?id=44314423](https://news.ycombinator.com/item?id=44314423)  
53. Andrej Karpathy's deep dive into LLMs video \- Codingscape, accessed January 25, 2026, [https://codingscape.com/blog/andrej-karpathys-deep-dive-into-llms-video](https://codingscape.com/blog/andrej-karpathys-deep-dive-into-llms-video)

[image1]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAmwAAAA4CAYAAABAFaTtAAADZ0lEQVR4Xu3dgW0jKRQGYJeSUlKKS0knV8qWcqXsLsoisf8Bw9gZ39j5PgnZvMcAZiPx5EjZywUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYMXPQTtCzp19AADCqHg6qojKeRVsAAAbsmA7Wq6RfQAAJh5RPGWB+Ig1AQCe2ujXoEcVUrnGUesAALyMUcF2FAUbAC+nXmhtO4PRfs6y171r7x3Pbc50zmf4OQXghZz1UpntaxR/lFvWv+UZ9jnjGZ9xTwA8oVlh9H8afUOR/WfR+yxn0p73mfc5c7Z9P/NZAnAyZ71QRsVD9h/tnvXvefYosz3Ncmwb/QwDwC4rl0l76eT4Uax9n2NG71u9Odp+6q3TxvN99vPZ0Xw1l3J877miF/sqvXXz8/SM4tyvPXfnDMDNZhd51SsAWjnHqEjIiytfW/ncbGwxGt/2e/H2tb6f9Wts1G/H57iiF6tyn6M2k+u343vP9mJpZQz/1Tt/ZwnATbYukMz3+r1LKVvqxapebs9c7bjRM1XmtvpFL1bNcsVW/h75WXOt7BcZyzlqbKSOf4U2kuNGLWU8+wCwbOsCyXyvn5dS+zoyy49yuVaVsXbc6Jkqc1v9oherZrlilq973Wojmc+x2S9WYtlnTZ5b/vsAwLLeBTK79Ksaz/wonmb5UW41vrL/KvOj/mzO0l8ZV/RiXyX3sbWXYhTnfnm22QeAZXmJzC76raJkVjDUWO99GuX2xotZrtjKV7O95+ee2crfI/cx23NrlvtqHyduXy3P/5HnDABDLqS5s1/aRxcYbxkAAB4jL3nGnuF8jijUqn8ysOGofQAA38QtxcQtz7ySHxmYqGf13c8MALiTYmLdnmKtdeQ3fgAA/PHxu71HbNXeYm3veAAALrd/u3YLBRsAwMDH73aN2Jb6685sNVftKcL2jvUrVwDgW3i7fBY9/0a8uGbgj62CrFfErVgdu3deAICndr18/smOUgC9/5XpF3FHFkur866OAwB4KT8ufxdtvWKtOLJYOnJuAICn9375LJhK4Xa9jP+7pyyqsn+Pr5wLAOAl1W/ZyutIFlXZv8fqXKvjAABeUinW3jL4IAoxAIAF1ww8kIINAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGfgHwYPxH4zVV+wAAAABJRU5ErkJggg==>

[image2]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAAYCAYAAAAs7gcTAAAAQUlEQVR4XmNgGAWDHvyHYkJiYIBNkGTFGACXCdjEsCrGJgYG2CSQxVDkiFYME8SH4QBDAB8gWiEIEK2YJCcMAgAAvC0o2PpmdkkAAAAASUVORK5CYII=>

[image3]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAYCAYAAAD6S912AAAAW0lEQVR4Xu3Q0QoAEAwF0P3/T/Ni0uxiTFE75cG4NyF6SCrLRVvkUioLXUrZlUI3/5TJfcUfjNboXkceyL0JCmuzJSiI5lMoiOZTWhB9wxItqM1M+EVHLwthQwbiUi7SpaYh8gAAAABJRU5ErkJggg==>

[image4]: <data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAZCAYAAADuWXTMAAAASklEQVR4Xu2M0QoAIAgD/f+fLnoQVm4SQVDgwV68TbMCaSLuKFhiSC8FIDtSALRDj4TQ8WEQOxwPB++Paef6OPXZA3Wf8Adrir/ppo0w0IEreQMAAAAASUVORK5CYII=>