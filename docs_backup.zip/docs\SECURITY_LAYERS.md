# Security Layers Documentation

## Overview

GRID implements a multi-layered security architecture with defense-in-depth principles. This document catalogs all security layers from encryption to AI safety.

## Security Architecture

```
┌─────────────────────────────────────────────────────────────┐
│              Application Layer Security                      │
│  (API Sentinels, Middleware, Headers)                       │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              Authentication Layer                            │
│  (JWT, API Keys, RBAC)                                      │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              Data Protection Layer                           │
│  (Encryption, Secrets Management, PII Redaction)            │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              AI Safety Layer                                 │
│  (API Key Validation, Error Sanitization)                   │
└──────────────────────────────────────────────────────────────┘
```

## Layer 1: API Sentinels (`application/mothership/security/api_sentinels.py`)

**Purpose**: Factory defaults security enforcement with deny-by-default posture.

### Features

1. **Threat Detection Patterns**
   - SQL Injection (9 patterns)
   - Cross-Site Scripting (XSS) (4 patterns)
   - Path Traversal (3 patterns)
   - Command Injection (2 patterns)
   - Header Injection (1 pattern)
   - SSRF (Server-Side Request Forgery) (2 patterns)
   - Template Injection (2 patterns)

2. **Input Sanitization**
   - Pattern-based threat detection
   - Configurable actions: REJECT, SANITIZE, LOG_ONLY, ALERT
   - Severity-based handling (1-10 scale)

3. **Authentication Levels**
   - `NONE`: Public endpoints only
   - `BASIC`: API key or token
   - `INTEGRITY`: Verified authentication with integrity checks
   - `ELEVATED`: MFA, session verification
   - `ADMIN`: Administrative access only

4. **Factory Defaults**
   - Deny-by-default configuration
   - Explicit enablement required
   - Security baseline enforcement

### Usage

```python
from application.mothership.security.api_sentinels import (
    apply_defaults,
    verify_api_against_defaults,
    API_DEFAULTS
)

# Apply security defaults to FastAPI app
apply_defaults(app)

# Verify API configuration
result = verify_api_against_defaults(app)
```

## Layer 2: Authentication (`application/mothership/security/`)

### JWT Authentication (`jwt.py`)

**Purpose**: Production-grade JWT token management.

**Features**:
- Token generation (access + refresh)
- Token validation
- Token refresh
- Secure secret validation
- Environment-aware configuration

**Configuration**:
- `MOTHERSHIP_SECRET_KEY`: JWT secret key (required in production)
- `JWT_ACCESS_TOKEN_EXPIRE_MINUTES`: Access token lifetime (default: 30)
- `JWT_REFRESH_TOKEN_EXPIRE_DAYS`: Refresh token lifetime (default: 7)
- `JWT_ALGORITHM`: Signing algorithm (default: HS256)

**Usage**:
```python
from application.mothership.security.jwt import JWTManager

manager = JWTManager()
token_pair = manager.create_token_pair(subject="user_id")
payload = manager.validate_token(token)
```

**Security**:
- Secret strength validation
- Minimum length requirements (32 chars dev, 64 chars prod)
- Auto-generation with warnings in development
- Fail-fast in production if secret missing

### API Key Authentication (`api_keys.py`)

**Purpose**: API key-based authentication.

**Features**:
- API key generation
- Key hashing (bcrypt)
- Key prefix storage (for identification)
- Rate limiting per key
- Expiration support

**Storage**: `mothership_api_keys` table

**Model**: `APIKeyRow`

**Security**:
- Keys stored as hashes (never plaintext)
- Prefix-only storage for identification
- Rate limiting per key
- Expiration enforcement

### RBAC (`rbac.py`)

**Purpose**: Role-Based Access Control.

**Roles** (hierarchical):
1. **ANONYMOUS**: Read-only public access
2. **READER**: Read + execute permissions
3. **WRITER**: Read + write + execute permissions
4. **ADMIN**: Full permissions except billing write
5. **SUPER_ADMIN**: All permissions including billing
6. **SERVICE_ACCOUNT**: Read + write + execute for services

**Permissions**:
- `READ`: Read access
- `WRITE`: Write access
- `DELETE`: Delete access
- `ADMIN`: Administrative access
- `EXECUTE`: Execute operations
- `SENSITIVE_READ`: Access sensitive data
- `BILLING_READ`: Billing read access
- `BILLING_WRITE`: Billing write access

**Usage**:
```python
from application.mothership.security.rbac import (
    get_permissions_for_role,
    has_permission
)

permissions = get_permissions_for_role(Role.ADMIN)
can_write = has_permission(user_permissions, Permission.WRITE)
```

## Layer 3: Data Protection

### Encryption (`grid/security/encryption.py`)

**Purpose**: AES-256-GCM encryption-at-rest for sensitive data.

**Algorithm**: AES-256-GCM (Authenticated Encryption)

**Features**:
- PBKDF2 key derivation (100,000 iterations)
- Random salt per encryption
- Random nonce per encryption
- Authentication tag for integrity

**Key Management**:
1. Environment variable: `GRID_ENCRYPTION_KEY` (base64 encoded)
2. GCP Secret Manager: `grid-production-wealth-data-encryption`
3. Fail if not found

**Usage**:
```python
from grid.security.encryption import DataEncryption, EncryptedStorage

encryption = DataEncryption()
encrypted = encryption.encrypt("sensitive data")
decrypted = encryption.decrypt(encrypted)

# Storage wrapper
storage = EncryptedStorage(encryption)
storage.store("key", "value")
value = storage.get("key")
```

**Security Properties**:
- Authenticated encryption (detects tampering)
- Unique nonce per operation (prevents replay)
- Salt-based key derivation (protects against rainbow tables)

### Secrets Management (`grid/security/secrets.py`, `local_secrets_manager.py`)

**Purpose**: Secure secrets storage and management.

#### Local Secrets Manager (`local_secrets_manager.py`)

**Features**:
- AES-256-GCM encryption
- SQLite storage (WAL mode)
- PBKDF2 key derivation (100,000 iterations)
- Master key management (`.master.key` file)
- Optional GCP Secret Manager sync

**Storage**: `~/.grid/secrets.db` (configurable)

**CLI**:
```bash
python -m grid.security.local_secrets_manager set MISTRAL_API_KEY "your-key"
python -m grid.security.local_secrets_manager get MISTRAL_API_KEY
```

**Security**:
- Master key stored separately (`.master.key`, 0o600 permissions)
- Per-secret encryption with unique nonce/salt
- Key derivation for each secret

#### Secrets Provider (`secrets.py`)

**Purpose**: Multi-provider secrets management.

**Providers**:
1. **VaultProvider**: HashiCorp Vault integration
2. **EnvironmentProvider**: Environment variables
3. **GCPProvider**: GCP Secret Manager (via `gcp_secrets.py`)

**Usage**:
```python
from grid.security.secrets import SecretsManager

manager = SecretsManager(provider="environment")
secret = manager.get_secret("api_key")
```

### PII Redaction (`grid/security/pii_redaction.py`)

**Purpose**: Protect Personally Identifiable Information in logs.

**Redaction Modes**:
- `NONE`: No redaction
- `PARTIAL`: Partial masking (e.g., `***-1234`)
- `FULL`: Complete masking (`***`)

**Patterns Detected**:
- Email addresses
- Phone numbers
- Credit card numbers
- SSN (Social Security Numbers)
- IP addresses
- API keys
- Passwords

**Usage**:
```python
from grid.security.pii_redaction import redact_log_message

safe_message = redact_log_message(
    "User email: user@example.com",
    mask_mode=RedactionMode.FULL
)
# Result: "User email: ***"
```

**Logging Integration**:
```python
from grid.security.pii_redaction import setup_logging_with_redaction

setup_logging_with_redaction(mask_mode=RedactionMode.FULL)
```

## Layer 4: AI Safety (`application/mothership/security/ai_safety.py`)

**Purpose**: Secure handling of AI API keys and error messages.

### Features

1. **API Key Validation**
   - Format validation for providers (Gemini, OpenAI, Anthropic)
   - Length requirements (minimum 32 characters)
   - Prefix validation (provider-specific)

2. **Error Sanitization**
   - Removes API keys from error messages
   - Prevents credential exposure in logs
   - Provider-aware sanitization

3. **Secret Masking**
   - Masks secrets in logs (e.g., `sk-***1234`)
   - Configurable mask length
   - Safe for logging and error reporting

### Usage

```python
from application.mothership.security.ai_safety import AISafetyConfig

safety = AISafetyConfig(environment="production")
api_key = safety.get_gemini_api_key(required=True)
is_valid = safety.validate_api_key_format(api_key, "gemini")

# Error sanitization
safe_error = safety.sanitize_error_message(error, api_provider="openai")
```

## Layer 5: Threat Detection (`grid/security/threat_detector.py`)

**Purpose**: Real-time threat detection and analysis.

### Features

1. **Threat Categories**
   - `SQL_INJECTION`: SQL injection attacks
   - `XSS`: Cross-site scripting
   - `PATH_TRAVERSAL`: Directory traversal
   - `COMMAND_INJECTION`: Command injection
   - `RATE_LIMIT_EXCEEDED`: Rate limit violations
   - `SUSPICIOUS_PATTERN`: Suspicious behavior patterns

2. **Risk Levels**
   - `LOW`: Low-risk threats
   - `MEDIUM`: Medium-risk threats
   - `HIGH`: High-risk threats
   - `CRITICAL`: Critical threats

3. **Threat Actions**
   - `LOG`: Log threat
   - `ALERT`: Alert security team
   - `BLOCK`: Block request
   - `RATE_LIMIT`: Rate limit request
   - `CHALLENGE`: Challenge user (CAPTCHA)

### Usage

```python
from grid.security.threat_detector import ThreatDetector

detector = ThreatDetector()
result = detector.analyze_request(request_data)

if result.risk_level == RiskLevel.HIGH:
    # Take action
    pass
```

## Layer 6: Input Sanitization (`grid/security/input_sanitizer.py`)

**Purpose**: Input validation and sanitization.

### Features

1. **Threat Types**
   - `SQL_INJECTION`
   - `XSS`
   - `PATH_TRAVERSAL`
   - `COMMAND_INJECTION`

2. **Threat Severity**
   - `LOW`: Low severity
   - `MEDIUM`: Medium severity
   - `HIGH`: High severity
   - `CRITICAL`: Critical severity

3. **Sanitization Actions**
   - `REJECT`: Reject input
   - `SANITIZE`: Sanitize and continue
   - `LOG_ONLY`: Log but allow
   - `ALERT`: Alert security team

### Usage

```python
from grid.security.input_sanitizer import InputSanitizer

sanitizer = InputSanitizer()
safe_input = sanitizer.sanitize(user_input)
```

## Layer 7: Audit Logging (`grid/security/audit_logger.py`)

**Purpose**: Security audit trail for compliance.

### Event Types

- `AUTHENTICATION`: Authentication events
- `AUTHORIZATION`: Authorization events
- `DATA_ACCESS`: Data access events
- `DATA_MODIFICATION`: Data modification events
- `SECURITY_EVENT`: Security-related events
- `SYSTEM_EVENT`: System events

### Features

- Structured logging (JSON)
- Event correlation (request_id)
- User tracking (actor_user_id)
- Resource tracking (resource_type, resource_id)
- IP address and user agent logging

### Usage

```python
from grid.security.audit_logger import AuditLogger, AuditEventType

logger = AuditLogger()
logger.log_event(
    event_type=AuditEventType.DATA_ACCESS,
    user_id="user_123",
    resource_type="case",
    resource_id="case_456",
    action="read",
    success=True
)
```

**Storage**: `mothership_audit_log` table

## Layer 8: Security Headers (`application/mothership/middleware/security_headers.py`)

**Purpose**: HTTP security headers enforcement.

### Headers

- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `X-XSS-Protection: 1; mode=block`
- `Strict-Transport-Security: max-age=31536000; includeSubDomains`
- `Content-Security-Policy: default-src 'self'`
- `Referrer-Policy: strict-origin-when-cross-origin`

### Usage

Applied automatically via FastAPI middleware.

## Configuration

### Environment Variables

**Authentication**:
- `MOTHERSHIP_SECRET_KEY`: JWT secret key (required in production)
- `JWT_ACCESS_TOKEN_EXPIRE_MINUTES`: Access token lifetime (default: 30)
- `JWT_REFRESH_TOKEN_EXPIRE_DAYS`: Refresh token lifetime (default: 7)

**Encryption**:
- `GRID_ENCRYPTION_KEY`: Encryption key (base64 encoded)

**API Keys**:
- `GEMINI_API_KEY`: Gemini API key
- `OPENAI_API_KEY`: OpenAI API key
- `ANTHROPIC_API_KEY`: Anthropic API key
- `MISTRAL_API_KEY`: Mistral API key

**Security**:
- `GRID_SECURITY_ENABLED`: Enable security features (default: true)
- `GRID_AUDIT_LOG_ENABLED`: Enable audit logging (default: true)
- `GRID_PII_REDACTION_MODE`: PII redaction mode (none, partial, full)

## Security Best Practices

1. **Production Deployment**:
   - Always set `MOTHERSHIP_SECRET_KEY` in production
   - Use strong encryption keys (64+ characters)
   - Enable audit logging
   - Use PII redaction (FULL mode)

2. **API Key Management**:
   - Never commit API keys to version control
   - Use secrets manager for storage
   - Rotate keys regularly
   - Monitor key usage

3. **Error Handling**:
   - Always sanitize error messages
   - Never expose secrets in logs
   - Use structured logging
   - Implement proper exception handling

4. **Input Validation**:
   - Validate all inputs
   - Sanitize user input
   - Use parameterized queries
   - Implement rate limiting

5. **Access Control**:
   - Use RBAC for authorization
   - Implement least privilege
   - Regular access reviews
   - Monitor access patterns

## Future Extensions

1. **Multi-Factor Authentication**: MFA support for elevated operations
2. **Certificate Pinning**: SSL/TLS certificate pinning
3. **Web Application Firewall**: WAF integration
4. **Intrusion Detection**: IDS/IPS integration
5. **Security Information and Event Management**: SIEM integration
