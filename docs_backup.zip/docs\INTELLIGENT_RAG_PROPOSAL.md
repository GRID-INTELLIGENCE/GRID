# Intelligent RAG Architecture Proposal

> **Status**: Draft Proposal  
> **Author**: GRID Engineering  
> **Target**: Q2 2026 Implementation  
> **Scope**: Upgrade RAG from retrieval+template to context-aware NLP

---

## Executive Summary

The current RAG implementation is fundamentally **retrieval + prompt stuffing** — it finds similar chunks via cosine distance and concatenates them into a prompt template. This produces generic, keyword-matched responses rather than intelligent, context-aware answers.

This proposal outlines a targeted upgrade path to build **actual intelligence** into the RAG system using:
- Query understanding and intent classification
- Multi-stage retrieval with semantic reranking
- Reasoning chains with evidence synthesis
- Contextual memory and conversation state
- Low-level transformer programming with HuggingFace

---

## Current Architecture Analysis

### What We Have

```
Query → Embed(nomic) → Vector Search(chromadb) → Top-K → Template → Ollama → Response
```

### What's Wrong

| Component | Problem | Impact |
|-----------|---------|--------|
| Query Processing | No understanding — "What is GRID?" == "How does GRID handle errors?" | Wrong retrieval intent |
| Retrieval | Pure cosine similarity, no semantic relevance to query *intent* | Irrelevant chunks |
| Ranking | Distance-based only, no cross-encoder reranking | Low precision |
| Context Assembly | Dumb concatenation of chunks | No coherence |
| Generation | Template-stuffed prompt, LLM just summarizes | No reasoning |
| Memory | Stateless — each query independent | No conversation flow |
| Fallback | Generic template when retrieval fails | Embarrassing responses |

### Evidence

```python
# Current: When retrieval returns nothing, we get this:
"""
Hello! I'm here to assist you with the **GRID** project codebase.
If you have questions about:
- **Architecture** (e.g., design patterns, system flow)
...
"""
# This is a hardcoded template, not intelligence.
```

---

## Proposed Architecture

### High-Level Design

```
                    ┌─────────────────────────────────────────────────────────────┐
                    │                    INTELLIGENT RAG                          │
                    └─────────────────────────────────────────────────────────────┘
                                              │
        ┌─────────────────────────────────────┼─────────────────────────────────────┐
        │                                     │                                     │
        ▼                                     ▼                                     ▼
┌───────────────┐                   ┌───────────────┐                     ┌───────────────┐
│ QUERY LAYER   │                   │ RETRIEVAL     │                     │ REASONING     │
│               │                   │ LAYER         │                     │ LAYER         │
│ • Intent      │                   │ • Hybrid      │                     │ • Evidence    │
│ • Entity NER  │──────────────────▶│ • Multi-hop   │────────────────────▶│ • Chain-of-   │
│ • Expansion   │                   │ • Rerank      │                     │   Thought     │
│ • Routing     │                   │ • Filter      │                     │ • Synthesis   │
└───────────────┘                   └───────────────┘                     └───────────────┘
        │                                     │                                     │
        └─────────────────────────────────────┼─────────────────────────────────────┘
                                              │
                                              ▼
                                    ┌───────────────┐
                                    │ MEMORY LAYER  │
                                    │               │
                                    │ • Conversation│
                                    │ • User Model  │
                                    │ • Fact Store  │
                                    └───────────────┘
```

---

## Component Specifications

### 1. Query Understanding Layer

**Purpose**: Transform raw queries into structured intents with entities and context.

#### 1.1 Intent Classification

```python
# Using a fine-tuned classifier on codebase query patterns
from transformers import AutoModelForSequenceClassification, AutoTokenizer

class QueryIntentClassifier:
    """Classify query intent for routing and retrieval strategy."""
    
    INTENTS = [
        "definition",      # "What is X?"
        "implementation",  # "How does X work?"
        "usage",           # "How do I use X?"
        "debugging",       # "Why is X failing?"
        "comparison",      # "Difference between X and Y?"
        "architecture",    # "How is X structured?"
        "location",        # "Where is X defined?"
        "relationship",    # "How does X relate to Y?"
    ]
    
    def __init__(self, model_name: str = "microsoft/deberta-v3-small"):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(
            model_name,
            num_labels=len(self.INTENTS),
            problem_type="single_label_classification"
        )
    
    def classify(self, query: str) -> dict:
        """Return intent with confidence scores."""
        inputs = self.tokenizer(query, return_tensors="pt", truncation=True)
        outputs = self.model(**inputs)
        probs = torch.softmax(outputs.logits, dim=-1)
        
        top_intent_idx = probs.argmax().item()
        return {
            "intent": self.INTENTS[top_intent_idx],
            "confidence": probs[0][top_intent_idx].item(),
            "all_scores": dict(zip(self.INTENTS, probs[0].tolist()))
        }
```

#### 1.2 Entity Extraction (Code-Aware NER)

```python
from transformers import AutoModelForTokenClassification, pipeline

class CodeEntityExtractor:
    """Extract code entities: functions, classes, files, modules."""
    
    ENTITY_TYPES = [
        "FUNCTION",   # function/method names
        "CLASS",      # class names
        "MODULE",     # module/package names
        "FILE",       # file paths
        "VARIABLE",   # variable names
        "CONFIG",     # configuration keys
    ]
    
    def __init__(self):
        # Use a code-trained NER model or fine-tune one
        self.ner = pipeline(
            "ner",
            model="microsoft/codebert-base",
            aggregation_strategy="simple"
        )
    
    def extract(self, query: str) -> list[dict]:
        """Extract entities with types and spans."""
        # Custom rules for code patterns
        entities = []
        
        # Regex patterns for common code references
        patterns = [
            (r'`([^`]+)`', "CODE_REF"),           # backtick references
            (r'(\w+\.py)', "FILE"),                # Python files
            (r'(\w+)\(\)', "FUNCTION"),            # function calls
            (r'class\s+(\w+)', "CLASS"),           # class definitions
            (r'@(\w+)', "DECORATOR"),              # decorators
        ]
        
        for pattern, entity_type in patterns:
            for match in re.finditer(pattern, query):
                entities.append({
                    "text": match.group(1),
                    "type": entity_type,
                    "start": match.start(),
                    "end": match.end()
                })
        
        return entities
```

#### 1.3 Query Expansion

```python
class QueryExpander:
    """Expand queries with synonyms, related terms, and code patterns."""
    
    def __init__(self, embedding_model):
        self.embedder = embedding_model
        self.code_synonyms = {
            "function": ["method", "def", "callable", "routine"],
            "class": ["type", "object", "model", "entity"],
            "error": ["exception", "failure", "bug", "issue"],
            "config": ["configuration", "settings", "options", "parameters"],
        }
    
    def expand(self, query: str, intent: str, entities: list) -> list[str]:
        """Generate expanded queries for better recall."""
        expansions = [query]  # Original always included
        
        # Intent-based expansion
        if intent == "implementation":
            expansions.append(f"how {query} is implemented")
            expansions.append(f"source code for {query}")
        elif intent == "usage":
            expansions.append(f"example of {query}")
            expansions.append(f"how to use {query}")
        
        # Entity-based expansion
        for entity in entities:
            if entity["type"] == "FUNCTION":
                expansions.append(f"def {entity['text']}")
            elif entity["type"] == "CLASS":
                expansions.append(f"class {entity['text']}")
        
        return list(set(expansions))
```

---

### 2. Intelligent Retrieval Layer

#### 2.1 Hybrid Search (Dense + Sparse)

```python
from rank_bm25 import BM25Okapi
import numpy as np

class HybridRetriever:
    """Combine dense vector search with sparse BM25 for better recall."""
    
    def __init__(self, dense_store, documents: list[str], alpha: float = 0.7):
        self.dense_store = dense_store
        self.alpha = alpha  # Weight for dense vs sparse
        
        # Build BM25 index
        tokenized = [doc.lower().split() for doc in documents]
        self.bm25 = BM25Okapi(tokenized)
        self.documents = documents
    
    def search(self, query: str, query_embedding: list[float], k: int = 20) -> list[dict]:
        """Hybrid search combining dense and sparse scores."""
        # Dense search
        dense_results = self.dense_store.query(query_embedding, n_results=k * 2)
        
        # Sparse search
        tokenized_query = query.lower().split()
        bm25_scores = self.bm25.get_scores(tokenized_query)
        sparse_top_k = np.argsort(bm25_scores)[-k * 2:][::-1]
        
        # Combine with reciprocal rank fusion
        combined_scores = {}
        
        for rank, doc_id in enumerate(dense_results["ids"]):
            combined_scores[doc_id] = combined_scores.get(doc_id, 0) + self.alpha / (rank + 1)
        
        for rank, idx in enumerate(sparse_top_k):
            doc_id = f"doc_{idx}"  # Map to document ID
            combined_scores[doc_id] = combined_scores.get(doc_id, 0) + (1 - self.alpha) / (rank + 1)
        
        # Sort by combined score
        sorted_docs = sorted(combined_scores.items(), key=lambda x: x[1], reverse=True)
        return sorted_docs[:k]
```

#### 2.2 Cross-Encoder Reranking

```python
from sentence_transformers import CrossEncoder

class SemanticReranker:
    """Rerank candidates using cross-encoder for precise relevance."""
    
    def __init__(self, model_name: str = "cross-encoder/ms-marco-MiniLM-L-6-v2"):
        self.model = CrossEncoder(model_name)
    
    def rerank(self, query: str, documents: list[str], top_k: int = 10) -> list[tuple[int, float]]:
        """Rerank documents by semantic relevance to query."""
        if not documents:
            return []
        
        # Create query-document pairs
        pairs = [[query, doc] for doc in documents]
        
        # Score all pairs
        scores = self.model.predict(pairs)
        
        # Sort by score
        ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)
        return ranked[:top_k]
```

#### 2.3 Multi-Hop Retrieval

```python
class MultiHopRetriever:
    """Follow references across documents for complex queries."""
    
    def __init__(self, base_retriever, max_hops: int = 2):
        self.retriever = base_retriever
        self.max_hops = max_hops
    
    def retrieve(self, query: str, initial_docs: list[dict]) -> list[dict]:
        """Expand retrieval by following cross-references."""
        all_docs = list(initial_docs)
        seen_ids = {doc["id"] for doc in initial_docs}
        
        for hop in range(self.max_hops):
            # Extract references from current docs
            references = self._extract_references(all_docs)
            
            if not references:
                break
            
            # Retrieve referenced documents
            for ref in references:
                if ref not in seen_ids:
                    ref_docs = self.retriever.search(ref, k=3)
                    for doc in ref_docs:
                        if doc["id"] not in seen_ids:
                            doc["hop"] = hop + 1
                            all_docs.append(doc)
                            seen_ids.add(doc["id"])
        
        return all_docs
    
    def _extract_references(self, docs: list[dict]) -> list[str]:
        """Extract file/function references from documents."""
        references = []
        patterns = [
            r'from\s+([\w.]+)\s+import',  # Python imports
            r'see\s+`([^`]+)`',            # Documentation references
            r'defined in\s+(\S+\.py)',     # File references
        ]
        
        for doc in docs:
            for pattern in patterns:
                matches = re.findall(pattern, doc.get("content", ""))
                references.extend(matches)
        
        return list(set(references))
```

---

### 3. Reasoning Layer

#### 3.1 Evidence Synthesis

```python
class EvidenceSynthesizer:
    """Synthesize coherent context from retrieved chunks."""
    
    def __init__(self, embedder):
        self.embedder = embedder
    
    def synthesize(self, query: str, chunks: list[dict], max_tokens: int = 4000) -> str:
        """Create coherent context from chunks with deduplication and ordering."""
        # Deduplicate similar chunks
        unique_chunks = self._deduplicate(chunks)
        
        # Order by relevance and logical flow
        ordered_chunks = self._order_chunks(query, unique_chunks)
        
        # Build context with section headers
        context_parts = []
        current_file = None
        
        for chunk in ordered_chunks:
            file_path = chunk.get("metadata", {}).get("path", "unknown")
            
            if file_path != current_file:
                context_parts.append(f"\n### From `{file_path}`:\n")
                current_file = file_path
            
            context_parts.append(chunk["content"])
        
        # Truncate to max tokens
        full_context = "\n".join(context_parts)
        return self._truncate_to_tokens(full_context, max_tokens)
    
    def _deduplicate(self, chunks: list[dict], threshold: float = 0.9) -> list[dict]:
        """Remove near-duplicate chunks."""
        unique = []
        seen_embeddings = []
        
        for chunk in chunks:
            emb = self.embedder.embed(chunk["content"])
            
            is_duplicate = False
            for seen_emb in seen_embeddings:
                similarity = np.dot(emb, seen_emb) / (np.linalg.norm(emb) * np.linalg.norm(seen_emb))
                if similarity > threshold:
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                unique.append(chunk)
                seen_embeddings.append(emb)
        
        return unique
    
    def _order_chunks(self, query: str, chunks: list[dict]) -> list[dict]:
        """Order chunks for logical flow."""
        # Group by file
        by_file = {}
        for chunk in chunks:
            path = chunk.get("metadata", {}).get("path", "unknown")
            by_file.setdefault(path, []).append(chunk)
        
        # Sort within each file by chunk_index
        for path in by_file:
            by_file[path].sort(key=lambda c: c.get("metadata", {}).get("chunk_index", 0))
        
        # Flatten in relevance order
        ordered = []
        for path, file_chunks in sorted(by_file.items()):
            ordered.extend(file_chunks)
        
        return ordered
```

#### 3.2 Chain-of-Thought Prompting

```python
class ReasoningEngine:
    """Generate answers with explicit reasoning chains."""
    
    REASONING_TEMPLATE = """You are an expert code analyst. Answer the question using ONLY the provided context.

## Context:
{context}

## Question:
{question}

## Instructions:
Think step by step:
1. First, identify which parts of the context are relevant to the question.
2. Extract the key facts from those relevant parts.
3. Reason about how those facts answer the question.
4. Provide a clear, specific answer with file references.

## Your Analysis:

### Step 1: Relevant Context
[Identify which files/sections are relevant]

### Step 2: Key Facts
[List the specific facts from the context]

### Step 3: Reasoning
[Explain how the facts answer the question]

### Step 4: Answer
[Provide the final answer with citations]
"""

    def __init__(self, llm):
        self.llm = llm
    
    def reason(self, query: str, context: str) -> dict:
        """Generate reasoned answer with chain-of-thought."""
        prompt = self.REASONING_TEMPLATE.format(
            context=context,
            question=query
        )
        
        response = self.llm.generate(prompt, temperature=0.3)
        
        # Parse structured response
        return self._parse_reasoning(response)
    
    def _parse_reasoning(self, response: str) -> dict:
        """Extract structured reasoning from response."""
        sections = {
            "relevant_context": "",
            "key_facts": "",
            "reasoning": "",
            "answer": ""
        }
        
        current_section = None
        lines = response.split("\n")
        
        for line in lines:
            if "Step 1" in line or "Relevant Context" in line:
                current_section = "relevant_context"
            elif "Step 2" in line or "Key Facts" in line:
                current_section = "key_facts"
            elif "Step 3" in line or "Reasoning" in line:
                current_section = "reasoning"
            elif "Step 4" in line or "Answer" in line:
                current_section = "answer"
            elif current_section:
                sections[current_section] += line + "\n"
        
        return sections
```

---

### 4. Memory Layer

#### 4.1 Conversation Memory

```python
from dataclasses import dataclass, field
from collections import deque

@dataclass
class ConversationTurn:
    """Single turn in conversation."""
    query: str
    intent: str
    entities: list[dict]
    retrieved_docs: list[str]
    answer: str
    timestamp: float = field(default_factory=time.time)

class ConversationMemory:
    """Maintain conversation state for contextual follow-ups."""
    
    def __init__(self, max_turns: int = 10):
        self.turns: deque[ConversationTurn] = deque(maxlen=max_turns)
        self.entity_mentions: dict[str, list[int]] = {}  # entity -> turn indices
        self.topic_stack: list[str] = []
    
    def add_turn(self, turn: ConversationTurn) -> None:
        """Add a conversation turn and update state."""
        turn_idx = len(self.turns)
        self.turns.append(turn)
        
        # Track entity mentions
        for entity in turn.entities:
            entity_key = entity["text"].lower()
            self.entity_mentions.setdefault(entity_key, []).append(turn_idx)
        
        # Update topic stack
        if turn.intent in ["definition", "architecture"]:
            self.topic_stack.append(turn.entities[0]["text"] if turn.entities else turn.query)
    
    def resolve_references(self, query: str) -> str:
        """Resolve pronouns and references using conversation history."""
        # Handle "it", "this", "that" references
        pronouns = ["it", "this", "that", "they", "these"]
        
        resolved = query
        for pronoun in pronouns:
            if pronoun in query.lower():
                # Find most recent relevant entity
                if self.topic_stack:
                    recent_topic = self.topic_stack[-1]
                    resolved = re.sub(
                        rf'\b{pronoun}\b',
                        recent_topic,
                        resolved,
                        flags=re.IGNORECASE
                    )
        
        return resolved
    
    def get_context_window(self, n_turns: int = 3) -> str:
        """Get recent conversation context for the LLM."""
        recent = list(self.turns)[-n_turns:]
        
        context_parts = []
        for turn in recent:
            context_parts.append(f"User: {turn.query}")
            context_parts.append(f"Assistant: {turn.answer[:500]}...")
        
        return "\n".join(context_parts)
```

#### 4.2 Fact Store (Extracted Knowledge)

```python
class FactStore:
    """Store extracted facts for quick retrieval without re-querying."""
    
    def __init__(self):
        self.facts: dict[str, list[dict]] = {}  # entity -> facts
        self.definitions: dict[str, str] = {}   # term -> definition
    
    def extract_facts(self, query: str, answer: str, entities: list[dict]) -> None:
        """Extract and store facts from Q&A pair."""
        # Simple fact extraction patterns
        fact_patterns = [
            r'(\w+)\s+is\s+(?:a|an|the)\s+(.+?)(?:\.|,|$)',
            r'(\w+)\s+(?:handles|processes|manages)\s+(.+?)(?:\.|,|$)',
            r'(\w+)\s+(?:contains|includes|has)\s+(.+?)(?:\.|,|$)',
        ]
        
        for pattern in fact_patterns:
            matches = re.findall(pattern, answer, re.IGNORECASE)
            for subject, predicate in matches:
                subject_lower = subject.lower()
                self.facts.setdefault(subject_lower, []).append({
                    "predicate": predicate,
                    "source_query": query,
                    "timestamp": time.time()
                })
        
        # Extract definitions for "What is X?" queries
        if "what is" in query.lower():
            for entity in entities:
                self.definitions[entity["text"].lower()] = answer[:500]
    
    def get_facts(self, entity: str) -> list[dict]:
        """Retrieve facts about an entity."""
        return self.facts.get(entity.lower(), [])
    
    def has_definition(self, term: str) -> bool:
        """Check if we have a cached definition."""
        return term.lower() in self.definitions
```

---

## Implementation Phases

### Phase 1: Foundation (2 weeks)
**Goal**: Replace dumb retrieval with intelligent query understanding.

- [ ] Implement `QueryIntentClassifier` with fine-tuned DeBERTa
- [ ] Implement `CodeEntityExtractor` with regex + CodeBERT
- [ ] Add query expansion based on intent
- [ ] Integrate into existing `chat.py`

**Success Metric**: Intent classification accuracy > 85% on test set.

### Phase 2: Retrieval Upgrade (2 weeks)
**Goal**: Improve retrieval precision with hybrid search and reranking.

- [ ] Implement `HybridRetriever` (dense + BM25)
- [ ] Add `SemanticReranker` with cross-encoder
- [ ] Implement `MultiHopRetriever` for complex queries
- [ ] Tune alpha weights on held-out queries

**Success Metric**: MRR@10 improvement > 20% over baseline.

### Phase 3: Reasoning (2 weeks)
**Goal**: Generate coherent, reasoned answers instead of summaries.

- [ ] Implement `EvidenceSynthesizer` for context assembly
- [ ] Add `ReasoningEngine` with chain-of-thought prompting
- [ ] Create answer templates per intent type
- [ ] Add citation extraction and verification

**Success Metric**: Human preference > 70% vs baseline on blind eval.

### Phase 4: Memory & Polish (2 weeks)
**Goal**: Enable contextual conversations and iterative refinement.

- [ ] Implement `ConversationMemory` with reference resolution
- [ ] Add `FactStore` for caching extracted knowledge
- [ ] Build user feedback loop for answer quality
- [ ] Performance optimization (caching, batching)

**Success Metric**: Multi-turn conversation coherence > 80%.

---

## Dependencies

### Required Models (Local)

| Model | Purpose | Size | Source |
|-------|---------|------|--------|
| `microsoft/deberta-v3-small` | Intent classification | 140MB | HuggingFace |
| `microsoft/codebert-base` | Code entity extraction | 500MB | HuggingFace |
| `cross-encoder/ms-marco-MiniLM-L-6-v2` | Reranking | 90MB | HuggingFace |
| `nomic-embed-text:latest` | Embeddings (existing) | 274MB | Ollama |
| `ministral-3:3b` | Generation (existing) | 2GB | Ollama |

### Python Packages

```toml
[project.optional-dependencies]
intelligent-rag = [
    "transformers>=4.36.0",
    "sentence-transformers>=2.2.0",
    "rank-bm25>=0.2.2",
    "torch>=2.0.0",
]
```

---

## Evaluation Framework

### Metrics

1. **Retrieval Quality**
   - MRR@10 (Mean Reciprocal Rank)
   - Recall@K
   - Precision@K

2. **Answer Quality**
   - Factual accuracy (manual annotation)
   - Citation correctness
   - Completeness

3. **User Experience**
   - Response latency (p50, p95)
   - Conversation coherence
   - User satisfaction (thumbs up/down)

### Test Set

Create a held-out evaluation set of 100 queries across all intent types:
- 20 definition queries ("What is X?")
- 20 implementation queries ("How does X work?")
- 20 usage queries ("How do I use X?")
- 20 debugging queries ("Why is X failing?")
- 20 complex/multi-hop queries

---

## Risks & Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Model loading latency | Slow startup | Lazy loading, model caching |
| Memory usage | OOM on small machines | Quantized models, offloading |
| Hallucination | Incorrect answers | Strict context grounding, citation verification |
| Complexity | Harder to maintain | Modular design, comprehensive tests |

---

## Decision Checkpoints

- [ ] **Week 2**: Intent classifier accuracy meets threshold → proceed to Phase 2
- [ ] **Week 4**: Retrieval MRR meets threshold → proceed to Phase 3
- [ ] **Week 6**: Human eval preference meets threshold → proceed to Phase 4
- [ ] **Week 8**: Full system latency < 5s p95 → production ready

---

## References

1. [RAG Survey: Retrieval-Augmented Generation for NLP](https://arxiv.org/abs/2312.10997)
2. [Self-RAG: Learning to Retrieve, Generate, and Critique](https://arxiv.org/abs/2310.11511)
3. [Chain-of-Thought Prompting Elicits Reasoning](https://arxiv.org/abs/2201.11903)
4. [CodeBERT: A Pre-Trained Model for Programming and Natural Languages](https://arxiv.org/abs/2002.08155)
5. [Cross-Encoders for Semantic Search](https://www.sbert.net/examples/applications/cross-encoder/README.html)

---

## Summary

This proposal upgrades GRID's RAG from a naive retrieval+template system to an intelligent, context-aware NLP pipeline. The key innovations are:

1. **Query Understanding**: Intent classification + entity extraction
2. **Smart Retrieval**: Hybrid search + cross-encoder reranking + multi-hop
3. **Reasoning**: Chain-of-thought prompting with evidence synthesis
4. **Memory**: Conversation state + fact caching

Total timeline: **8 weeks** with clear go/no-go checkpoints at each phase.

The architecture is modular — each component can be enabled/disabled independently, allowing incremental rollout and A/B testing.