# GRID Usage Scenarios 2026-01-07

**Project Status**: Python 3.13.11 Verified | Dependencies Stabilized | Legacy Support Active

This document outlines the usage scenarios for the GRID codebase as of Jan 7, 2026. It serves as a guide for the next session's activities.

---

## 1. Environment Setup (Start Here)

Ensure your environment is synchronized with the latest updates (Python 3.13 + pinned dependencies).

```powershell
# 1. Update/Sync Environment
cd e:\grid
uv sync

# 2. Verify Python Version (Should be 3.13.11+)
python --version

# 3. Verify Dependencies (Ensure scikit-learn 1.8.0 is present)
uv run pip show scikit-learn
```

---

## 2. Core Scenarios

### Scenario A: General System Analysis
Use the `grid` CLI to perform standard text analysis. This validates the core Python environment.

```powershell
# Standard analysis
python -m grid analyze "The system is functioning within normal parameters."

# JSON output for pipelining
python -m grid analyze "Status report." --output json
```

### Scenario B: RAG System Operations
The RAG system has been enhanced with quality gates and advanced search features.

**1. Indexing (with Quality Gate)**
Only index files that meet the quality threshold (simulated):
```powershell
# Rebuild index, filtering for quality > 0.5
python -m tools.rag.cli index --rebuild --quality-threshold 0.5
```

**2. Querying (Advanced)**
Use Hybrid Search (BM25 + Vector) and Re-ranking for best results:
```powershell
# Hybrid search + Cross-encoder reranking
python -m tools.rag.cli query "What is the cognitive architecture?" --hybrid --rerank
```

### Scenario C: Legacy Module Validation (Clustering)
Legacy code (`legacy_src`) is now active and monitored. Use this to verify the `scikit-learn` integration.

**1. Run the Regression Test**
This confirms `DBSCAN` is working and producing the expected structure (`clusters`, `noise`).
```powershell
# Run the specific legacy unit test
uv run pytest tests/unit/test_pattern_engine_dbscan.py
```

---

## 3. Development Workflows

### Testing
We now support native async tests in pytest.

```powershell
# Run everything (Unit + Integration)
uv run pytest tests/

# Run fast (skip RAG/Integration if configured)
uv run pytest tests/unit
```

### Code Quality (Linting)
The `legacy_src` directory is no longer excluded from linting.

```powershell
# Check entire repo (including legacy_src)
uv run ruff check .

# Fix auto-fixable issues
uv run ruff check . --fix
```

---

## 5. New Capabilities (2026-01-07 Updates)

### Seed Data Validation
Ensure the core research topics in `seed/topics_seed.json` are valid and reflected in documentation.

```powershell
# Validate seed structure
uv run python scripts/validate_seed.py

# Run gap analysis
uv run python scripts/gap_analysis.py
```

### Live CI Monitoring
Monitor GitHub Actions workflows directly from the terminal.

```powershell

# Watch GRID CI
make watch-ci
```

---

## 6. Troubleshooting
- **`ModuleNotFoundError: No module named 'sklearn'`**: Run `uv sync` to install the pinned version.
- **Ruff errors in `legacy_src`**: These are real now. Fix them or add specific `# noqa` suppressions if the legacy code cannot be changed.
