# Frontend Architecture Documentation

**Last Updated**: 2026-01-10  
**Status**: Current State Documentation

## Overview

The GRID project contains frontend-related code in two distinct locations:

1. **`web-client/`** - Service layer and reusable components
2. **`research/experiments/hogwarts-visualizer/`** - Experimental React visualization application

## Architecture Components

### 1. Web Client Service Layer (`web-client/`)

**Purpose**: Service layer providing reusable frontend infrastructure

**Location**: `web-client/`

**Key Files**:
- `src/services/navigationService.ts` - Navigation streaming service with fetch-based SSE client
- `src/components/streaming/StreamingComponents.tsx` - React components for streaming UI

#### Navigation Service (`navigationService.ts`)

**Implementation**: Uses `fetch` + `ReadableStream` for Server-Sent Events (SSE)

**Features**:
- POST request support (unlike native EventSource which is GET-only)
- Automatic reconnection with exponential backoff
- Event parsing for `progress`, `result`, `status`, and `error` events
- Comprehensive error handling and logging

**Endpoint**: `/api/v1/navigation/plan-stream` (matches backend router)

**Usage Example**:
```typescript
import { streamNavigationPlan } from './navigationService';

streamNavigationPlan({
    goal: "Analyze codebase structure",
    context: { depth: "deep" }
}, {
    onProgress: (data) => updateProgressBar(data.progress),
    onResult: (data) => commitNavigationResult(data),
    onStatus: (data) => handleStatusUpdate(data),
    onError: (error) => handleStreamingError(error)
});
```

#### Streaming Components (`StreamingComponents.tsx`)

**Components**:
- `TransparencyContainer` - Visual feedback with opacity and blur effects
- `AutoscrollContainer` - Automatic scrolling behavior for streaming content
- `StreamingProgress` - Progress bar component
- `StreamResultDisplay` - Display component for navigation results

**Status**: Components are defined but integration location is unclear. These components are available for use by any consuming React application.

### 2. Hogwarts Visualizer (`research/experiments/hogwarts-visualizer/`)

**Purpose**: Experimental React + TypeScript visualization application

**Location**: `research/experiments/hogwarts-visualizer/`

**Tech Stack**:
- React + TypeScript
- Vite (build tool)
- Tailwind CSS
- Recharts (data visualization)

**Features**:
- House-themed UI (Gryffindor, Slytherin, Hufflepuff, Ravenclaw)
- Navigation planning visualization
- Interactive charts (Bar charts, Radar charts)
- Mock/Real API toggle
- Responsive design

**Status**: **Experimental** - This is a research/experiment project, not the primary production UI.

**Development**:
```bash
cd research/experiments/hogwarts-visualizer
npm install
npm run dev  # Runs on http://localhost:3000
```

## Current State Analysis

### Service Layer (`web-client/`)

**Status**: ✅ Implemented

- Navigation service with proper SSE implementation (fetch-based, not EventSource)
- Streaming UI components available
- Service layer is production-ready

**Integration Status**: ⚠️ Components exist but no clear consuming application identified

### Visualization Application (`hogwarts-visualizer/`)

**Status**: 🔬 Experimental

- Fully functional React application
- Used for experimentation and visualization demos
- Not the primary production UI

### Primary Chat Client

**Status**: ❓ Unknown

The primary chat client UI that consumes `navigationService` and `StreamingComponents` has not been identified in the codebase. Potential scenarios:

1. **Separate Repository**: The main chat client may be in a separate repository not included in this codebase
2. **Future Work**: The service layer was built in anticipation of future UI development
3. **Different Location**: The UI may exist in an unindexed or excluded directory

## Integration Points

### Backend API Endpoints

The frontend services connect to the following backend endpoints:

- **Navigation Streaming**: `POST /api/v1/navigation/plan-stream`
  - Returns Server-Sent Events (SSE)
  - Events: `progress`, `result`, `status`, `error`
  - Backend router: `src/application/mothership/routers/navigation_simple.py`

### Service Layer API

The `web-client` service layer provides:

- `navigationService.stream()` - Stream navigation plans
- `StreamingComponents` - React components for streaming UI

## Recommendations

### Short Term

1. **Document Integration Location**: Identify or document where `StreamingComponents` are consumed
2. **Verify Endpoint Alignment**: Ensure frontend endpoint paths match backend routes (✅ Fixed: `/plan-stream` path corrected)

### Long Term

1. **Primary UI Application**: Identify or create the primary chat client UI
2. **Component Integration**: Integrate `StreamingComponents` into the primary UI application
3. **Service Layer Testing**: Add tests for navigation service integration

## File Reference

- Service Layer: `web-client/src/services/navigationService.ts`
- Streaming Components: `web-client/src/components/streaming/StreamingComponents.tsx`
- Experimental UI: `research/experiments/hogwarts-visualizer/`
- Backend Router: `src/application/mothership/routers/navigation_simple.py`

## Notes

- The SSE implementation uses `fetch` + `ReadableStream` (not `EventSource`) to support POST requests
- Backend supports both GET (with query param) and POST methods for streaming endpoint
- Streaming components are TypeScript React components with proper type definitions
- The experimental visualizer uses different API patterns and is not integrated with the service layer
