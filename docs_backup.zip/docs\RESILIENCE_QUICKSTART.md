# GRID Error Resilience: Quick Start (5 min)

## TL;DR

GRID now has production-grade error recovery with:
- 🔄 Automatic retry with exponential backoff
- 📊 Built-in metrics for observability
- ⚙️ Runtime policy tuning (no code changes)
- 🧪 Comprehensive integration tests

## Installation (Already Done!)

All components are already implemented:

```
✓ grid/resilience/metrics.py         - Metrics collection
✓ grid/resilience/observed_decorators.py - Metrics-aware decorators
✓ grid/resilience/policy_override.py - Runtime config
✓ grid/resilience/api.py            - FastAPI endpoints
✓ config/retry_policies.yaml         - Policy templates
✓ tests/integration/test_error_recovery.py - Integration tests
```

## 3-Step Integration

### 1️⃣ Add Decorator to Your Function

```python
from grid.resilience.observed_decorators import observed_retry

@observed_retry(
    "network.fetch_api",           # Unique operation name
    max_attempts=3,                 # Retry 3 times
    exceptions=(ConnectionError, TimeoutError)  # On these errors
)
def fetch_data(url: str) -> dict:
    return requests.get(url).json()

# Call normally - retry & metrics automatic!
data = fetch_data("https://api.example.com/data")
```

### 2️⃣ Register Metrics Endpoint (Optional but Recommended)

```python
# In your FastAPI app
from fastapi import FastAPI
from grid.resilience.api import create_metrics_router

app = FastAPI()
app.include_router(create_metrics_router())

# Now available: http://localhost:8000/metrics/retry
```

### 3️⃣ Tune Policies at Runtime (Optional)

```bash
# No code changes needed!
export GRID_POLICY_NETWORK_MAX_ATTEMPTS=5
export GRID_POLICY_NETWORK_TIMEOUT_SECONDS=180

# Restart app - new policy applied
```

## Monitor Operations

```bash
# Check overall health
curl http://localhost:8000/metrics/retry | jq .

# Example response:
# {
#   "aggregate_success_rate_pct": 94.2,
#   "aggregate_fallback_rate_pct": 2.1,
#   "total_operations_tracked": 12,
#   "operations": {
#     "network.fetch_api": {
#       "success_rate_pct": 93.33,
#       "total_attempts": 45,
#       "last_error": "ConnectionError: timeout"
#     }
#   }
# }
```

## Decorators Available

### Sync with Retry
```python
from grid.resilience.observed_decorators import observed_retry

@observed_retry("operation_name", max_attempts=3)
def sync_operation():
    pass
```

### Async with Retry
```python
from grid.resilience.observed_decorators import observed_async_retry

@observed_async_retry("operation_name", max_attempts=3)
async def async_operation():
    pass
```

### Sync with Fallback
```python
from grid.resilience.observed_decorators import observed_fallback

def fallback_result():
    return {"cached": True}

@observed_fallback("operation_name", fallback_func=fallback_result)
def operation_with_fallback():
    pass
```

### Async with Fallback
```python
from grid.resilience.observed_decorators import observed_async_fallback

async def fallback_result_async():
    return {"cached": True}

@observed_async_fallback("operation_name", 
                         fallback_func=fallback_result_async)
async def operation_with_fallback_async():
    pass
```

## Common Patterns

### Pattern 1: Retry Network Calls

```python
@observed_retry(
    "network.external_api",
    max_attempts=4,
    exceptions=(ConnectionError, TimeoutError)
)
async def call_external_api(endpoint: str) -> dict:
    async with aiohttp.ClientSession() as session:
        async with session.get(f"https://api.example.com{endpoint}") as resp:
            return await resp.json()
```

### Pattern 2: Retry with Fallback

```python
def get_cached_data():
    return {"data": [], "source": "cache"}

@observed_fallback(
    "api.search",
    fallback_func=get_cached_data,
    exceptions=(ConnectionError, TimeoutError)
)
def search(query: str):
    return requests.get(f"https://api.example.com/search?q={query}").json()
```

### Pattern 3: LLM with Aggressive Retry

```python
@observed_async_retry(
    "llm.inference",
    max_attempts=3,
    backoff_factor=2.0,
    exceptions=(TimeoutError,)
)
async def llm_complete(prompt: str) -> str:
    return await model.complete(prompt, timeout=30)
```

## Default Policies

Pre-built policies for common operation types:

| Type | Attempts | Timeout |
|------|----------|---------|
| `file_io` | 3 | 30s |
| `network` | 4 | 120s |
| `database` | 3 | 60s |
| `llm` | 3 | 180s |
| `rag` | 3 | 120s |

## Override Policies

### Via Config File (config/retry_policies.yaml)

```yaml
network:
  max_attempts: 5
  backoff_factor: 1.5
  timeout_seconds: 180
```

Load in code:
```python
from grid.resilience.policy_override import load_policy_overrides
load_policy_overrides("config/retry_policies.yaml")
```

### Via Environment Variables

```bash
export GRID_POLICY_NETWORK_MAX_ATTEMPTS=5
export GRID_POLICY_LLM_TIMEOUT_SECONDS=300
```

Apply in code:
```python
from grid.resilience.policy_override import apply_env_policy_overrides
apply_env_policy_overrides()
```

## Run Tests

```bash
# All tests including integration
make test

# Just error recovery tests
pytest tests/integration/test_error_recovery.py -v

# With coverage
pytest tests/integration/test_error_recovery.py --cov=grid.resilience
```

## Troubleshooting

❌ **Metrics not recorded**
→ Use `observed_retry` not `retry`

❌ **Policies not changing**
→ Call `load_policy_overrides()` or `apply_env_policy_overrides()` early

❌ **No /metrics endpoint**
→ Register metrics router with app

## Next Steps

1. ✅ Identify critical operations (network, I/O, LLM)
2. ✅ Apply `@observed_*` decorators
3. ✅ Register metrics endpoint
4. ✅ Monitor via dashboard
5. ✅ Tune policies as needed

## Full Documentation

See [RESILIENCE_IMPLEMENTATION_GUIDE.md](RESILIENCE_IMPLEMENTATION_GUIDE.md) for comprehensive reference.

---

**Status**: ✅ Production Ready  
**Last Updated**: January 25, 2026
