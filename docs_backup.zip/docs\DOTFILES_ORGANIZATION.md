# Dotfiles Organization Strategy

**Date**: 2026-01-XX
**Purpose**: Document the organization of dotfiles and ignore files for clean workspace navigation

## Philosophy

**Goal**: Start each work session with only **navigational and frequently used fundamentals** visible, while everything else is **properly organized and stored by relevance**.

## Strategy

### Hybrid Approach
- **Essential files stay at root** (required by tools)
- **Organized copies stored in `config/dotfiles/`** (for reference)
- **Environment files organized in `config/env/`** (by environment type)
- **Documentation explains location and purpose** (for clarity)

## File Organization

### At Root (Required by Tools)
These files **MUST** remain at root because tools require them there:

| File | Tool | Purpose | Frequency |
|------|------|---------|-----------|
| `.gitignore` | Git | Version control exclusions | Daily |
| `.cursorignore` | Cursor | IDE context exclusions | Daily |
| `.agentignore` | Agent tools | AI agent exclusions | Periodic |
| `.cursorrules` | Cursor | IDE behavior rules | Daily |
| `.env` | Runtime | Active environment config | Daily |
| `.env.example` | Template | Environment template | Periodic |

### In `config/dotfiles/` (Organized Reference)
Organized copies stored for **easy reference**, **version control**, and **documentation**:

All dotfiles and ignore files are copied here for:
- ✅ Easy browsing and comparison
- ✅ Version control history
- ✅ Documentation and understanding
- ✅ Maintenance and updates

**Files Stored:**
- `.agentignore` - Agent exclusions
- `.cascadeignore` - Cascade exclusions
- `.cursorignore` - Cursor exclusions
- `.cursorrules` - Cursor rules
- `.editorconfig` - Editor configuration
- `.gitignore` - Git exclusions
- `.mypy.ini` - Type checking config
- `.pre-commit-config.yaml` - Pre-commit hooks
- `.python-version` - Python version

### In `config/env/` (Environment-Specific)
Environment files organized by **environment type**:

- `.env.development` - Development environment
- `.env.staging` - Staging environment
- `.env.production` - Production environment
- `.env.venv` - Virtual environment configuration

**Note**: `.env` and `.env.example` remain at root for convenience and visibility.

## Structure

```
grid/
├── .gitignore              # ⚠️ Required at root by Git
├── .cursorignore           # ⚠️ Required at root by Cursor
├── .agentignore            # ⚠️ Required at root by Agent tools
├── .cursorrules            # ⚠️ Required at root by Cursor
├── .env                    # ⚠️ Convenience (local development)
├── .env.example            # ⚠️ Template (visible for reference)
│
└── config/
    ├── dotfiles/           # 📁 Organized copies (reference)
    │   ├── .agentignore
    │   ├── .cascadeignore
    │   ├── .cursorignore
    │   ├── .cursorrules
    │   ├── .editorconfig
    │   ├── .gitignore
    │   ├── .mypy.ini
    │   ├── .pre-commit-config.yaml
    │   ├── .python-version
    │   └── README.md
    │
    └── env/                # 📁 Environment configs (by type)
        ├── .env.development
        ├── .env.staging
        ├── .env.production
        ├── .env.venv
        └── README.md
```

## Benefits

### Clean Root Directory
✅ **Minimal clutter**: Only essential files visible
✅ **Fast navigation**: Find what you need quickly
✅ **Clear focus**: Focus on code, not configuration
✅ **Professional appearance**: Clean, organized structure

### Organized Configuration
✅ **Centralized**: All configs in one place
✅ **Documented**: Clear purpose for each file
✅ **Version controlled**: Track configuration changes
✅ **Easy maintenance**: Update in one place, sync to root

### Workspace Focus
✅ **Start session**: Clean view of essentials
✅ **Navigate quickly**: Know where everything is
✅ **Reference easily**: Find configs when needed
✅ **Reduce cognitive load**: Less clutter, more focus

## Maintenance

### Updating Ignore Files

**When updating root files:**
1. Update the root file (required by tool)
2. Update the copy in `config/dotfiles/` (for reference)
3. Keep them synchronized

**Example:**
```bash
# Update .gitignore at root
vim .gitignore

# Sync to config/dotfiles/
cp .gitignore config/dotfiles/.gitignore
```

### Adding New Environment Files

**When adding new environment:**
1. Create file in `config/env/`
2. Use `.env.example` as template
3. Update `config/env/README.md` if needed

**Example:**
```bash
# Create new environment file
cp config/env/.env.example config/env/.env.testing

# Update as needed
vim config/env/.env.testing
```

## Tools Requiring Root-Level Files

### Git (`.gitignore`)
Git requires `.gitignore` at repository root. It will not look in subdirectories (unless explicitly configured).


### Cursor (`.cursorignore`, `.cursorrules`)
Cursor IDE requires these files at workspace root for proper behavior.

### Agent Tools (`.agentignore`)
AI agent tools typically require `.agentignore` at project root.

## Best Practices

1. **Keep root minimal**: Only files required by tools
2. **Organize copies**: Store organized copies in `config/dotfiles/`
3. **Document everything**: Explain location and purpose
4. **Sync regularly**: Keep root and config copies synchronized
5. **Version control**: Track changes to configuration files
6. **Environment-specific**: Organize environment files by type

## Conclusion

This organization strategy provides:
- ✅ **Clean workspace**: Only essentials visible at root
- ✅ **Organized storage**: Everything properly organized by relevance
- ✅ **Easy navigation**: Know where to find everything
- ✅ **Professional structure**: Clean, maintainable organization

When you start a work session, you see **only the fundamentals you need** for navigation and daily work, while everything else is **properly organized and easily accessible** when needed.
