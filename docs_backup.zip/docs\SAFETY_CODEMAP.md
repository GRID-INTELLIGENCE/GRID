# Grid Safety Architecture Codemap
*Border Definitions, Gradient Analysis, and Structural Integrity*

## Module Dependency Graph

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           GRID SAFETY ARCHITECTURE                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      LAYER 0: CONFIGURATION                         │   │
│  │  ┌──────────────────┐    ┌──────────────────┐                       │   │
│  │  │ safety/config.py │───▶│ SafetyConfig     │                       │   │
│  │  │                  │    │ • denylist       │                       │   │
│  │  │                  │    │ • blocked_env    │                       │   │
│  │  │                  │    │ • required_env   │                       │   │
│  │  │                  │    │ • threshold: 0.5 │                       │   │
│  │  └──────────────────┘    └──────────────────┘                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      LAYER 1: INPUT BOUNDARY                        │   │
│  │  ┌──────────────────────────┐    ┌──────────────────────────┐       │   │
│  │  │ security/input_sanitizer │    │ security/threat_detector │       │   │
│  │  │ ════════════════════════ │    │ ════════════════════════ │       │   │
│  │  │ • ThreatSeverity (5)     │    │ • ThreatAction (6)       │       │   │
│  │  │ • ThreatType (9)         │    │ • ThreatCategory (11)    │       │   │
│  │  │ • SanitizationConfig     │    │ • RiskLevel (5)          │       │   │
│  │  │ • InputSanitizer         │    │ • ThreatDetector         │       │   │
│  │  │   - 47 danger patterns   │    │   - 12 default patterns  │       │   │
│  │  │   - sanitize_text()      │    │   - analyze_request()    │       │   │
│  │  │   - sanitize_json()      │    │   - rate limiting        │       │   │
│  │  │   - detect_threats()     │    │   - behavioral analysis  │       │   │
│  │  └──────────────────────────┘    └──────────────────────────┘       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      LAYER 2: GUARDRAIL BOUNDARY                    │   │
│  │  ┌──────────────────────────┐    ┌──────────────────────────┐       │   │
│  │  │ safety/guardrails.py     │    │ security/production.py   │       │   │
│  │  │ ════════════════════════ │    │ ════════════════════════ │       │   │
│  │  │ • GuardrailError         │    │ • Environment (3)        │       │   │
│  │  │ • SafetyGuardrails       │    │ • SecurityLevel (3)      │       │   │
│  │  │   - CONTRIBUTION_SCORES  │    │ • SecurityConfig         │       │   │
│  │  │   - validate_command()   │    │ • ProductionSecurityMgr  │       │   │
│  │  │   - run_all_checks()     │    │   - is_command_allowed() │       │   │
│  │  │ • @contribution_guard    │    │   - validate_environment │       │   │
│  │  │ • @production_guard      │    │   - max_failed: 3-100    │       │   │
│  │  └──────────────────────────┘    └──────────────────────────┘       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      LAYER 3: TRACING BOUNDARY                      │   │
│  │  ┌──────────────────────────┐    ┌──────────────────────────┐       │   │
│  │  │ tracing/action_trace.py  │    │ tracing/trace_manager.py │       │   │
│  │  │ ════════════════════════ │    │ ════════════════════════ │       │   │
│  │  │ • TraceOrigin (17)       │    │ • TraceManager           │       │   │
│  │  │ • TraceContext           │    │   - create_trace()       │       │   │
│  │  │   - trace_id             │    │   - trace_action()       │       │   │
│  │  │   - parent_trace_id      │    │   - get_active_trace()   │       │   │
│  │  │   - origin               │    │   - get_trace_chain()    │       │   │
│  │  │   - user_id, org_id      │    │ • get_trace_manager()    │       │   │
│  │  │ • ActionTrace            │    │                          │       │   │
│  │  │   - safety_score         │    │                          │       │   │
│  │  │   - risk_level           │    │                          │       │   │
│  │  │   - guardrail_violations │    │                          │       │   │
│  │  │   - compliance_flags     │    │                          │       │   │
│  │  └──────────────────────────┘    └──────────────────────────┘       │   │
│  │                                                                      │   │
│  │  ┌──────────────────────────┐                                        │   │
│  │  │ tracing/ai_safety_tracer │                                        │   │
│  │  │ ════════════════════════ │                                        │   │
│  │  │ • hash_prompt()          │                                        │   │
│  │  │ • @trace_model_inference │                                        │   │
│  │  │ • @trace_safety_analysis │                                        │   │
│  │  │ • @trace_guardrail_check │                                        │   │
│  │  │ • validate_response_safety()                                      │   │
│  │  │   - min_safety_score: 0.7                                         │   │
│  │  └──────────────────────────┘                                        │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                    │                                        │
│                                    ▼                                        │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      LAYER 4: API SAFETY BOUNDARY                   │   │
│  │  ┌──────────────────────────────────────────────────────────────┐   │   │
│  │  │ application/mothership/security/ai_safety.py                 │   │   │
│  │  │ ════════════════════════════════════════════════════════════ │   │   │
│  │  │ • AISafetyConfig                                             │   │   │
│  │  │   - get_gemini_api_key()                                     │   │   │
│  │  │   - get_openai_api_key()                                     │   │   │
│  │  │   - get_anthropic_api_key()                                  │   │   │
│  │  │   - validate_api_key_format()                                │   │   │
│  │  │   - sanitize_error_message()                                 │   │   │
│  │  │ • get_ai_safety_config()                                     │   │   │
│  │  └──────────────────────────────────────────────────────────────┘   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Border Definitions

### Border 1: Configuration → Input (Gradient: 0.0 → 0.3)
```
Crossing Point: SafetyConfig → InputSanitizer/ThreatDetector
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Gradient: Static config values flow into dynamic detection
Contrast: Low - Both deal with raw configuration data

Parameters:
  ├── denylist           → pattern matching
  ├── blocked_env_vars   → environment checks
  ├── contribution_threshold → score validation
  └── check_contribution → feature toggle
```

### Border 2: Input → Guardrail (Gradient: 0.3 → 0.6)
```
Crossing Point: InputSanitizer/ThreatDetector → SafetyGuardrails
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Gradient: Detection results feed enforcement decisions
Contrast: Medium - Detection is passive, guardrails are active

Data Flow:
  ├── ThreatSeverity     → GuardrailError trigger
  ├── SanitizationResult → command validation
  ├── ThreatAnalysisResult → security level adjustment
  └── risk_score         → contribution threshold
```

### Border 3: Guardrail → Tracing (Gradient: 0.6 → 0.8)
```
Crossing Point: SafetyGuardrails → TraceManager/ActionTrace
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Gradient: Enforcement decisions recorded for audit
Contrast: High - Enforcement vs observation

Data Flow:
  ├── GuardrailError     → guardrail_violations[]
  ├── command validation → action_type
  ├── contribution_score → safety_score
  └── security_level     → risk_level
```

### Border 4: Tracing → API Safety (Gradient: 0.8 → 1.0)
```
Crossing Point: ActionTrace → AISafetyConfig
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Gradient: Internal traces connect to external API calls
Contrast: Very High - Internal state vs external interface

Data Flow:
  ├── trace_id           → request correlation
  ├── model_used         → API key selection
  ├── prompt_hash        → security tracking
  └── safety_score       → response validation
```

## Gradient Scale Definition

```
GRADIENT SCALE: 0.0 ─────────────────────────────────────── 1.0
                │                                            │
                ▼                                            ▼
          CONFIGURATION                                  EXECUTION
          (Static)                                       (Dynamic)

0.0  ████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Config
0.1  ████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Environment
0.2  ████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Pattern Load
0.3  ████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Detection
0.4  ████████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Analysis
0.5  ████████████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░  Validation
0.6  ████████████████████████████░░░░░░░░░░░░░░░░░░░░░░  Enforcement
0.7  ████████████████████████████████░░░░░░░░░░░░░░░░░░  Tracing
0.8  ████████████████████████████████████░░░░░░░░░░░░░░  Recording
0.9  ████████████████████████████████████████░░░░░░░░░░  API Call
1.0  ████████████████████████████████████████████░░░░░░  Response
```

## Contrast Definitions

### Low Contrast Zones (ΔG < 0.2)
- Config ↔ Environment loading
- Pattern compilation ↔ Pattern matching
- Trace creation ↔ Trace storage

### Medium Contrast Zones (0.2 ≤ ΔG < 0.4)
- Detection ↔ Validation
- Analysis ↔ Enforcement
- Recording ↔ API preparation

### High Contrast Zones (ΔG ≥ 0.4)
- **Input → Guardrail** (passive → active)
- **Guardrail → Tracing** (action → observation)
- **Tracing → API** (internal → external)

## Structural Integrity Points

### Critical Junctions

```
Junction 1: InputSanitizer.sanitize_text() → ThreatDetector.analyze_request()
────────────────────────────────────────────────────────────────────────────
Integrity Check: Both must process same content
Failure Mode: Sanitized content bypasses threat detection
Mitigation: Chain sanitization before detection

Junction 2: SafetyGuardrails.validate_command() → TraceManager.trace_action()
────────────────────────────────────────────────────────────────────────────
Integrity Check: All validations must be traced
Failure Mode: Untraced security decisions
Mitigation: Decorator pattern ensures tracing

Junction 3: ThreatDetector → ProductionSecurityManager
────────────────────────────────────────────────────────
Integrity Check: Risk scores must influence security level
Failure Mode: High-risk requests bypass production controls
Mitigation: Unified risk threshold (0.9 auto-block)
```

### Dependency Chain

```
SafetyConfig.from_env()
    │
    ├──▶ SafetyGuardrails.run_all_checks()
    │        │
    │        ├──▶ check_environment_lockdown()
    │        │
    │        └──▶ validate_command()
    │                 │
    │                 └──▶ ProductionSecurityManager.is_command_allowed()
    │
    └──▶ InputSanitizer(SanitizationConfig)
             │
             ├──▶ sanitize_text_full()
             │        │
             │        └──▶ ThreatDetector.analyze_request()
             │
             └──▶ TraceManager.trace_action()
                      │
                      └──▶ ActionTrace(safety_score, risk_level)
```

## File Reference Map

| Module | File | Lines | Key Classes |
|--------|------|-------|-------------|
| Config | `src/grid/safety/config.py` | 35 | `SafetyConfig` |
| Guardrails | `src/grid/safety/guardrails.py` | 145 | `SafetyGuardrails`, `GuardrailError` |
| Sanitizer | `src/grid/security/input_sanitizer.py` | 654 | `InputSanitizer`, `SanitizationConfig` |
| Detector | `src/grid/security/threat_detector.py` | 855 | `ThreatDetector`, `ThreatPattern` |
| Production | `src/grid/security/production.py` | 221 | `ProductionSecurityManager` |
| Trace | `src/grid/tracing/action_trace.py` | 169 | `ActionTrace`, `TraceContext` |
| Manager | `src/grid/tracing/trace_manager.py` | 240 | `TraceManager` |
| AI Tracer | `src/grid/tracing/ai_safety_tracer.py` | 176 | decorators |
| AI Safety | `src/application/mothership/security/ai_safety.py` | 208 | `AISafetyConfig` |

## Enum Registry

### ThreatSeverity (5 levels)
```python
NONE     = "none"      # Gradient: 0.0
LOW      = "low"       # Gradient: 0.25
MEDIUM   = "medium"    # Gradient: 0.5
HIGH     = "high"      # Gradient: 0.75
CRITICAL = "critical"  # Gradient: 1.0
```

### ThreatType (9 types)
```python
XSS, SQL_INJECTION, COMMAND_INJECTION, CODE_INJECTION,
PATH_TRAVERSAL, OVERSIZED_INPUT, DEEP_NESTING,
INVALID_ENCODING, SUSPICIOUS_PATTERN
```

### ThreatCategory (11 types)
```python
INJECTION, XSS, BRUTE_FORCE, RATE_LIMIT, DOS,
ENUMERATION, RECONNAISSANCE, DATA_EXFILTRATION,
PRIVILEGE_ESCALATION, MALICIOUS_PAYLOAD, ANOMALY
```

### ThreatAction (6 types)
```python
ALLOW, MONITOR, CHALLENGE, THROTTLE, BLOCK, REPORT
```

### TraceOrigin (17 types)
```python
USER_INPUT, API_REQUEST, SCHEDULED_TASK, EVENT_TRIGGER,
SYSTEM_INIT, COGNITIVE_DECISION, PATTERN_MATCH,
EXTERNAL_WEBHOOK, INTERNAL_PIPELINE, EMERGENCY_REALTIME,
MODEL_INFERENCE, SAFETY_ANALYSIS, COMPLIANCE_CHECK,
GUARDRAIL_VIOLATION, RISK_ASSESSMENT, PROMPT_VALIDATION,
PII_DETECTION
```

### RiskLevel (5 levels)
```python
NONE, LOW, MEDIUM, HIGH, CRITICAL
```

### Environment (3 types)
```python
DEVELOPMENT, STAGING, PRODUCTION
```

### SecurityLevel (3 types)
```python
PERMISSIVE, STANDARD, RESTRICTIVE
```

## Threshold Matrix

| Parameter | Dev | Staging | Prod | Border |
|-----------|-----|---------|------|--------|
| `contribution_threshold` | 0.0 | 0.6 | 0.8 | Guardrail |
| `min_safety_score` | 0.5 | 0.7 | 0.7 | Tracing |
| `auto_block_threshold` | 0.9 | 0.9 | 0.9 | Detector |
| `max_failed_attempts` | 100 | 10 | 3 | Production |
| `rate_limit_max` | 100 | 100 | 100 | Detector |
| `max_text_length` | 100000 | 100000 | 100000 | Sanitizer |
| `max_json_depth` | 10 | 10 | 10 | Sanitizer |

## Risk Score Calculation

```
risk_score = Σ(component_score × weight) / Σ(weights)

Components:
  ├── pattern_risk:   max(threat.risk_score)  × 0.4
  ├── rate_risk:      exceeded ? 0.6-0.8 : proportional × 0.2
  ├── behavior_risk:  len(flags) × 0.2       × 0.2
  └── history_risk:   (not implemented)      × 0.2

Risk Level Mapping:
  0.0 - 0.2  →  NONE
  0.2 - 0.4  →  LOW
  0.4 - 0.6  →  MEDIUM
  0.6 - 0.8  →  HIGH
  0.8 - 1.0  →  CRITICAL
```
