# WSL Performance Optimization - Quick Reference

> **Quick Setup Time**: 30 minutes | **Expected Performance Gain**: 2-5x faster

---

## 🚀 Quick Start (30 Minutes)

### Step 1: Create `.wslconfig` (Windows)

Location: `%USERPROFILE%\.wslconfig`

```ini
[wsl2]
processors=6
memory=8GB
swap=8GB
pageReporting=false
vmIdleTimeout=60000
localhostForwarding=true

[experimental]
autoMemoryReclaim=gradual
sparseVhd=true
```

### Step 2: Apply Changes

```powershell
wsl --shutdown
wsl
```

### Step 3: Add Windows Defender Exclusions (PowerShell Admin)

```powershell
Add-MpPreference -ExclusionPath "\\wsl$\Ubuntu"
Add-MpPreference -ExclusionPath "$env:LOCALAPPDATA\Packages\CanonicalGroupLimited*"
Add-MpPreference -ExclusionProcess "wsl.exe"
Add-MpPreference -ExclusionProcess "wslhost.exe"
```

### Step 4: Move Project to WSL Filesystem

```bash
# In WSL
cd ~
mkdir -p projects
cp -r /mnt/e/grid ~/projects/grid
cd ~/projects/grid
```

**Why**: Windows filesystem (`/mnt/e/`) is 2-10x slower than native WSL filesystem (`/home/`)

---

## 📊 Performance Benchmarks

| Operation | Before (Windows FS) | After (WSL FS) | Improvement |
|-----------|---------------------|----------------|-------------|
| `git status` | 2-3s | <0.5s | **5-6x faster** |
| `pytest` (unit) | 60s | 20-25s | **2.5-3x faster** |
| `pip install` | 120s | 40-50s | **2-3x faster** |
| `ruff check .` | 15s | 3-4s | **4-5x faster** |
| File I/O (1GB) | 45s | 8-10s | **5x faster** |

---

## ⚡ Essential Commands

### Check WSL Version
```powershell
wsl --version
wsl --status
```

### Restart WSL
```powershell
wsl --shutdown
wsl
```

### Access WSL Files from Windows
```
\\wsl$\Ubuntu\home\username\projects\grid
```

### Monitor Performance
```bash
# In WSL
htop           # CPU & Memory
iotop          # Disk I/O (sudo)
df -h          # Disk usage
free -h        # Memory usage
```

---

## 🔧 Automated Setup

### Run Optimization Script (PowerShell Admin)

```powershell
cd E:\grid
.\scripts\setup_wsl_optimization.ps1
```

Options:
- `-MemoryGB 12` - Set memory allocation
- `-ProcessorCount 8` - Set CPU cores
- `-WhatIf` - Preview changes without applying

---

## 🎯 Quick Fixes

### Problem: "WSL won't start"
```powershell
wsl --shutdown
wsl --update
wsl
```

### Problem: "Out of memory"
Edit `.wslconfig`:
```ini
memory=12GB
swap=16GB
```

### Problem: "Git is slow"
```bash
git config --global core.untrackedCache true
git config --global core.fsmonitor true
git config --global feature.manyFiles true
```

### Problem: "Tests are slow"
```bash
# Use parallel execution
pytest -n auto
```

---

## 📁 Project Structure After Migration

```
Windows:  E:\grid (OLD - SLOW)
          ↓ migrate
WSL:      /home/username/projects/grid (NEW - FAST)
          ↓ access from Windows
Windows:  \\wsl$\Ubuntu\home\username\projects\grid
```

---

## 🛠️ IDE Configuration

### VS Code / Windsurf

1. **Open WSL folder**:
   - `Ctrl+Shift+P` → "Remote-WSL: Open Folder in WSL"
   - Navigate to `/home/username/projects/grid`

2. **Or use path directly**:
   - File → Open Folder
   - Enter: `\\wsl$\Ubuntu\home\username\projects\grid`

3. **Select Python interpreter**:
   - `Ctrl+Shift+P` → "Python: Select Interpreter"
   - Choose: `.venv/bin/python` (WSL)

---

## 📈 Verification Checklist

After optimization, verify:

- [ ] WSL filesystem location: `pwd` shows `/home/...` not `/mnt/...`
- [ ] Git status < 1s: `time git status`
- [ ] Tests faster: `time pytest tests/unit -x`
- [ ] IDE connected to WSL
- [ ] Python from `.venv/bin/python` (not Windows)
- [ ] Docker using WSL2 backend

---

## 🔍 Performance Monitoring

### Run Benchmark
```bash
# Before optimization
~/benchmark_wsl.sh > before.txt

# After optimization
~/benchmark_wsl.sh > after.txt

# Compare
diff -u before.txt after.txt
```

### Live Monitoring Dashboard
```bash
./scripts/monitor_wsl_performance.sh
```

---

## 🚨 Common Mistakes

### ❌ DON'T: Access Windows files from WSL
```bash
cd /mnt/e/grid  # SLOW
```

### ✅ DO: Access WSL files
```bash
cd ~/projects/grid  # FAST
```

---

### ❌ DON'T: Use Windows Python from WSL
```bash
/mnt/c/Python313/python.exe  # SLOW
```

### ✅ DO: Use WSL Python
```bash
python3  # or .venv/bin/python
```

---

### ❌ DON'T: Keep `.venv` on Windows filesystem
```
E:\grid\.venv  # SLOW
```

### ✅ DO: Keep `.venv` in WSL
```
/home/username/projects/grid/.venv  # FAST
```

---

## 🔗 Quick Links

| Resource | Link |
|----------|------|
| Full Guide | `docs/guides/WSL_PERFORMANCE_OPTIMIZATION.md` |
| Setup Script | `scripts/setup_wsl_optimization.ps1` |
| Monitor Script | `scripts/monitor_wsl_performance.sh` |
| WSL Docs | https://learn.microsoft.com/en-us/windows/wsl/ |

---

## 💡 Pro Tips

1. **Use WSL-native terminal**: Windows Terminal or built-in WSL terminal (faster than Windows CMD/PowerShell → WSL)

2. **Enable systemd** (`/etc/wsl.conf`):
   ```ini
   [boot]
   systemd=true
   ```

3. **Disable unnecessary startup services**:
   ```bash
   sudo systemctl disable <service-name>
   ```

4. **Use `rsync` for fast file operations**:
   ```bash
   rsync -avhP /mnt/e/grid ~/projects/
   ```

5. **Clean Docker regularly**:
   ```bash
   docker system prune -af --volumes
   ```

---

## 📞 Support

If optimization doesn't improve performance:

1. Check if project is truly in WSL filesystem: `pwd`
2. Verify Windows Defender exclusions: `Get-MpPreference | Select ExclusionPath`
3. Restart WSL: `wsl --shutdown && wsl`
4. Check logs: `dmesg | tail` (in WSL)
5. Review full guide: `docs/guides/WSL_PERFORMANCE_OPTIMIZATION.md`

---

**Last Updated**: 2024
**Tested On**: Windows 11 Build 28000, WSL2 2.0.0+, Ubuntu 22.04