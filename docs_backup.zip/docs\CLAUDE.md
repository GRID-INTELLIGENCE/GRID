# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

GRID (Geometric Resonance Intelligence Driver) is a comprehensive framework for exploring complex systems through:
- **Event-driven Agentic System**: Receptionist → Lawyer → Client workflow for structured case processing
- **Local-First RAG**: ChromaDB + Ollama (no external APIs required)
- **Cognitive Decision Support**: Light of the Seven cognitive architecture
- **Domain-Driven Design**: Professional architectural patterns with service layer decoupling
- **Intelligent Skills Ecosystem**: Auto-discovered, persistent, performance-tracked skills

## Environment Setup

**This repo uses UV as the Python venv/package manager.** Do not use `python -m venv` or `pip` directly.

```bash
# Create and activate virtual environment
uv venv --python 3.13 --clear
.\.venv\Scripts\Activate.ps1

# Install dependencies
uv sync --group dev --group test
```

When running `python -m grid` manually, ensure `src` is in your PYTHONPATH:
```powershell
$env:PYTHONPATH="src"; python -m grid --help
```

## Common Commands

### Build and Install
```bash
make install           # Sync dependencies via uv
make build-dist        # Build Python distribution artifacts
```

### Testing
```bash
make test              # Run fast unit + integration tests
make test-all          # Run ALL tests (including slow)
pytest tests/unit      # Unit tests only
pytest tests/integration  # Integration tests only
pytest -k "test_name"  # Run specific test
```

### Linting and Formatting
```bash
make lint              # Run Ruff + Mypy
make format            # Auto-format with Black + Ruff
uv run ruff check . --fix
uv run black .
```

### Local Development
```bash
make run               # Run Mothership API locally
uv run python -m application.mothership.main
```

### RAG System
```bash
rag-query "How does X work?"              # Query knowledge base
rag-index docs/ --rebuild --curate        # Index/rebuild docs
```

### Docker Infrastructure
```bash
make start-infra       # Start Postgres, Redis, Chroma, Ollama
make stop-infra        # Stop all infrastructure
```

### Pre-commit Hooks
```bash
pre-commit run --all-files
make pre-commit        # Run all pre-commit hooks
```

## Architecture Overview

### High-Level Layer Structure

```
┌─────────────────────────────────────────────────────────────────┐
│                    Application Layer (FastAPI)                   │
│  application/mothership/ - Main API with auth, agentic, skills  │
│  application/resonance/  - Canvas flip communication layer      │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                  Core Intelligence Layer                         │
│  grid/agentic/     - Event-driven case management               │
│  grid/context/     - User context & pattern recognition         │
│  grid/workflow/    - Task orchestration across projects         │
│  grid/skills/      - Extensible skills registry                 │
│  grid/essence/     - Core state management                      │
│  grid/patterns/    - 9 cognition patterns (Flow, Spatial, etc.) │
│  grid/awareness/   - Context & temporal/spatial fields          │
│  grid/evolution/   - State evolution pipelines                  │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                    RAG System (Local-First)                      │
│  tools/rag/ - ChromaDB + Ollama embeddings/LLM, hybrid search   │
└─────────────────────────────────────────────────────────────────┘
                              ↓
┌─────────────────────────────────────────────────────────────────┐
│                 Infrastructure & Storage                         │
│  MCP Servers (workspace/mcp/) - database, filesystem, memory    │
│  Databricks - Cloud-backed vector store & case storage         │
│  Postgres/Redis - Local data & caching                          │
└─────────────────────────────────────────────────────────────────┘
```

### Key Architectural Patterns

**Event-Driven Agentic System:**
- Cases flow through: CaseCreated → CaseCategorized → CaseReferenceGenerated → CaseExecuted → CaseCompleted
- EventBus (`grid/agentic/event_bus.py`) centralizes all events with optional Redis pub-sub
- Each lifecycle event has a handler in `grid/agentic/event_handlers.py`
- Repository pattern in `application/mothership/repositories/agentic.py` for Databricks persistence

**Dependency Injection:**
- `application/mothership/dependencies.py` provides singleton services
- FastAPI's `Depends()` injects services into route handlers
- Service layer decoupled from API routes following DDD principles

**Skills Ecosystem:**
- Skills auto-discovered from `src/tools/agent_prompts/` directory
- `grid/skills/registry.py` maintains skill catalog with performance tracking
- Skills run via `grid.skills.run()` CLI or through the agentic system

**Local-First RAG:**
- Embeddings: Ollama's `nomic-embed-text-v2-moe` or HuggingFace
- LLM: Ollama's `ministral` or `gpt-oss-safeguard`
- Vector store: ChromaDB (`.rag_db/`), Databricks, or in-memory
- Hybrid search: Vector similarity + BM25 keyword search
- Reranker: Optional cross-encoder for improved relevance

## Important Configuration Files

### Project Configuration
- `pyproject.toml` - Project metadata, dependencies, tool configs (pytest, ruff, black, mypy)
- `.cursorrules` - AI assistant rules, local-first principles, coding standards
- `.pre-commit-config.yaml` - 3-tier CI: fast auto-fixers (commit), validation (push)
- `Makefile` - Common development commands

### Environment
- `config/env/development.env` - Development environment variables
- `config/secrets_manager.yaml` - Secret management configuration

### Tests
- `pytest.ini` (via pyproject.toml) - Test configuration with markers (unit, integration, api, scratch)

## Core Services

### Mothership API (`src/application/mothership/`)
Main FastAPI application with routers for:
- `/api/v1/agentic/` - Case management workflow
- `/api/v1/resonance/` - Canvas flip communication
- `/api/v1/skills/` - Skills health and execution
- `/api/v1/navigation/` - Navigation services

Entry point: `src/application/mothership/main.py:main()`

### Agentic System (`src/grid/agentic/`)
- `agentic_system.py` - Main orchestrator, executes cases, gets recommendations
- `agent_executor.py` - Executes agent tasks using reference files
- `event_bus.py` - Async event bus with Redis pub-sub support
- `event_handlers.py` - Case lifecycle event handlers

### RAG System (`src/tools/rag/`)
- `rag_engine.py` - Unified engine orchestrating embedding, retrieval, generation
- `cli.py` - CLI commands: `query`, `index`, `stats`
- `config.py` - RAGConfig with local-only enforcement
- `vector_store/` - ChromaDB, Databricks, in-memory implementations
- `embeddings/` - Ollama, HuggingFace, OpenAI providers
- `llm/` - Ollama local, Ollama cloud, Llama.cpp providers

### Context System (`src/grid/context/`)
- `user_context_manager.py` - Tracks user task patterns and preferences
- `pattern_recognition.py` - Recognizes patterns in user behavior
- `recognizer.py` - Recognizes current development context
- `learning_engine.py` - Learns from completed tasks

### Workflow Orchestrator (`src/grid/workflow/orchestrator.py`)
Coordinates tasks across projects using user context and pattern recognition.

## MCP Servers (`workspace/mcp/`)

Model Context Protocol servers for IDE integration:
- `database/server.py` - SQLite database operations
- `filesystem/server.py` - Filesystem operations
- `memory/server.py` - Key-value memory store
- `postgres/server.py` - PostgreSQL operations

Each server includes HTTP health endpoints for Docker monitoring.

## Local-First Operation Principles

**NEVER suggest external API calls** (OpenAI, Anthropic) unless explicitly requested:
- Use local Ollama models for embeddings and LLM
- RAG context stays local (ChromaDB in `.rag_db/`)
- Default to local-only solutions

Available Ollama models:
- Embeddings: `nomic-embed-text-v2-moe:latest`
- LLM: `ministral` or `gpt-oss-safeguard`

## Code Quality Standards

- Python 3.13 with full type hints
- Line length: 120 characters
- Use Pydantic for data models
- Follow PEP 8 with project-specific overrides
- Run `make lint` before committing

### Import Organization
```python
# Group imports: stdlib, third-party, local
from pathlib import Path  # stdlib
from fastapi import FastAPI  # third-party
from grid.agentic import AgenticSystem  # local
```

### Error Handling
- Use custom exception hierarchy
- Provide clear error messages
- Log errors with context
- Fail fast for configuration errors

## Before Making Changes

1. **Read Relevant Files**: Check existing implementations in the same area
2. **Check Architecture**: Verify your change fits the layered architecture
3. **Review Patterns**: Look for similar patterns in the codebase
4. **Query RAG**: Use RAG system to understand project context
5. **Consider Tests**: Ensure tests exist or need to be created

## Testing Strategy

- **Unit tests**: Fast, isolated (tests/unit/)
- **Integration tests**: Slower, cross-module (tests/integration/)
- **API tests**: Endpoint testing (tests/api/)
- **Markers**: `@pytest.mark.unit`, `@pytest.mark.integration`, `@pytest.mark.scratch`

Scratch tests are experimental and excluded from default CI runs.

## CI/CD

- GitHub Actions runs tests, linting, and builds
- Pre-push hooks catch issues before remote CI
- Use `make watch-ci` to monitor GitHub Actions runs

## Documentation Reference

- `README.md` - Project overview and quickstart
- `docs/ARCHITECTURE.md` - Detailed architecture documentation
- `docs/AGENTIC_SYSTEM.md` - Agentic system documentation
- `docs/AGENTIC_SYSTEM_USAGE.md` - Agentic system usage guide
- `.cursorrules` - AI assistant coding guidelines

## Module Boundaries

- `src/grid/` - Core intelligence layer
- `src/application/` - FastAPI applications
- `src/cognitive/` - Cognitive architecture (Light of the Seven)
- `src/tools/` - Development tools (RAG, utilities)
- `tests/` - Test suite
- `workspace/mcp/` - MCP servers