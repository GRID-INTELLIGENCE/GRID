# GRID Settings Harmonization Guide

**Generated:** 2026-01-10  
**Purpose:** Ensure consistent, error-free development across VS Code, Antigravity IDE, and system configuration.

---

## 🎯 SECTION 1: CURRENT SETTINGS INVENTORY

### 1.1 Global Settings Locations

| Location | Purpose | Status |
|----------|---------|--------|
| `C:\Users\irfan\.gemini\settings.json` | Gemini CLI global config | ✅ Active |
| `C:\Users\irfan\.gemini\antigravity\mcp_config.json` | Antigravity MCP servers | ⚠️ Empty |
| `C:\Users\irfan\AppData\Roaming\Code\User\settings.json` | VS Code user settings | ✅ Active |
| `E:\grid\pyproject.toml` | Project Python tooling | ✅ Active |
| `E:\grid\config\env\development.env` | Environment variables | ✅ Created |

### 1.2 VS Code Current Configuration Analysis

**Positive Findings:**
- ✅ Python 3.13 interpreter path correctly set
- ✅ PYTHONPATH includes `E:\grid` and `E:\grid\src`
- ✅ Black formatter configured with `--line-length=120`
- ✅ Pytest enabled with proper test paths
- ✅ Terminal environment variables set for GRID

**Issues Identified:**
- ⚠️ Using Black as formatter (pyproject.toml uses Ruff)
- ⚠️ Pylint enabled (conflicts with Ruff linting)
- ⚠️ `light_of_the_seven` in PYTHONPATH (may not exist)
- ⚠️ Missing Ruff extension settings

---

## 📋 SECTION 2: RECOMMENDED VS CODE SETTINGS

Replace or merge with your current `settings.json`:

```json
{
  // ═══════════════════════════════════════════════════════════════
  // EDITOR SETTINGS
  // ═══════════════════════════════════════════════════════════════
  "editor.fontSize": 14,
  "editor.fontFamily": "'Fira Code', 'Courier New', monospace",
  "editor.fontLigatures": true,
  "editor.lineHeight": 1.6,
  "editor.tabSize": 4,
  "editor.insertSpaces": true,
  "editor.trimAutoWhitespace": true,
  "editor.formatOnSave": true,
  "editor.renderWhitespace": "selection",
  "editor.bracketPairColorization.enabled": true,
  "editor.guides.bracketPairs": "active",
  "editor.rulers": [80, 120],
  
  // ═══════════════════════════════════════════════════════════════
  // FILE SETTINGS
  // ═══════════════════════════════════════════════════════════════
  "files.autoSave": "afterDelay",
  "files.autoSaveDelay": 1000,
  "files.trimTrailingWhitespace": true,
  "files.insertFinalNewline": true,
  
  // ═══════════════════════════════════════════════════════════════
  // PYTHON SETTINGS (Aligned with pyproject.toml)
  // ═══════════════════════════════════════════════════════════════
  "python.defaultInterpreterPath": "C:\\Users\\irfan\\AppData\\Local\\Programs\\Python\\Python313\\python.exe",
  
  // Use Ruff for BOTH formatting AND linting (replaces Black + Pylint)
  "[python]": {
    "editor.defaultFormatter": "charliermarsh.ruff",
    "editor.formatOnSave": true,
    "editor.codeActionsOnSave": {
      "source.organizeImports.ruff": "explicit",
      "source.fixAll.ruff": "explicit"
    }
  },
  
  // Disable legacy linters (Ruff handles these)
  "python.linting.enabled": false,
  "python.linting.pylintEnabled": false,
  "python.formatting.provider": "none",
  
  // Ruff extension settings (matches pyproject.toml)
  "ruff.lineLength": 120,
  "ruff.lint.select": ["E", "F", "B", "I"],
  "ruff.lint.ignore": ["B008", "E501", "F401", "E402", "B017", "F821"],
  "ruff.organizeImports": true,
  "ruff.fixAll": true,
  
  // Analysis paths (cleaned up)
  "python.analysis.extraPaths": [
    "E:\\grid",
    "E:\\grid\\src"
  ],
  "python.analysis.typeCheckingMode": "basic",
  "python.analysis.diagnosticMode": "workspace",
  
  // Testing
  "python.testing.pytestEnabled": true,
  "python.testing.pytestArgs": [
    "tests",
    "-v",
    "--tb=short",
    "--strict-markers"
  ],
  
  // ═══════════════════════════════════════════════════════════════
  // TERMINAL SETTINGS (Aligned with CLI helpers)
  // ═══════════════════════════════════════════════════════════════
  "terminal.integrated.defaultProfile.windows": "PowerShell",
  "terminal.integrated.fontSize": 12,
  "terminal.integrated.lineHeight": 1.4,
  "terminal.integrated.suggest.enabled": true,
  
  "terminal.integrated.env.windows": {
    "PYTHONPATH": "E:\\grid\\src",
    "GRID_ROOT": "E:\\grid",
    "GRID_SRC": "E:\\grid\\src",
    "MOTHERSHIP_ENVIRONMENT": "development",
    "MOTHERSHIP_LOG_LEVEL": "DEBUG"
  },
  
  "terminal.integrated.profiles.windows": {
    "PowerShell": {
      "source": "PowerShell",
      "icon": "terminal-powershell",
      "args": [
        "-NoExit",
        "-Command",
        ". E:\\grid\\scripts\\cli_helpers.ps1"
      ]
    }
  },
  
  // ═══════════════════════════════════════════════════════════════
  // WORKBENCH & GENERAL
  // ═══════════════════════════════════════════════════════════════
  "workbench.colorTheme": "Visual Studio Dark",
  "workbench.editor.showTabs": "multiple",
  "git.ignoreLimitWarning": true,
  "git.autorefresh": true,
  "telemetry.telemetryLevel": "off"
}
```

---

## 📋 SECTION 3: RECOMMENDED GEMINI CLI SETTINGS

Update `C:\Users\irfan\.gemini\settings.json`:

```json
{
  "security": {
    "auth": {
      "selectedType": "oauth-personal"
    }
  },
  "general": {
    "previewFeatures": true
  },
  "model": {
    "name": "auto-gemini-3"
  },
  "mcp": {
    "serverDiscovery": true,
    "allowed": ["*"]
  },
  "mcpServers": {
      "args": ["mcp", "gateway", "run"],
      "env": {
        "LOCALAPPDATA": "C:\\Users\\irfan\\AppData\\Local",
        "ProgramData": "C:\\ProgramData",
        "ProgramFiles": "C:\\Program Files"
      }
    }
  },
  "pythonSettings": {
    "pythonPath": "C:\\Users\\irfan\\AppData\\Local\\Programs\\Python\\Python313\\python.exe",
    "gridWorkspace": "E:\\grid",
    "gridSrc": "E:\\grid\\src"
  }
}
```

---

## 📋 SECTION 4: PYPROJECT.TOML ALIGNMENT CHECK

Your `pyproject.toml` is well-configured. Key points:

| Setting | Value | VS Code Alignment |
|---------|-------|-------------------|
| `line-length` | 120 | ✅ Matched |
| `target-version` | py313 | ✅ Matched |
| `ruff.lint.select` | E, F, B, I | ✅ Matched |
| `ruff.lint.extend-ignore` | B008, E501, F401, E402, B017, F821 | ✅ Matched |
| `pythonpath` | ["src", "."] | ⚠️ Update VS Code |

**Note:** The VS Code settings above are aligned with your `pyproject.toml` to ensure consistent behavior between CLI and editor.

---

## ⚠️ SECTION 5: WORKSPACE CONFIGURATION FIX

Your `pyproject.toml` has workspace members that may not exist:

```toml
[tool.uv.workspace]
members = [".", "light_of_the_seven", "data", "docs", "datakit", "Arena/the_chase/python"]
```

This causes the `uv add` error. **Recommended fix:**

```toml
[tool.uv.workspace]
members = ["."]  # Simplified - add others only when they have pyproject.toml
```

---

## 🔄 SECTION 6: HARMONIZATION ACTIONS

### Action 1: Update VS Code Settings
Run this PowerShell command to backup and view current settings:

```powershell
# Backup current settings
Copy-Item "$env:APPDATA\Code\User\settings.json" "$env:APPDATA\Code\User\settings.json.backup"
Write-Host "Backup created at: $env:APPDATA\Code\User\settings.json.backup"
```

Then manually merge the recommended settings from Section 2.

### Action 2: Install Ruff VS Code Extension
```powershell
code --install-extension charliermarsh.ruff
```

### Action 3: Apply CLI Helpers Auto-Load
Add to your PowerShell profile:
```powershell
Add-Content $PROFILE "`n# GRID CLI Helpers`n. E:\grid\scripts\cli_helpers.ps1"
```

---

## ✅ SECTION 7: VERIFICATION CHECKLIST

After applying changes, verify:

- [ ] Ruff formats on save in VS Code
- [ ] No Pylint warnings appear (Ruff handles linting)
- [ ] Terminal opens with GRID helpers loaded
- [ ] `python -m pytest tests/` runs successfully
- [ ] `python -m alembic current` runs without errors
- [ ] Import statements auto-organize on save

---

*This guide ensures all settings across VS Code, Gemini CLI, and pyproject.toml are harmonized for error-free GRID development.*
