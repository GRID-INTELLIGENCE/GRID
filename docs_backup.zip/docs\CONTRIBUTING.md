# Contributing

Thanks for taking the time to contribute to GRID.

## What to contribute

- Fixes that improve portability (paths, OS-specific assumptions).
- Tests that increase confidence in the Python utilities.
- Documentation cleanup that makes the directory easier to navigate.
- Performance optimizations that maintain the <0.1ms SLA.
- New skills for the skills registry.

## Development Setup

**This repo uses UV as the Python venv/package manager.** Do not use `python -m venv` or `pip` directly—use UV for all venv and package operations.

```powershell
# Create and activate virtual environment with UV
Set-Location e:\grid
uv venv --python 3.13 --clear
.\.venv\Scripts\Activate.ps1

# Install dependencies (dev and test groups)
uv sync --group dev --group test
```

### Legacy setup (not recommended)

```bash
# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .\.venv\Scripts\Activate.ps1

# Install dependencies
pip install -e ".[dev,test]"
```

## Code Quality Tools

The project uses the following tools for code quality:

- **Ruff**: Fast Python linter and formatter (replaces Black)
- **Mypy**: Static type checker
- **Pytest**: Test runner

### Running Checks Locally

```bash
# Lint and Format check
uv run ruff check .
uv run ruff format --check .

# Type check
uv run mypy src/grid

# Run tests
uv run pytest tests/ -v
```

### Legacy Code Strategy

To maintain development velocity, the project employs a pragmatic strategy for legacy directories (`archive/`, `EUFLE/`, `research/`):
- **Linting**: These directories are excluded from global `ruff` checks to avoid noise from unmainatined code.
- **Testing**: Tests in these directories are not part of the critical path CI unless explicitly stated.
- **New Code**: All new code in active directories (`src/grid/`, `src/application/`) must strictly follow current standards (Type hints, Ruff formatting).

Or use the verification script:
```powershell
.\scripts\verify.ps1
```

## Testing

- Run the full test suite: `uv run pytest tests/`
- Run specific test file: `uv run pytest tests/api/test_router.py`
- Run with coverage: `uv run pytest tests/ --cov=grid --cov=application`
- Run benchmarks: `uv run pytest tests/test_grid_benchmark.py -q`

All tests should pass before submitting a PR.

## Submitting changes

- Prefer small, focused commits.
- Include a short summary in the commit message.
- Follow the existing code style (Black formatted, type hints required).
- Ensure all checks pass (`ruff`, `mypy`, `pytest`).
- Update documentation if adding new features.
- Check [docs/AGENTS.md](AGENTS.md) for agent-specific development guidelines.

## Project Structure

- `grid/` - Core intelligence layer (essence, patterns, awareness, evolution, interfaces)
- `application/` - Application-specific code (mothership API, resonance endpoints)
- `tools/rag/` - Local-first RAG system (ChromaDB, Ollama)
- `light_of_the_seven/` - Cognitive layer and research
- `docs/` - Documentation
- `tests/` - Test suite

## Questions?

Open a GitHub issue or check the documentation in `docs/`.
