# Cursor 2.0 Workflow Guide

This guide explains when and how to use Cursor 2.0 effectively for GRID development.

## When to Use Cursor

Cursor 2.0 is best for:
- **Complex multi-step tasks** requiring careful planning
- **Architecture decisions** that need thorough analysis
- **Refactoring** with impact analysis
- **Feature implementation** with multiple components
- **Debugging** complex issues systematically

## Key Features

### Plan Mode
- Use Plan Mode (`Cmd+I` then select Plan) for tasks >5 minutes
- Creates structured plans with todos
- Generates artifacts for implementation
- Reference plan templates in `.cursor/templates/plan/`

**Available Templates:**
- `refactor_plan.md` - Refactoring with impact analysis
- `migration_plan.md` - Database/schema migrations
- `debugging_plan.md` - Systematic debugging

### Background Agents
Run tasks asynchronously without blocking:
- **Index RAG**: Rebuild RAG index in background
- **Run Tests**: Continuous test execution
- **Monitor Performance**: Performance tracking

Use commands in `.cursor/commands/` to start background agents.

### Checkpoints
- Create checkpoints before major changes (`Cmd+K`)
- Restore to checkpoint if needed
- Useful for experimental changes

### Multi-Agent Chats
- Use multiple agents for parallel work:
  - One agent for implementation
  - Another for testing
  - Another for documentation

## Workflow Patterns

### Feature Implementation
1. **Plan**: Use Plan Mode with `feature_implementation.md` template
2. **Checkpoint**: Create checkpoint before starting
3. **Implement**: Follow plan step by step
4. **Test**: Run background test agent
5. **Review**: Use multi-agent review

### Refactoring
1. **Plan**: Use `refactor_plan.md` template
2. **Impact Analysis**: Identify all affected files
3. **Checkpoint**: Create checkpoint
4. **Incremental Changes**: Make small, testable changes
5. **Validate**: Run full test suite

### Debugging
1. **Plan**: Use `debugging_plan.md` template
2. **Reproduce**: Document reproduction steps
3. **Investigate**: Use file references and RAG queries
4. **Fix**: Implement fix with regression test
5. **Validate**: Verify fix doesn't break other functionality

## Commands

### Environment Commands
Access via Cursor's command palette:
- `install` - Set up Python environment
- `test` - Run test suite with coverage
- `lint` - Run linters and type checker
- `format` - Auto-fix formatting issues
- `start` - Start the Mothership API server

### Background Agent Commands
- `index_rag` - Rebuild RAG index
- `run_tests` - Continuous test runner
- `monitor_performance` - Performance tracking

## Best Practices

1. **Use Plan Mode First**: For any task >5 minutes, start with Plan Mode
2. **Create Checkpoints**: Before major changes, create checkpoints
3. **Run Background Agents**: Use for async tasks (RAG indexing, tests)
4. **Multi-Agent Chats**: Parallelize work with multiple agents
5. **Reference Templates**: Use plan templates for consistency
6. **Query RAG**: Use RAG system for project context

## Integration with Other Tools

### Handoff to Windsurf
- Export plan context using `scripts/handoff_task.py`
- Windsurf can use file references for implementation
- Maintain context across tool switches

### Handoff to Antigravity
- Convert Cursor plan to Antigravity workflow
- Use `scripts/handoff_task.py convert --plan <plan.md>`
- Antigravity can execute autonomously

## Examples

### Example: Adding a New Feature
```bash
# 1. Create plan in Cursor Plan Mode
# 2. Reference feature_implementation.md template
# 3. Create checkpoint
# 4. Implement following plan
# 5. Run background test agent
# 6. Review with multi-agent chat
```

### Example: Refactoring
```bash
# 1. Use refactor_plan.md template
# 2. Analyze impact with RAG queries
# 3. Create checkpoint
# 4. Make incremental changes
# 5. Run tests after each change
# 6. Validate architecture alignment
```

## Notes

- Cursor excels at planning and orchestration
- Use for complex, multi-step tasks
- Leverage background agents for async work
- Create checkpoints for safety
- Use multi-agent chats for parallel work
