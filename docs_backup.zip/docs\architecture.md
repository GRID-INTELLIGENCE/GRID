# GRID Architecture Documentation

## Overview

GRID (Geometric Resonance Intelligence Driver) is a Python-based framework for exploring complex systems through geometric resonance patterns. It combines a layered architecture with cognitive decision support, local-first RAG, and pattern recognition capabilities.

## Architectural Layers

### 1. Core Intelligence Layer (`grid/`)

The foundation of the framework providing essential intelligence services:

- **Essence** (`grid/essence/`): Core state management and quantum transformations
- **Patterns** (`grid/patterns/`): Pattern recognition using 9 cognition patterns (Flow, Spatial, Rhythm, Color, Repetition, Deviation, Cause, Time, Combination)
- **Awareness** (`grid/awareness/`): Context management and temporal/spatial field processing
- **Evolution** (`grid/evolution/`): State evolution and transformation pipelines
- **Interfaces** (`grid/interfaces/`): Bridge interfaces for quantum state transfer and sensory processing
- **Skills** (`grid/skills/`): Extensible skills registry (refine, transform, cross-reference, compress, RAG)

### 2. Application Layer (`application/`)

Application-specific code built on FastAPI:

- **Mothership** (`application/mothership/`): Main API aggregator with routers for:
  - Authentication and authorization
  - API key management
  - Payment processing (Stripe integration)
  - Performance metrics
- **Resonance** (`application/resonance/`): Canvas flip communication layer:
  - `/api/v1/resonance/process` - Baseline resonance loop
  - `/api/v1/resonance/definitive` - Mid-process checkpoint (~65% completion)
  - Skills orchestration (5 skills in pipeline)
  - Path triage (left/right/straight metaphors)

### 3. RAG System (`tools/rag/`)

Local-first Retrieval-Augmented Generation system:

- **ChromaDB**: Vector store (`.rag_db/` directory)
- **Ollama Integration**: Local embeddings (`nomic-embed-text-v2-moe:latest`) and LLM (`ministral` or `gpt-oss-safeguard`)
- **Hybrid Search**: Combines vector similarity with BM25 keyword search
- **Reranker**: Optional reranking for improved relevance
- **Cache**: Query result caching for performance

### 4. Cognitive Layer (`light_of_the_seven/`)

Cognitive architecture and research:

- **Cognitive Layer** (`light_of_the_seven/cognitive_layer/`): Decision support, cognitive load analysis, mental models, bounded rationality
- **Research**: Domain-specific research and documentation
- **Tools**: Additional cognitive tools and utilities

### 5. Database Layer

Data persistence using SQLAlchemy:

- **Models**: ORM models for application data
- **Sessions**: Database connection and transaction management
- **Migrations**: Schema versioning with Alembic

### 6. Utilities and Tools

- **Scripts** (`scripts/`): Utility scripts including git-topic PoC
- **Tests** (`tests/`): Comprehensive test suite (171 tests passing)
- **Docs** (`docs/`): Project documentation

## Core Patterns

### Builder Pattern
The application uses the **Builder Pattern** (`src/core/builder.py`) for initialization. This decouples the construction of the `FastAPI` application from its configuration, allowing for flexible assembly of:
- Settings
- Routers
- Middleware
- Lifespan contexts

### Dependency Inversion
We follow **Clean Architecture** principles. High-level modules depend on abstractions (defined in `src/core/interfaces.py`), not concrete implementations.
- **Interfaces**: `IDatabase`, `IEmailService`, `ILogger`, `IVisionService`
- **Injection**: Dependencies are wired up during the Build phase.

## Design Patterns

### Dependency Injection

The framework uses a simple dependency injection container:

```python
# Service registration
container.register_singleton(DatabaseService, DatabaseService())
container.register_transient(UserService, UserService)

# Service resolution
db_service = container.get(DatabaseService)
user_service = container.get(UserService)
```

### Factory Pattern

FastAPI application factory for creating configured instances:

```python
def create_app() -> FastAPI:
    app = FastAPI(...)
    configure_middleware(app)
    include_routers(app)
    return app
```

### Repository Pattern

Database access through repository classes (to be implemented):

```python
class UserRepository:
    def __init__(self, db_session: Session):
        self.db = db_session

    def find_by_id(self, user_id: int) -> Optional[User]:
        return self.db.query(User).filter(User.id == user_id).first()
```

### Service Provider Pattern

Service providers for organizing service registration:

```python
class DatabaseServiceProvider(ServiceProvider):
    def register(self, container: Container) -> None:
        container.register_singleton(Session, create_db_session)
        container.register_transient(UserRepository, UserRepository)
```

## Data Flow

### Request Flow

1. **Request Reception**: FastAPI receives HTTP request
2. **Middleware Processing**: Logging, CORS, security headers
3. **Route Matching**: FastAPI matches request to route handler
4. **Dependency Resolution**: FastAPI resolves dependencies
5. **Business Logic**: Service layer processes request
6. **Database Operations**: Repository layer handles data access
7. **Response Generation**: Response created and sent through middleware

### NER System Pipeline

The NER system follows this processing pipeline:

```
Input Event → NER Service → Entity Extraction → Relationship Extraction →
Pattern Engine → Relationship Analyzer → Scenario Analyzer → Output
```

**Relationship Analyzer** computes relationship judgments by:
1. Extracting contextual features (history, emotions, triggers, risk, etc.)
2. Computing numeric polarity score (-1.0 to +1.0)
3. Classifying relationship label (supportive, cooperative, neutral, competitive, adversarial, manipulative, ambiguous)
4. Calculating confidence and generating explanations

See `relationship_analyzer_design.md` for detailed design.

### Application Startup Flow

1. **Configuration Loading**: Environment variables and settings loaded
2. **Container Setup**: Dependency injection container configured
3. **Database Initialization**: Connection established and migrations run
4. **Service Registration**: All services registered in container
5. **Server Start**: FastAPI server starts listening for requests

## Configuration Management

### Environment-Based Configuration

The framework supports multiple environments:

- **Development**: Debug mode enabled, verbose logging
- **Staging**: Production-like settings with debug features
- **Production**: Optimized for performance and security

### Configuration Hierarchy

1. Default values in code
2. Environment variables
3. `.env` file values
4. Runtime overrides (CLI arguments)

## Security Architecture

### Authentication Flow

1. **Login Request**: User provides credentials
2. **Credential Validation**: Password verified against hash
3. **Token Generation**: JWT access and refresh tokens created
4. **Token Storage**: Tokens stored securely on client
5. **Authenticated Requests**: Access token sent in Authorization header

### Authorization Model

- **Role-Based Access Control**: Users assigned roles/permissions
- **Resource-Based Authorization**: Permissions checked per resource
- **JWT Claims**: User identity and permissions encoded in token

## Error Handling Strategy

### Exception Hierarchy

```
FrameworkException
├── ConfigurationError
├── DatabaseError
├── ValidationError
├── AuthenticationError
├── AuthorizationError
├── NotFoundError
├── ConflictError
├── RateLimitError
└── ExternalServiceError
```

### Error Response Format

```json
{
  "error": "ValidationError",
  "message": "Invalid request data",
  "error_code": "VALIDATION_FAILED",
  "details": {
    "field": "email",
    "issue": "Invalid format"
  }
}
```

## Testing Strategy

### Test Types

- **Unit Tests**: Individual component testing
- **Integration Tests**: Component interaction testing
- **API Tests**: Endpoint testing with HTTP requests
- **Database Tests**: Repository and model testing

### Test Organization

```
tests/
├── unit/           # Fast, isolated tests
├── integration/    # Slower, component tests
├── conftest.py     # Shared fixtures and configuration
└── fixtures/       # Test data and utilities
```

## Performance Considerations

### Database Optimization

- **Connection Pooling**: Reuse database connections
- **Query Optimization**: Efficient queries with proper indexing
- **Caching**: Redis integration for frequently accessed data

### API Performance

- **Async Processing**: Non-blocking request handling
- **Response Compression**: Gzip compression for large responses
- **Rate Limiting**: Prevent abuse and ensure fair usage

### Memory Management

- **Dependency Lifecycle**: Proper service lifecycle management
- **Resource Cleanup**: Automatic cleanup of database connections
- **Lazy Loading**: Load resources only when needed

## Scalability Patterns

### Horizontal Scaling

- **Stateless Design**: Services designed to be stateless
- **Load Balancing**: Multiple server instances behind load balancer
- **Database Sharding**: Partition data across multiple databases

### Vertical Scaling

- **Resource Optimization**: Efficient resource utilization
- **Caching Layers**: Multiple levels of caching
- **Background Processing**: Async task processing with Celery

## Monitoring and Observability

### Logging Strategy

- **Structured Logging**: JSON-formatted logs with context
- **Log Levels**: DEBUG, INFO, WARNING, ERROR, CRITICAL
- **Log Rotation**: Automatic log file rotation and retention

### Health Checks

- **Application Health**: Basic application status
- **Dependency Health**: Database and external service status
- **Resource Health**: Memory, CPU, and disk usage

### Metrics Collection

- **Request Metrics**: Response times, error rates
- **Business Metrics**: User activity, feature usage
- **System Metrics**: Resource utilization

## Deployment Architecture

### Container Strategy

```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY src/ ./src/
CMD ["python", "-m", "src.cli.main", "serve"]
```

### Environment Configuration

- **Development**: Local development with hot reload
- **Staging**: Pre-production testing environment
- **Production**: Optimized for security and performance

## Future Enhancements

### Planned Features

- **GraphQL Support**: GraphQL API endpoint
- **WebSocket Support**: Real-time communication
- **Event System**: Event-driven architecture
- **Plugin System**: Extensible plugin architecture
- **Multi-tenancy**: Support for multiple organizations

### Technology Roadmap

- **Message Queues**: RabbitMQ or Apache Kafka integration
- **Search Engine**: Elasticsearch integration
- **File Storage**: S3 or MinIO integration
- **Monitoring**: Prometheus and Grafana integration
