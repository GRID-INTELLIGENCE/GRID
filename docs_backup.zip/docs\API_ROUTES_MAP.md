# Mothership API Routes Comprehensive Map

## Overview

The Mothership Cockpit FastAPI application exposes a comprehensive REST API with multiple router modules. Routes are dynamically loaded from `config/api_routes.yaml` with fallback to hardcoded defaults.

## Base Configuration

- **Base Prefix**: `/api/v1`
- **Configuration**: `config/api_routes.yaml`
- **Router Factory**: `application.mothership.routers.create_api_router()`

## Router Modules

### 1. Health Router (`health.py`)

**Base Path**: `/api/v1/health`  
**Tags**: `["health"]`

#### Endpoints

1. **GET `/api/v1/health/health`**
   - **Summary**: Comprehensive health check
   - **Response**: `ApiResponse[HealthCheckResponse]`
   - **Checks**: Cockpit service, state store, components, critical alerts
   - **Returns**: Status, version, uptime, checks dict

2. **GET `/api/v1/health/live`**
   - **Summary**: Kubernetes liveness probe
   - **Response**: `LivenessResponse`
   - **Purpose**: Minimal check that service is alive (not deadlocked)
   - **Always returns**: `200 OK` if process running

3. **GET `/api/v1/health/ready`**
   - **Summary**: Kubernetes readiness probe
   - **Response**: `ReadinessResponse`
   - **Checks**: Cockpit started, state accessible, integrations
   - **Status**: `200 OK` if ready, `503 Service Unavailable` if not

4. **GET `/api/v1/health/startup`**
   - **Summary**: Kubernetes startup probe
   - **Response**: `Dict[str, Any]`
   - **Purpose**: Indicates service has completed startup
   - **Status**: `200 OK` if started, `503` if not

5. **GET `/api/v1/health/version`**
   - **Summary**: Version information
   - **Response**: `Dict[str, Any]`
   - **Returns**: App name, version, environment, debug flag, Python version

6. **GET `/api/v1/health/security`**
   - **Summary**: Security health check
   - **Response**: `ApiResponse[SecurityHealthResponse]`
   - **Purpose**: Verify API security configuration against factory defaults
   - **Checks**: CORS, security headers, authentication, rate limiting, etc.

7. **GET `/api/v1/health/skills`**
   - **Summary**: Skills system health check
   - **Response**: Skills health metrics

8. **GET `/api/v1/health/intelligence`**
   - **Summary**: Intelligence system health check
   - **Response**: Intelligence system metrics

9. **GET `/api/v1/health/circuit-breaker`**
   - **Summary**: Circuit breaker status
   - **Response**: Circuit breaker metrics and status

### 2. Agentic Router (`agentic.py`)

**Base Path**: `/api/v1/agentic`  
**Tags**: `["agentic"]`  
**Authentication**: Required (`RequiredAuth`)

#### Endpoints

1. **POST `/api/v1/agentic/cases`**
   - **Summary**: Create new case (receptionist intake)
   - **Status**: `201 Created`
   - **Request**: `CaseCreateRequest`
   - **Response**: `CaseResponse`
   - **Purpose**: Receives raw input, processes through receptionist workflow
   - **Events Emitted**:
     - `case.created`
     - `case.categorized`
     - `case.reference_generated`

2. **GET `/api/v1/agentic/cases/{case_id}`**
   - **Summary**: Get case status and details
   - **Response**: `CaseResponse`
   - **Returns**: Case status, category, priority, confidence, events, timestamps

3. **POST `/api/v1/agentic/cases/{case_id}/enrich`**
   - **Summary**: Enrich existing case with additional input
   - **Request**: `CaseEnrichRequest`
   - **Response**: `CaseResponse`
   - **Purpose**: Add context to existing case

4. **POST `/api/v1/agentic/cases/{case_id}/execute`**
   - **Summary**: Execute case (lawyer phase)
   - **Request**: `CaseExecuteRequest`
   - **Response**: `CaseResponse`
   - **Purpose**: Execute case through lawyer workflow

5. **POST `/api/v1/agentic/cases/{case_id}/execute-iterative`**
   - **Summary**: Execute iterative lawyer phase
   - **Purpose**: Iterative execution for complex cases

6. **GET `/api/v1/agentic/cases/{case_id}/reference`**
   - **Summary**: Get case reference file contents
   - **Response**: Reference file contents

7. **GET `/api/v1/agentic/experience`**
   - **Summary**: Get agent experience metrics
   - **Response**: `AgentExperienceResponse`
   - **Returns**: Aggregate experience data across all cases

### 3. Cockpit Router (`cockpit.py`)

**Base Path**: `/api/v1/cockpit` (implicit via state endpoints)  
**Authentication**: Varies by endpoint

#### Endpoints

1. **GET `/api/v1/health`** (also in health router)
   - **Summary**: Health check
   - **Auth**: None
   - **Response**: `HealthCheckResponse`

2. **GET `/api/v1/ready`**
   - **Summary**: Readiness probe
   - **Auth**: None
   - **Response**: `ReadinessResponse`

3. **GET `/api/v1/live`**
   - **Summary**: Liveness probe
   - **Auth**: None
   - **Response**: `LivenessResponse`

4. **GET `/api/v1/state`**
   - **Summary**: Get cockpit state
   - **Auth**: `Auth` (optional)
   - **Response**: `ApiResponse[CockpitStateResponse]`
   - **Returns**: State summary, mode, version, uptime, summary metrics

5. **GET `/api/v1/state/full`**
   - **Summary**: Get full cockpit state
   - **Auth**: `RequiredAuth`
   - **Response**: `ApiResponse[Dict[str, Any]]`
   - **Returns**: Complete state with all entities

6. **GET `/api/v1/state/components`**
   - **Summary**: List all components
   - **Response**: Component list

7. **GET `/api/v1/state/operations`**
   - **Summary**: List all operations
   - **Response**: Operation list

8. **GET `/api/v1/state/alerts`**
   - **Summary**: List all alerts
   - **Response**: Alert list

9. **GET `/api/v1/state/sessions`**
   - **Summary**: List all sessions
   - **Response**: Session list

10. **PUT `/api/v1/state/mode`**
    - **Summary**: Update operation mode
    - **Auth**: `WriteAuth`
    - **Request**: `CockpitModeUpdateRequest`
    - **Response**: Mode change response

11. **POST `/api/v1/state/components/register`**
    - **Summary**: Register new component
    - **Auth**: `WriteAuth`

12. **POST `/api/v1/state/alerts/create`**
    - **Summary**: Create alert
    - **Auth**: `WriteAuth`

13. **GET `/api/v1/state/diagnostics`**
    - **Summary**: Run system diagnostics
    - **Response**: `DiagnosticsResponse`

### 4. Authentication Router (`auth.py`)

**Base Path**: `/api/v1/auth`  
**Tags**: `["auth"]`

#### Endpoints

1. **POST `/api/v1/auth/login`**
   - **Summary**: User login
   - **Request**: Login credentials
   - **Response**: `ApiResponse[TokenResponse]`
   - **Returns**: JWT access token and refresh token

2. **POST `/api/v1/auth/refresh`**
   - **Summary**: Refresh access token
   - **Request**: Refresh token
   - **Response**: `ApiResponse[RefreshResponse]`
   - **Returns**: New access token

3. **GET `/api/v1/auth/validate`**
   - **Summary**: Validate token
   - **Response**: `ApiResponse[ValidateResponse]`
   - **Returns**: Token validity and user info

4. **POST `/api/v1/auth/logout`**
   - **Summary**: User logout
   - **Response**: `ApiResponse[Dict[str, Any]]`
   - **Purpose**: Invalidate token

### 5. Payment Router (`payment.py`)

**Base Path**: `/api/v1/payment`  
**Tags**: `["payment"]`  
**Authentication**: Required

#### Endpoints

1. **POST `/api/v1/payment/create`**
   - **Summary**: Create payment
   - **Status**: `201 Created`
   - **Response**: `CreatePaymentResponse`

2. **POST `/api/v1/payment/webhook`**
   - **Summary**: Payment webhook (Stripe)
   - **Status**: `200 OK`
   - **Purpose**: Receive webhook events from payment provider

3. **GET `/api/v1/payment/transaction/{transaction_id}`**
   - **Summary**: Get transaction details
   - **Response**: `PaymentTransactionResponse`

4. **POST `/api/v1/payment/refund`**
   - **Summary**: Process refund
   - **Status**: `201 Created`
   - **Response**: `RefundResponse`

5. **POST `/api/v1/payment/subscription/create`**
   - **Summary**: Create subscription
   - **Status**: `201 Created`
   - **Response**: `SubscriptionResponse`

6. **POST `/api/v1/payment/subscription/cancel`**
   - **Summary**: Cancel subscription
   - **Response**: `SubscriptionResponse`

7. **GET `/api/v1/payment/subscription/{subscription_id}`**
   - **Summary**: Get subscription details
   - **Response**: `SubscriptionResponse`

8. **GET `/api/v1/payment/subscriptions`**
   - **Summary**: List subscriptions
   - **Response**: `List[SubscriptionResponse]`

### 6. Billing Router (`billing.py`)

**Base Path**: `/api/v1/billing`  
**Tags**: `["billing"]`

#### Endpoints

1. **GET `/api/v1/billing/usage`**
   - **Summary**: Get usage summary
   - **Response**: Usage summary with metrics

2. **GET `/api/v1/billing/invoices`**
   - **Summary**: List invoices
   - **Response**: `List[InvoiceResponse]`

3. **GET `/api/v1/billing/invoices/{invoice_id}`**
   - **Summary**: Get invoice details
   - **Response**: `InvoiceResponse`

### 7. Navigation Router (`navigation.py`)

**Base Path**: `/api/v1/navigation`

#### Endpoints

1. **POST `/api/v1/navigation/plan`**
   - **Summary**: Generate navigation plan
   - **Request**: Navigation request
   - **Response**: `ApiResponse[NavigationPlanOut]`

2. **POST `/api/v1/navigation/decision`**
   - **Summary**: Make navigation decision
   - **Request**: Decision request
   - **Response**: `ApiResponse[DecisionResponseOut]`

### 8. Navigation Simple Router (`navigation_simple.py`)

**Base Path**: `/api/v1/navigation`  
**Tags**: `["navigation"]`

#### Endpoints

1. **POST `/api/v1/navigation/plan`**
   - **Summary**: Generate navigation plan (simple)
   - **Response**: `ApiResponse[NavigationPlan]`

2. **POST `/api/v1/navigation/decision`**
   - **Summary**: Make navigation decision (simple)
   - **Response**: `ApiResponse[Dict[str, Any]]`

3. **POST `/api/v1/navigation/plan-stream`**
   - **Summary**: Stream navigation plan (SSE)
   - **Response**: `EventSourceResponse`
   - **Purpose**: Server-sent events for real-time plan updates

4. **GET `/api/v1/navigation/plan-stream`**
   - **Summary**: Get navigation plan stream (SSE)
   - **Response**: `EventSourceResponse`

### 9. Intelligence Router (`intelligence.py`)

**Base Path**: `/api/v1/intelligence`  
**Prefix**: `/intelligence` (configured)

#### Endpoints

1. **POST `/api/v1/intelligence/process`**
   - **Summary**: Process input through intelligence pipeline
   - **Request**: Intelligence request with data and context
   - **Response**: `ApiResponse[Dict[str, Any]]`
   - **Purpose**: Process data through GRID intelligence system
   - **Returns**: Processed result with interaction count

### 10. Resonance Router (`application.resonance.api.router`)

**Base Path**: `/api/v1/resonance`  
**Prefix**: `/resonance`  
**Tags**: `["resonance"]`

#### Endpoints

1. **POST `/api/v1/resonance/process`**
   - **Summary**: Process activity through resonance system
   - **Request**: `ActivityProcessRequest`
   - **Response**: `ResonanceResponse`

2. **POST `/api/v1/resonance/context`**
   - **Summary**: Get context snapshot
   - **Response**: `ContextResponse`

3. **POST `/api/v1/resonance/triage`**
   - **Summary**: Path triage analysis
   - **Response**: `PathTriageResponse`

4. **POST `/api/v1/resonance/step`** (definitive endpoint)
   - **Summary**: Definitive step processing
   - **Request**: `DefinitiveStepRequest`
   - **Response**: `DefinitiveStepResponse`
   - **Feature Flag**: `RESONANCE_DEFINITIVE_ENABLED` (default: true)

5. **POST `/api/v1/resonance/choice`**
   - **Summary**: Definitive choice processing
   - **Response**: `DefinitiveChoiceResponse`

6. **GET `/api/v1/resonance/events`**
   - **Summary**: List activity events
   - **Response**: `ActivityEventsResponse`

7. **GET `/api/v1/resonance/usecases`**
   - **Summary**: List use cases
   - **Response**: `List[UseCaseResponse]`

8. **GET `/api/v1/resonance/faqs`**
   - **Summary**: List FAQs
   - **Response**: `List[FAQItemResponse]`

9. **WebSocket `/api/v1/resonance/ws`**
   - **Summary**: WebSocket endpoint for real-time processing
   - **Purpose**: Real-time activity resonance processing

10. **Performance Sub-router** (`performance.py`)
    - **GET `/api/v1/resonance/performance`**: Performance metrics
    - Additional performance endpoints

### 11. Canvas Router (`application.canvas.api`)

**Base Path**: `/api/v1/canvas`

#### Endpoints

- Canvas integration endpoints (Wheel, Territory Map, etc.)
- Routing and relevance scoring
- Resonance adapter integration

### 12. Skills Router (`application.skills.api`)

**Base Path**: `/api/v1/skills`  
**Tags**: `["skills"]`

#### Endpoints

1. **GET `/api/v1/skills/health`**
   - **Summary**: Skills health status
   - **Query Params**: `status_filter`, `min_executions`
   - **Response**: `Dict[str, List[SkillHealthResponse]]`
   - **Returns**: Health metrics for all registered skills

2. **GET `/api/v1/skills/intelligence/{skill_id}`**
   - **Summary**: Detailed intelligence for specific skill
   - **Response**: Skill intelligence details with patterns
   - **Returns**: Summary, patterns, timestamp

3. **GET `/api/v1/skills/signal-quality`**
   - **Summary**: Global signal quality metrics
   - **Response**: NSR (Noise-to-Signal Ratio) details
   - **Returns**: NSR ratio, noise count, signal count, threshold

4. **GET `/api/v1/skills/diagnostics`**
   - **Summary**: Comprehensive system diagnostics
   - **Response**: Full diagnostic report
   - **Returns**: System health report from `SkillsDiagnostics`

### 13. AGENT Router (`grid.AGENT.api.router`)

**Base Path**: `/api/v1/agent`  
**Status**: Disabled by default (`enabled: false` in config)

#### Endpoints

- Agent-specific endpoints (when enabled)

## Router Registration Flow

1. **Load Configuration**: `_load_api_routes_config()` reads `config/api_routes.yaml`
2. **Fallback**: If config not found, uses hardcoded default specs
3. **Module Import**: For each enabled router spec:
   - Extracts module path and attribute name
   - Imports router object via `_import_router()`
   - Includes router with optional prefix and tags
4. **Router Assembly**: All routers combined into single `APIRouter` with base prefix

## Authentication Levels

1. **No Auth**: Public endpoints (health, liveness, readiness)
2. **Optional Auth** (`Auth`): Some state endpoints
3. **Required Auth** (`RequiredAuth`): Most API endpoints
4. **Write Auth** (`WriteAuth`): State modification endpoints

## Response Patterns

### Standard Response
```python
ApiResponse[T](
    success: bool,
    data: T,
    message: Optional[str],
    request_id: Optional[str]
)
```

### Error Response
```python
ApiResponse[None](
    success: false,
    error: Dict[str, Any],
    request_id: Optional[str],
    timestamp: str
)
```

## WebSocket Endpoints

1. **Resonance WebSocket**: `/api/v1/resonance/ws`
   - Real-time activity processing
   - Bidirectional communication

## Server-Sent Events (SSE)

1. **Navigation Plan Stream**: 
   - `POST /api/v1/navigation/plan-stream`
   - `GET /api/v1/navigation/plan-stream`
   - Real-time plan updates

## Feature Flags

- `RESONANCE_DEFINITIVE_ENABLED`: Controls definitive resonance endpoints (default: true)

## API Versioning

- Current version: `v1` (via `/api/v1` prefix)
- Resonance API version: `1.0.0` (metadata)
- Future: Versioning via header or URL path

## Configuration File Structure

```yaml
__schema__: 2026.1
prefix: "/api/v1"
routers:
  - module: "application.mothership.routers.auth:router"
    enabled: true
  - module: "application.mothership.routers.navigation_simple:router"
    enabled: true
    stream: false
    hooks:
      pre_import: "validate_streaming_capability"
  - module: "application.resonance.api.router:router"
    prefix: "/resonance"
    tags: ["resonance"]
    enabled: true
```

## Middleware

All routes pass through:
1. **CORS Middleware**: Cross-origin resource sharing
2. **GZip Middleware**: Response compression
3. **Security Middleware**: Security headers, API sentinels
4. **Rate Limiting**: Redis-based rate limiting
5. **Circuit Breaker**: Failure detection and isolation
6. **Usage Tracking**: Request analytics
7. **Stream Monitor**: Streaming response monitoring

## Observability

All endpoints support:
- **Request ID**: Traceability via request ID header
- **Structured Logging**: JSON-formatted logs
- **Metrics**: Prometheus metrics export
- **Tracing**: Distributed tracing (when enabled)
- **Health Checks**: Comprehensive health monitoring
