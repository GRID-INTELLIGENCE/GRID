# Database Schema Documentation

## Overview

GRID uses SQLAlchemy 2.0 (async) with Alembic for migrations. The database schema supports multiple domains: agentic system, billing, cockpit state, and audit logging.

## Base Configuration

**ORM**: SQLAlchemy 2.0 (async)  
**Migrations**: Alembic  
**Database**: Databricks (primary), SQLite (local/skills)  
**Connection**: Async via `asyncpg` for PostgreSQL-like databases

## Schema Structure

### Base Model (`models_base.py`)

**Base Class**: `Base` (declarative base)

**Features**:
- Standardized table structure
- Timestamps (created_at, updated_at)
- Soft deletes (optional)
- JSON columns support

## Tables

### 1. Agentic System Tables

#### `agentic_cases` (`models_agentic.py`)

**Purpose**: Store agentic cases (case management system).

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `case_id` | String(255) | No | - | Primary key, unique case identifier |
| `raw_input` | Text | No | - | Original raw user input |
| `user_id` | String(255) | Yes | NULL | User identifier |
| `category` | String(100) | Yes | NULL | Case category |
| `priority` | String(50) | Yes | "medium" | Case priority (low, medium, high, critical) |
| `confidence` | Float | Yes | NULL | Classification confidence score (0.0-1.0) |
| `structured_data` | JSON | Yes | NULL | Structured case data from filing system |
| `labels` | JSON | Yes | NULL | Case labels (array) |
| `keywords` | JSON | Yes | NULL | Extracted keywords (array) |
| `entities` | JSON | Yes | NULL | Extracted entities (array) |
| `relationships` | JSON | Yes | NULL | Detected relationships (array) |
| `reference_file_path` | String(500) | Yes | NULL | Path to reference file |
| `status` | String(50) | No | "created" | Case status: created, categorized, reference_generated, executed, completed |
| `agent_role` | String(100) | Yes | NULL | Agent role used for execution |
| `task` | String(100) | Yes | NULL | Task executed |
| `outcome` | String(50) | Yes | NULL | Case outcome: success, partial, failure |
| `solution` | Text | Yes | NULL | Solution applied |
| `agent_experience` | JSON | Yes | NULL | Agent experience data |
| `created_at` | DateTime | No | utcnow() | Case creation timestamp |
| `updated_at` | DateTime | Yes | NULL | Last update timestamp (auto-update) |
| `completed_at` | DateTime | Yes | NULL | Completion timestamp |
| `execution_time_seconds` | Float | Yes | NULL | Execution time in seconds |

**Indexes**:
- Primary key: `case_id`
- Index on: `user_id`, `category`, `status`, `created_at`

**Relationships**: None (standalone table)

**Model Class**: `AgenticCase`

**Methods**:
- `to_dict()`: Convert model to dictionary

### 2. Billing Tables

#### `api_keys` (`models_billing.py`)

**Purpose**: Store API keys for authentication.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `key_id` | String(255) | No | - | Primary key, unique key identifier |
| `key_value` | String(255) | No | - | Encrypted API key value |
| `user_id` | String(255) | Yes | NULL | User identifier (foreign key) |
| `name` | String(255) | Yes | NULL | Key name/description |
| `scopes` | JSON | Yes | NULL | Key scopes/permissions (array) |
| `rate_limit` | Integer | Yes | 1000 | Rate limit per hour |
| `is_active` | Boolean | No | True | Whether key is active |
| `expires_at` | DateTime | Yes | NULL | Expiration timestamp |
| `last_used_at` | DateTime | Yes | NULL | Last usage timestamp |
| `created_at` | DateTime | No | utcnow() | Creation timestamp |
| `updated_at` | DateTime | Yes | NULL | Last update timestamp |

**Model Class**: `APIKeyRow`

#### `usage_records` (`models_billing.py`)

**Purpose**: Track API usage for billing.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `record_id` | String(255) | No | - | Primary key, unique record identifier |
| `user_id` | String(255) | Yes | NULL | User identifier |
| `api_key_id` | String(255) | Yes | NULL | API key identifier (foreign key) |
| `endpoint` | String(255) | Yes | NULL | API endpoint |
| `method` | String(10) | Yes | NULL | HTTP method |
| `status_code` | Integer | Yes | NULL | HTTP status code |
| `request_size_bytes` | Integer | Yes | NULL | Request size in bytes |
| `response_size_bytes` | Integer | Yes | NULL | Response size in bytes |
| `duration_ms` | Integer | Yes | NULL | Request duration in milliseconds |
| `token_count` | Integer | Yes | NULL | Token count (if applicable) |
| `cost_usd` | Float | Yes | NULL | Cost in USD |
| `timestamp` | DateTime | No | utcnow() | Request timestamp |

**Model Class**: `UsageRecordRow`

#### `payment_transactions` (`models_billing.py`)

**Purpose**: Store payment transactions.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `transaction_id` | String(255) | No | - | Primary key, unique transaction identifier |
| `user_id` | String(255) | Yes | NULL | User identifier |
| `amount_cents` | Integer | No | - | Amount in cents |
| `currency` | String(3) | No | "USD" | Currency code |
| `status` | String(50) | No | "pending" | Transaction status: pending, completed, failed, refunded |
| `payment_method_id` | String(255) | Yes | NULL | Payment method identifier |
| `stripe_payment_intent_id` | String(255) | Yes | NULL | Stripe payment intent ID |
| `stripe_charge_id` | String(255) | Yes | NULL | Stripe charge ID |
| `metadata` | JSON | Yes | NULL | Additional metadata |
| `created_at` | DateTime | No | utcnow() | Creation timestamp |
| `updated_at` | DateTime | Yes | NULL | Last update timestamp |
| `completed_at` | DateTime | Yes | NULL | Completion timestamp |

**Model Class**: `PaymentTransactionRow`

#### `subscriptions` (`models_billing.py`)

**Purpose**: Store user subscriptions.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `subscription_id` | String(255) | No | - | Primary key, unique subscription identifier |
| `user_id` | String(255) | Yes | NULL | User identifier |
| `plan_id` | String(255) | Yes | NULL | Plan identifier |
| `status` | String(50) | No | "active" | Subscription status: active, canceled, expired, past_due |
| `stripe_subscription_id` | String(255) | Yes | NULL | Stripe subscription ID |
| `current_period_start` | DateTime | Yes | NULL | Current period start |
| `current_period_end` | DateTime | Yes | NULL | Current period end |
| `cancel_at_period_end` | Boolean | No | False | Whether to cancel at period end |
| `canceled_at` | DateTime | Yes | NULL | Cancellation timestamp |
| `metadata` | JSON | Yes | NULL | Additional metadata |
| `created_at` | DateTime | No | utcnow() | Creation timestamp |
| `updated_at` | DateTime | Yes | NULL | Last update timestamp |

**Model Class**: `SubscriptionRow`

#### `invoices` (`models_billing.py`)

**Purpose**: Store invoices.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `invoice_id` | String(255) | No | - | Primary key, unique invoice identifier |
| `user_id` | String(255) | Yes | NULL | User identifier |
| `subscription_id` | String(255) | Yes | NULL | Subscription identifier (foreign key) |
| `amount_cents` | Integer | No | - | Amount in cents |
| `currency` | String(3) | No | "USD" | Currency code |
| `status` | String(50) | No | "draft" | Invoice status: draft, open, paid, void |
| `stripe_invoice_id` | String(255) | Yes | NULL | Stripe invoice ID |
| `invoice_pdf_url` | String(500) | Yes | NULL | Invoice PDF URL |
| `hosted_invoice_url` | String(500) | Yes | NULL | Hosted invoice URL |
| `period_start` | DateTime | Yes | NULL | Invoice period start |
| `period_end` | DateTime | Yes | NULL | Invoice period end |
| `due_date` | DateTime | Yes | NULL | Due date |
| `paid_at` | DateTime | Yes | NULL | Payment timestamp |
| `metadata` | JSON | Yes | NULL | Additional metadata |
| `created_at` | DateTime | No | utcnow() | Creation timestamp |
| `updated_at` | DateTime | Yes | NULL | Last update timestamp |

**Model Class**: `InvoiceRow`

### 3. Cockpit State Tables

#### `cockpit_state` (`models_cockpit.py`)

**Purpose**: Store cockpit system state.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `state_id` | String(255) | No | - | Primary key, unique state identifier |
| `state` | String(50) | No | "offline" | System state: offline, initializing, online, degraded, maintenance |
| `mode` | String(50) | No | "normal" | Operation mode: normal, emergency, maintenance |
| `version` | String(50) | Yes | NULL | System version |
| `uptime_seconds` | Float | No | 0.0 | Uptime in seconds |
| `started_at` | DateTime | Yes | NULL | Start timestamp |
| `metadata` | JSON | Yes | NULL | Additional metadata |
| `updated_at` | DateTime | No | utcnow() | Last update timestamp (auto-update) |

**Model Class**: `CockpitStateRow`

#### `cockpit_sessions` (`models_cockpit.py`)

**Purpose**: Store cockpit sessions.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `session_id` | String(255) | No | - | Primary key, unique session identifier |
| `user_id` | String(255) | Yes | NULL | User identifier |
| `state_id` | String(255) | Yes | NULL | State identifier (foreign key) |
| `status` | String(50) | No | "active" | Session status: active, inactive, terminated |
| `metadata` | JSON | Yes | NULL | Additional metadata |
| `created_at` | DateTime | No | utcnow() | Creation timestamp |
| `updated_at` | DateTime | Yes | NULL | Last update timestamp |
| `expires_at` | DateTime | Yes | NULL | Expiration timestamp |

**Model Class**: `CockpitSessionRow`

#### `cockpit_operations` (`models_cockpit.py`)

**Purpose**: Store cockpit operations/tasks.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `operation_id` | String(255) | No | - | Primary key, unique operation identifier |
| `session_id` | String(255) | Yes | NULL | Session identifier (foreign key) |
| `name` | String(255) | Yes | NULL | Operation name |
| `status` | String(50) | No | "pending" | Operation status: pending, queued, running, completed, failed |
| `priority` | Integer | No | 0 | Priority (higher = more important) |
| `metadata` | JSON | Yes | NULL | Additional metadata |
| `created_at` | DateTime | No | utcnow() | Creation timestamp |
| `updated_at` | DateTime | Yes | NULL | Last update timestamp |
| `started_at` | DateTime | Yes | NULL | Start timestamp |
| `completed_at` | DateTime | Yes | NULL | Completion timestamp |

**Model Class**: `CockpitOperationRow`

#### `cockpit_components` (`models_cockpit.py`)

**Purpose**: Store cockpit components.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `component_id` | String(255) | No | - | Primary key, unique component identifier |
| `state_id` | String(255) | Yes | NULL | State identifier (foreign key) |
| `name` | String(255) | No | - | Component name |
| `type` | String(100) | Yes | NULL | Component type |
| `status` | String(50) | No | "unknown" | Component status: healthy, degraded, unhealthy, unknown |
| `metadata` | JSON | Yes | NULL | Additional metadata |
| `created_at` | DateTime | No | utcnow() | Creation timestamp |
| `updated_at` | DateTime | Yes | NULL | Last update timestamp |

**Model Class**: `CockpitComponentRow`

#### `cockpit_alerts` (`models_cockpit.py`)

**Purpose**: Store cockpit alerts.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `alert_id` | String(255) | No | - | Primary key, unique alert identifier |
| `state_id` | String(255) | Yes | NULL | State identifier (foreign key) |
| `component_id` | String(255) | Yes | NULL | Component identifier (foreign key) |
| `title` | String(255) | No | - | Alert title |
| `message` | Text | Yes | NULL | Alert message |
| `severity` | String(50) | No | "info" | Alert severity: info, warning, error, critical |
| `status` | String(50) | No | "active" | Alert status: active, resolved, acknowledged |
| `is_resolved` | Boolean | No | False | Whether alert is resolved |
| `resolved_at` | DateTime | Yes | NULL | Resolution timestamp |
| `metadata` | JSON | Yes | NULL | Additional metadata |
| `created_at` | DateTime | No | utcnow() | Creation timestamp |
| `updated_at` | DateTime | Yes | NULL | Last update timestamp |

**Model Class**: `CockpitAlertRow`

### 4. Audit Tables

#### `audit_logs` (`models_audit.py`)

**Purpose**: Store audit logs for security and compliance.

**Schema**:

| Column | Type | Nullable | Default | Description |
|--------|------|----------|---------|-------------|
| `log_id` | String(255) | No | - | Primary key, unique log identifier |
| `user_id` | String(255) | Yes | NULL | User identifier |
| `action` | String(100) | No | - | Action performed |
| `resource_type` | String(100) | Yes | NULL | Resource type |
| `resource_id` | String(255) | Yes | NULL | Resource identifier |
| `status` | String(50) | No | "success" | Action status: success, failure, error |
| `ip_address` | String(45) | Yes | NULL | IP address (IPv4 or IPv6) |
| `user_agent` | String(500) | Yes | NULL | User agent string |
| `metadata` | JSON | Yes | NULL | Additional metadata |
| `created_at` | DateTime | No | utcnow() | Creation timestamp |

**Model Class**: `AuditLogRow`

## Skills System Database

### SQLite Database: `data/skills_intelligence.db`

**Purpose**: Store skills execution tracking and intelligence.

**Tables** (via SQLAlchemy ORM):

#### `skill_executions`

| Column | Type | Description |
|--------|------|-------------|
| `id` | Integer | Primary key |
| `skill_id` | String | Skill identifier |
| `timestamp` | Float | Execution timestamp |
| `status` | String | Execution status: success, failure, timeout, partial |
| `input_args` | JSON | Input arguments |
| `output` | JSON | Output result |
| `error` | Text | Error message (if failed) |
| `execution_time_ms` | Float | Execution time in milliseconds |
| `confidence_score` | Float | Confidence score (0.0-1.0) |
| `fallback_used` | Boolean | Whether fallback was used |

#### `skill_intelligence`

| Column | Type | Description |
|--------|------|-------------|
| `id` | Integer | Primary key |
| `skill_id` | String | Skill identifier |
| `decision_type` | String | Decision type |
| `rationale` | Text | Decision rationale |
| `confidence_score` | Float | Confidence score |
| `alternatives` | JSON | Alternative options considered |
| `timestamp` | Float | Decision timestamp |

**Storage Mode**: SQLite WAL (Write-Ahead Logging) for concurrent reads/writes.

**Persistence**: Batched (10 records or 30 seconds).

## Migrations

### Alembic Configuration

**Config File**: `alembic.ini`

**Migration Location**: `application/mothership/db/migrations/`

**Template**: `script.py.mako`

**Environment**: `env.py`

### Migration Workflow

1. **Generate Migration**:
   ```bash
   alembic revision --autogenerate -m "description"
   ```

2. **Review Migration**: Check generated migration file

3. **Apply Migration**:
   ```bash
   alembic upgrade head
   ```

4. **Rollback Migration**:
   ```bash
   alembic downgrade -1
   ```

## Database Connection

### Connection Pool

**Engine**: `application.mothership.db.engine.get_async_sessionmaker()`

**Configuration**:
- Async SQLAlchemy 2.0
- Connection pooling
- Transaction management

### Databricks Integration

**Connector**: `application.mothership.db.databricks_connector.DatabricksConnector`

**Features**:
- Databricks SQL connector
- Async query execution
- Schema management

## Repository Pattern

### Agentic Repository

**Location**: `application.mothership.repositories.agentic.AgenticRepository`

**Methods**:
- `create_case()`: Create case record
- `get_case()`: Get case by ID
- `update_case_status()`: Update case status
- `find_similar_cases()`: Find similar cases

### Database Repository

**Location**: `application.mothership.repositories.db_repos.DatabaseRepository`

**Methods**: Generic CRUD operations

### Payment Repository

**Location**: `application.mothership.repositories.payment.PaymentRepository`

**Methods**:
- Payment transaction operations
- Subscription management
- Invoice operations

## Best Practices

1. **Async Operations**: Use async/await for all database operations
2. **Transactions**: Use context managers for transaction management
3. **Connection Pooling**: Reuse connections via sessionmaker
4. **Error Handling**: Handle database errors gracefully
5. **Migrations**: Always review auto-generated migrations before applying
6. **Indexes**: Add indexes for frequently queried columns
7. **Soft Deletes**: Use soft deletes where appropriate
8. **Audit Logging**: Log all critical operations to audit_logs

## Future Extensions

1. **Read Replicas**: Separate read/write databases
2. **Sharding**: Horizontal scaling via sharding
3. **Event Sourcing**: Complete event history
4. **CQRS**: Separate read/write models
5. **Time-Series Data**: Optimize for time-series queries
