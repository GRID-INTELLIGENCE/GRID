# Weekly Relationship Review – 2025-11-23

**Total Joules (last 7 days):** 0.0
**Total Points (last 7 days):** 10.0

## Reflection Questions
1. Did the system feel supportive this week?
2. Were the points awarded fair for the effort you logged?
3. What could be improved in the feedback you received?

---

# Weekly Relationship Review – 2025-11-23

**Total Joules (last 7 days):** 0.0
**Total Points (last 7 days):** 20.0

## Reflection Questions
1. Did the system feel supportive this week?
2. Were the points awarded fair for the effort you logged?
3. What could be improved in the feedback you received?

---

# Weekly Relationship Review – 2025-11-23

**Total Joules (last 7 days):** 0.0
**Total Points (last 7 days):** 30.0

## Reflection Questions
1. Did the system feel supportive this week?
2. Were the points awarded fair for the effort you logged?
3. What could be improved in the feedback you received?

---

# Weekly Relationship Review – 2025-11-23

**Total Joules (last 7 days):** 0.0
**Total Points (last 7 days):** 40.0

## Reflection Questions
1. Did the system feel supportive this week?
2. Were the points awarded fair for the effort you logged?
3. What could be improved in the feedback you received?

---

# Weekly Relationship Review – 2025-11-24

**Total Joules (last 7 days):** 95.0
**Total Points (last 7 days):** 65.1

## Reflection Questions
1. Did the system feel supportive this week?
2. Were the points awarded fair for the effort you logged?
3. What could be improved in the feedback you received?

---
