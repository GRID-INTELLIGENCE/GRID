# Deployment Guide for Enhanced RAG Server

## Prerequisites

- Python 3.13
- uv package manager
- Linux server (Ubuntu 20.04+ recommended)
- Systemd (for service management)
- 2GB+ RAM
- 10GB+ disk space

## Quick Start

### 1. Clone Repository

```bash
git clone https://github.com/irfankabir02/GRID.git
cd GRID
```

### 2. Set Up Environment

```bash
# Install uv if not present
curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"

# Create virtual environment
uv venv --python 3.13

# Install dependencies
uv sync --group dev --group test
```

### 3. Configure Environment

```bash
# Copy production environment template
cp .env.production.template .env.production

# Edit configuration
nano .env.production
```

Required environment variables:
- `RAG_EMBEDDING_PROVIDER`: huggingface, openai, or cohere
- `RAG_LLM_MODE`: ollama, openai, or cohere
- `OLLAMA_BASE_URL`: http://localhost:11434 (if using Ollama)
- `RAG_VECTOR_STORE_PATH`: Path to vector store

### 4. Run Deployment Script

```bash
# Make script executable
chmod +x scripts/deploy.sh

# Run deployment (requires sudo)
sudo ./scripts/deploy.sh
```

### 5. Verify Deployment

```bash
# Check service status
systemctl status grid-rag-enhanced
systemctl status memory-mcp
systemctl status grid-agentic

# Check logs
journalctl -u grid-rag-enhanced -f
journalctl -u memory-mcp -f
journalctl -u grid-agentic -f

# Test endpoints
curl http://localhost:8002/health
curl http://localhost:8003/health
curl http://localhost:8004/health
```

## Manual Deployment

If the deployment script fails, follow these steps:

### 1. Create Deployment Directory

```bash
sudo mkdir -p /opt/grid-rag-enhanced
sudo chown $USER:$USER /opt/grid-rag-enhanced
```

### 2. Copy Files

```bash
cp -r src/ /opt/grid-rag-enhanced/
cp -r tests/ /opt/grid-rag-enhanced/
cp requirements.txt /opt/grid-rag-enhanced/
cp pyproject.toml /opt/grid-rag-enhanced/
cp -r mcp-setup/ /opt/grid-rag-enhanced/
cp -r workspace/ /opt/grid-rag-enhanced/
```

### 3. Install Dependencies

```bash
cd /opt/grid-rag-enhanced
uv venv --python 3.13
source .venv/bin/activate
uv sync
```

### 4. Create Systemd Services

See `scripts/deploy.sh` for service definitions.

### 5. Start Services

```bash
sudo systemctl start grid-rag-enhanced
sudo systemctl start memory-mcp
sudo systemctl start grid-agentic
```

## GitHub Actions Deployment

The `.github/workflows/deploy.yml` workflow automatically:

1. Runs tests
2. Verifies MCP servers
3. Verifies Ghost Registry handlers
4. Runs performance benchmarks
5. Creates deployment package
6. Uploads deployment artifact

To deploy manually:

```bash
# Trigger workflow
gh workflow run deploy.yml

# Download artifact
gh run download <run-id>

# Extract and deploy
tar -xzf grid-rag-enhanced-*.tar.gz
cd deployment
sudo ./scripts/deploy.sh
```

## Configuration

### Environment Variables

Key environment variables (see `.env.production.template`):

- `RAG_EMBEDDING_PROVIDER`: Embedding model provider
- `RAG_LLM_MODE`: LLM provider mode
- `RAG_VECTOR_STORE_PATH`: Vector store location
- `LOG_LEVEL`: Logging verbosity
- `QUERY_TIMEOUT`: Query timeout in seconds

### Production Configuration

Edit `config/production.yaml` for advanced configuration:

- Server settings
- RAG parameters
- Performance targets
- Security settings
- Monitoring configuration

## Monitoring

### Logs

```bash
# View logs
tail -f /var/log/grid-rag-enhanced/grid-rag-enhanced.log

# Rotate logs (automatic)
logrotate -f /etc/logrotate.d/grid-rag-enhanced
```

### Health Checks

```bash
# Check server health
curl http://localhost:8002/health
curl http://localhost:8003/health
curl http://localhost:8004/health

# Check metrics
curl http://localhost:9090/metrics
```

### Performance Monitoring

```bash
# Run benchmarks
python tests/performance/benchmark_rag_performance.py

# Run load tests
python tests/performance/load_test_rag.py
```

## Troubleshooting

### Service Won't Start

```bash
# Check service status
systemctl status grid-rag-enhanced

# View logs
journalctl -u grid-rag-enhanced -n 100

# Check for errors
journalctl -u grid-rag-enhanced | grep -i error
```

### Port Already in Use

```bash
# Find process using port
sudo lsof -i :8002

# Kill process
sudo kill -9 <PID>
```

### Import Errors

```bash
# Verify Python path
echo $PYTHONPATH

# Test imports
python -c "from grid.mcp.enhanced_rag_server import EnhancedRAGMCPServer"
python -c "from tools.rag.conversational_rag import create_conversational_rag_engine"
```

### Performance Issues

```bash
# Run performance benchmarks
python tests/performance/benchmark_rag_performance.py

# Check memory usage
free -h

# Check CPU usage
top
```

## Rollback

If deployment fails:

```bash
# Stop services
sudo systemctl stop grid-rag-enhanced memory-mcp grid-agentic

# Restore from backup
sudo rm -rf /opt/grid-rag-enhanced/*
sudo cp -r /opt/grid-rag-enhanced-backups/backup-<timestamp>/* /opt/grid-rag-enhanced/

# Restart services
sudo systemctl start grid-rag-enhanced memory-mcp grid-agentic

# Verify
systemctl status grid-rag-enhanced memory-mcp grid-agentic
```

## Performance Targets

After deployment, verify these targets:

- Query Latency (P95): < 500ms
- Session Operations: < 10ms
- Concurrent Queries: 50+
- Success Rate: > 99.9%

Run benchmarks to verify:

```bash
python tests/performance/benchmark_rag_performance.py
```

## Security

### Authentication

Configure JWT authentication in `.env.production`:

```bash
REQUIRE_AUTH=true
AUTH_SECRET=your_secure_secret_here
```

### Rate Limiting

Enabled by default. Configure in `config/production.yaml`:

```yaml
security:
  rate_limiting:
    enabled: true
    queries_per_minute: 100
    burst_size: 10
```

### Input Sanitization

Enabled by default. All inputs are sanitized before processing.

## Support

For issues:

1. Check logs: `/var/log/grid-rag-enhanced/`
2. Run diagnostics: `python tests/performance/benchmark_rag_performance.py`
3. Check documentation: `docs/`
4. Open issue: https://github.com/irfankabir02/GRID/issues
