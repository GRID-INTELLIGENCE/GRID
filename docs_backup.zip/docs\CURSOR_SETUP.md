# Cursor 2.0 Setup and Usage Guide

This guide covers how to use Cursor 2.0 features effectively in the GRID project.

## Overview

GRID uses Cursor 2.0's modular rules system and advanced features for AI-powered development. This setup maximizes Cursor's capabilities while maintaining code quality and consistency.

## Key Features

### Composer (Agent Mode) - `Cmd+I` / `Ctrl+I`

The Composer can plan and execute multi-file changes, run terminal commands, and use Plan Mode for complex tasks.

**Best Practices:**
- Use Plan Mode for complex, multi-step changes
- Provide clear, specific instructions
- Review changes before applying
- Use for refactoring, feature additions, and bug fixes

**Example:**
```
Use Plan Mode to add a new service endpoint for user management.
Follow the API patterns in src/application/mothership/routers/.
```

### Tab (Predictive Edit) - `Tab`

Beyond simple autocomplete; predicts multi-line edits and suggests next steps.

**Best Practices:**
- Accept early suggestions to guide context
- Review diffs before applying
- Use for incremental improvements

### Codebase Chat - `Cmd+L` / `Ctrl+L`

Interact with your entire codebase. The AI uses a local index to understand relationships.

**Best Practices:**
- Ask questions about codebase structure
- Find similar implementations
- Understand relationships between files
- Query patterns and conventions

**Example:**
```
@Codebase How does the navigation service integrate with the backend API?
```

### Plan Mode

A capability within Composer that forces AI to "think" and lay out a roadmap before coding.

**Best Practices:**
- Use for complex, multi-step refactors
- Include Mermaid diagrams for architecture visualization
- Split tasks into clear phases
- Review plan before execution

**Templates:**
- `.cursor/templates/plan/feature_implementation.md`
- `.cursor/templates/plan/refactor_template.md`
- `.cursor/templates/plan/bug_fix_template.md`

## Rules System

GRID uses Cursor 2.0's modular rules system with `.cursor/rules/*.mdc` files.

### Rule Files

Rules are organized by domain:

- `project_identity.mdc` - Project overview
- `local_first.mdc` - Local-only operation rules
- `architecture.mdc` - Architecture constraints
- `python_standards.mdc` - Python coding standards
- `typescript_standards.mdc` - TypeScript standards
- `api_patterns.mdc` - FastAPI patterns
- `testing.mdc` - Testing standards
- `cognitive_layer.mdc` - Cognitive layer integration
- `rag_usage.mdc` - RAG system usage
- `code_generation.mdc` - AI code generation guidelines
- `ai_behavior.mdc` - General AI behavior

### How Rules Work

- Rules are scoped via glob patterns in YAML frontmatter
- Each rule applies only to matching files
- Rules have priorities for conflict resolution
- Rules are automatically loaded by Cursor

**Example:**
```yaml
---
name: "Python Standards"
globs:
  - "**/*.py"
priority: 90
---
```

## Context Management

### .cursorignore

The `.cursorignore` file excludes files/directories from Cursor's indexing to improve performance.

**Included patterns:**
- Build artifacts (`dist/`, `build/`)
- Virtual environments (`.venv/`, `venv/`)
- Cache directories (`__pycache__/`, `.pytest_cache/`)
- Large data files
- Archive directories

### @ Mentions

Use `@` mentions to add context:

- `@Files` - Reference specific files
- `@Folders` - Include folder contents
- `@Docs` - External documentation (FastAPI, Pydantic, etc.)
- `@Web` - Web search results

**Example:**
```
@FastAPI docs Add authentication middleware to the API router
```

## External Documentation (@Docs)

GRID has indexed external documentation:

- **FastAPI**: `https://fastapi.tiangolo.com/`
- **Pydantic**: `https://docs.pydantic.dev/`
- **SQLAlchemy**: `https://docs.sqlalchemy.org/`
- **pytest**: `https://docs.pytest.org/`
- **Ollama**: `https://ollama.ai/docs`
- **ChromaDB**: `https://docs.trychroma.com/`

**Usage:**
```
@Docs FastAPI How do I add rate limiting to an endpoint?
```

## Memory Configuration

Cursor's Memory feature learns project-specific patterns from `.cursor/memories.json`.

**Key Memories:**
- Local-first principle
- Python 3.13.11 requirement
- Layered architecture rules
- Type hints requirement
- Test coverage ≥80%

These memories help Cursor maintain consistency across sessions.

## Background Agents

Background agents can run tasks asynchronously in isolated environments.

**Configuration:** `.cursor/environment.json`

**Available Commands:**
- `install` - Set up environment
- `test` - Run test suite
- `lint` - Run linters
- `format` - Auto-fix formatting
- `start` - Start services

**Usage:**
Use Background Agents for:
- Dependency updates
- Bulk refactoring
- Running test suites
- Code cleanup tasks

## Command Templates

Standardized workflows in `.cursor/commands/`:

- `add_feature.md` - Feature addition workflow
- `fix_bug.md` - Bug fixing workflow
- `refactor_module.md` - Refactoring workflow

**Usage:**
Reference these templates when using Composer for common tasks.

## Best Practices

### 1. Use Plan Mode for Complex Tasks
Always start complex refactors or feature additions with Plan Mode.

### 2. Reference Rules
Mention relevant rule files when asking for changes:
```
Follow the patterns in .cursor/rules/api_patterns.mdc
```

### 3. Query RAG First
Before making changes, query RAG for context:
```bash
python -m tools.rag.cli query "How does authentication work?"
```

### 4. Use @ Mentions
Include relevant files and documentation:
```
@src/application/mothership/routers/auth.py Add OAuth2 support
```

### 5. Test-Driven Development
Ask Cursor to write tests first, then implement:
```
Write a test for user authentication, then implement it
```

### 6. Review Changes
Always review Composer's changes before applying:
- Check type hints
- Verify architecture compliance
- Ensure tests are included
- Validate error handling

## Troubleshooting

### Rules Not Applying

1. Check rule glob patterns match your files
2. Verify rule file format (YAML frontmatter)
3. Ensure rules are in `.cursor/rules/` directory

### Context Issues

1. Check `.cursorignore` isn't excluding needed files
2. Use `@Files` to explicitly include files
3. Query RAG for project context

### Performance Issues

1. Review `.cursorignore` for unnecessary exclusions
2. Exclude large directories from indexing
3. Use specific file mentions instead of broad queries

## Resources

- **Cursor Documentation**: https://docs.cursor.com/
- **Cursor Changelog**: https://cursor.com/changelog
- **Cursor Forum**: https://forum.cursor.com/

## Maintenance

- Review rules quarterly
- Update `.cursorignore` as needed
- Keep external docs indexed
- Monitor Cursor changelog for new features
