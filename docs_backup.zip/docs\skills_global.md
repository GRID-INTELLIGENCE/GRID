# GRID Global Skills Documentation

**Purpose**: Core reusable skills that work across projects. These skills provide fundamental text processing, transformation, and compression capabilities that are independent of GRID-specific services.

## Overview

Global skills are framework-level capabilities that can be used in any project context. They operate on text input and provide structured output without requiring GRID-specific services like RAG, NER, or the knowledge graph.

**Skills Registry**: `src/grid/skills/registry.py`
**Base Protocol**: `src/grid/skills/base.py`

## Skills Registry

**Registry Implementation**: `src/grid/skills/registry.py`
**Base Protocol**: `src/grid/skills/base.py`

### Registry Loading Process

The registry dynamically loads all built-in skills using `importlib`:

```python
def _load_builtin_skills(registry: SkillRegistry) -> None:
    import importlib
    import logging

    skills_to_load = [
        ("youtube_transcript_analyze", ".youtube_transcript_analyze"),
        ("intelligence_git_analyze", ".intelligence_git_analyze"),
        ("rag_query_knowledge", ".rag_query_knowledge"),
        ("patterns_detect_entities", ".patterns_detect_entities"),
        ("analysis_process_context", ".analysis_process_context"),
        ("cross_reference_explain", ".cross_reference_explain"),
        ("compress_articulate", ".compress_articulate"),
        ("context_refine", ".context_refine"),
        ("transform_schema_map", ".transform_schema_map"),
        ("topic_extractor", ".topic_extractor"),
        ("knowledge_capture", ".knowledge_capture"),
    ]

    for name, relative_path in skills_to_load:
        module = importlib.import_module(relative_path, package="grid.skills")
        skill = getattr(module, name)
        registry.register(skill)
```

### Skill Registration Table

| Skill ID | Module Path | Variable Name |
|----------|-------------|---------------|
| `context.refine` | `grid.skills.context_refine` | `context_refine` |
| `transform.schema_map` | `grid.skills.transform_schema_map` | `transform_schema_map` |
| `compress.articulate` | `grid.skills.compress_articulate` | `compress_articulate` |
| `compress.secure` | `grid.skills.compress_secure` | `compress_secure` |
| `cross_reference.explain` | `grid.skills.cross_reference_explain` | `cross_reference_explain` |
| `topic_extractor` | `grid.skills.topic_extractor` | `topic_extractor` |

### CLI Integration

The CLI commands use the registry to list and run skills:

```python
# List skills (src/grid/__main__.py:162-178)
def skills_list_command(args: argparse.Namespace) -> int:
    from grid.skills.registry import default_registry

    payload = {
        "skills": [
            {
                "id": s.id,
                "name": s.name,
                "description": s.description,
            }
            for s in default_registry.list()
        ]
    }

    sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0

# Run skill (src/grid/__main__.py:181-204)
def skills_run_command(args: argparse.Namespace) -> int:
    from grid.skills.registry import default_registry

    skill = default_registry.get(args.skill_id)
    if skill is None:
        raise SystemExit(f"Unknown skill: {args.skill_id}")

    skill_args: Dict[str, Any] = {}
    if args.args_json or args.args_file:
        skill_args.update(_read_json_payload(args.args_json, args.args_file))

    result = skill.run(skill_args)

    sys.stdout.write(json.dumps(result, indent=2, ensure_ascii=False))
    return 0
```

### Registry Usage Examples

```python
from grid.skills.registry import default_registry

# List all available skills
skills = default_registry.list()
for skill in skills:
    print(f"{skill.id}: {skill.name}")

# Get a specific skill
skill = default_registry.get("context.refine")
if skill:
    result = skill.run({"text": "sample text", "use_llm": False})
    print(result)

# Run skill directly
result = default_registry.get("compress.articulate").run({
    "text": "Sample text to compress",
    "max_chars": 100
})
```

## Skills List

1. `context.refine` - Text refinement with pronoun minimization
2. `transform.schema_map` - Schema mapping to structured formats
3. `compress.articulate` - Text compression to character budget
4. `compress.secure` - Secure compression with semantic-technological integration
5. `cross_reference.explain` - Cross-domain explanations (map + compass)
6. `topic_extractor` - Extract discussion topics with wall-board metaphor

---

## 1. `context.refine`

**Purpose**: Refine context into structured, pronoun-minimized text for clarity. Reduces noise in collaboration-oriented text.

### Capabilities

- Removes pronouns and replaces with explicit nouns where possible
- Normalizes whitespace
- Optional LLM mode for higher-quality rewriting with structured sections
- Heuristic fallback mode (no LLM required)

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.context_refine import context_refine
# registry.register(context_refine)
```

### Code Context

```14:66:src/grid/skills/context_refine.py
def _refine(args: Mapping[str, Any]) -> Dict[str, Any]:
    text = args.get("text") or args.get("input")
    if text is None:
        return {
            "skill": "context.refine",
            "status": "error",
            "error": "Missing required parameter: 'text'",
        }

    text = str(text)
    use_llm = bool(args.get("use_llm") or args.get("useLLM"))

    if use_llm:
        try:
            from tools.rag.config import RAGConfig
            from tools.rag.llm.factory import get_llm_provider

            config = RAGConfig.from_env()
            config.ensure_local_only()
            llm = get_llm_provider(config=config)

            prompt = (
                "Rewrite the text into a refined structured form with minimal noise.\n"
                "Rules:\n"
                "- Avoid pronouns. Replace pronouns with explicit nouns where possible.\n"
                "- Prefer bullet points and short sentences.\n"
                "- Preserve technical meaning.\n"
                "- Output sections: Facts, Assumptions, Goals, Constraints, Next actions.\n\n"
                f"TEXT:\n{text}\n"
            )
            out = llm.generate(prompt=prompt, temperature=0.2)
            return {
                "skill": "context.refine",
                "status": "success",
                "output": out.strip(),
            }
        except Exception as e:
            return {
                "skill": "context.refine",
                "status": "error",
                "error": str(e),
            }

    # Heuristic fallback: remove pronouns + normalize whitespace
    cleaned = _PRONOUNS.sub("", text)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    return {
        "skill": "context.refine",
        "status": "success",
        "output": cleaned,
        "note": "Heuristic mode used. Enable use_llm for higher-quality rewriting.",
    }
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `text` | string | Yes | - | Input text to refine (also accepts `input`) |
| `use_llm` | boolean | No | `false` | Enable LLM mode for structured rewriting (requires Ollama) |

### Usage Examples

#### Heuristic Mode (No LLM Required)

```powershell
.\venv\Scripts\python.exe -m grid skills run context.refine --args-json "{text:'I think we should do it because it is important and it will help us. It will also reduce confusion.', use_llm:false}"
```

**Output**:
```json
{
  "skill": "context.refine",
  "status": "success",
  "output": "think should do because is important and will help. will also reduce confusion.",
  "note": "Heuristic mode used. Enable use_llm for higher-quality rewriting."
}
```

#### LLM Mode (Requires Ollama)

```powershell
.\venv\Scripts\python.exe -m grid skills run context.refine --args-json "{text:'I think we should do it because it is important and it will help us.', use_llm:true}"
```

**Output**:
```json
{
  "skill": "context.refine",
  "status": "success",
  "output": "Facts:\n- Action is important\n- Action will help\n\nAssumptions:\n- Action is feasible\n\nGoals:\n- Complete the action\n- Reduce confusion\n\nConstraints:\n- None specified\n\nNext actions:\n- Execute the action"
}
```

### Performance Notes

- **Heuristic mode**: < 10ms (local processing only)
- **LLM mode**: 500ms - 2s (depends on Ollama response time)
- **Character reduction**: Typically 10-30% reduction in text length

---

## 2. `transform.schema_map`

**Purpose**: Transform freeform text into a structured schema. Supports multiple target schemas including default GRID schema, context engineering, resonance, knowledgebase, sensory, and more.

### Capabilities

- Maps unstructured text to predefined schemas
- Supports 10+ target schemas (default, context_engineering, resonance, knowledgebase, sensory, ai_safety, etc.)
- Heuristic-first approach (no LLM required)
- Optional LLM mode for complex mappings
- Output formats: JSON or Markdown

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.transform_schema_map import transform_schema_map
# registry.register(transform_schema_map)
```

### Code Context

```808:813:src/grid/skills/transform_schema_map.py
transform_schema_map = SimpleSkill(
    id="transform.schema_map",
    name="Transform Schema Map",
    description="Transform freeform text into a structured schema (default or custom frameworks)",
    handler=_transform,
)
```

The handler function `_transform` supports multiple schemas defined in `_schema_spec()`:

```41:100:src/grid/skills/transform_schema_map.py
def _schema_spec(name: str) -> Dict[str, Any]:
    key = (name or "").strip().lower()

    if key in {"default", "grid", "facts"}:
        return {
            "name": "default",
            "sections": ["facts", "assumptions", "goals", "constraints", "next_actions"],
            "template": {
                "facts": [],
                "assumptions": [],
                "goals": [],
                "constraints": [],
                "next_actions": [],
            },
        }

    if key in {"sensory", "senses"}:
        return {
            "name": "sensory",
            "sections": [
                "sight",
                "sound",
                "taste",
                "smell",
                "touch",
                "sixth_sense",
                "unified_trigger",
            ],
            "template": {
                "sight": {"element": "", "essence": "", "modes": []},
                "sound": {"element": "", "essence": "", "modes": []},
                "taste": {"element": "", "essence": "", "modes": []},
                "smell": {"element": "", "essence": "", "modes": []},
                "touch": {"element": "", "essence": "", "modes": []},
                "sixth_sense": {"element": "", "essence": "", "modes": []},
                "unified_trigger": {"function": "", "purpose": ""},
            },
        }

    if key in {"resonance"}:
        return {
            "name": "resonance",
            "sections": [
                "principles",
                "activate_mystique",
                "implementation_notes",
            ],
            "template": {
                "principles": [],
                "activate_mystique": {"purpose": "", "how_it_works": [], "why_it_works": [], "examples": []},
                "implementation_notes": [],
            },
        }

    if key in {"ai_safety", "safety", "ai safety"}:
        return {
            "name": "ai_safety",
            "sections": [
                "value_proposition",
                "architecture",
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `text` | string | Yes | - | Freeform text to transform |
| `target_schema` | string | No | `"default"` | Target schema name (default, context_engineering, resonance, knowledgebase, sensory, ai_safety, etc.) |
| `output_format` | string | No | `"json"` | Output format: `"json"` or `"markdown"` |
| `use_llm` | boolean | No | `false` | Enable LLM mode for complex mappings |

### Supported Schemas

- `default` / `grid` / `facts` - Standard GRID schema (facts, assumptions, goals, constraints, next_actions)
- `context_engineering` - Context Engineering Service schema
- `resonance` - Resonance Framework schema
- `knowledgebase` - Shield/Sword knowledgebase schema
- `sensory` / `senses` - Sensory schema (sight, sound, taste, smell, touch, sixth_sense)
- `ai_safety` / `safety` - AI Safety schema
- And more (see `_schema_spec()` function)

### Usage Examples

#### Default Schema (Heuristic)

```powershell
.\venv\Scripts\python.exe -m grid skills run transform.schema_map --args-json "{text:'Context Engineering Service: vector-based indexing, semantic recall, contradiction resolution. Retrieval logic: Primary Recall, Contextual Recall, Contradiction Flagging. Next: integrate thought_signature with StepBloom IF-THEN.', target_schema:'default', output_format:'json', use_llm:false}"
```

#### Context Engineering Schema

```powershell
.\venv\Scripts\python.exe -m grid skills run transform.schema_map --args-json "{text:'Context Engineering Service: vector-based indexing, semantic recall, contradiction resolution. Retrieval logic: Primary Recall, Contextual Recall, Contradiction Flagging. Next: integrate thought_signature with StepBloom IF-THEN.', target_schema:'context_engineering', output_format:'json', use_llm:false}"
```

#### Resonance Schema

```powershell
.\venv\Scripts\python.exe -m grid skills run transform.schema_map --args-json "{text:'The Resonance Framework: 1) Identify core challenges. 2) Break challenges into manageable components. 3) Balance structure and flexibility. Mystique Activation: Purpose: add mentorship. How it works: user selects character. Examples: What would Uncle Iroh say?', target_schema:'resonance', output_format:'json', use_llm:false}"
```

#### Knowledgebase Schema (Shield/Sword)

```powershell
.\venv\Scripts\python.exe -m grid skills run transform.schema_map --args-json "{text:'Shield = vetted safe core. Sword = consequences/access control. Define scope rings + timeframes. Add feedback loops and early alerts.', target_schema:'knowledgebase', output_format:'markdown', use_llm:false}"
```

### Performance Notes

- **Heuristic mode**: 50-200ms (pattern matching and text parsing)
- **LLM mode**: 1-3s (depends on Ollama and text complexity)
- **Schema support**: 10+ predefined schemas, extensible

---

## 3. `compress.articulate`

**Purpose**: Compress and articulate complex text using minimal characters while preserving meaning. Useful for character-budget constraints (e.g., social media, summaries).

### Capabilities

- Compresses text to a strict character budget
- Preserves key concepts and technical meaning
- Avoids pronouns, prefers concrete nouns
- Heuristic fallback (first sentence + trimming)
- LLM mode for semantic-aware compression

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.compress_articulate import compress_articulate
# registry.register(compress_articulate)
```

### Code Context

```8:77:src/grid/skills/compress_articulate.py
def _compress(args: Mapping[str, Any]) -> Dict[str, Any]:
    text = args.get("text") or args.get("concept") or args.get("input")
    if text is None:
        return {
            "skill": "compress.articulate",
            "status": "error",
            "error": "Missing required parameter: 'text' (or 'concept')",
        }

    text = str(text)
    max_chars = int(args.get("max_chars", 280) or 280)
    use_llm = bool(args.get("use_llm") or args.get("useLLM"))

    if max_chars < 50:
        max_chars = 50

    if use_llm:
        try:
            from tools.rag.config import RAGConfig
            from tools.rag.llm.factory import get_llm_provider

            config = RAGConfig.from_env()
            config.ensure_local_only()
            llm = get_llm_provider(config=config)

            prompt = (
                "Rewrite the following content to be maximally clear while using as few characters as possible.\n"
                f"Hard limit: {max_chars} characters.\n"
                "Avoid pronouns if possible. Prefer concrete nouns.\n\n"
                f"CONTENT:\n{text}\n\n"
                "OUTPUT (must be <= limit):"
            )
            out = llm.generate(prompt=prompt, temperature=0.2)
            out = out.strip()
            if len(out) > max_chars:
                out = out[: max_chars - 1].rstrip() + "…"
            return {
                "skill": "compress.articulate",
                "status": "success",
                "max_chars": max_chars,
                "chars": len(out),
                "output": out,
            }
        except Exception as e:
            return {
                "skill": "compress.articulate",
                "status": "error",
                "error": str(e),
            }

    # Heuristic fallback: first sentence + trimming
    trimmed = " ".join(text.split())
    if len(trimmed) > max_chars:
        trimmed = trimmed[: max_chars - 1].rstrip() + "…"

    return {
        "skill": "compress.articulate",
        "status": "success",
        "max_chars": max_chars,
        "chars": len(trimmed),
        "output": trimmed,
    }
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `text` | string | Yes | - | Text to compress (also accepts `concept` or `input`) |
| `max_chars` | integer | No | `280` | Maximum character limit (minimum 50) |
| `use_llm` | boolean | No | `false` | Enable LLM mode for semantic-aware compression |

### Usage Examples

#### Heuristic Mode

```powershell
.\venv\Scripts\python.exe -m grid skills run compress.articulate --args-json "{text:'StepBloom validates steps before proceeding; use IF-THEN checkpoints.', max_chars:80, use_llm:false}"
```

**Output**:
```json
{
  "skill": "compress.articulate",
  "status": "success",
  "max_chars": 80,
  "chars": 65,
  "output": "StepBloom validates steps before proceeding; use IF-THEN checkpoints."
}
```

#### LLM Mode

```powershell
.\venv\Scripts\python.exe -m grid skills run compress.articulate --args-json "{text:'The StepBloom framework provides a structured execution model that validates each step before proceeding to the next. It uses IF-THEN checkpoints to ensure correctness and prevent errors.', max_chars:80, use_llm:true}"
```

**Output**:
```json
{
  "skill": "compress.articulate",
  "status": "success",
  "max_chars": 80,
  "chars": 78,
  "output": "StepBloom: structured execution with IF-THEN validation checkpoints preventing errors."
}
```

### Performance Notes

- **Heuristic mode**: < 10ms (simple text trimming)
- **LLM mode**: 500ms - 2s (semantic compression)
- **Compression ratio**: Typically 30-60% of original length
- **Character limit enforcement**: Hard limit with ellipsis truncation

---

## 4. `compress.secure`

**Purpose**: Compress text with semantic-technological security/privacy layer. Demonstrates "covers semantics with technologies" concept where semantics are protected by technological security measures.

### Capabilities

- Semantic compression (uses `compress.articulate` internally)
- Semantic analysis (entities, relationships, context extraction)
- Security metadata (semantic hash, compression signature)
- Semantic preservation scoring
- Security level configuration

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.compress_secure import compress_secure
# registry.register(compress_secure)
```

### Code Context

```18:98:src/grid/skills/compress_secure.py
def _secure_compress(args: Mapping[str, Any]) -> Dict[str, Any]:
    """Compress text with semantic-technological security layer.

    This function demonstrates the "covers semantics with technologies" concept:
    - Semantic Layer: Understands and preserves meaning
    - Technological Layer: Compresses and encrypts for security
    - Integration: Semantics guide technology, technology protects semantics
    """
    text = args.get("text") or args.get("concept") or args.get("input")
    if text is None:
        return {
            "skill": "compress.secure",
            "status": "error",
            "error": "Missing required parameter: 'text' (or 'concept')",
        }

    text = str(text)
    max_chars = int(args.get("max_chars", 280) or 280)
    security_level = float(args.get("security_level", 0.5) or 0.5)
    use_llm = bool(args.get("use_llm") or args.get("useLLM"))

    if max_chars < 50:
        max_chars = 50

    # Step 1: Semantic Compression (using existing compress_articulate)
    compression_args = {
        "text": text,
        "max_chars": max_chars,
        "use_llm": use_llm,
    }
    compressed_result = compress_articulate.handler(compression_args)

    if compressed_result.get("status") != "success":
        return {
            "skill": "compress.secure",
            "status": "error",
            "error": f"Compression failed: {compressed_result.get('error', 'unknown')}",
        }

    compressed_text = compressed_result["output"]

    # Step 2: Semantic Analysis (extract entities, relationships, context)
    semantic_analysis = _analyze_semantics(text, compressed_text)

    # Step 3: Technological Security Layer
    # Create semantic hash for integrity
    semantic_hash = hashlib.sha256(
        json.dumps(semantic_analysis, sort_keys=True).encode()
    ).hexdigest()

    # Create compression signature (obfuscates original structure)
    compression_signature = hashlib.sha256(
        compressed_text.encode()
    ).hexdigest()[:16]

    # Step 4: Security Metadata
    security_metadata = {
        "compression_ratio": compressed_result["chars"] / len(text) if len(text) > 0 else 0.0,
        "semantic_preservation": _calculate_semantic_preservation(text, compressed_text),
        "security_level": security_level,
        "semantic_hash": semantic_hash,
        "compression_signature": compression_signature,
        "original_size": len(text),
        "compressed_size": compressed_result["chars"],
    }

    return {
        "skill": "compress.secure",
        "status": "success",
        "max_chars": max_chars,
        "chars": compressed_result["chars"],
        "output": compressed_text,
        "security_layer": {
            "enabled": True,
            "semantic_hash": semantic_hash,
            "compression_signature": compression_signature,
            "security_level": security_level,
        },
        "semantic_analysis": semantic_analysis,
        "security_metadata": security_metadata,
    }
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `text` | string | Yes | - | Text to compress securely |
| `max_chars` | integer | No | `280` | Maximum character limit |
| `security_level` | float | No | `0.5` | Security level (0.0 - 1.0) |
| `use_llm` | boolean | No | `false` | Enable LLM mode for compression |

### Usage Examples

```powershell
.\venv\Scripts\python.exe -m grid skills run compress.secure --args-json "{text:'The GRID framework provides geometric resonance intelligence for complex systems.', max_chars:100, security_level:0.7, use_llm:false}"
```

**Output**:
```json
{
  "skill": "compress.secure",
  "status": "success",
  "max_chars": 100,
  "chars": 75,
  "output": "GRID framework provides geometric resonance intelligence for complex systems.",
  "security_layer": {
    "enabled": true,
    "semantic_hash": "a3f5b2c8d9e1f4a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0",
    "compression_signature": "b2c8d9e1f4a6b7c8",
    "security_level": 0.7
  },
  "semantic_analysis": {
    "entities": ["GRID", "framework"],
    "relationships": [],
    "context": {"domain": "technology"},
    "semantic_density": 0.2
  },
  "security_metadata": {
    "compression_ratio": 0.75,
    "semantic_preservation": 0.85,
    "security_level": 0.7,
    "semantic_hash": "a3f5b2c8d9e1f4a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0",
    "compression_signature": "b2c8d9e1f4a6b7c8",
    "original_size": 100,
    "compressed_size": 75
  }
}
```

### Performance Notes

- **Processing time**: 50-200ms (includes compression + semantic analysis + hashing)
- **Semantic preservation**: Score 0.0-1.0 (typically 0.7-0.9)
- **Security features**: SHA-256 hashing for integrity verification

---

## 5. `cross_reference.explain`

**Purpose**: Generate cross-domain explanations (maps + compass) to make complex concepts accessible across different domains.

### Capabilities

- Maps concepts from source domain to target domain
- Creates mapping tables (source_term → target_term → why)
- Provides navigation "compass" (decision rules)
- Provides structural "map" (big pieces and connections)
- Heuristic fallback with example mappings
- LLM mode for rich cross-domain explanations

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.cross_reference_explain import cross_reference_explain
# registry.register(cross_reference_explain)
```

### Code Context

```8:120:src/grid/skills/cross_reference_explain.py
def _explain(args: Mapping[str, Any]) -> Dict[str, Any]:
    concept = str(args.get("concept") or "").strip()
    source_domain = str(args.get("source_domain") or args.get("sourceDomain") or "").strip()
    target_domain = str(args.get("target_domain") or args.get("targetDomain") or "").strip()
    style = str(args.get("style") or "plain").strip()
    use_llm = bool(args.get("use_llm") or args.get("useLLM") or args.get("use_rag") or args.get("useRag"))

    if not concept:
        return {
            "skill": "cross_reference.explain",
            "status": "error",
            "error": "Missing required parameter: 'concept'",
        }

    if not source_domain:
        source_domain = "source domain"
    if not target_domain:
        target_domain = "target domain"

    if use_llm:
        try:
            from tools.rag.config import RAGConfig
            from tools.rag.llm.factory import get_llm_provider

            config = RAGConfig.from_env()
            config.ensure_local_only()
            llm = get_llm_provider(config=config)

            prompt = (
                "Create a cross-domain explanation that maps concepts from one domain to another.\n"
                f"Source domain: {source_domain}\n"
                f"Target domain: {target_domain}\n"
                f"Concept to explain: {concept}\n\n"
                "Output format:\n"
                "1) A one-paragraph explanation in the target domain.\n"
                "2) A mapping table with 5-10 rows: source_term -> target_term -> why.\n"
                "3) A short 'compass' section: how to navigate decisions (3 rules).\n"
                "4) A short 'map' section: the big pieces and how they connect (5 bullets).\n\n"
                f"Style: {style}\n"
                "Avoid fluff. Prefer concrete nouns."
            )
            text = llm.generate(prompt=prompt, temperature=0.3)
            return {
                "skill": "cross_reference.explain",
                "status": "success",
                "concept": concept,
                "source_domain": source_domain,
                "target_domain": target_domain,
                "output": text,
            }
        except Exception as e:
            return {
                "skill": "cross_reference.explain",
                "status": "error",
                "error": str(e),
                "concept": concept,
                "source_domain": source_domain,
                "target_domain": target_domain,
            }

    # Heuristic fallback
    mapping = [
        {
            "source": "signal",
            "target": "input",
            "why": "Both represent incoming information to be interpreted.",
        },
        {
            "source": "noise",
            "target": "confounder",
            "why": "Both reduce clarity and must be filtered.",
        },
        {
            "source": "model",
            "target": "explanation frame",
            "why": "Both structure interpretation and prediction.",
        },
    ]

    output = (
        f"Explain '{concept}' by mapping from {source_domain} to {target_domain}. "
        "Use a mapping table and a navigation compass."
    )

    return {
        "skill": "cross_reference.explain",
        "status": "success",
        "concept": concept,
        "source_domain": source_domain,
        "target_domain": target_domain,
        "output": output,
        "mapping": mapping,
        "compass": [
            "Prefer stable invariants over surface details.",
            "Separate signal from noise before optimizing.",
            "Validate mapping with at least one counterexample.",
        ],
        "map": [
            "Inputs",
            "Constraints",
            "Transformations",
            "Outputs",
            "Feedback loop",
        ],
    }
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `concept` | string | Yes | - | Concept to explain |
| `source_domain` | string | No | `"source domain"` | Source domain name |
| `target_domain` | string | No | `"target domain"` | Target domain name |
| `style` | string | No | `"plain"` | Output style |
| `use_llm` | boolean | No | `false` | Enable LLM mode for rich explanations |

### Usage Examples

#### Heuristic Mode

```powershell
.\venv\Scripts\python.exe -m grid skills run cross_reference.explain --args-json "{concept:'StepBloom', source_domain:'execution frameworks', target_domain:'software delivery', use_llm:false}"
```

**Output**:
```json
{
  "skill": "cross_reference.explain",
  "status": "success",
  "concept": "StepBloom",
  "source_domain": "execution frameworks",
  "target_domain": "software delivery",
  "output": "Explain 'StepBloom' by mapping from execution frameworks to software delivery. Use a mapping table and a navigation compass.",
  "mapping": [
    {
      "source": "signal",
      "target": "input",
      "why": "Both represent incoming information to be interpreted."
    },
    {
      "source": "noise",
      "target": "confounder",
      "why": "Both reduce clarity and must be filtered."
    },
    {
      "source": "model",
      "target": "explanation frame",
      "why": "Both structure interpretation and prediction."
    }
  ],
  "compass": [
    "Prefer stable invariants over surface details.",
    "Separate signal from noise before optimizing.",
    "Validate mapping with at least one counterexample."
  ],
  "map": [
    "Inputs",
    "Constraints",
    "Transformations",
    "Outputs",
    "Feedback loop"
  ]
}
```

#### LLM Mode

```powershell
.\venv\Scripts\python.exe -m grid skills run cross_reference.explain --args-json "{concept:'StepBloom', source_domain:'execution frameworks', target_domain:'software delivery', use_llm:true}"
```

### Performance Notes

- **Heuristic mode**: < 10ms (template-based mapping)
- **LLM mode**: 1-3s (rich cross-domain explanation generation)
- **Output structure**: Map + Compass format for navigation

---

## 6. `topic_extractor`

**Purpose**: Extract discussion topics using wall-board metaphor with pins and stitching imagery. Creates visual map of conversation flow.

### Capabilities

- Extracts main discussion topics from text
- Uses wall-board metaphor (topics as pinned notes, connections as threads)
- Provides topic structure: topic, pins (key points), connections, weight
- Heuristic fallback (keyword-based clustering)
- LLM mode for semantic topic extraction

### Module Import

```python
# Registry loads this skill dynamically:
# from grid.skills.topic_extractor import topic_extractor
# registry.register(topic_extractor)
```

### Code Context

```9:285:src/grid/skills/topic_extractor.py
def _extract_topics(args: Mapping[str, Any]) -> Dict[str, Any]:
    """Extract discussion topics using wall-board metaphor with pins/stitching imagery."""
    text = args.get("text") or args.get("input")
    if text is None:
        return {
            "skill": "topic_extractor",
            "status": "error",
            "error": "Missing required parameter: 'text'",
        }

    text = str(text)
    use_llm = bool(args.get("use_llm") or args.get("useLLM"))
    max_topics = int(args.get("max_topics", 8))

    if use_llm:
        try:
            from tools.rag.config import RAGConfig
            from tools.rag.llm.factory import get_llm_provider

            config = RAGConfig.from_env()
            config.ensure_local_only()
            llm = get_llm_provider(config=config)

            prompt = (
                "Extract the main discussion topics from this text using a wall-board metaphor. "
                "Imagine each topic as a note pinned to a wall with colorful pins, connected by "
                "thread like stitches creating a visual map of the conversation flow.\n\n"
                "For each topic, provide:\n"
                "- topic: The main theme/subject\n"
                "- pins: Key points or sub-topics (bullet points)\n"
                "- connections: How this topic links to other topics\n"
                "- weight: Relative importance (1-10)\n\n"
                f"TEXT:\n{text}\n\n"
                "Format as JSON array of topic objects."
            )
            out = llm.generate(prompt=prompt, temperature=0.3)

            return {
                "skill": "topic_extractor",
                "status": "success",
                "output": out.strip(),
                "metaphor": "wall_board",
            }
        except Exception as e:
            return {
                "skill": "topic_extractor",
                "status": "error",
                "error": str(e),
            }

    # Heuristic fallback: extract key phrases and create topic clusters
    # ... (heuristic implementation)
```

### Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `text` | string | Yes | - | Text to extract topics from |
| `max_topics` | integer | No | `8` | Maximum number of topics to extract |
| `use_llm` | boolean | No | `false` | Enable LLM mode for semantic extraction |

### Usage Examples

```powershell
.\venv\Scripts\python.exe -m grid skills run topic_extractor --args-json "{text:'We discussed the GRID framework architecture. The pattern engine uses regex matching. The RAG system provides local-first retrieval. Next steps include integrating the cognitive layer.', max_topics:5, use_llm:false}"
```

**Output**:
```json
{
  "skill": "topic_extractor",
  "status": "success",
  "topics": [
    {
      "topic": "GRID framework architecture",
      "pins": ["pattern engine", "RAG system", "cognitive layer"],
      "connections": ["pattern engine", "RAG system"],
      "weight": 8
    },
    {
      "topic": "Pattern engine",
      "pins": ["regex matching"],
      "connections": ["GRID framework architecture"],
      "weight": 6
    }
  ],
  "summary": {
    "total_topics": 2,
    "connections": 1,
    "metaphor": "Each topic is a note pinned to the wall, connected by threads showing conversation flow"
  },
  "note": "Heuristic mode used. Enable use_llm for higher-quality topic extraction."
}
```

### Performance Notes

- **Heuristic mode**: 50-200ms (keyword extraction and clustering)
- **LLM mode**: 1-3s (semantic topic extraction)
- **Topic structure**: Wall-board metaphor with pins and connections

---

## Skills Registry

All skills are dynamically imported and registered in `src/grid/skills/registry.py`:

```24:62:src/grid/skills/registry.py
def _load_builtin_skills(registry: SkillRegistry) -> None:
    import importlib
    import logging
    import traceback

    logger = logging.getLogger(__name__)

    skills_to_load = [
        ("youtube_transcript_analyze", ".youtube_transcript_analyze"),
        ("intelligence_git_analyze", ".intelligence_git_analyze"),
        ("rag_query_knowledge", ".rag_query_knowledge"),
        ("patterns_detect_entities", ".patterns_detect_entities"),
        ("analysis_process_context", ".analysis_process_context"),
        ("cross_reference_explain", ".cross_reference_explain"),
        ("compress_articulate", ".compress_articulate"),
        ("context_refine", ".context_refine"),
        ("transform_schema_map", ".transform_schema_map"),
        ("topic_extractor", ".topic_extractor"),
        ("knowledge_capture", ".knowledge_capture"),
    ]

    for name, relative_path in skills_to_load:
        try:
            # Use importlib for cleaner dynamic relative imports
            module = importlib.import_module(relative_path, package="grid.skills")
            skill = getattr(module, name)
            registry.register(skill)
        except Exception as e:
            error_msg = f"Failed to load skill '{name}' from '{relative_path}': {type(e).__name__}: {e}"
            logger.error(error_msg)


default_registry = SkillRegistry()
_load_builtin_skills(default_registry)
```

### Global Skills Registration

The following global skills are loaded from their respective modules:

| Skill ID | Module Path | Variable Name |
|----------|-------------|---------------|
| `context.refine` | `grid.skills.context_refine` | `context_refine` |
| `transform.schema_map` | `grid.skills.transform_schema_map` | `transform_schema_map` |
| `compress.articulate` | `grid.skills.compress_articulate` | `compress_articulate` |
| `compress.secure` | `grid.skills.compress_secure` | `compress_secure` |
| `cross_reference.explain` | `grid.skills.cross_reference_explain` | `cross_reference_explain` |
| `topic_extractor` | `grid.skills.topic_extractor` | `topic_extractor` |

**Note**: `compress.secure` is not currently in the registry's `skills_to_load` list but exists as a skill implementation.

## CLI Integration

Skills are accessed through the CLI via the registry:

```163:178:src/grid/__main__.py
def skills_list_command(args: argparse.Namespace) -> int:
    from grid.skills.registry import default_registry

    payload = {
        "skills": [
            {
                "id": s.id,
                "name": s.name,
                "description": s.description,
            }
            for s in default_registry.list()
        ]
    }

    sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False))
    sys.stdout.write("\n")
    return 0
```

```181:195:src/grid/__main__.py
def skills_run_command(args: argparse.Namespace) -> int:
    from grid.skills.registry import default_registry

    skill = default_registry.get(args.skill_id)
    if skill is None:
        raise SystemExit(f"Unknown skill: {args.skill_id}")

    skill_args: Dict[str, Any] = {}
    if args.args_json or args.args_file:
        # ... parse args ...

    result = skill.run(skill_args)
    # ... output result ...
```

## Base Skill Protocol

All skills implement the `Skill` protocol defined in `src/grid/skills/base.py`:

```7:29:src/grid/skills/base.py
class Skill(Protocol):
    """Protocol defining the skill interface."""

    id: str
    name: str
    description: str
    version: str  # Semantic version for contract stability

    def run(self, args: Mapping[str, Any]) -> Dict[str, Any]: ...


@dataclass(frozen=True)
class SimpleSkill:
    """Simple skill implementation with handler function."""

    id: str
    name: str
    description: str
    handler: Any
    version: str = "1.0.0"  # Default version for backwards compatibility

    def run(self, args: Mapping[str, Any]) -> Dict[str, Any]:
        return self.handler(args)
```

## Performance Summary

| Skill | Heuristic Mode | LLM Mode | Use Case |
|-------|---------------|----------|----------|
| `context.refine` | < 10ms | 500ms-2s | Text cleanup |
| `transform.schema_map` | 50-200ms | 1-3s | Schema mapping |
| `compress.articulate` | < 10ms | 500ms-2s | Text compression |
| `compress.secure` | 50-200ms | 500ms-2s | Secure compression |
| `cross_reference.explain` | < 10ms | 1-3s | Cross-domain explanation |
| `topic_extractor` | 50-200ms | 1-3s | Topic extraction |

## Design Philosophy

Global skills are designed to be:
- **Framework-agnostic**: Work without GRID-specific services
- **Composable**: Can be chained together
- **Local-first**: Heuristic modes work without external dependencies
- **Extensible**: Easy to add new skills following the protocol
- **Testable**: Pure functions where possible
