# Inference Abrasiveness Configuration Guide

**Purpose:** Fine-tuned control over inference behavior with controlled automation, similar to Storage Sense Group Policy/Intune settings.

**Date:** 2026-01-08
**Version:** 1.0.0

---

## Overview

The Inference Abrasiveness Configuration provides **fine-tuned control** to subtly adjust abrasiveness parameters in inference operations. It works with relevant references and extensions, allowing controlled automation configs that dial up or down the aggressiveness of inference operations.

**Key Features:**
- ✅ Similar to Storage Sense Group Policy/Intune settings pattern
- ✅ Fine-tuned control with subtle adjustments
- ✅ Works with reference architecture patterns
- ✅ Supports extensions/modules with overrides
- ✅ Controlled automation with thresholds and cadence
- ✅ Cleanup settings similar to Storage Sense

---

## Storage Sense Pattern Mapping

This configuration follows the **Storage Sense Group Policy/Intune pattern**:

| Storage Sense Setting | Inference Abrasiveness Equivalent |
|----------------------|-----------------------------------|
| `AllowStorageSenseGlobal` | `enabled` (Enable/disable system-wide) |
| `AllowStorageSenseTemporaryFilesCleanup` | `cleanup.enable_temporary_cleanup` |
| `ConfigStorageSenseCloudContentDehydrationThreshold` | `cleanup.cloud_content_dehydration_threshold` |
| `ConfigStorageSenseDownloadsCleanupThreshold` | `cleanup.downloads_cleanup_threshold` |
| `ConfigStorageSenseRecycleBinCleanupThreshold` | `cleanup.recycle_bin_cleanup_threshold` |
| `ConfigStorageSenseGlobalCadence` | `global_cadence` (0=low space, 1=daily, 7=weekly, 30=monthly) |

---

## Configuration Structure

### Global Control

```python
enabled: bool = True  # Enable/disable system-wide (AllowStorageSenseGlobal)
global_cadence: AbrasivenessCadence = AbrasivenessCadence.DAILY  # Execution frequency
abrasiveness_level: InferenceAbrasivenessLevel = InferenceAbrasivenessLevel.BALANCED
```

### Cadence Values (Similar to Storage Sense)

- `0` = **LOW_SPACE**: Trigger only when resources are low
- `1` = **DAILY**: Daily execution
- `7` = **WEEKLY**: Weekly execution
- `30` = **MONTHLY**: Monthly execution
- `-1` = **CONTINUOUS**: Continuous monitoring (highest abrasiveness)

### Abrasiveness Levels

- **PASSIVE**: Minimal interference, high confidence required
- **BALANCED**: Default balanced approach
- **AGGRESSIVE**: More proactive inference
- **MAXIMUM**: Maximum abrasiveness (use with caution)

---

## Thresholds Configuration

Fine-tuned thresholds for triggering abrasiveness adjustments:

```python
thresholds: AbrasivenessThresholds = {
    "confidence_threshold": 0.7,  # Minimum confidence before action (0.0-1.0)
    "resource_utilization_threshold": 0.8,  # CPU/memory threshold (0.0-1.0)
    "inference_failure_threshold": 5,  # Failed inferences before adjustment
    "temporal_decay_threshold": 0.5,  # Confidence decay threshold (0.0-1.0)
    "pattern_deviation_threshold": 0.3,  # Pattern deviation threshold (0.0-1.0)
}
```

---

## Cleanup Settings (Storage Sense Pattern)

Cleanup settings similar to Storage Sense cleanup controls:

```python
cleanup: InferenceCleanupSettings = {
    "enable_temporary_cleanup": True,  # Similar to AllowStorageSenseTemporaryFilesCleanup
    "enable_stale_cleanup": True,
    "enable_cache_cleanup": True,
    "temporary_files_cleanup_threshold": 7,  # Days before temp cleanup
    "stale_results_cleanup_threshold": 30,  # Days before stale cleanup
    "cache_cleanup_threshold": 90,  # Days before cache cleanup
    "cloud_content_dehydration_threshold": 0.5,  # Similar to ConfigStorageSenseCloudContentDehydrationThreshold
    "downloads_cleanup_threshold": 30,  # Similar to ConfigStorageSenseDownloadsCleanupThreshold
    "recycle_bin_cleanup_threshold": 14,  # Similar to ConfigStorageSenseRecycleBinCleanupThreshold
}
```

---

## Reference Integration

Works with **reference architecture patterns** for alignment:

```python
enable_reference_integration: bool = True
reference_pattern_matching: bool = True
reference_threshold_adjustment: float = 0.1  # Adjustment factor (0.0-1.0)
reference_confidence_boost: float = 0.05  # Confidence boost (0.0-1.0)
```

**How it works:**
- Uses reference patterns (Security Module, Mothership, RAG System, etc.) for alignment
- Adjusts thresholds based on reference patterns
- Boosts confidence when reference patterns match

---

## Extension Support

Supports **extensions/modules** with fine-grained control:

```python
enable_extension_support: bool = True
extension_enabled: List[str] = ["rag", "cognitive_layer", "pattern_recognition"]
extension_abrasiveness_override: Dict[str, InferenceAbrasivenessLevel] = {
    "rag": InferenceAbrasivenessLevel.AGGRESSIVE,
    "cognitive_layer": InferenceAbrasivenessLevel.PASSIVE,
    "pattern_recognition": InferenceAbrasivenessLevel.BALANCED,
}
extension_threshold_multiplier: Dict[str, float] = {
    "rag": 0.8,  # Lower thresholds for RAG
    "cognitive_layer": 1.2,  # Higher thresholds for cognitive layer
    "pattern_recognition": 1.0,  # Default for pattern recognition
}
```

**Per-extension overrides:**
- Each extension can have its own abrasiveness level
- Threshold multipliers allow fine-tuning per extension
- Extensions can be enabled/disabled individually

---

## Fine-Tuning Parameters

Subtle adjustment controls for fine-tuned inference behavior:

```python
confidence_adjustment_factor: float = 1.0  # Multiplier for confidence (0.5-2.0)
temporal_decay_rate: float = 0.95  # Temporal decay rate (0.0-1.0)
pattern_adherence_weight: float = 0.7  # Pattern adherence weight (0.0-1.0)
deviation_tolerance: float = 0.15  # Deviation tolerance (0.0-1.0)
```

**How to use:**
- **confidence_adjustment_factor**: Increase (>1.0) for more aggressive, decrease (<1.0) for more conservative
- **temporal_decay_rate**: Higher = faster decay, lower = slower decay
- **pattern_adherence_weight**: Higher = more strict pattern matching, lower = more flexible
- **deviation_tolerance**: Higher = more tolerant of deviations, lower = less tolerant

---

## Environment Variables

Configuration via environment variables (similar to Intune policy pattern):

```bash
# Global Control
INFERENCE_ABRASIVENESS_ENABLED=true
INFERENCE_ABRASIVENESS_GLOBAL_CADENCE=1  # 0=low space, 1=daily, 7=weekly, 30=monthly
INFERENCE_ABRASIVENESS_LEVEL=balanced  # passive, balanced, aggressive, maximum

# Thresholds
INFERENCE_CONFIDENCE_THRESHOLD=0.7
INFERENCE_RESOURCE_THRESHOLD=0.8
INFERENCE_FAILURE_THRESHOLD=5
INFERENCE_TEMPORAL_DECAY_THRESHOLD=0.5
INFERENCE_PATTERN_DEVIATION_THRESHOLD=0.3

# Cleanup (Storage Sense pattern)
INFERENCE_CLEANUP_TEMPORARY=true
INFERENCE_CLEANUP_STALE=true
INFERENCE_CLEANUP_CACHE=true
INFERENCE_CLEANUP_TEMP_THRESHOLD=7
INFERENCE_CLEANUP_STALE_THRESHOLD=30
INFERENCE_CLEANUP_CACHE_THRESHOLD=90
INFERENCE_CLOUD_DEHYDRATION_THRESHOLD=0.5
INFERENCE_DOWNLOADS_CLEANUP_THRESHOLD=30
INFERENCE_RECYCLE_BIN_CLEANUP_THRESHOLD=14

# Reference Integration
INFERENCE_REFERENCE_INTEGRATION=true
INFERENCE_REFERENCE_PATTERN_MATCHING=true
INFERENCE_REFERENCE_THRESHOLD_ADJUSTMENT=0.1
INFERENCE_REFERENCE_CONFIDENCE_BOOST=0.05

# Extensions (comma-separated)
INFERENCE_EXTENSION_ENABLED=rag,cognitive_layer,pattern_recognition

# Fine-Tuning
INFERENCE_CONFIDENCE_ADJUSTMENT_FACTOR=1.0
INFERENCE_TEMPORAL_DECAY_RATE=0.95
INFERENCE_PATTERN_ADHERENCE_WEIGHT=0.7
INFERENCE_DEVIATION_TOLERANCE=0.15

# Cadence
INFERENCE_CADENCE_OVERRIDE=  # Optional override (0, 1, 7, 30, -1)
INFERENCE_CADENCE_SCHEDULING=true
INFERENCE_CADENCE_ADAPTIVE=true
```

---

## Usage Examples

### Python API

```python
from application.mothership.config.inference_abrasiveness import (
    InferenceAbrasivenessConfig,
    InferenceAbrasivenessLevel,
    AbrasivenessCadence,
)

# Load from environment
config = InferenceAbrasivenessConfig.from_env()

# Adjust confidence with reference boost
adjusted_confidence = config.adjust_confidence(0.75, use_reference_boost=True)

# Check if adjustment should be triggered
should_adjust = config.should_trigger_adjustment(
    current_confidence=0.6,
    resource_utilization=0.85,
    failure_count=6,
    pattern_deviation=0.35,
)

# Get extension-specific abrasiveness
extension_level = config.get_extension_abrasiveness("rag")

# Get extension threshold multiplier
threshold_mult = config.get_extension_threshold_multiplier("rag")

# Validate configuration
issues = config.validate()
if issues:
    print(f"Configuration issues: {issues}")
```

### JSON Configuration

```json
{
  "enabled": true,
  "global_cadence": 1,
  "abrasiveness_level": "balanced",
  "thresholds": {
    "confidence_threshold": 0.7,
    "resource_utilization_threshold": 0.8,
    "inference_failure_threshold": 5,
    "temporal_decay_threshold": 0.5,
    "pattern_deviation_threshold": 0.3
  },
  "cleanup": {
    "enable_temporary_cleanup": true,
    "temporary_files_cleanup_threshold": 7,
    "downloads_cleanup_threshold": 30,
    "recycle_bin_cleanup_threshold": 14
  },
  "enable_reference_integration": true,
  "enable_extension_support": true,
  "extension_enabled": ["rag", "cognitive_layer"],
  "confidence_adjustment_factor": 1.0,
  "pattern_adherence_weight": 0.7
}
```

---

## Presets

Pre-configured presets available in `scaffolds/inference_abrasiveness_presets.json`:

1. **Passive_Conservative**: Minimal interference, high confidence required
2. **Balanced_Default**: Default balanced approach
3. **Aggressive_Proactive**: More proactive inference
4. **Maximum_Performance**: Maximum abrasiveness (use with caution)
5. **Reference_Alignment**: Optimized for reference architecture alignment
6. **Extension_Optimized**: Optimized for extension/module support

---

## Integration with Mothership Config

The inference abrasiveness configuration is integrated into the main `MothershipSettings`:

```python
from application.mothership.config import get_settings

settings = get_settings()
if settings.inference_abrasiveness:
    config = settings.inference_abrasiveness
    # Use config...
```

---

## Validation

The configuration includes comprehensive validation:

```python
issues = config.validate()
# Returns list of validation issues (empty if valid)
```

**Validation checks:**
- Thresholds are within valid ranges (0.0-1.0)
- Fine-tuning parameters are within bounds
- Reference integration parameters are valid
- Extension configuration is consistent

---

## Best Practices

1. **Start with Balanced**: Use `balanced` level as default
2. **Adjust Gradually**: Fine-tune parameters gradually (0.05-0.1 increments)
3. **Use Reference Integration**: Enable for alignment with reference architecture
4. **Per-Extension Tuning**: Use extension overrides for specific modules
5. **Monitor Performance**: Track inference performance and adjust accordingly
6. **Validation**: Always validate configuration before deployment

---

## Troubleshooting

### Configuration not loading
- Check environment variables are set correctly
- Verify `INFERENCE_ABRASIVENESS_ENABLED=true`
- Check for typos in variable names

### Thresholds not triggering
- Lower thresholds for more aggressive triggering
- Check `enable_automated_adjustment` is enabled
- Verify resource utilization is being monitored

### Extension overrides not working
- Ensure `enable_extension_support=true`
- Check extension names match exactly
- Verify extension is in `extension_enabled` list

---

## References

- **Storage Sense Group Policy**: Windows Storage Sense policy pattern
- **Intune Settings**: Microsoft Intune configuration pattern
- **Reference Architecture**: `PROJECT_STRENGTH_ANALYSIS.md`
- **Scaffolds**: `scaffolds/inference_abrasiveness_presets.json`

---

**Status:** ✅ Configuration Complete
**Version:** 1.0.0
**Last Updated:** 2026-01-08
