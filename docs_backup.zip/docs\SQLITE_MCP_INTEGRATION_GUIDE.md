# SQLite MCP Server Integration Guide

## Overview

This guide covers the integration of the SQLite MCP Server with your configuration hub system, including setup, configuration, and usage with your existing database files.

## Quick Installation

### VS Code Installation

#### Option 1: UV Installation (Recommended)

1. Open VS Code
2. Press `Ctrl + Shift + P`
3. Type "Preferences: Open Settings (JSON)"
4. Add the following configuration:

```json
{
  "mcp": {
    "inputs": [
      {
        "type": "promptString",
        "id": "db_path",
        "description": "SQLite Database Path",
        "default": "${workspaceFolder}/data/databases/grid.db.backup"
      }
    ],
    "servers": {
      "sqlite": {
        "command": "uvx",
        "args": ["mcp-server-sqlite", "--db-path", "${input:db_path}"]
      }
    }
  }
}
```

#### Option 2: Add to Workspace

Create `.vscode/mcp.json` in your workspace:

```json
{
  "mcp": {
    "inputs": [
      {
        "type": "promptString",
        "id": "db_path",
        "description": "SQLite Database Path",
        "default": "${workspaceFolder}/data/databases/grid.db.backup"
      }
    ],
    "servers": {
      "sqlite": {
        "command": "uvx",
        "args": ["mcp-server-sqlite", "--db-path", "${input:db_path}"]
      }
    }
  }
}
```

### Docker Installation

```json
{
  "mcp": {
    "inputs": [
      {
        "type": "promptString",
        "id": "db_path",
        "description": "SQLite Database Path (within container)",
        "default": "/mcp/db.sqlite"
      }
    ],
    "servers": {
      "sqlite": {
        "command": "docker",
        "args": [
          "run",
          "-i",
          "--rm",
          "-v",
          "mcp-sqlite:/mcp",
          "mcp/sqlite",
          "--db-path",
          "${input:db_path}"
        ]
      }
    }
  }
}
```

## Configuration Hub Integration

### Database Profile Configuration

The configuration hub already includes a comprehensive database profile with SQLite MCP server integration:

#### Database Profile (`config/hub/profiles/database.yaml`)

```yaml
mcp:
  database:
    servers:
      sqlite:
        name: "SQLite MCP Server"
        description: "Database operations and business intelligence"
        command: "uvx"
        args: ["mcp-server-sqlite", "--db-path", "${input:db_path}"]
        enabled: true

      sqlite_grid:
        name: "SQLite Grid MCP Server"
        description: "Grid project database operations"
        command: "uvx"
        args:
          [
            "mcp-server-sqlite",
            "--db-path",
            "${workspaceFolder}/data/databases/grid.db.backup",
          ]
        enabled: true
```

### Available Database Files

Your system has the following database files ready for SQLite MCP integration:

- **grid.db.backup** (65KB) - Main GRID project database
- **interfaces_metrics.db** (90KB) - Interface metrics database
- **skills_intelligence.db** (60KB) - Skills intelligence database
- **mothership.db** (0KB) - Motherhood database (empty)

### Context-Specific Configuration

#### Database Context (`config/hub/contexts/database.yaml`)

```yaml
mcp:
  servers:
    sqlite:
      enabled: true
      timeout: 30
      env:
        SQLITE_DEBUG: "true"
        SQLITE_TIMEOUT: "30"
```

## Usage Examples

### 1. Basic Database Operations

```python
# Load database configuration
from config.hub.dynamic.loader import ConfigLoader

loader = ConfigLoader()
result = loader.load_config('database', 'database')

# The configuration will include SQLite MCP server settings
```

### 2. Sync Database Configuration

```python
# Sync database profile (simulated)
from config.hub.sync.to_user import UserConfigSync

sync_manager = UserConfigSync()
# Note: Database is not a real IDE, but configuration is ready
```

### 3. Manual SQLite MCP Server Testing

```bash
# Test with specific database
uvx mcp-server-sqlite --db-path e:/grid/data/databases/grid.db.backup

# Test with interfaces database
uvx mcp-server-sqlite --db-path e:/grid/data/databases/interfaces_metrics.db

# Test with skills database
uvx mcp-server-sqlite --db-path e:/grid/data/databases/skills_intelligence.db
```

## MCP Server Features

### Available Tools

The SQLite MCP Server provides the following tools:

1. **read_query** - Execute SELECT queries
2. **write_query** - Execute INSERT, UPDATE, DELETE queries
3. **create_table** - Create new tables
4. **list_tables** - List all tables in the database
5. **describe_table** - Get table schema information

### Resources

1. **memo://insights** - Business insights memo (auto-updated)

### Prompts

1. **mcp-demo** - Interactive demonstration prompt

## Database Schema Examples

### Grid Database Schema

```sql
-- Example tables that might exist in grid.db.backup
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    user_id INTEGER,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

### Interfaces Metrics Schema

```sql
-- Example tables for interfaces_metrics.db
CREATE TABLE IF NOT EXISTS metrics (
    id INTEGER PRIMARY KEY,
    interface_name TEXT NOT NULL,
    metric_value REAL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Skills Intelligence Schema

```sql
-- Example tables for skills_intelligence.db
CREATE TABLE IF NOT EXISTS skills (
    id INTEGER PRIMARY KEY,
    skill_name TEXT NOT NULL,
    proficiency_level INTEGER,
    category TEXT,
    last_assessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Integration with Existing IDEs

### VS Code Integration

Your existing VS Code settings already include SQLite MCP configuration:

```json
{
  "mcp": {
    "inputs": [
      {
        "type": "promptString",
        "id": "db_path",
        "description": "SQLite Database Path",
        "default": "${workspaceFolder}/db.sqlite"
      }
    ],
    "servers": {
      "sqlite": {
        "command": "uvx",
        "args": ["mcp-server-sqlite", "--db-path", "${input:db_path}"]
      }
    }
  }
}
```

### Cursor Integration

Cursor MCP configuration includes SQLite server:

```json
{
  "mcpServers": {
    "sqlite": {
      "command": "powershell",
      "args": [
        "-NoProfile",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        "e:\\EUFLE\\mcp_sqlite_wrapper.ps1"
      ]
    }
  }
}
```

### Windsurf Integration

Windsurf can use the same configuration as VS Code.

## Troubleshooting

### Common Issues

#### 1. UVX Command Not Found

```bash
# Install UV
pip install uv

# Or use pip directly
pip install mcp-server-sqlite
```

#### 2. Database File Not Found

```bash
# Check database files exist
ls -la e:/grid/data/databases/

# Test database connection
sqlite3 e:/grid/data/databases/grid.db.backup ".tables"
```

#### 3. MCP Server Timeout

```bash
# Test with longer timeout
uvx mcp-server-sqlite --db-path e:/grid/data/databases/grid.db.backup --timeout 60
```

#### 4. Permission Issues

```bash
# Check file permissions
ls -la e:/grid/data/databases/*.db*

# Fix permissions if needed
chmod 644 e:/grid/data/databases/*.db
```

### Debug Mode

Enable debug logging for SQLite MCP:

```yaml
# In your MCP configuration
servers:
  sqlite:
    env:
      SQLITE_DEBUG: "true"
      LOG_LEVEL: "DEBUG"
```

## Performance Optimization

### Database Optimization

1. **Use WAL Mode**: Better for concurrent access
2. **Enable Query Caching**: Reduces repeated query overhead
3. **Index Optimization**: Improves query performance
4. **Connection Pooling**: Reduces connection overhead

### MCP Server Optimization

1. **Increase Timeout**: For complex queries
2. **Enable Caching**: For repeated operations
3. **Limit Result Size**: For large datasets
4. **Use Pagination**: For large result sets

## Security Considerations

### Database Security

1. **Parameterized Queries**: Prevent SQL injection
2. **Access Control**: Limit database operations
3. **Audit Logging**: Track database access
4. **Encryption**: For sensitive data

### MCP Security

1. **Path Restrictions**: Limit database file access
2. **Command Validation**: Prevent arbitrary SQL execution
3. **Resource Limits**: Prevent resource exhaustion
4. **Input Sanitization**: Validate all inputs

## Advanced Usage

### Custom Database Queries

```python
# Example of using the SQLite MCP server programmatically
import sqlite3
from pathlib import Path

def query_database(db_path: str, query: str):
    """Execute a query on the database"""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(query)
    results = cursor.fetchall()
    conn.close()
    return results

# Usage
db_path = "e:/grid/data/databases/grid.db.backup"
results = query_database(db_path, "SELECT * FROM users LIMIT 10")
```

### Database Migration

```python
# Example migration script
def migrate_database(db_path: str):
    """Run database migrations"""
    conn = sqlite3.connect(db_path)

    # Create migration table if not exists
    conn.execute("""
        CREATE TABLE IF NOT EXISTS migrations (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Run migrations
    migrations = [
        "ALTER TABLE users ADD COLUMN updated_at TIMESTAMP",
        "CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)",
        "CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id)"
    ]

    for migration in migrations:
        try:
            conn.execute(migration)
            print(f"Executed: {migration}")
        except sqlite3.Error as e:
            print(f"Error: {e}")

    conn.commit()
    conn.close()
```

## Best Practices

### 1. Database Design

- Use proper primary keys
- Add appropriate indexes
- Normalize data structure
- Use foreign key constraints

### 2. Query Optimization

- Use EXPLAIN QUERY PLAN
- Avoid SELECT \* in production
- Use appropriate data types
- Implement query caching

### 3. MCP Integration

- Validate all inputs
- Handle errors gracefully
- Use appropriate timeouts
- Log all operations

### 4. Configuration Management

- Use environment variables
- Separate development/production configs
- Version control configuration files
- Document all settings

## Next Steps

1. **Test Integration**: Run the test suite to verify everything works
2. **Configure IDEs**: Update your IDE settings with SQLite MCP configuration
3. **Create Database Scripts**: Develop scripts for database operations
4. **Monitor Performance**: Set up monitoring for database operations
5. **Document Usage**: Create documentation for your specific use cases

## Support

For additional help:

1. Check the [SQLite MCP Server documentation](https://github.com/modelcontextprotocol/servers)
2. Review the [MCP specification](https://modelcontextprotocol.io/)
3. Test with the MCP inspector: `mcp dev`
4. Check the configuration hub documentation

## Conclusion

The SQLite MCP Server integration provides powerful database capabilities within your development environment. With proper configuration and the existing database files, you can perform complex database operations directly from your IDE, enhancing your development workflow significantly.
