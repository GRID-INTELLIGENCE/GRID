# NUL Guard Utility

This Go tool hunts down Windows `nul` device artifacts, deletes them, and hardens the repo against future occurrences.

## Features

1. **Deep scan** of the entire tree (default `.`) to locate any file or directory literally named `nul`.
2. **Parallel deletion** with configurable worker count and optional dry-run mode.
3. **Source attribution** reporting to identify which top-level areas generate the artifacts most often.
4. **Blocklist reinforcement** via `reports/nul_blocklist.json` plus automatic entries in `.git/info/exclude`.

## Usage

```powershell
# From repo root
set GOEXE="C:\path\to\go.exe"  # Ensure Go 1.21+ is installed and on PATH
$env:PATH = "$env:PATH;C:\path\to\go\bin"

go run ./scripts/nul_guard -root . -workers 16
```

### Flags

| Flag         | Default                      | Description                                  |
| ------------ | ---------------------------- | -------------------------------------------- |
| `-root`      | `.`                          | Root directory to inspect                    |
| `-blocklist` | `reports/nul_blocklist.json` | Where hardened blocklist metadata is written |
| `-dry-run`   | `false`                      | Scan only, no deletions                      |
| `-workers`   | `8`                          | Concurrent delete workers                    |

## Outputs

- `reports/nul_blocklist.json`: cumulative metadata with wildcard patterns and per-source counts.
- `.git/info/exclude`: ensures `**/nul` entries stay excluded from git tracking.

## Notes

- The utility relies on Go 1.21+. Install Go if `go`/`gofmt` aren’t available on PATH.
- Windows may recreate `nul` entries when certain tools mis-handle reserved device names; re-run this utility whenever that happens.
