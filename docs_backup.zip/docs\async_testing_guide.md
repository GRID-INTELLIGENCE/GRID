# Async Testing Guide for pytest-asyncio 0.24+

## Quick Reference

| Mode       | Best For               | Fixture Decorator                  | Config                    |
| ---------- | ---------------------- | ---------------------------------- | ------------------------- |
| **AUTO**   | Asyncio-only projects  | `@pytest_asyncio.fixture` optional | `asyncio_mode = "auto"`   |
| **STRICT** | Multi-async frameworks | `@pytest_asyncio.fixture` required | `asyncio_mode = "strict"` |

**GRID uses**: AUTO mode (asyncio only)

---

## 1. Configuration

### pyproject.toml Setup

```toml
[tool.pytest.ini_options]
pythonpath = ["src", "."]
testpaths = ["tests"]
python_files = ["test_*.py"]
python_functions = ["test_*"]

# CRITICAL: Event loop management (pytest-asyncio 0.24+)
asyncio_mode = "auto"  # Already set!
asyncio_default_fixture_loop_scope = "function"  # Add this line
```

### Mode Comparison

#### AUTO Mode (Recommended for GRID)

```python
# pyproject.toml
asyncio_mode = "auto"

# conftest.py - No special setup needed
# All async test functions and fixtures are auto-detected

# test_example.py
async def test_example():  # Works! No @pytest.mark.asyncio needed
    await some_async_function()
    assert True

@pytest.fixture
async def my_fixture():  # Works! No @pytest_asyncio.fixture needed
    return await some_async_setup()
```

**Pros:**

- Simplest configuration
- Auto-adds @pytest.mark.asyncio to all async functions
- No need to distinguish between sync and async fixtures

**Cons:**

- Can't coexist with other async frameworks (trio, curio)

---

## 2. Fixture Patterns

### Pattern 1: Function-Scoped Async Fixture (Default)

```python
import pytest_asyncio
from typing import AsyncGenerator

@pytest_asyncio.fixture
async def event_bus() -> AsyncGenerator:
    """
    Function-scoped async fixture: New instance for each test.

    Guarantees: Isolation, no cross-test contamination
    Cost: More setup/teardown overhead
    """
    bus = EventBus(use_redis=False)
    yield bus
    # Cleanup runs after test
    bus.cleanup()

@pytest.mark.asyncio
async def test_event_bus(event_bus):
    await event_bus.publish({"event": "test"})
    assert len(event_bus.history) == 1
```

**Use when:**

- Tests mutate fixture state (most common)
- You need isolation between tests
- Running parallel tests (pytest-xdist)

---

### Pattern 2: Module-Scoped Async Fixture

```python
import pytest_asyncio
from typing import AsyncGenerator

@pytest_asyncio.fixture(loop_scope="module")
async def shared_database() -> AsyncGenerator:
    """
    Module-scoped fixture: Single instance shared by all tests in module.

    Guarantees: All tests in module share same event loop
    Cost: Tests must handle shared state carefully
    """
    db = Database()
    await db.initialize()
    yield db
    await db.cleanup()

pytestmark = pytest.mark.asyncio(loop_scope="module")

async def test_query_1(shared_database):
    result = await shared_database.query("SELECT 1")
    assert result == 1

async def test_query_2(shared_database):
    result = await shared_database.query("SELECT 2")
    assert result == 2
```

**Use when:**

- Fixture setup is expensive (database connections, model loading)
- Tests don't conflict over shared state
- All tests in module use same loop scope

---

### Pattern 3: Sync Fixture with asyncio.run()

```python
import asyncio
import pytest

@pytest.fixture
def sample_activity_id(service: ResonanceService) -> str:
    """
    Sync fixture that calls async function using asyncio.run().

    SAFE in AUTO mode: pytest-asyncio ensures no event loop is running
    when sync fixtures are evaluated.
    """
    activity_id, _ = asyncio.run(
        service.process_activity(
            query="test",
            activity_type="general",
            context={}
        )
    )
    return activity_id

def test_with_sync_fixture(sample_activity_id):
    assert sample_activity_id is not None
    assert isinstance(sample_activity_id, str)
```

**Use when:**

- Fixture setup is inherently sync
- You want simple, straightforward code
- No complex async state management needed

---

## 3. Common Patterns in GRID

### EventBus Testing

```python
import pytest_asyncio
from grid.agentic.event_bus import EventBus
from typing import AsyncGenerator

# conftest.py
@pytest_asyncio.fixture
async def event_bus() -> AsyncGenerator[EventBus, None]:
    """Fresh event bus for each test."""
    bus = EventBus(use_redis=False)
    yield bus
    # Cleanup

# test_event_bus.py
@pytest.mark.asyncio
async def test_event_filtering(event_bus):
    """Each test gets isolated event bus."""
    await event_bus.subscribe("case.created", my_handler)
    await event_bus.publish({"event_type": "case.created"})
    assert len(event_bus.history) == 1
```

### API/Service Testing

```python
import pytest
import pytest_asyncio
from application.resonance.api.service import ResonanceService
from typing import AsyncGenerator

# conftest.py - Use asyncio.run() in sync fixture
@pytest.fixture
def sample_activity_id(service: ResonanceService) -> str:
    """Sync fixture using asyncio.run() - SAFE in AUTO mode."""
    activity_id, _ = asyncio.run(
        service.process_activity(
            query="test",
            activity_type="general",
            context={}
        )
    )
    return activity_id

# Alternative: Pure async fixture
@pytest_asyncio.fixture
async def activity_id(service: ResonanceService) -> AsyncGenerator[str, None]:
    activity_id, _ = await service.process_activity(
        query="test",
        activity_type="general",
        context={}
    )
    yield activity_id
```

### RAG Engine Testing

```python
@pytest_asyncio.fixture
async def rag_engine() -> AsyncGenerator:
    """RAG engine with Ollama."""
    engine = RAGEngine(model="nomic-embed-text-v2-moe:latest")
    yield engine
    # Cleanup if needed

@pytest.mark.asyncio
async def test_rag_query(rag_engine):
    result = await rag_engine.query("How does GRID handle async?")
    assert "async" in result.lower()
```

---

## 4. Troubleshooting

### Error: "Event loop is closed"

**Cause**: Function-scoped fixtures trying to use a closed loop
**Fix**: Ensure fixture has `loop_scope="function"` and uses `yield`, not `return`

```python
# WRONG
@pytest_asyncio.fixture
def async_fixture():
    return await setup()  # Loop closed before test runs!

# RIGHT
@pytest_asyncio.fixture
async def async_fixture():
    result = await setup()
    yield result
    # Cleanup here
```

### Error: "There is no current event loop"

**Cause**: sync code calling async without running loop
**Fix**: Use `asyncio.run()` in sync context (safe in AUTO mode)

```python
# WRONG
def test_sync():
    result = await async_function()  # SyntaxError - can't await in sync

# RIGHT
def test_sync():
    result = asyncio.run(async_function())  # Correct for sync context
```

### Error: "cannot reuse already awaited coroutine"

**Cause**: Reusing same coroutine object
**Fix**: Create fresh coroutine each time

```python
# WRONG
coro = some_async_function()
await coro
await coro  # Error!

# RIGHT
await some_async_function()
await some_async_function()
```

---

## 5. Migration Checklist (STRICT → AUTO)

If upgrading from older pytest-asyncio or switching from STRICT mode:

```python
# OLD (STRICT mode)
@pytest.fixture
def my_fixture():
    return sync_resource()

# NEW (AUTO mode - no change needed!)
@pytest.fixture
def my_fixture():
    return sync_resource()

# OLD (STRICT mode)
@pytest_asyncio.fixture
async def async_fixture():
    return await async_resource()

# NEW (AUTO mode - optional: can drop decorator)
async def async_fixture():  # Auto-detected
    return await async_resource()

# Or keep it explicit for clarity:
@pytest_asyncio.fixture
async def async_fixture():
    return await async_resource()
```

**Steps:**

1. ✓ Set `asyncio_mode = "auto"` in pyproject.toml
2. ✓ Set `asyncio_default_fixture_loop_scope = "function"`
3. ✓ Keep existing `@pytest_asyncio.fixture` decorators (they still work)
4. ✓ Keep existing `@pytest.mark.asyncio` decorators (recommended for clarity)
5. ✓ Test: `pytest tests/ -v --tb=short`

---

## 6. Key Deprecations (0.23 → 0.24+)

From pytest-asyncio 0.24+ release notes:

| Deprecated                  | Replacement                  | Status                     |
| --------------------------- | ---------------------------- | -------------------------- |
| `scope=` parameter          | `loop_scope=` parameter      | Use explicit `loop_scope=` |
| Manual `event_loop` fixture | pytest-asyncio manages loops | Remove custom fixtures     |

**Action for GRID**: No urgent changes needed - backward compatible, but recommended to update for clarity:

```python
# OLD
@pytest.mark.asyncio(scope="module")
async def test_something():
    pass

# NEW (0.24+ style)
@pytest.mark.asyncio(loop_scope="module")
async def test_something():
    pass
```

---

## 7. References

- [pytest-asyncio docs](https://pytest-asyncio.readthedocs.io/)
- [Migration guide v0.23→0.24](https://pytest-asyncio.readthedocs.io/en/latest/how-to-guides/migrate_from_0_23.html)
- [Loop scope reference](https://pytest-asyncio.readthedocs.io/en/latest/reference/api.html)

---

## Questions?

For GRID-specific async testing questions:

1. Check existing test patterns in `tests/api/conftest.py`, `tests/conftest.py`
2. Review RAG async patterns in `tools/rag/`
3. Examine agentic event bus tests in `tests/integration/test_agentic_events.py`
