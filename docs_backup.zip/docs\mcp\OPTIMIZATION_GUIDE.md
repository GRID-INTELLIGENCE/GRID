# GRID MCP Optimization Guide

> Advanced performance tuning and optimization strategies for GRID's MCP servers

## Table of Contents

1. [Performance Baseline](#performance-baseline)
2. [RAG Optimization](#rag-optimization)
3. [Git Server Optimization](#git-server-optimization)
4. [Mastermind Server Optimization](#mastermind-server-optimization)
5. [Memory Management](#memory-management)
6. [Caching Strategies](#caching-strategies)
7. [Resource Limits](#resource-limits)
8. [Monitoring & Profiling](#monitoring--profiling)

---

## Performance Baseline

### Measuring Current Performance

Before optimizing, establish baseline metrics:

```bash
# Test RAG query latency
time python -m tools.rag.cli query "What are the cognition patterns?"

# Test Git operations
time git -C E:\grid log --oneline -n 50

# Monitor memory usage
python scripts/monitor_mcp_memory.py

# Profile server startup time
time python src/grid/mcp/multi_git_server.py &
```

### Expected Performance (Reference)

**Hardware**: Windows 11, i7-12700K, 32GB RAM, NVMe SSD

| Operation | Target | Acceptable | Poor |
|-----------|--------|------------|------|
| Git status | <100ms | 100-300ms | >300ms |
| Git log (50) | <200ms | 200-500ms | >500ms |
| RAG embedding | <200ms | 200-500ms | >500ms |
| RAG search | <50ms | 50-100ms | >100ms |
| RAG generation | <3s | 3-7s | >7s |
| File analysis | <1s | 1-3s | >3s |
| Memory search | <50ms | 50-150ms | >150ms |

---

## RAG Optimization

### 1. Embedding Optimization

**Use Lighter Models**:
```json
{
  "env": {
    "RAG_EMBEDDING_MODEL": "BAAI/bge-small-en-v1.5",  // 133M params, fast
    // Instead of:
    // "RAG_EMBEDDING_MODEL": "BAAI/bge-large-en-v1.5"  // 335M params, slow
  }
}
```

**Batch Embeddings** (modify `grid_rag_mcp_server.py`):
```python
# Instead of embedding one by one
async def embed_batch(self, texts: list[str]) -> list[list[float]]:
    """Batch embed for efficiency"""
    # Process in batches of 32
    batch_size = 32
    results = []
    for i in range(0, len(texts), batch_size):
        batch = texts[i:i+batch_size]
        embeddings = await self.embedder.embed_batch(batch)
        results.extend(embeddings)
    return results
```

**Enable Embedding Cache**:
```json
{
  "env": {
    "RAG_CACHE_ENABLED": "true",
    "RAG_CACHE_SIZE": "1000",  // Cache 1000 most recent embeddings
    "RAG_CACHE_TTL": "3600"    // 1 hour TTL
  }
}
```

### 2. Vector Search Optimization

**Tune ChromaDB Settings**:
```python
# In grid_rag_mcp_server.py initialization
import chromadb

client = chromadb.PersistentClient(
    path=str(config.vector_store_path),
    settings=chromadb.Settings(
        anonymized_telemetry=False,
        allow_reset=False,
        # Performance tuning
        chroma_db_impl="duckdb+parquet",  # Fast query engine
        chroma_segment_max_size_bytes=1024*1024*100,  # 100MB segments
    )
)
```

**Optimize Search Parameters**:
```python
# Reduce K for faster search
results = collection.query(
    query_embeddings=[embedding],
    n_results=5,  # Instead of 10 or 20
    include=["documents", "metadatas", "distances"]
)
```

**Use Approximate Search** (for large collections):
```python
# Add HNSW index configuration
collection = client.get_or_create_collection(
    name="grid_docs",
    metadata={
        "hnsw:space": "cosine",
        "hnsw:construction_ef": 200,  // Higher = more accurate, slower
        "hnsw:M": 16,                 // Higher = more accurate, more memory
        "hnsw:search_ef": 100         // Higher = more accurate, slower
    }
)
```

### 3. Context Window Optimization

**Reduce Context Size**:
```python
# Configure in RAGEngine
config = RAGConfig(
    max_context_tokens=2048,  # Instead of 4096
    chunk_size=256,           # Instead of 512
    chunk_overlap=32,         # Instead of 64
)
```

**Smart Context Pruning**:
```python
def prune_context(chunks: list[str], max_tokens: int) -> list[str]:
    """Keep most relevant chunks within token limit"""
    # Sort by relevance score (distance)
    sorted_chunks = sorted(chunks, key=lambda x: x['distance'])
    
    # Accumulate until token limit
    result = []
    token_count = 0
    for chunk in sorted_chunks:
        chunk_tokens = len(chunk['text'].split()) * 1.3  # Rough estimate
        if token_count + chunk_tokens > max_tokens:
            break
        result.append(chunk)
        token_count += chunk_tokens
    
    return result
```

### 4. LLM Optimization

**Use Smaller Models**:
```json
{
  "env": {
    "RAG_LLM_MODEL_LOCAL": "ministral-3:3b",  // 3B params, fast
    // Consider alternatives:
    // "qwen3-coder:1.5b"  // Even faster for code
    // "ministral-8b"      // Better quality, slower
  }
}
```

**Adjust Generation Parameters**:
```python
# In Ollama request
response = ollama.generate(
    model="ministral-3:3b",
    prompt=prompt,
    options={
        "temperature": 0.7,
        "top_p": 0.9,
        "top_k": 40,
        "num_predict": 512,     # Limit response length
        "num_ctx": 2048,        // Smaller context window
        "num_thread": 8,        // CPU threads
        "num_gpu": 1            // GPU layers (if available)
    }
)
```

### 5. Indexing Optimization

**Incremental Indexing**:
```python
# Index only new/changed files
def index_incremental(path: Path):
    """Index only files modified since last index"""
    last_index_time = get_last_index_time()
    
    for file in path.rglob("*"):
        if file.is_file() and file.stat().st_mtime > last_index_time:
            index_file(file)
```

**Parallel Indexing**:
```python
import asyncio
from concurrent.futures import ThreadPoolExecutor

async def index_parallel(files: list[Path], max_workers: int = 4):
    """Index files in parallel"""
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        loop = asyncio.get_event_loop()
        tasks = [
            loop.run_in_executor(executor, index_file, file)
            for file in files
        ]
        await asyncio.gather(*tasks)
```

**Filter Non-Essential Files**:
```python
# Skip large/binary/generated files
SKIP_PATTERNS = [
    "*.pyc", "__pycache__", "*.so", "*.dll",
    "node_modules", ".git", ".venv",
    "*.jpg", "*.png", "*.pdf",  // Binary files
    "dist", "build", ".eggs"
]

def should_index(path: Path) -> bool:
    """Check if file should be indexed"""
    for pattern in SKIP_PATTERNS:
        if path.match(pattern):
            return False
    return True
```

---

## Git Server Optimization

### 1. Repository Caching

**Cache Git Metadata**:
```python
@dataclass
class GitRepoCache:
    """Cache for expensive Git operations"""
    status: str | None = None
    status_time: float = 0
    branch: str | None = None
    branch_time: float = 0
    
    TTL: float = 30.0  # 30 second cache

class MultiGitMCPServer:
    def __init__(self):
        self.repo_cache: dict[str, GitRepoCache] = {}
    
    def _get_cached_status(self, repo: GitRepo) -> str | None:
        """Get cached status if fresh"""
        cache = self.repo_cache.get(repo.name)
        if cache and (time.time() - cache.status_time) < cache.TTL:
            return cache.status
        return None
```

### 2. Limit Output

**Restrict Log Size**:
```python
# Default to reasonable limits
async def _git_log(self, args: dict[str, Any]) -> CallToolResult:
    max_count = min(args.get("max_count", 50), 100)  # Cap at 100
    # ...
```

**Use Porcelain Format**:
```python
# Already optimized - porcelain format is faster
output = self._run_git(repo, ["status", "--porcelain"])
```

### 3. Lazy Loading

**Don't Load All Repos on Startup**:
```python
def _load_repositories(self):
    """Lazy load repositories"""
    # Only validate paths, don't run git commands
    repos_env = os.getenv("GIT_MCP_REPOSITORIES", "")
    for repo_def in repos_env.split(";"):
        # Store definition, validate on first use
        self.repo_definitions[name] = path
```

### 4. Subprocess Optimization

**Reuse Git Processes** (advanced):
```python
class GitProcessPool:
    """Pool of persistent git processes"""
    
    def __init__(self, max_processes: int = 4):
        self.processes: list[subprocess.Popen] = []
        self.max_processes = max_processes
    
    async def run_command(self, repo: Path, args: list[str]) -> str:
        """Run git command using process pool"""
        # Implementation using persistent processes
        pass
```

---

## Mastermind Server Optimization

### 1. Analysis Caching

**Cache File Analysis Results**:
```python
@dataclass
class AnalysisCache:
    """Cache for file analysis"""
    file_hash: str
    analysis: dict[str, Any]
    timestamp: float

class MastermindServer:
    def __init__(self):
        self.analysis_cache: dict[Path, AnalysisCache] = {}
        self.cache_ttl = 300  # 5 minutes
    
    async def analyze_file(self, file_path: Path) -> dict:
        """Analyze file with caching"""
        # Check cache
        cached = self.analysis_cache.get(file_path)
        if cached:
            # Verify file hasn't changed
            current_hash = hashlib.md5(file_path.read_bytes()).hexdigest()
            if (cached.file_hash == current_hash and 
                time.time() - cached.timestamp < self.cache_ttl):
                return cached.analysis
        
        # Perform analysis
        analysis = self._analyze_file_impl(file_path)
        
        # Update cache
        self.analysis_cache[file_path] = AnalysisCache(
            file_hash=hashlib.md5(file_path.read_bytes()).hexdigest(),
            analysis=analysis,
            timestamp=time.time()
        )
        
        return analysis
```

### 2. Limit Scope

**Constrain Search Depth**:
```python
async def search_code(self, query: str, max_depth: int = 3) -> list[dict]:
    """Search code with depth limit"""
    # Only search up to max_depth directories deep
    pass
```

**Filter by File Type**:
```python
# Only analyze relevant files
ANALYZED_EXTENSIONS = {".py", ".js", ".ts", ".jsx", ".tsx", ".md"}

def should_analyze(path: Path) -> bool:
    return path.suffix in ANALYZED_EXTENSIONS
```

### 3. Async Operations

**Parallelize Analysis**:
```python
async def analyze_codebase(self) -> dict:
    """Analyze codebase in parallel"""
    files = list(self.grid_root.rglob("*.py"))
    
    # Analyze in parallel
    tasks = [self.analyze_file(f) for f in files[:100]]  # Limit files
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    # Aggregate results
    return self._aggregate_analysis(results)
```

---

## Memory Management

### 1. Memory Server Optimization

**Limit Memory File Size**:
```python
def cleanup_old_memories(memory_path: Path, max_age_days: int = 90):
    """Remove old memories to keep file size manageable"""
    with open(memory_path) as f:
        data = json.load(f)
    
    cutoff = time.time() - (max_age_days * 86400)
    data["cases"] = [
        case for case in data["cases"]
        if parse_timestamp(case["timestamp"]) > cutoff
    ]
    
    with open(memory_path, "w") as f:
        json.dump(data, f, indent=2)
```

**Index Keywords for Fast Search**:
```python
# Already implemented in memory.json structure
# Ensure keywords are indexed:
{
  "keywords": {
    "testing": ["case-001", "case-045", "case-112"],
    "ci": ["case-001", "case-023"],
    // ...
  }
}
```

### 2. Process Memory Optimization

**Set Python Memory Limits**:
```bash
# In Zed configuration, set environment variable
export PYTHONMALLOC=malloc
export MALLOC_ARENA_MAX=2  # Limit memory arenas
```

**Use Memory Profiling**:
```python
# Add to server initialization
import tracemalloc

tracemalloc.start()

# Later, check memory usage
snapshot = tracemalloc.take_snapshot()
top_stats = snapshot.statistics('lineno')
for stat in top_stats[:10]:
    print(stat)
```

---

## Caching Strategies

### 1. Multi-Level Caching

**L1: In-Memory Cache** (fastest):
```python
from functools import lru_cache

@lru_cache(maxsize=128)
def get_project_structure(root: Path) -> dict:
    """Cached project structure"""
    return build_tree(root)
```

**L2: Disk Cache** (persistent):
```python
import diskcache

cache = diskcache.Cache(".mcp_cache")

@cache.memoize(expire=3600)  # 1 hour
def expensive_operation(param: str) -> dict:
    # ...
    pass
```

**L3: Distributed Cache** (team environments):
```python
import redis

redis_client = redis.Redis(host='localhost', port=6379)

def get_with_cache(key: str, compute_fn):
    """Get from Redis or compute"""
    cached = redis_client.get(key)
    if cached:
        return json.loads(cached)
    
    result = compute_fn()
    redis_client.setex(key, 3600, json.dumps(result))
    return result
```

### 2. Cache Invalidation

**File Modification Tracking**:
```python
class FileModificationTracker:
    """Track file modifications for cache invalidation"""
    
    def __init__(self):
        self.mtimes: dict[Path, float] = {}
    
    def is_modified(self, path: Path) -> bool:
        """Check if file was modified since last check"""
        current_mtime = path.stat().st_mtime
        last_mtime = self.mtimes.get(path, 0)
        
        if current_mtime > last_mtime:
            self.mtimes[path] = current_mtime
            return True
        return False
```

---

## Resource Limits

### 1. CPU Limits

**Thread Pool Sizing**:
```python
import os
import multiprocessing

# Optimal thread count
CPU_COUNT = os.cpu_count() or 4
THREAD_POOL_SIZE = max(1, CPU_COUNT - 1)  # Leave one core free

executor = ThreadPoolExecutor(max_workers=THREAD_POOL_SIZE)
```

**Process Priority** (Windows):
```python
import psutil
import os

# Set lower priority to avoid blocking system
p = psutil.Process(os.getpid())
p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
```

### 2. Memory Limits

**Set Maximum Memory per Server**:
```python
import resource

# Limit to 2GB
resource.setrlimit(
    resource.RLIMIT_AS,
    (2 * 1024 * 1024 * 1024, 2 * 1024 * 1024 * 1024)
)
```

**Monitor Memory Usage**:
```python
import psutil

def check_memory_usage():
    """Alert if memory usage too high"""
    process = psutil.Process()
    mem_info = process.memory_info()
    
    if mem_info.rss > 1024 * 1024 * 1024:  # 1GB
        logger.warning(f"High memory usage: {mem_info.rss / 1024**2:.1f}MB")
```

### 3. Disk I/O Limits

**Batch File Operations**:
```python
def read_files_batch(paths: list[Path], batch_size: int = 100):
    """Read files in batches to limit I/O"""
    for i in range(0, len(paths), batch_size):
        batch = paths[i:i+batch_size]
        for path in batch:
            yield path.read_text()
        time.sleep(0.1)  # Brief pause between batches
```

---

## Monitoring & Profiling

### 1. Performance Monitoring

**Add Timing Metrics**:
```python
import time
from functools import wraps

def timed(func):
    """Decorator to time function execution"""
    @wraps(func)
    async def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = await func(*args, **kwargs)
        elapsed = time.perf_counter() - start
        logger.info(f"{func.__name__} took {elapsed:.3f}s")
        return result
    return wrapper

@timed
async def handle_query(args: dict):
    # ...
    pass
```

**Track Tool Usage**:
```python
class ToolMetrics:
    """Track tool usage statistics"""
    
    def __init__(self):
        self.call_counts: dict[str, int] = {}
        self.total_time: dict[str, float] = {}
        self.errors: dict[str, int] = {}
    
    def record_call(self, tool_name: str, duration: float, error: bool = False):
        self.call_counts[tool_name] = self.call_counts.get(tool_name, 0) + 1
        self.total_time[tool_name] = self.total_time.get(tool_name, 0) + duration
        if error:
            self.errors[tool_name] = self.errors.get(tool_name, 0) + 1
    
    def get_stats(self) -> dict:
        return {
            "calls": self.call_counts,
            "avg_time": {
                k: self.total_time[k] / self.call_counts[k]
                for k in self.call_counts
            },
            "errors": self.errors
        }
```

### 2. Profiling

**CPU Profiling**:
```python
import cProfile
import pstats

# Profile a function
profiler = cProfile.Profile()
profiler.enable()

# Run code
result = expensive_function()

profiler.disable()
stats = pstats.Stats(profiler)
stats.sort_stats('cumulative')
stats.print_stats(20)  # Top 20 functions
```

**Memory Profiling**:
```python
from memory_profiler import profile

@profile
def memory_intensive_function():
    # Function will be profiled for memory usage
    pass
```

### 3. Logging Optimization

**Structured Logging**:
```python
import structlog

logger = structlog.get_logger()

# Log with context
logger.info(
    "query_processed",
    tool="rag_query",
    duration_ms=duration * 1000,
    result_count=len(results),
    cache_hit=cache_hit
)
```

**Conditional Debug Logging**:
```python
# Only log details if DEBUG level
if logger.isEnabledFor(logging.DEBUG):
    logger.debug(f"Detailed context: {expensive_to_serialize(data)}")
```

---

## Optimization Checklist

### Quick Wins (Implement First)

- [ ] Enable RAG caching
- [ ] Use smaller embedding model (bge-small)
- [ ] Reduce RAG context window to 2048 tokens
- [ ] Cache Git status for 30 seconds
- [ ] Limit git log to 50 commits max
- [ ] Add LRU cache to file analysis
- [ ] Clean up old memories (>90 days)

### Medium Impact (Next Priority)

- [ ] Implement parallel indexing
- [ ] Add file modification tracking
- [ ] Optimize ChromaDB settings
- [ ] Batch file operations
- [ ] Use smaller LLM (ministral-3:3b or qwen3-coder:1.5b)
- [ ] Add performance metrics
- [ ] Implement incremental RAG indexing

### Advanced (Optional)

- [ ] Distributed caching (Redis)
- [ ] Process pooling for Git operations
- [ ] GPU acceleration for embeddings
- [ ] Custom HNSW index tuning
- [ ] Multi-level cache hierarchy
- [ ] Advanced memory profiling

---

## Performance Testing

### Benchmark Script

```python
#!/usr/bin/env python3
"""MCP Performance Benchmark"""

import asyncio
import time
from pathlib import Path

async def benchmark_rag():
    """Benchmark RAG operations"""
    queries = [
        "What are the 9 cognition patterns?",
        "How does event processing work?",
        "Explain the architecture",
    ]
    
    times = []
    for query in queries:
        start = time.perf_counter()
        # Run query
        await run_rag_query(query)
        elapsed = time.perf_counter() - start
        times.append(elapsed)
    
    print(f"RAG avg: {sum(times)/len(times):.2f}s")

async def benchmark_git():
    """Benchmark Git operations"""
    ops = [
        ("status", []),
        ("log", ["-n", "50"]),
        ("branch", ["-a"]),
    ]
    
    for op, args in ops:
        start = time.perf_counter()
        # Run git operation
        await run_git_command(op, args)
        elapsed = time.perf_counter() - start
        print(f"Git {op}: {elapsed*1000:.1f}ms")

async def main():
    print("=" * 60)
    print("MCP Performance Benchmark")
    print("=" * 60)
    
    await benchmark_rag()
    await benchmark_git()

if __name__ == "__main__":
    asyncio.run(main())
```

---

## Summary

### Key Optimization Principles

1. **Cache Aggressively**: Cache at multiple levels (memory, disk, distributed)
2. **Limit Scope**: Don't process more than necessary
3. **Parallelize**: Use async/await and thread pools
4. **Monitor**: Track metrics to identify bottlenecks
5. **Iterate**: Profile, optimize, measure, repeat

### Expected Improvements

After implementing optimizations:

- **RAG queries**: 30-50% faster
- **Git operations**: 20-40% faster
- **Memory usage**: 25-35% reduction
- **Startup time**: 40-60% faster
- **Overall responsiveness**: Significantly improved

### Next Steps

1. Run benchmark to establish baseline
2. Implement quick wins
3. Measure improvements
4. Tackle medium-impact optimizations
5. Profile and identify remaining bottlenecks

---

**Document Version**: 1.0  
**Last Updated**: 2025-01-15  
**Performance Target**: <3s for typical RAG query, <100ms for Git operations