# Test Setup and Troubleshooting

## Prerequisites

### System Requirements

1. **Microsoft Visual C++ Redistributable**
   - Required for PyTorch (used by sentence-transformers)
   - Download: https://aka.ms/vs/17/release/vc_redist.x64.exe
   - Install if you see: `OSError: [WinError 126] The specified module could not be found`

2. **Python 3.13+**
   - GRID uses Python 3.13
   - Ensure virtual environment uses Python 3.13

## Installation Steps

### 1. Install Dependencies

```powershell
# Install missing dependencies
pip install psutil
```

### 2. Install Visual C++ Redistributable (if needed)

If you see torch DLL errors:
1. Download: https://aka.ms/vs/17/release/vc_redist.x64.exe
2. Install the redistributable
3. Restart your terminal
4. Re-run tests

### 3. Run Tests

```powershell
# Run all tests
python -m pytest

# Run specific test file
python -m pytest tests/unit/test_events_core.py

# Run with verbose output
python -m pytest -v

# Run with coverage
python -m pytest --cov=src --cov-report=term-missing
```

## Known Test Issues

### 1. Torch DLL Error

**Error**:
```
OSError: [WinError 126] The specified module could not be found. Error loading torch\lib\c10.dll
```

**Solution**: Install Visual C++ Redistributable from https://aka.ms/vs/17/release/vc_redist.x64.exe

### 2. Missing psutil

**Error**:
```
ModuleNotFoundError: No module named 'psutil'
```

**Solution**:
```powershell
pip install psutil
```

### 3. DEFINITION Module Import

**Error**:
```
ModuleNotFoundError: No module named 'DEFINITION'
```

**Solution**: This is expected - DEFINITION is in `.context/` and added to sys.path by conftest.py. The import works at runtime but not statically.

## Skipping Problematic Tests

If certain tests fail due to missing dependencies, you can skip them:

```python
# Add this to test files that require torch
import pytest

try:
    import torch
    HAS_TORCH = True
except (ImportError, OSError):
    HAS_TORCH = False

pytestmark = pytest.mark.skipif(
    not HAS_TORCH,
    reason="Requires PyTorch (needs Visual C++ Redistributable)"
)
```

## Running Tests Without Problematic Dependencies

```powershell
# Skip tests that require torch
python -m pytest -m "not (cross_encoder or hybrid_search)"

# Skip integration tests
python -m pytest tests/unit/

# Run only unit tests
python -m pytest tests/unit/ -v
```

## Quick Fix Commands

```powershell
# Install missing dependencies
pip install psutil

# Reinstall torch with proper dependencies
pip uninstall torch
pip install torch

# Run tests
python -m pytest tests/unit/ -v --tb=short
```

## Test Organization

- **Unit Tests**: `tests/unit/` - Test individual modules
- **Integration Tests**: `tests/integration/` - Test component integration
- **API Tests**: `tests/api/` - Test API endpoints
- **Cognitive Tests**: `tests/cognitive/` - Test cognitive layer
- **Performance Tests**: `tests/performance/` - Performance benchmarks

## Common Issues

### Issue: Tests fail with import errors

**Cause**: Missing dependencies or incorrect Python path

**Solution**:
```powershell
# Ensure you're in the project root
cd E:\grid

# Activate virtual environment
.\.venv\Scripts\Activate.ps1

# Reinstall dependencies
uv pip install -e .

# Run tests
python -m pytest
```

### Issue: Tests fail with path errors

**Cause**: Incorrect working directory

**Solution**: Always run tests from project root (`E:\grid`)

### Issue: Tests timeout

**Cause**: Tests taking too long

**Solution**:
```powershell
# Increase timeout
python -m pytest --timeout=60
```

## Getting Help

If tests continue to fail:

1. Check the error message carefully
2. Install missing dependencies
3. Ensure Visual C++ Redistributable is installed
4. Run from project root directory
5. Check virtual environment is activated
6. Review test output for specific errors
