# Dependency Version Matrix

**Last Updated:** 2026-01-24

This document tracks version decisions, compatibility constraints, and divergence reasons across all Python projects in the workspace.

**Related Documents:**

- [DEVELOPMENT_GUIDE.md](DEVELOPMENT_GUIDE.md) - Build, test, and deployment commands
- [AGENTS.md](docs/AGENTS.md) - AI agent behavior guidelines and patterns
- [SECURITY_VULNERABILITY_REPORT.md](SECURITY_VULNERABILITY_REPORT.md) - Security status and fixes

## Overview

This workspace contains multiple Python projects with varying dependency requirements. While some core dependencies align (FastAPI, Pydantic), others diverge due to specific project needs (e.g., ML/AI libraries for EUFLE).

### Workspace Strategy

- **Python Version:** Unified on Python 3.13.11 across all projects.
- **Package Manager:** `uv` is the primary recommended tool for speed and resolution, with `pip` as a fallback.
- **Virtual Environments:** Each core project maintains its own isolated virtual environment to prevent cross-project dependency conflicts.

## Core Projects

### GRID (`grid/`)

- **Version**: 2.2.0
- **Location**: `e:\grid`
- **Python**: 3.13.11 (Constraint: `>=3.13,<3.14`)
- **Primary requirements**: `pyproject.toml`, `requirements.txt`
- **Virtual environment**: `e:\grid\.venv`
- **Key dependencies**: `fastapi>=0.104.0`, `scikit-learn==1.8.0` (pinned), `mcp[cli]>=1.25.0`

### EUFLE (`EUFLE/`)

- **Location**: `e:\grid\EUFLE`
- **Python**: 3.13.11
- **Requirements**: [DEPENDENCIES.md](file:///e:/grid/EUFLE/docs/DEPENDENCIES.md), `config/requirements.txt`
- **Status**: Separate subproject with independent ML/AI dependency management.
- **Key dependencies**: `torch==2.9.1+cpu`, `transformers==4.57.3`, `peft==0.18.0`

### Legacy Pipeline (`archive/legacy/pipeline/`)

- **Location**: `e:\grid\archive\legacy\pipeline`
- **Python**: 3.13.11 (Legacy support for 3.8-3.12)
- **Requirements**: `pyproject.toml`, `requirements.txt`
- **Status**: Archived data processing system for unstructured data.
- **Key dependencies**: `pydantic>=2.0.0`, `scikit-learn>=1.3.0`

## Python Version Configuration

The workspace enforces Python 3.13.11 through a layered configuration:

1. **Root Configuration**: `.python-version` in `e:\grid` specifies `3.13.11`, detected by `pyenv` and `uv`.
2. **Package Manager Constraint**: `pyproject.toml` specifies `requires-python = ">=3.13,<3.14"`.
3. **Environment Setup**: Initialized via `uv venv --python 3.13 --clear` as documented in `README.md`.

## Docker Build Strategy

GRID uses containerization for consistent deployment:

- **Base Image**: `python:3.13-slim` for a minimal runtime environment.
- **Multi-Stage Build**: A builder stage installs `uv` and dependencies, while the final stage copies only the built virtual environment.
- **Layer Caching**: `requirements.txt` and `uv.lock` are copied and installed before application code to leverage Docker's layer cache.
- **Security**: Executes as a non-root user (`grid:grid`) following the principle of least privilege.

## Opentelemetry Status

**Current Status**: No opentelemetry packages are currently used across any projects.

**Audit Results (2025-01-08):**

- Searched all `requirements*.txt` files across workspace; no opentelemetry packages found.

## Version Alignment Strategy

### Critical Dependencies (Should Align)

- **Python**: All projects target 3.13.11 - **Aligned**.
- **FastAPI**: All relevant projects use `>=0.104.0` - **Aligned**.
- **Pydantic**: GRID targets `>=2.4.0`, Pipeline targets `>=2.0.0` - **Compatible**.

### Independent Dependencies (Can Diverge)

- **ML/AI libraries**: EUFLE has specific heavy ML requirements (`torch`, `transformers`) that are independent from GRID core.
- **Database drivers**: Projects may use different drivers (e.g., `asyncpg`, `databricks-sql-connector`) based on specific integration needs.

## Package Manager Strategy

### Primary: `uv`

- Faster dependency resolution and installation.
- Recommended for all new installations and CI/CD pipelines.

### Fallback: `pip`

- Available within virtual environments (e.g., via `ensurepip`).
- Use only when `uv` is unavailable or for legacy compatibility.

---

## AI Agent Development Integration

### Agent Workflow Dependencies

| Component          | Command                            | Purpose                            |
| ------------------ | ---------------------------------- | ---------------------------------- |
| Environment Setup  | `uv venv --python 3.13 --clear`    | Initialize isolated venv           |
| Dependency Install | `uv sync --group dev --group test` | Full dev environment               |
| Security Tests     | `pytest tests/security/`           | Validate path traversal protection |
| Linting            | `ruff check . && black --check .`  | Code quality                       |
| Type Checking      | `mypy src/grid`                    | Type safety                        |

### Path Traversal Security Context

> [!CAUTION]
> All file operations in agent workflows must use `PathValidator`.

**Critical Pattern:**

```python
from src.grid.security.path_validator import PathValidator

# Validate paths before file operations
base_path = Path(allowed_directory).resolve()
validated = PathValidator.validate_path(user_input, base_path)
```

**Security Tests Location:** `tests/security/test_path_traversal.py`

### Docker Integration Points

- **Base Image**: `python:3.13-slim`
- **Build Strategy**: Multi-stage with `uv` for dependency caching
- **Runtime User**: `grid:grid` (non-root)

### Agent Prompts Context

When working with GRID dependencies, agents should:

1. Check `DEPENDENCY_MATRIX.md` for version constraints
2. Use `uv` for all package management operations
3. Validate file paths with `PathValidator` class
4. Test security implications of dependency changes
5. Respect the dual package manager strategy (uv primary, pip fallback)

\_Audit Notes:

- **Date**: 2026-01-24
- **Audit**: Opentelemetry audit completed - no packages found
- **B904 fixes**: Exception chaining fixes completed across all projects
- **Environment**: Verified pip availability in .venv
- **Security**: All 9/9 security tests passing - PathValidator implemented
- **Automation**: Agent setup script and CI validation deployed
