# Multi-Repository Git MCP Server

A custom MCP server that provides Git operations for multiple repositories, allowing you to switch between different codebases seamlessly.

## Features

- **Multiple Repository Support**: Work with multiple Git repositories simultaneously
- **Repository Switching**: Switch between repositories on the fly
- **Standard Git Operations**: Status, log, diff, branches, file content
- **Dynamic Repository Addition**: Add new repositories without restarting

## Configuration

The server is configured in `c:\Users\irfan\.codeium\windsurf\mcp_config.json`:

```json
"git": {
  "args": ["E:\\grid\\src\\grid\\mcp\\multi_git_server.py"],
  "command": "C:\\Users\\irfan\\AppData\\Local\\Programs\\Python\\Python313\\python.exe",
  "disabled": false,
  "env": {
    "PYTHONPATH": "E:\\grid\\src;E:\\grid",
    "GIT_MCP_REPOSITORIES": "default:E:\\grid;docs:E:\\grid\\docs"
  }
}
```

### Environment Variables

- **GIT_MCP_REPOSITORIES**: Semicolon-separated list of repositories
  - Format: `name1:path1[:description1];name2:path2[:description2]`
  - Example: `main:C:\\project;docs:C:\\project\\docs:Documentation`

## Available Tools

### Repository Management

- `git_list_repos` - List all configured repositories
- `git_switch_repo` - Switch to a different repository
- `git_add_repo` - Add a new repository

### Git Operations

- `git_status` - Show repository status (porcelain)
- `git_log` - Show recent commits
- `git_diff` - Show diff between refs or working tree
- `git_branches` - List all branches
- `git_show_file` - Show file content at specific ref

## Usage Examples

### 1. List all repositories

```json
{
  "name": "git_list_repos",
  "arguments": {}
}
```

### 2. Switch repository

```json
{
  "name": "git_switch_repo",
  "arguments": {
    "repo": "docs"
  }
}
```

### 3. Get status (uses active repo)

```json
{
  "name": "git_status",
  "arguments": {}
}
```

### 4. Get status for specific repo

```json
{
  "name": "git_status",
  "arguments": {
    "repo": "docs"
  }
}
```

### 5. Show recent commits

```json
{
  "name": "git_log",
  "arguments": {
    "max_count": 10
  }
}
```

### 6. Add a new repository

```json
{
  "name": "git_add_repo",
  "arguments": {
    "name": "frontend",
    "path": "C:\\project\\frontend",
    "description": "Frontend application"
  }
}
```

## Repository Format

The server supports repositories in the following format:

- **Default repository**: Always available, points to current working directory
- **Environment-defined**: Loaded from `GIT_MCP_REPOSITORIES` environment variable
- **Dynamic addition**: Add repositories at runtime using `git_add_repo`

## Sample Output

### git_list_repos

```json
[
  {
    "name": "default",
    "path": "E:\\grid",
    "description": "Current working directory",
    "is_active": true,
    "branch": "main"
  },
  {
    "name": "docs",
    "path": "E:\\grid\\docs",
    "description": "Documentation",
    "is_active": false,
    "branch": "gh-pages"
  }
]
```

### git_status

```
 M src/app.py
 M README.md
?? new_file.txt
```

### git_log

```
a1b2c3d (HEAD -> main) Add new feature
e4f5g6h (origin/main) Fix bug in parser
i7j8k9l Update documentation
```

## Error Handling

The server provides clear error messages for:

- Repository not found
- Not a git repository
- Invalid git operations
- Missing required arguments

## Best Practices

1. **Repository Naming**: Use descriptive names (e.g., "frontend", "backend", "docs")
2. **Path Validation**: Ensure paths exist and contain `.git` directory
3. **Active Repository**: Always check which repository is active before operations
4. **Environment Setup**: Configure repositories in environment for persistence

## Troubleshooting

### Common Issues

1. **"Repository not found"**
   - Check if the repository name is correct
   - Use `git_list_repos` to see available repositories

2. **"Not a git repository"**
   - Ensure the path contains a `.git` directory
   - Initialize with `git init` if needed

3. **"Git command failed"**
   - Check if the repository is in a valid git state
   - Verify file permissions

### Adding New Repositories

1. **Via Environment Variable** (requires restart):

   ```bash
   GIT_MCP_REPOSITORIES="name1:path1;name2:path2"
   ```

2. **Via Tool** (dynamic):
   ```json
   {
     "name": "git_add_repo",
     "arguments": {
       "name": "new-repo",
       "path": "C:\\path\\to\\repo"
     }
   }
   ```

## Integration with IDE

The server integrates seamlessly with MCP-compatible IDEs, providing:

- Auto-completion for repository names
- Context-aware git operations
- Quick switching between repositories
- Real-time status updates
