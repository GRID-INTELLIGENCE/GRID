# CI/CD Pipeline Monitoring Guide

**Last Updated:** 2026-01-07
**Status:** ✅ Active monitoring system in place

## Overview

This guide explains how to monitor GitHub Actions workflows from the CLI and use the iterative feedback loop to automatically fix issues until the CI/CD pipeline is fully green.

---

## Quick Start

### Monitor and Auto-Fix CI/CD Pipeline

```bash
# Run iterative feedback loop (auto-fixes issues)
python scripts/monitor_ci_feedback_loop.py

# Watch-only mode (no fixes)
python scripts/monitor_ci_feedback_loop.py --watch-only

# Specify workflow and max iterations
python scripts/monitor_ci_feedback_loop.py --workflow "GRID CI/CD Pipeline" --max-iterations 10
```

### Using Makefile

```bash
# Monitor and auto-fix
make monitor-ci

# Watch-only mode
make monitor-ci-watch
```

---

## Manual Monitoring Commands

### Check Latest Workflow Run

```bash
# List latest workflow runs
gh run list --workflow "GRID CI/CD Pipeline" --limit 5

# View specific run details
gh run view <run-id>

# View run logs
gh run view <run-id> --log

# Watch a running workflow
gh run watch <run-id>
```

### Check Workflow Status

```bash
# Get latest run status
gh run list --workflow "GRID CI/CD Pipeline" --limit 1 --json status,conclusion,url

# Get failed jobs
gh run view <run-id> --json jobs --jq '.jobs[] | select(.conclusion=="failure") | {name: .name, conclusion: .conclusion, url: .url}'
```

---

## Feedback Loop Script

### Features

The `monitor_ci_feedback_loop.py` script provides:

1. **Automatic Workflow Detection** - Finds the latest workflow run
2. **Status Monitoring** - Tracks job status and completion
3. **Auto-Fix Capabilities** - Attempts to fix common issues:
   - Lint issues (Ruff auto-fix)
   - Format issues (Black auto-format)
   - Test failures (runs locally to see errors)
4. **Iterative Improvement** - Commits and pushes fixes automatically
5. **Status Reporting** - Shows detailed job status and URLs

### Script Options

```bash
python scripts/monitor_ci_feedback_loop.py [OPTIONS]

Options:
  --workflow WORKFLOW         Workflow name to monitor (default: "GRID CI/CD Pipeline")
  --max-iterations N          Maximum iterations before giving up (default: 10)
  --watch-only                Only watch, don't attempt fixes
  -h, --help                  Show help message
```

### How It Works

1. **Fetch Latest Run** - Gets the most recent workflow run
2. **Check Status** - Determines if workflow is complete
3. **Identify Failures** - Lists all failed jobs
4. **Attempt Fixes** - Runs local checks and fixes issues:
   - For lint jobs: Runs `ruff check` and `ruff check --fix`
   - For format jobs: Runs `black --check` and `black`
   - For test jobs: Runs `pytest` locally to see errors
5. **Commit & Push** - Commits fixes with descriptive message
6. **Wait & Repeat** - Waits for next workflow run and repeats

### Example Output

```
============================================================
[GRID] CI/CD Pipeline Feedback Loop
============================================================
Workflow: GRID CI/CD Pipeline
Max iterations: 10
============================================================

============================================================
Iteration 1/10
============================================================

[INFO] Fetching latest workflow run for: GRID CI/CD Pipeline
[INFO] Workflow Run: 20801366322
[INFO] Status: completed
[INFO] Conclusion: failure
[INFO] URL: https://github.com/irfankabir02/GRID/actions/runs/20801366322
[INFO] Branch: architecture/stabilization
[INFO] SHA: c36c55be

[INFO] Found 2 failed job(s):
  - Lint: failure (https://github.com/.../job/59746801026)
  - CI Status Summary: failure (https://github.com/.../job/59746831550)

[INFO] Attempting to fix: Lint
[INFO] Analyzing failed job: Lint
[INFO] Running local lint check (ruff)...
[FAIL] Lint check failed
[INFO] Attempting to auto-fix lint issues...
[OK] Changes committed and pushed
```

---

## Common Issues and Fixes

### Lint Failures (Ruff)

**Issue:** Import sorting, unused variables, code style violations

**Auto-Fix:**
```bash
# Script automatically runs:
uv run ruff check . --fix
```

**Manual Fix:**
```bash
uv run ruff check .
uv run ruff check . --fix
```

### Format Failures (Black)

**Issue:** Code formatting doesn't match Black standards

**Auto-Fix:**
```bash
# Script automatically runs:
uv run black grid/ application/ tools/ tests/
```

**Manual Fix:**
```bash
uv run black --check grid/ application/ tools/ tests/
uv run black grid/ application/ tools/ tests/
```

### Test Failures

**Issue:** Unit tests failing in CI

**Debug:**
```bash
# Run tests locally (script does this automatically)
uv run pytest tests/unit/ -v

# Run with specific error details
uv run pytest tests/unit/ -v --tb=short
```

### Build Failures

**Issue:** Package build fails

**Debug:**
```bash
# Build locally
uv run python -m build

# Verify package
uv run twine check dist/*
```

---

## Continuous Monitoring

### Setup Automated Monitoring

You can set up a cron job or scheduled task to run the monitoring script:

**Linux/macOS (cron):**
```bash
# Run every 5 minutes
*/5 * * * * cd /path/to/grid && python scripts/monitor_ci_feedback_loop.py --max-iterations 3
```

**Windows (Task Scheduler):**
```powershell
# Create scheduled task to run every 5 minutes
$action = New-ScheduledTaskAction -Execute "python" -Argument "E:\grid\scripts\monitor_ci_feedback_loop.py --max-iterations 3" -WorkingDirectory "E:\grid"
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Hours 24)
Register-ScheduledTask -TaskName "Monitor GRID CI" -Action $action -Trigger $trigger
```

---

## Best Practices

1. **Run Locally First** - Always test fixes locally before pushing
2. **Check Logs** - Review CI/CD job logs for detailed error messages
3. **Iterative Fixes** - Fix one issue at a time, commit, and re-check
4. **Monitor Progress** - Use `--watch-only` to monitor without auto-fixing
5. **Set Limits** - Use `--max-iterations` to prevent infinite loops

---

## Troubleshooting

### Script Can't Find Workflow

**Issue:** `[ERROR] Could not fetch workflow runs`

**Fix:**
```bash
# Check if GitHub CLI is authenticated
gh auth status

# Check if workflow name is correct
gh workflow list

# Use exact workflow name
python scripts/monitor_ci_feedback_loop.py --workflow "GRID CI/CD Pipeline"
```

### Auto-Fix Doesn't Work

**Issue:** Script can't auto-fix issues

**Fix:**
- Check if issue is in auto-fixable category (lint, format)
- Review job logs for manual fixes required
- Use `--watch-only` mode to see issues without fixing

### Script Stuck in Loop

**Issue:** Script keeps iterating without fixing

**Fix:**
- Use `--max-iterations` to limit iterations
- Check if fixes are actually being committed
- Review git status to see if changes are staged

---

## Integration with CI/CD

The monitoring script integrates seamlessly with:

- ✅ **Pre-push hooks** - Run local checks before push
- ✅ **CI/CD pipeline** - Same checks run in GitHub Actions
- ✅ **Makefile** - Easy commands via `make monitor-ci`

---

## References

- **CI/CD Pipeline:** `.github/workflows/main.yaml`
- **Deployment Map:** `docs/DEPLOYMENT_MAP.md`
- **Git Hooks:** `scripts/hooks/pre-push-evolved`
- **GitHub CLI Docs:** https://cli.github.com/manual/

---

## Summary

✅ **Automated monitoring and feedback loop is ready**
✅ **Auto-fixes common lint and format issues**
✅ **Integrates with CI/CD pipeline and git hooks**
✅ **Cross-platform compatible (Windows/Linux/macOS)**

The monitoring system continuously checks, refines, and updates the codebase until the CI/CD pipeline is fully green.
