# GRID Satellite Navigation System

**Created:** 2026-01-10  
**Purpose:** Eliminate path conflicts and import errors through spatial intelligence

---

## 🛰️ **System Overview**

This system combines:
1. **Territory Map** (`application/canvas/territory_map.py`) - Spatial hierarchy of GRID codebase
2. **Path Navigator** (`scripts/path_navigator.py`) - CLI tool with LLM integration  
3. **Wheel Visualization** (`application/canvas/wheel.py`) - Existing dynamic zone tracking

Together, they form a **self-aware navigation layer** for GRID development.

---

## 📍 **Territory Zones**

Aligned with `wheel.py` WheelZone enum:

| Zone | Location | Purpose |
|------|----------|---------|
| **CORE** | `src/grid/` | Core intelligence, agentic systems, events |
| **COGNITIVE** | `src/cognitive/` | Cognitive processing layer |
| **APPLICATION** | `src/application/` | FastAPI apps (mothership, resonance, canvas) |
| **TOOLS** | `src/tools/` | Utilities, RAG, integration |
| **ARENA** | `Arena/` | Simulation and game systems |
| **INTERFACES** | `src/grid/interfaces/` | Bridge components |
| **AGENTIC** | `src/grid/agentic/` | Agentic system core |

---

## 🗺️ **Spatial Pyramid Levels**

Inspired by Google Earth Engine tile pyramids:

```
L0: ROOT           e:\grid
L1: PACKAGES       src/, tests/, config/
L2: MODULES        grid/, application/, tools/
L3: SUBMODULES     mothership/, resonance/, canvas/
L4: COMPONENTS     routers/, models/, schemas/
L5: FILES          Individual .py files
```

---

## 🔧 **Usage**

### Show Territory Map
```powershell
python scripts/path_navigator.py map
```

**Output:**
```
📦 APPLICATION Zone (4 nodes)
   • src\application
     Import: application
   • src\application\mothership
     Import: application.mothership
```

### Get Import Guide
```powershell
# All patterns
python scripts/path_navigator.py guide

# Filter by zone
python scripts/path_navigator.py guide application
```

### Diagnose Import Error
```powershell
python scripts/path_navigator.py diagnose "No module named 'application'"
```

**Output:**
```
🛰️  GRID Path Navigator - Diagnosing Import Error

Error: No module named 'application'

📍 Map Analysis:
   PYTHONPATH issue: Run from src/ or set PYTHONPATH=e:\grid\src

🤖 Consulting Mistral LLM...
   Fix: Ensure PYTHONPATH includes src/. Run: $env:PYTHONPATH="e:\grid\src"
```

---

## 🧠 **LLM Integration**

The navigator consults **Mistral Nemo** (7.1GB local model) for dynamic context:

1. Territory map provides **structural knowledge**
2. Mistral provides **contextual intelligence**
3. Combined = **precise diagnosis**

To use a different model:
```python
# In path_navigator.py
call_mistral(prompt, model="deepseek-v3.2:cloud")  # Use cloud model
```

---

## 📊 **Common Import Patterns**

### Pattern 1: Relative Imports (within same module)
```python
# ✅ CORRECT
from . import routers  # In application/mothership/__init__.py
from .config import settings  # In application/mothership/main.py

# ❌ WRONG
from application.mothership import routers  # Absolute when relative is cleaner
```

### Pattern 2: Absolute Imports (cross-module)
```python
# ✅ CORRECT
from application.mothership.main import create_app
from grid.agentic.agentic_system import AgenticSystem

# ❌ WRONG
from src.application.mothership import main  # Don't include 'src'
```

### Pattern 3: Cross-Zone Imports
```python
# ✅ CORRECT (APPLICATION → CORE)
from grid.events.core import EventBus

# ✅ CORRECT (APPLICATION → TOOLS)
from tools.integration import ToolsProvider

# ❌ WRONG
from ..grid.events import EventBus  # Don't use relative for cross-zone
```

---

## 🔍 **How It Works**

### Satellite Observation Pattern
1. **High-level scan** - Identify major zones (L0-L2)
2. **Zone mapping** - Catalog each zone's components (L3-L4)
3. **Path indexing** - Store import paths and relationships
4. **Pattern learning** - Register common import patterns

### Resolution Intelligence
1. **Structural check** - Does path exist in territory map?
2. **Pattern match** - Which common pattern applies?
3. **LLM consultation** - Ask Mistral for context-specific advice
4. **Provide fix** - Return actionable solution

---

## 🎯 **Best Practices (From Earlier Challenges)**

Based on your early terminal struggles:

### ✅ DO:
1. **Always run from `src/`** - `cd E:\grid\src; python -m application.mothership.main`
2. **Use `python -m`** - Not bare script names
3. **Set PYTHONPATH** - `$env:PYTHONPATH="e:\grid\src"`
4. **Verify with map** - `python scripts/path_navigator.py map`
5. **Consult LLM** - Let Mistral help with tricky errors

### ❌ AVOID:
1. Including `src/` in import paths
2. Relative imports for cross-zone navigation
3. Running scripts without setting PYTHONPATH
4. Hardcoding absolute paths in code

---

## 🚀 **Integration with Existing Tools**

### With CLI Helpers
```powershell
# Load helpers + navigate
. E:\grid\scripts\cli_helpers.ps1
gridsrc  # Navigate to src/

# Run path navigator
python scripts/path_navigator.py guide
```

### With Canvas Wheel
```python
from application.canvas.wheel import EnvironmentWheel, WheelZone
from application.canvas.territory_map import get_grid_map

wheel = EnvironmentWheel()
grid_map = get_grid_map()

# Track agent movement through zones
wheel.add_agent("agent-1", "Navigator", WheelZone.APPLICATION)
zone_map = grid_map.get_zone_map()
```

### Programmatic API
```python
from application.canvas.territory_map import get_grid_map

grid_map = get_grid_map()

# Check import validity
fix = grid_map.resolve_import_path(
    Path("e:/grid/src/application/mothership/main.py"),
    "from application.canvas import router"
)

if fix:
    print(f"Suggested fix: {fix}")
else:
    print("Import looks valid!")
```

---

## 📦 **Files Created**

| File | Purpose |
|------|---------|
| `src/application/canvas/territory_map.py` | Core territory map with spatial hierarchy |
| `scripts/path_navigator.py` | Interactive CLI navigator with LLM integration |
| `docs/SATELLITE_NAVIGATION.md` | This documentation |

---

## 🌟 **Key Innovations**

1. **Self-referential intelligence** - GRID helps navigate GRID
2. **Spatial hierarchy** - Borrowed from Google Maps/Earth Engine
3. **LLM augmentation** - Mistral provides dynamic context
4. **Zone-based navigation** - Aligned with existing wheel system
5. **Error prevention** - Catches issues before they interrupt flow

---

## 🎓 **Learning from Early Challenges**

You mentioned path conflicts and import errors interrupted your flow. This system addresses them by:

- **Pre-validation** - Check imports before running
- **Instant diagnosis** - No more searching Stack Overflow
- **Pattern library** - Common fixes at your fingertips
- **LLM backup** - Mistral handles edge cases
- **Spatial awareness** - Always know where you are in the codebase

---

*"When you observe something from up above, the routine itself feeds the monitoring and logging best practices."*  
— Your vision, implemented as spatial intelligence for GRID navigation.
