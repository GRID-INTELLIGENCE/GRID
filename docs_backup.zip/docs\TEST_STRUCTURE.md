# Test Structure Documentation

## Overview

GRID maintains a comprehensive test suite organized by test type and domain. This document catalogs the test structure and organization patterns.

## Test Directory Structure

```
tests/
├── api/                    # API endpoint tests
├── integration/            # Integration tests
├── unit/                   # Unit tests
│   └── navigation/         # Navigation-specific unit tests
├── performance/            # Performance tests
├── security/               # Security tests
├── skills/                 # Skills system tests
├── load/                   # Load testing
├── scratch/                # Experimental tests
└── fixtures/               # Test fixtures
```

## Test Organization

### 1. API Tests (`tests/api/`)

**Purpose**: Test FastAPI endpoints and HTTP interactions.

**Files (13 files)**:
- `test_auth_jwt.py`: JWT authentication tests
- `test_e2e.py`: End-to-end API tests
- `test_jwt_security_advanced.py`: Advanced JWT security tests
- `test_navigation_simple.py`: Simple navigation API tests
- `test_navigation.py`: Navigation API tests
- `test_property_based_auth.py`: Property-based auth tests
- `test_router.py`: Router tests
- `test_schemas.py`: Schema validation tests
- `test_security_governance.py`: Security governance tests
- `test_service.py`: Service endpoint tests
- `test_streaming_security.py`: Streaming security tests
- `test_websocket.py`: WebSocket endpoint tests
- `conftest.py`: Pytest fixtures and configuration

**Test Patterns**:
- FastAPI TestClient usage
- Authentication testing
- Authorization testing
- Schema validation
- Error handling

**Example**:
```python
from fastapi.testclient import TestClient

def test_health_endpoint(client: TestClient):
    response = client.get("/api/v1/health/health")
    assert response.status_code == 200
```

### 2. Integration Tests (`tests/integration/`)

**Purpose**: Test cross-module integration and workflows.

**Files (5 files)**:
- `test_ai_brain_integration.py`: AI brain integration tests
- `test_navigation_auth_integration.py`: Navigation + auth integration
- `test_pipeline_robustness.py`: Pipeline robustness tests
- `test_rag_cli_flags.py`: RAG CLI integration tests
- `test_skill_contracts.py`: Skill contract tests

**Test Patterns**:
- Multi-component testing
- End-to-end workflows
- Contract testing
- Error propagation

**Example**:
```python
def test_skill_contract():
    skill = default_registry.get("rag.query_knowledge")
    result = skill.run({"query": "test"})
    assert "status" in result
```

### 3. Unit Tests (`tests/unit/`)

**Purpose**: Test individual components in isolation.

**Files (15+ files)**:

**Navigation Tests** (`tests/unit/navigation/`):
- `test_navigation_input.py`: Input processing tests
- `test_path_optimization_agent.py`: Path optimization tests

**Core Tests**:
- `test_cli.py`: CLI tests
- `test_contribution_tracker.py`: Contribution tracking tests
- `test_enhanced_path_navigator.py`: Enhanced navigation tests
- `test_input_processor.py`: Input processing tests
- `test_intelligent_routing.py`: Intelligent routing tests
- `test_message_broker_retry_persistence.py`: Message broker tests
- `test_nl_dev.py`: Natural language development tests
- `test_outputs.py`: Output handling tests
- `test_pattern_engine_dbscan.py`: DBSCAN pattern engine tests
- `test_pattern_engine_matching.py`: Pattern matching tests
- `test_pattern_engine_mist.py`: MIST pattern engine tests
- `test_pattern_engine_rag.py`: RAG pattern engine tests
- `test_skills_components.py`: Skills component tests
- `test_trajectory_diffusion.py`: Trajectory diffusion tests
- `test_transform_schema_map.py`: Schema transformation tests

**Test Patterns**:
- Component isolation
- Mock dependencies
- Fast execution
- Deterministic results

**Example**:
```python
def test_skill_discovery():
    engine = SkillDiscoveryEngine()
    count = engine.discover_skills()
    assert count > 0
```

### 4. Performance Tests (`tests/performance/`)

**Purpose**: Test performance characteristics and benchmarks.

**Files**:
- `capture_earth_baseline.py`: Baseline performance capture
- `earth_resonance_baseline.json`: Baseline metrics
- `test_resonance_load.py`: Resonance load tests

**Test Patterns**:
- Latency measurement
- Throughput testing
- Load testing
- Baseline comparison

**Example**:
```python
def test_resonance_performance():
    start = time.time()
    result = resonance_service.process(activity)
    duration = time.time() - start
    assert duration < 1.0  # Performance threshold
```

### 5. Security Tests (`tests/security/`)

**Purpose**: Test security features and vulnerabilities.

**Files**:
- `test_security_hardening.py`: Security hardening tests

**Test Patterns**:
- Vulnerability testing
- Security feature validation
- Attack simulation
- Compliance testing

**Example**:
```python
def test_sql_injection_protection():
    malicious_input = "'; DROP TABLE users; --"
    result = sanitizer.sanitize(malicious_input)
    assert "DROP" not in result
```

### 6. Skills Tests (`tests/skills/`)

**Purpose**: Test skills system components.

**Files**:
- `conftest.py`: Skills test fixtures

**Test Patterns**:
- Skill execution testing
- Registry testing
- Discovery testing
- Performance testing

### 7. Load Tests (`tests/load/`)

**Purpose**: Test system under load.

**Files**:
- `navigation_stream_test.js`: Navigation stream load test (JavaScript)

**Test Patterns**:
- Concurrent request testing
- Stress testing
- Endurance testing
- Capacity planning

### 8. Scratch Tests (`tests/scratch/`)

**Purpose**: Experimental and exploratory tests.

**Files (4 files)**:
- `analyze_repo.py`: Repository analysis
- `test_import.py`: Import testing
- `test_nomic_v2.py`: Nomic v2 embedding tests
- `test_rag_precision.py`: RAG precision tests

**Characteristics**:
- Excluded from CI (marked with `@pytest.mark.scratch`)
- Experimental code
- Not required to pass

### 9. Core Tests (`tests/`)

**Purpose**: Tests for core functionality.

**Files (44+ files)**:
- `test_agentic_api.py`: Agentic API tests
- `test_agentic_system.py`: Agentic system tests
- `test_arena_structure_fixes.py`: Arena structure tests
- `test_async_boolean.py`: Async boolean tests
- `test_boundary_foundation.py`: Boundary foundation tests
- `test_cli_guardrails.py`: CLI guardrail tests
- `test_compress_secure.py`: Secure compression tests
- `test_databricks_agentic.py`: Databricks agentic tests
- `test_domain_integrity.py`: Domain integrity tests
- `test_domain_tracking.py`: Domain tracking tests
- `test_embedded_agentic.py`: Embedded agentic tests
- `test_event_bus.py`: Event bus tests
- `test_event_handlers.py`: Event handler tests
- `test_fibonacci_evolution.py`: Fibonacci evolution tests
- `test_git_intelligence.py`: Git intelligence tests
- `test_git_topic_utils.py`: Git topic utility tests
- `test_grid_benchmark.py`: Grid benchmark tests
- `test_grid_intelligence.py`: Grid intelligence tests
- `test_honor_decay_edge_cases.py`: Honor decay edge case tests
- `test_hybrid_detection.py`: Hybrid detection tests
- `test_landscape_detector.py`: Landscape detector tests
- `test_mistral_iss.py`: Mistral ISS tests
- `test_overwatch_resonance_arena.py`: Overwatch resonance arena tests
- `test_paper_todos.py`: Paper todos tests
- `test_pencil_notes.py`: Pencil notes tests
- `test_pipeline_productivity.py`: Pipeline productivity tests
- `test_rag_contracts.py`: RAG contract tests
- `test_rag.py`: RAG tests
- `test_realtime_adapter.py`: Real-time adapter tests
- `test_safety_structural_integrity.py`: Safety structural integrity tests
- `test_skills_intelligence.py`: Skills intelligence tests
- `test_structural_learning.py`: Structural learning tests
- `test_sustain_decay_arena.py`: Sustain decay arena tests
- `test_tap_model.py`: TAP model tests
- `test_version_3_5.py`: Version 3.5 tests
- `test_version_4_5.py`: Version 4.5 tests
- `test_wealth_management_consolidation.py`: Wealth management tests
- `async_stress_harness.py`: Async stress testing harness
- `benchmark_arena_structure.py`: Arena structure benchmarking
- `smoke_test_inference.py`: Inference smoke tests
- `smoke_test_native_clients.py`: Native client smoke tests
- `verify_behavior_foundation.py`: Behavior foundation verification
- `verify_intelligence_recovery.py`: Intelligence recovery verification
- `verify_native_integration.py`: Native integration verification
- `run_arena_tests.py`: Arena test runner
- `conftest.py`: Global pytest fixtures

### 10. Test Fixtures (`tests/fixtures/`)

**Purpose**: Shared test data and fixtures.

**Files**:
- `report_example.json`: Example report fixture

**Usage**: Shared across multiple test files

### 11. Mock Skills (`tests/mock_skills/`)

**Purpose**: Mock skills for testing.

**Files**:
- `performance_optimization/metadata.json`: Mock skill metadata

## Test Configuration

### Pytest Configuration

**Location**: `pyproject.toml` (pytest.ini_options)

**Settings**:
- `pythonpath = ["src", "."]`
- `testpaths = ["tests"]`
- `python_files = ["test_*.py"]`
- `python_functions = ["test_*"]`
- `asyncio_mode = "auto"`

**Markers**:
- `@pytest.mark.scratch`: Experimental tests (excluded from CI)
- `@pytest.mark.unit`: Unit tests (fast, isolated)
- `@pytest.mark.integration`: Integration tests (slower, cross-module)
- `@pytest.mark.api`: API endpoint tests
- `@pytest.mark.critical`: Critical path tests (must pass)
- `@pytest.mark.flaky`: Flaky tests (may fail intermittently)
- `@pytest.mark.slow`: Slow running tests (> 1 second)
- `@pytest.mark.asyncio`: Async tests
- `@pytest.mark.database`: Tests requiring database

**Filtering**:
- Warnings filtered for pkg_resources, sqlalchemy, pydantic deprecations

### Conftest Files

**Location**: Multiple conftest.py files

**Files**:
- `tests/conftest.py`: Global fixtures
- `tests/api/conftest.py`: API test fixtures
- `tests/skills/conftest.py`: Skills test fixtures

**Purpose**: Shared fixtures and configuration

**Example**:
```python
@pytest.fixture
def test_client():
    from fastapi.testclient import TestClient
    from application.mothership.main import create_app
    app = create_app()
    return TestClient(app)
```

## Test Execution

### Running All Tests

```bash
pytest tests/
```

### Running by Category

```bash
# Unit tests only
pytest tests/unit/ -m unit

# Integration tests only
pytest tests/integration/ -m integration

# API tests only
pytest tests/api/ -m api

# Critical tests only
pytest -m critical
```

### Excluding Scratch Tests

```bash
pytest tests/ -m "not scratch"
```

### Running with Coverage

```bash
pytest tests/ --cov=src --cov-report=html
```

### Running Specific Test File

```bash
pytest tests/unit/test_skills_components.py
```

### Running Specific Test Function

```bash
pytest tests/unit/test_skills_components.py::test_skill_discovery
```

## Test Coverage

**Target**: 90%+ coverage for core components

**Measured Components**:
- Skills system
- Agentic system
- RAG engine
- Security layers
- API endpoints

**Tools**: pytest-cov

**Reporting**: HTML coverage reports

## Test Patterns

### 1. Unit Test Pattern

```python
def test_component_functionality():
    # Arrange
    component = Component()
    
    # Act
    result = component.method(input)
    
    # Assert
    assert result == expected
```

### 2. Integration Test Pattern

```python
async def test_integration_workflow():
    # Setup
    system = System()
    await system.initialize()
    
    # Execute
    result = await system.process(data)
    
    # Verify
    assert result.status == "success"
    
    # Cleanup
    await system.cleanup()
```

### 3. API Test Pattern

```python
def test_api_endpoint(client: TestClient):
    response = client.post(
        "/api/v1/endpoint",
        json={"data": "value"},
        headers={"Authorization": "Bearer token"}
    )
    assert response.status_code == 200
    assert response.json()["status"] == "success"
```

### 4. Property-Based Test Pattern

```python
from hypothesis import given, strategies as st

@given(st.text(min_size=1, max_size=100))
def test_processing_property(text):
    result = processor.process(text)
    assert isinstance(result, dict)
    assert "status" in result
```

### 5. Async Test Pattern

```python
@pytest.mark.asyncio
async def test_async_operation():
    result = await async_function()
    assert result is not None
```

## Test Markers Usage

### Scratch Tests

```python
@pytest.mark.scratch
def test_experimental_feature():
    # Experimental test - may fail
    pass
```

**CI**: Excluded by default

### Slow Tests

```python
@pytest.mark.slow
def test_time_consuming_operation():
    # Long-running test
    pass
```

**CI**: Run separately

### Critical Tests

```python
@pytest.mark.critical
def test_essential_feature():
    # Must pass for deployment
    assert critical_operation() == expected
```

**CI**: Always run, must pass

## Test Fixtures

### Common Fixtures

**Location**: `tests/conftest.py`

**Fixtures**:
- `test_client`: FastAPI TestClient
- `mock_skill_registry`: Mock skill registry
- `test_event_bus`: Event bus for testing
- `test_database`: Test database session

### Domain-Specific Fixtures

**API Tests**: `tests/api/conftest.py`
- `auth_headers`: Authentication headers
- `api_client`: Authenticated API client

**Skills Tests**: `tests/skills/conftest.py`
- `skill_registry`: Skill registry for testing
- `mock_execution_tracker`: Mock execution tracker

## Test Best Practices

1. **Isolation**: Each test should be independent
2. **Determinism**: Tests should produce consistent results
3. **Speed**: Unit tests should be fast (< 100ms each)
4. **Coverage**: Aim for 90%+ coverage on core components
5. **Readability**: Clear test names and assertions
6. **Maintenance**: Update tests when code changes
7. **CI Integration**: All tests should pass in CI

## CI/CD Integration

### GitHub Actions

**Workflows**:
- `agent_validation.yml`: Agent validation tests
- `main.yaml`: Main CI workflow
- `release.yaml`: Release validation
- `skills_continuous_quality.yml`: Skills quality checks

### Test Execution in CI

```yaml
- name: Run tests
  run: |
    pytest tests/ -m "not scratch" --cov=src --cov-report=xml
```

### Quality Gates

- All critical tests must pass
- Unit test coverage > 90%
- Integration tests must pass
- Security tests must pass

## Future Extensions

1. **Property-Based Testing**: More Hypothesis usage
2. **Mutation Testing**: Validate test quality
3. **Performance Regression**: Automated performance testing
4. **Chaos Engineering**: Failure injection testing
5. **Contract Testing**: API contract validation
