# Databricks Token Troubleshooting

## Current Status

✅ **DNS Resolution**: Fixed (using alternative hostname)  
⚠️ **Access Token**: 403 Forbidden - Invalid access token

## Token Validation

Your token format appears correct:
- ✅ Starts with `dapi`
- ✅ Length: 36 characters
- ✅ Format: Valid

However, Databricks is rejecting it with **403 Forbidden**.

## Possible Causes

### 1. Token Expired
- Access tokens can expire
- Check token creation date in Databricks

### 2. Insufficient Permissions
- Token may not have SQL warehouse permissions
- Verify token has "SQL" or "All" permissions

### 3. Wrong Workspace
- Token may be for a different workspace
- Verify workspace matches hostname

### 4. Warehouse Not Accessible
- Warehouse may be stopped
- Warehouse ID may be incorrect

## Solutions

### Option 1: Generate New Token

1. **Go to Databricks Workspace**
   - User Settings → Developer → Access Tokens

2. **Generate New Token**
   - Click "Generate New Token"
   - Set expiration (or no expiration)
   - Ensure "SQL" permissions are enabled

3. **Update Environment Variable**
   ```powershell
   $env:DATABRICKS_ACCESS_TOKEN = "dapi_your_new_token_here"
   ```

4. **Test Connection**
   ```bash
   python scripts/validate_databricks_token.py
   ```

### Option 2: Verify Warehouse

1. **Check Warehouse Status**
   - Go to SQL Warehouses in Databricks
   - Verify warehouse `fb7d0da7c909119a` is running
   - Start warehouse if stopped

2. **Verify HTTP Path**
   - Check Connection Details for warehouse
   - Verify HTTP path matches: `/sql/1.0/warehouses/fb7d0da7c909119a`

### Option 3: Check Token Permissions

1. **Review Token Permissions**
   - In Databricks, check token details
   - Ensure it has SQL warehouse access
   - May need workspace admin to grant permissions

## Validation Script

Run the validation script for detailed diagnostics:

```bash
python scripts/validate_databricks_token.py
```

This will:
- Check token format
- Test DNS resolution
- Attempt connection
- Provide specific recommendations

## Once Token is Fixed

After resolving the token issue:

1. **Test Connection**
   ```bash
   python -c "from application.mothership.db.databricks_connector import validate_databricks_connection; print('SUCCESS' if validate_databricks_connection() else 'FAILED')"
   ```

2. **Initialize Tables**
   ```bash
   python scripts/init_databricks_tables.py
   ```

3. **Enable Databricks**
   ```bash
   $env:USE_DATABRICKS = "true"
   ```

4. **Cleanup Old Files** (if any)
   ```bash
   python scripts/cleanup_old_database.py
   ```

## Next Steps

While token issue is being resolved, we can:
1. ✅ Continue with Phase 1 remaining components
2. ✅ Test compression security layer
3. ✅ Test embedded agentic detection
4. ⏳ Proceed with context enhancement and Fibonacci evolution

The migration infrastructure is ready and will work once the token is valid.
