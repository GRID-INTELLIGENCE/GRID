# GRID Virtual Environment Strategy

## Overview
The GRID project currently has multiple virtual environment directories (`.venv`, `venv`, `datakit/venv`, `docs/.venv`, `Arena/.venv`), which causes dependency resolution ambiguity and import confusion.

## Recommended Strategy

### 1. Unified Root Environment
Consolidate all dependencies into a single root `.venv` managed by `uv`.

### 2. Standardization with `uv`
Use `uv` for lightning-fast, reproducible environment management.
```powershell
# Install dependencies
uv file sync

# Run tests from root
uv run pytest
```

### 3. Path Standards
Always execute tests and commands from the repository root to ensure consistent path resolution.

### 4. Workspace Excludes
Update `.agentignore` and `.gitignore` to exclude all non-root `venv` directories to avoid tool crashes and search pollution.

## Implementation Plan
1. Delete all non-root `venv` and `.venv` directories.
2. Run `uv sync` to ensure root `.venv` has all necessary dependencies (including optional ones like `test` and `dev`).
3. Update CI/CD pipelines to enforce root-only execution.
