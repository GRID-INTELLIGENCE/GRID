# WSL Performance Optimization - Execution Checklist

> **Estimated Time**: 2 hours total | **Expected Performance**: 2-5x faster development workflow

---

## Pre-Flight Check (5 minutes)

- [ ] **Verify you're on Windows 11** (WSL2 works best on Win11)
  ```powershell
  Get-ComputerInfo | Select-Object WindowsVersion
  ```

- [ ] **Check available disk space** (need ~2x project size for migration)
  ```powershell
  Get-PSDrive C | Select-Object Used,Free
  ```

- [ ] **Backup important data** (optional but recommended)
  ```powershell
  # Backup current project
  Copy-Item E:\grid E:\grid_backup_$(Get-Date -Format "yyyyMMdd") -Recurse
  ```

- [ ] **Close all WSL-related applications** (VS Code, terminals, etc.)

---

## Phase 1: Validation & Baseline (15 minutes)

### Step 1: Validate Current Configuration

- [ ] **Run validation script** (PowerShell)
  ```powershell
  cd E:\grid
  .\scripts\validate_wsl_config.ps1 -Detailed
  ```

- [ ] **Record your current score**: ______ / 100

- [ ] **Note any red/yellow warnings**:
  - [ ] WSL not installed
  - [ ] No .wslconfig file
  - [ ] No Windows Defender exclusions
  - [ ] Project not in WSL filesystem
  - [ ] Other: ________________________________

### Step 2: Baseline Performance Measurement

- [ ] **Run baseline benchmark** (WSL)
  ```bash
  # In WSL
  cd /mnt/e/grid
  
  # Time git status (record result)
  time git status
  ```
  **Result**: ________ seconds

- [ ] **Record current test execution time**
  ```bash
  time pytest tests/unit -x -q 2>&1 | tail -1
  ```
  **Result**: ________ seconds

- [ ] **Check file system location**
  ```bash
  pwd
  # Should show: /mnt/e/grid (Windows FS - SLOW)
  ```

---

## Phase 2: Windows-Side Configuration (30 minutes)

### Step 3: Create .wslconfig

**Requirements**: PowerShell (Admin)

- [ ] **Option A: Use automated script** (RECOMMENDED)
  ```powershell
  # PowerShell as Administrator
  cd E:\grid
  .\scripts\setup_wsl_optimization.ps1
  ```

- [ ] **Option B: Manual creation**
  ```powershell
  # Create C:\Users\YourUsername\.wslconfig
  notepad $env:USERPROFILE\.wslconfig
  ```
  
  Paste this content:
  ```ini
  [wsl2]
  processors=6
  memory=8GB
  swap=8GB
  pageReporting=false
  vmIdleTimeout=60000
  localhostForwarding=true
  
  [experimental]
  autoMemoryReclaim=gradual
  sparseVhd=true
  ```

- [ ] **Verify .wslconfig was created**
  ```powershell
  Test-Path $env:USERPROFILE\.wslconfig
  # Should return: True
  ```

### Step 4: Configure Windows Defender Exclusions

**Requirements**: PowerShell (Admin)

- [ ] **Add WSL exclusions**
  ```powershell
  # PowerShell as Administrator
  Add-MpPreference -ExclusionPath "\\wsl$\Ubuntu"
  Add-MpPreference -ExclusionPath "$env:LOCALAPPDATA\Packages\CanonicalGroupLimited*"
  Add-MpPreference -ExclusionProcess "wsl.exe"
  Add-MpPreference -ExclusionProcess "wslhost.exe"
  Add-MpPreference -ExclusionProcess "wslservice.exe"
  ```

- [ ] **Verify exclusions were added**
  ```powershell
  Get-MpPreference | Select-Object -ExpandProperty ExclusionPath | Where-Object { $_ -like "*wsl*" }
  ```

### Step 5: Restart WSL

- [ ] **Shutdown WSL to apply changes**
  ```powershell
  wsl --shutdown
  ```

- [ ] **Wait 10 seconds**, then restart
  ```powershell
  wsl
  ```

- [ ] **Verify WSL started successfully**
  ```bash
  # In WSL
  echo "WSL is running!"
  ```

---

## Phase 3: WSL-Side Configuration (30 minutes)

### Step 6: Run WSL Internal Configuration

- [ ] **Copy and run the internal setup script**
  ```bash
  # In WSL
  bash ~/setup_wsl_internal.sh
  ```

  This script will:
  - Configure `/etc/wsl.conf`
  - Tune kernel parameters
  - Optimize Git configuration
  - Install essential tools (htop, rsync, etc.)
  - Set up shell aliases
  - Create benchmark script

- [ ] **Verify script completed without errors**

### Step 7: Restart WSL Again

- [ ] **Shutdown WSL to apply internal changes**
  ```powershell
  wsl --shutdown
  ```

- [ ] **Wait 10 seconds**, then restart
  ```powershell
  wsl
  ```

- [ ] **Verify systemd is running** (if enabled)
  ```bash
  systemctl status
  ```

---

## Phase 4: Project Migration (45 minutes)

### Step 8: Pre-Migration Benchmark

- [ ] **Run benchmark on Windows filesystem** (if not done in Phase 1)
  ```bash
  # In WSL
  cd /mnt/e/grid
  ~/benchmark_wsl.sh > ~/benchmark_before.txt
  cat ~/benchmark_before.txt
  ```

### Step 9: Migrate Project to WSL Filesystem

**⚠️ WARNING**: This copies the entire project. Original remains at E:\grid

- [ ] **Option A: Use migration script** (RECOMMENDED)
  ```bash
  # In WSL
  bash /mnt/e/grid/scripts/migrate_to_wsl.sh
  ```

- [ ] **Option B: Manual migration**
  ```bash
  # In WSL
  mkdir -p ~/projects
  rsync -avhP --exclude='.venv' --exclude='node_modules' --exclude='__pycache__' \
        /mnt/e/grid/ ~/projects/grid/
  ```

- [ ] **Verify migration**
  ```bash
  cd ~/projects/grid
  ls -la
  git status
  ```

### Step 10: Rebuild Virtual Environment

- [ ] **Remove old Windows venv**
  ```bash
  cd ~/projects/grid
  rm -rf .venv
  ```

- [ ] **Create new WSL venv**
  ```bash
  python3 -m venv .venv
  source .venv/bin/activate
  ```

- [ ] **Install dependencies**
  ```bash
  # If using uv (recommended)
  uv sync
  
  # Or with pip
  pip install --upgrade pip
  pip install -r requirements.txt
  ```

- [ ] **Verify installation**
  ```bash
  python --version
  pip list | head -20
  ```

---

## Phase 5: Verification & Benchmarking (15 minutes)

### Step 11: Post-Migration Benchmark

- [ ] **Run benchmark on WSL filesystem**
  ```bash
  cd ~/projects/grid
  ~/benchmark_wsl.sh > ~/benchmark_after.txt
  cat ~/benchmark_after.txt
  ```

- [ ] **Compare results**
  ```bash
  diff -u ~/benchmark_before.txt ~/benchmark_after.txt
  ```

### Step 12: Functional Verification

- [ ] **Test Git operations**
  ```bash
  cd ~/projects/grid
  time git status
  # Should be < 1 second
  ```
  **Result**: ________ seconds (vs ________ before)

- [ ] **Run unit tests**
  ```bash
  source .venv/bin/activate
  time pytest tests/unit -x -q
  ```
  **Result**: ________ seconds (vs ________ before)

- [ ] **Test linting**
  ```bash
  time ruff check src/grid
  ```
  **Result**: ________ seconds (vs ________ before)

- [ ] **Test Python imports**
  ```bash
  time python -c "import grid; import application; import tools"
  ```
  **Result**: ________ seconds (vs ________ before)

### Step 13: IDE Configuration

- [ ] **Update VS Code / Windsurf workspace**
  - Close current workspace
  - Open folder: `\\wsl$\Ubuntu\home\YOURUSERNAME\projects\grid`
  - Or use: Remote-WSL extension

- [ ] **Select WSL Python interpreter**
  - `Ctrl+Shift+P` → "Python: Select Interpreter"
  - Choose: `~/projects/grid/.venv/bin/python`

- [ ] **Verify terminal uses WSL**
  - Open integrated terminal
  - Run: `pwd` → should show `/home/...` not `/mnt/...`

- [ ] **Update .env file** (if exists)
  ```bash
  cd ~/projects/grid
  nano .env
  # Update paths:
  # GRID_ROOT=/home/yourusername/projects/grid
  # PYTHONPATH=/home/yourusername/projects/grid/src
  ```

---

## Phase 6: Final Validation (15 minutes)

### Step 14: Re-run Configuration Validator

- [ ] **Run validator again** (PowerShell)
  ```powershell
  cd E:\grid
  .\scripts\validate_wsl_config.ps1 -Detailed -ExportReport validation_after.json
  ```

- [ ] **Record new score**: ______ / 100 (vs ______ before)

- [ ] **Verify all checks are green**:
  - [ ] WSL installed
  - [ ] Distributions found
  - [ ] .wslconfig configured
  - [ ] Memory configured
  - [ ] Processors configured
  - [ ] Swap configured
  - [ ] Experimental features enabled
  - [ ] Windows Defender exclusions
  - [ ] Project in WSL filesystem

### Step 15: Performance Comparison Summary

**Fill in your measurements:**

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Git Status | ______s | ______s | ______x |
| Unit Tests | ______s | ______s | ______x |
| Ruff Check | ______s | ______s | ______x |
| File I/O | ______s | ______s | ______x |

### Step 16: Start Monitoring

- [ ] **Run performance monitor** (keep running in separate terminal)
  ```bash
  bash scripts/monitor_wsl_performance.sh
  ```

- [ ] **Verify "Location" shows**: `WSL (FAST)`
- [ ] **Verify "Git Status"**: < 1 second
- [ ] **Check overall rating**: Should be "Good" or "Excellent"

---

## Post-Migration Tasks (Ongoing)

### Immediate (Day 1)

- [ ] **Update documentation** with new WSL paths
- [ ] **Update CI/CD configs** if they reference local paths
- [ ] **Update team documentation** if working in a team
- [ ] **Test all major workflows** (build, test, deploy)
- [ ] **Verify Docker works** with WSL2 backend

### Week 1

- [ ] **Monitor performance daily** using `monitor_wsl_performance.sh`
- [ ] **Compare development speed** subjectively
- [ ] **Check for any broken scripts** that had hardcoded Windows paths
- [ ] **Update bookmarks/shortcuts** to point to WSL path

### After 1 Week (Cleanup)

- [ ] **Delete Windows copy** if everything works well
  ```powershell
  # ONLY AFTER VERIFYING EVERYTHING WORKS
  Remove-Item E:\grid -Recurse -Force
  ```

- [ ] **Delete backups** if no longer needed
  ```bash
  rm -rf ~/grid_backup_*
  ```

---

## Troubleshooting Checklist

### Problem: WSL won't start after .wslconfig changes

- [ ] **Check .wslconfig syntax**
  ```powershell
  Get-Content $env:USERPROFILE\.wslconfig
  ```

- [ ] **Try with reduced settings**
  - Reduce memory to 4GB
  - Reduce processors to 4
  - Disable experimental features

- [ ] **Update WSL**
  ```powershell
  wsl --update
  ```

### Problem: "Out of memory" errors in WSL

- [ ] **Increase memory in .wslconfig**
  ```ini
  memory=12GB
  swap=16GB
  ```

- [ ] **Restart WSL**
  ```powershell
  wsl --shutdown
  wsl
  ```

### Problem: File operations still slow after migration

- [ ] **Verify you're in WSL filesystem**
  ```bash
  pwd
  # Should show: /home/username/... NOT /mnt/...
  ```

- [ ] **Check Windows Defender exclusions**
  ```powershell
  Get-MpPreference | Select-Object -ExpandProperty ExclusionPath
  ```

- [ ] **Verify .wslconfig is active**
  ```bash
  # In WSL
  free -h  # Check if memory matches .wslconfig
  nproc    # Check if processors match .wslconfig
  ```

### Problem: Git operations still slow

- [ ] **Rebuild git index**
  ```bash
  cd ~/projects/grid
  git update-index --really-refresh
  git gc --aggressive --prune=now
  ```

- [ ] **Verify git config**
  ```bash
  git config --get core.untrackedCache
  git config --get core.fsmonitor
  # Both should return: true
  ```

### Problem: IDE not connecting to WSL

- [ ] **Install Remote-WSL extension** (VS Code)
- [ ] **Use correct path format**: `\\wsl$\Ubuntu\home\username\projects\grid`
- [ ] **Restart IDE** after changing workspace
- [ ] **Check WSL is running**: `wsl echo "running"`

### Problem: Tests fail after migration

- [ ] **Verify virtual environment is activated**
  ```bash
  which python
  # Should show: /home/username/projects/grid/.venv/bin/python
  ```

- [ ] **Reinstall dependencies**
  ```bash
  cd ~/projects/grid
  source .venv/bin/activate
  pip install --upgrade pip
  pip install -r requirements.txt
  ```

- [ ] **Check PYTHONPATH**
  ```bash
  echo $PYTHONPATH
  # Should include: /home/username/projects/grid/src
  ```

---

## Rollback Procedure

If something goes wrong and you need to revert:

### Rollback Steps

1. [ ] **Shutdown WSL**
   ```powershell
   wsl --shutdown
   ```

2. [ ] **Restore old .wslconfig** (if you backed it up)
   ```powershell
   Copy-Item $env:USERPROFILE\.wslconfig.backup.* $env:USERPROFILE\.wslconfig
   ```

3. [ ] **Or delete .wslconfig entirely**
   ```powershell
   Remove-Item $env:USERPROFILE\.wslconfig
   ```

4. [ ] **Restart WSL**
   ```powershell
   wsl
   ```

5. [ ] **Continue working from Windows filesystem**
   ```bash
   cd /mnt/e/grid
   ```

---

## Success Criteria

You've successfully optimized WSL if:

- ✅ **Validation score** ≥ 80/100
- ✅ **Git status** completes in < 1 second
- ✅ **Unit tests** run 2-3x faster
- ✅ **File operations** feel noticeably snappier
- ✅ **No stability issues** after 24 hours of use
- ✅ **IDE performance** improved (syntax checking, intellisense)

---

## Maintenance Schedule

### Daily
- [ ] Monitor performance with: `bash scripts/monitor_wsl_performance.sh`
- [ ] Check for WSL updates: `wsl --update`

### Weekly
- [ ] Review disk usage: `df -h`
- [ ] Clean Docker images: `docker system prune -af`
- [ ] Check git performance: `time git status`

### Monthly
- [ ] Re-run benchmark: `~/benchmark_wsl.sh`
- [ ] Review .wslconfig settings
- [ ] Update WSL: `wsl --update`
- [ ] Clean up old logs: `rm -rf ~/projects/grid/logs/*.log.old`

---

## Performance Optimization Scorecard

| Area | Before | After | Status |
|------|--------|-------|--------|
| **Configuration** | | | |
| .wslconfig exists | ☐ | ☐ | |
| Defender exclusions | ☐ | ☐ | |
| Project in WSL FS | ☐ | ☐ | |
| **Performance** | | | |
| Git status (seconds) | _____ | _____ | |
| Unit tests (seconds) | _____ | _____ | |
| Ruff check (seconds) | _____ | _____ | |
| **Score** | | | |
| Validation score | _____/100 | _____/100 | |
| Overall rating | _____ | _____ | |

---

## Quick Reference Commands

### Check Configuration
```powershell
# Validation
.\scripts\validate_wsl_config.ps1

# WSL version
wsl --version
```

### Performance
```bash
# Benchmark
~/benchmark_wsl.sh

# Monitor
bash scripts/monitor_wsl_performance.sh

# Quick git check
time git status
```

### Maintenance
```powershell
# Restart WSL
wsl --shutdown
wsl

# Update WSL
wsl --update
```

### Project Access
```bash
# WSL path (fast)
cd ~/projects/grid

# Windows path (slow - avoid)
cd /mnt/e/grid
```

### IDE
```
Windows path to open in IDE:
\\wsl$\Ubuntu\home\YOURUSERNAME\projects\grid

Or use Remote-WSL extension in VS Code
```

---

## Resources

| Document | Description |
|----------|-------------|
| [WSL_PERFORMANCE_OPTIMIZATION.md](guides/WSL_PERFORMANCE_OPTIMIZATION.md) | Full optimization guide |
| [WSL_QUICK_REFERENCE.md](WSL_QUICK_REFERENCE.md) | Quick reference card |
| [PROJECT_TASKS.md](PROJECT_TASKS.md) | Project task list |

### Scripts

| Script | Purpose |
|--------|---------|
| `scripts/validate_wsl_config.ps1` | Validate configuration |
| `scripts/setup_wsl_optimization.ps1` | Automated setup |
| `scripts/monitor_wsl_performance.sh` | Real-time monitoring |
| `scripts/migrate_to_wsl.sh` | Project migration |

---

## Notes & Tips

💡 **Pro Tips:**
- Keep your project in WSL filesystem for best performance
- Use Windows Terminal or WSL terminal (faster than CMD → WSL)
- Enable systemd for better service management
- Use `rsync` instead of `cp` for large file operations
- Clean Docker regularly: `docker system prune -af`

⚠️ **Common Mistakes:**
- Using `/mnt/e/grid` instead of `~/projects/grid`
- Not restarting WSL after config changes
- Forgetting to rebuild `.venv` after migration
- Using Windows Python from WSL

📊 **Expected Results:**
- 2-5x faster git operations
- 2-3x faster test execution
- 4-5x faster linting
- 5x faster file I/O
- Much snappier overall development experience

---

**Completion Date**: ________________

**Final Score**: ______ / 100

**Performance Improvement**: ______x faster

**Notes**:
_____________________________________________
_____________________________________________
_____________________________________________

---

*Last Updated: 2024*
*GRID Version: 2.2.0*