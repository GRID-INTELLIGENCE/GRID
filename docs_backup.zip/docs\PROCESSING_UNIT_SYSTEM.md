# Processing Unit System - Complete Documentation

## Overview

The Processing Unit System acts as the "receptionist" layer that structures raw input, categorizes cases, and creates reference files before passing to the agent (lawyer). This system removes confusion and gaps from I/O ambiguity by providing structured transformation and clear reference creation.

## Architecture

The system follows the lawyer's office metaphor:

- **Client (User)**: Provides raw input (case)
- **Receptionist (Processing Unit)**: Logs, labels, categorizes, creates structure
- **Office (Knowledge Base)**: Comprehensive suite of agent evolution system
- **Lawyer (Agent)**: Executes tasks using reference file as context

## Core Components

### 1. Processing Unit (`processing_unit.py`)

Main entry point that orchestrates the receptionist workflow.

**Key Features**:
- Processes raw input through structured workflow
- Generates case IDs and timestamps
- Creates reference files
- Handles user enrichment (examples, scenarios, phenomena)
- Integrates with advanced protocols for rare cases

**Usage**:
```python
from tools.agent_prompts.processing_unit import ProcessingUnit

processing_unit = ProcessingUnit(
    knowledge_base_path=Path("tools/agent_prompts"),
    reference_output_path=Path(".case_references")
)

result = processing_unit.process_input(
    raw_input="I need to add contract testing to CI",
    examples=["Similar setup in another project"],
    scenarios=["Run tests on every PR"]
)
```

### 2. Case Filing System (`case_filing.py`)

Handles iterative logging, labeling, and categorization.

**Key Features**:
- **Iterative Logging**: 5 iterations to refine structure
  1. Basic extraction (keywords, entities)
  2. Category detection
  3. Priority detection
  4. Label generation
  5. Relationship detection
- **Category Classification**: 11 standard categories + RARE
- **Confidence Scoring**: 0.0-1.0 confidence in classification
- **Rare Case Detection**: Identifies cases that don't fit standard categories

**Categories**:
- CODE_ANALYSIS
- ARCHITECTURE
- TESTING
- DOCUMENTATION
- DEPLOYMENT
- SECURITY
- PERFORMANCE
- BUG_FIX
- FEATURE_REQUEST
- REFACTORING
- INTEGRATION
- RARE (new/rare cases)

### 3. Reference Generator (`reference_generator.py`)

Loads structure against comprehensive suite and generates reference files.

**Key Features**:
- Maps case structure to agent evolution system components
- Recommends roles (Analyst, Architect, Planner, etc.)
- Recommends tasks (/inventory, /gapanalysis, /plan, etc.)
- Generates workflow recommendations
- Creates agent context string

**Reference File Structure**:
```json
{
  "case_id": "CASE-abc123",
  "timestamp": "2025-01-08T10:00:00Z",
  "raw_input": "Original user input",
  "structured_data": {
    "category": "testing",
    "priority": "high",
    "keywords": ["test", "ci", "contract"],
    ...
  },
  "comprehensive_suite_mapping": {
    "recommended_roles": ["Executor", "Evaluator"],
    "recommended_tasks": ["/inventory", "/execute", "/validate"]
  },
  "context_for_agent": "Formatted context string",
  "user_context": {
    "examples": [...],
    "scenarios": [...]
  }
}
```

### 4. Advanced Protocols Handler (`advanced_protocols.py`)

Handles rare cases with web search, memory integration, and query generation.

**Key Features**:
- **Memory Search**: Searches past cases for similar patterns
- **Web Search**: Performs web search for case refinement (placeholder for integration)
- **Nuance Generation**: Identifies subtle differences and critical details
- **Insight Generation**: Produces actionable insights
- **MCQ Query Generation**: Creates contextualization questions (like custom mode)

**For Rare Cases**:
1. Search memory/knowledgebase for similar cases
2. Perform web search (if enabled)
3. Generate nuances and insights
4. Create MCQ-style queries for contextualization
5. Update reference file with advanced protocol data
6. Store in memory for future cases

### 5. Continuous Learning System (`continuous_learning.py`)

Manages knowledge enrichment, experience tracking, and self-evolving training.

**Key Features**:
- **Case Completion Recording**: Records solutions and outcomes
- **Experience Tracking**: Tracks agent experience by category, outcome, priority
- **Pattern Recognition**: Identifies common patterns in solutions
- **Memory Management**: Enforces memory constraints naturally
- **Recommendations**: Provides recommendations based on similar past cases

**Learning Benefits**:
1. **User Learning**: User subconsciously learns technical parts
2. **Knowledge Base Enrichment**: Office continuously enriched with data
3. **Agent Experience**: Agent gets incremental values and evolving capability
4. **Continuous Delivery**: Pipeline for concurrent updates and self-evolving training

## Workflow

### Standard Case Processing

```
1. User provides raw input
   ↓
2. Processing Unit receives input
   ↓
3. Case Filing System:
   - Iteration 1: Extract keywords, entities
   - Iteration 2: Detect category
   - Iteration 3: Detect priority
   - Iteration 4: Generate labels
   - Iteration 5: Detect relationships
   ↓
4. Check if rare case
   ↓
5. Reference Generator:
   - Load structure against comprehensive suite
   - Map to relevant components
   - Generate reference file
   ↓
6. If rare case:
   - Advanced Protocols Handler:
     - Search memory
     - Web search (if enabled)
     - Generate nuances/insights
     - Create MCQ queries
   ↓
7. Reference file ready for agent
```

### User Enrichment

Users can provide additional context after initial processing:

```python
processing_unit.enrich_with_user_input(
    case_id="CASE-abc123",
    additional_context="Additional details",
    examples=["More examples"],
    scenarios=["More scenarios"]
)
```

This allows users to:
- Reflect/resurface seed instances
- Provide examples from personal experience
- Add scenarios/phenomena
- Further contextualize the case

## Integration with Agent Evolution System

The processing unit integrates seamlessly with the agent evolution system:

### Role Mapping

Cases are mapped to relevant roles:
- **CODE_ANALYSIS** → Analyst, Executor
- **ARCHITECTURE** → Architect, Planner
- **TESTING** → Executor, Evaluator
- **SECURITY** → SafetyOfficer, Architect
- etc.

### Task Mapping

Cases are mapped to relevant tasks:
- **Keywords** → Task selection (/inventory, /gapanalysis, etc.)
- **Category** → Workflow recommendations
- **Priority** → Execution urgency

### Reference File as Context

The reference file provides complete context for the agent:
- Structured data (category, priority, keywords)
- Recommended roles and tasks
- Workflow recommendations
- User examples and scenarios
- Advanced protocol data (for rare cases)

## Advanced Protocols

### For Rare Cases

When a case doesn't fit standard categories (confidence < 0.3 or category = RARE):

1. **Memory Search**: Find similar past cases
2. **Web Search**: Refine with external knowledge (placeholder)
3. **Nuance Generation**: Identify critical differences
4. **Insight Generation**: Produce actionable insights
5. **Query Generation**: Create MCQ-style questions for contextualization

### MCQ-Style Queries

Example queries generated:
- "Is this case primarily about [category]?"
- "What is the priority level for this case?"
- "What is the scope of this case?"
- "Are the provided examples relevant to the solution?"

These queries help the agent (lawyer) contextualize the case before execution.

## Continuous Learning

### Experience Tracking

The system tracks:
- Total cases processed
- Category distribution
- Success rate
- Experience by category
- Common patterns
- Learning insights

### Knowledge Enrichment

After case completion:
```python
learning_system.record_case_completion(
    case_id="CASE-abc123",
    structure=structure,
    solution="Solution applied",
    outcome="success",
    agent_experience={
        "lessons": ["Lesson 1", "Lesson 2"],
        "time_taken": "2 hours"
    }
)
```

### Recommendations

Get recommendations based on similar cases:
```python
recommendations = learning_system.get_recommendations(structure)
```

Returns:
- Similar cases with solutions
- Expected outcomes
- Lessons learned

## Benefits

### 1. Removes I/O Ambiguity

- Raw input → Structured data
- Clear categorization
- Reference file creation
- No confusion about case type

### 2. User Learning

Users subconsciously learn:
- Technical terminology
- Category classifications
- System capabilities
- Best practices

### 3. Knowledge Base Enrichment

Office (knowledge base) continuously enriched:
- New cases stored
- Patterns identified
- Solutions tracked
- Memory constraints managed naturally

### 4. Agent Experience

Agent (lawyer) gets:
- Incremental values
- Evolving capability
- Experience from past cases
- Recommendations for similar cases

### 5. Continuous Delivery

System provides:
- Concurrent updates
- Self-evolving training
- Systematic operational method
- Minimum risk and mistakes

## Usage Examples

### Basic Processing

```python
from tools.agent_prompts.processing_unit import ProcessingUnit
from pathlib import Path

# Initialize
processing_unit = ProcessingUnit(
    knowledge_base_path=Path("tools/agent_prompts"),
    reference_output_path=Path(".case_references")
)

# Process input
result = processing_unit.process_input(
    raw_input="Add authentication endpoint with JWT",
    examples=["Similar endpoint in auth service"],
    scenarios=["User logs in, receives JWT, uses for requests"]
)

print(f"Case ID: {result.case_id}")
print(f"Category: {result.category.value}")
print(f"Reference File: {result.reference_file_path}")
```

### Enrichment

```python
# Enrich with additional context
processing_unit.enrich_with_user_input(
    case_id=result.case_id,
    additional_context="Need rate limiting",
    examples=["Rate limiting in API gateway"],
    scenarios=["Prevent brute force attacks"]
)
```

### Continuous Learning

```python
from tools.agent_prompts.continuous_learning import ContinuousLearningSystem

learning_system = ContinuousLearningSystem(
    memory_path=Path(".case_memory")
)

# Record completion
learning_system.record_case_completion(
    case_id=result.case_id,
    structure=result.structured_data,
    solution="Implemented JWT endpoint with rate limiting",
    outcome="success",
    agent_experience={
        "lessons": ["Use secure token storage", "Implement rate limiting"],
        "time_taken": "3 hours"
    }
)

# Get experience
experience = learning_system.get_agent_experience()
print(f"Total cases: {experience['total_cases']}")
print(f"Success rate: {experience['success_rate']:.1%}")
```

## CLI Usage

### Process Input

```bash
python -m tools.agent_prompts.processing_unit \
    "Add contract testing to CI pipeline" \
    --knowledge-base tools/agent_prompts \
    --output .case_references \
    --examples "Similar setup in project X" \
    --scenarios "Run tests on every PR"
```

## File Structure

```
tools/agent_prompts/
├── processing_unit.py          # Main processing unit
├── case_filing.py              # Case filing system
├── reference_generator.py      # Reference file generator
├── advanced_protocols.py       # Advanced protocols handler
└── continuous_learning.py      # Continuous learning system

.case_references/               # Generated reference files
├── CASE-abc123_reference.json
└── CASE-def456_reference.json

.case_memory/                   # Memory storage
├── memory.json                 # Case memory
├── knowledge_base.json         # Knowledge base
└── experience_tracker.json     # Experience tracker
```

## Integration Points

### With Agent Evolution System

- Uses comprehensive suite (system_prompt.md, role_templates.md, etc.)
- Maps cases to roles and tasks
- Generates context for agent execution

### With RAG System

- Can integrate with local RAG for web search
- Uses Ollama models for semantic search
- Stores context in ChromaDB

### With GRID Architecture

- Aligns with "Creative Internals, Deterministic Exteriors"
- Uses EssentialState, Context, PatternRecognition
- Integrates with Embedded Agentic Knowledge System

## Best Practices

1. **Always Process Through Receptionist**: Don't skip the processing unit
2. **Provide Examples/Scenarios**: Helps with categorization and context
3. **Enrich When Needed**: Use enrichment for additional context
4. **Record Completions**: Enable continuous learning
5. **Review Recommendations**: Use past cases for guidance

## Troubleshooting

### Low Confidence Scores

**Problem**: Case has low confidence (< 0.3)

**Solution**:
- Provide more examples/scenarios
- Use enrichment to add context
- Advanced protocols will handle rare cases

### Memory Constraints

**Problem**: Memory size exceeds limit

**Solution**:
- System auto-cleans old cases (keeps 80%)
- Adjust `max_memory_size_mb` if needed
- Manual cleanup of `.case_memory/` if necessary

### Rare Case Handling

**Problem**: Case doesn't fit standard categories

**Solution**:
- Advanced protocols automatically activate
- MCQ queries help contextualize
- Memory search finds similar cases
- Web search provides external knowledge

## References

- **Agent Evolution System**: `docs/AGENT_EVOLUTION_SYSTEM.md`
- **Embedded Agentic System**: `docs/EMBEDDED_AGENTIC_SYSTEM_SUMMARY.md`
- **GRID Architecture**: `docs/architecture.md`

## Conclusion

The Processing Unit System provides a complete receptionist layer that:

- **Structures** raw input into clear categories
- **Removes** I/O ambiguity through transformation
- **Creates** reference files for agent context
- **Handles** rare cases with advanced protocols
- **Enables** continuous learning and knowledge enrichment
- **Provides** systematic operational method with minimum risk

The system enables the office (knowledge base), user (client), and agent (lawyer) to exchange value efficiently while continuously learning and evolving.
