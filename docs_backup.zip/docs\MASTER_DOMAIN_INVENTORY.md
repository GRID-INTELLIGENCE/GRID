# MASTER DOMAIN INVENTORY: 2026-01-09

## Overview
This inventory maps the 14 project domains of GRID to their precise **Structural (Y)** and **Temporal (X)** coordinates. Coordinates are based on the dual metaphors of the **Railway (Interlock/Rigid)** and the **Freeway (Flux/Scalable)**.

### Coordinate Basis:
- **X-Axis (Temporal)**: `0.0` (Causal/Deterministic) -> `1.0` (Volatile/Ephemeral)
- **Y-Axis (Structural)**: `0.0` (Rigid/Iron Frame) -> `1.0` (Fluid/Modular)

---

## Domain Mapping Table

| ID | Domain Name | X (Temporal) | Y (Structural) | Metaphor | Technical Purpose |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **01** | **GRID Core** | 0.1 | 0.1 | Railway | The seed; rigid structure and strict causal time. |
| **02** | **Mothership** | 0.4 | 0.8 | Freeway | Standard service logic; evolves structurally. |
| **03** | **Resonance** | 0.9 | 0.8 | Freeway | Real-time signal flux; high structural scaling. |
| **04** | **Light of the Seven** | 0.2 | 0.9 | Freeway | Deterministic cognitive logic; maximal structural hierarchy. |
| **05** | **Tools** | 0.5 | 0.4 | Freeway | Resource lane; balanced volatility. |
| **06** | **EQ** | 0.6 | 0.4 | Freeway | Resource lane; jittered retry persistence. |
| **07** | **The Arena** | 0.7 | 0.5 | Hybrid | Simulation flux; high event load. |
| **08** | **Connectivity** | 0.5 | 0.5 | Hybrid | Integration bridge; balanced integration types. |
| **09** | **Research Knowledge** | 0.0 | 0.0 | Railway | The Hard Anchor; immutable history and documentation. |
| **10** | **Iron Frame** | 0.1 | 0.0 | Iron Frame | Pure Structural Rigidity (Backplane). |
| **11** | **Temporal Drift** | 1.0 | 0.1 | Drift | Pure Temporal Volatility (Entropy). |
| **12** | **Worker Pool** | 0.8 | 0.2 | The Asphalt | High task velocity; rigid infrastructure (Redis). |
| **13** | **Distribution Manager** | 0.3 | 0.3 | Interchange | Central gatekeeper; enforces order across lanes. |
| **14** | **Highway Router** | 0.2 | 0.4 | Navigation | Logic-heavy; deterministic navigation paths. |

---

## Precise Coordinate Visualization (Dalí Metaphor)

Based on the `dali_geometry_blocks.json` schema, the domains are distributed across the 100x80 canvas as follows:

- **The Ground Plane (Y=0)**: Worker Pool (50, 0), Research Knowledge (10, 0), Iron Frame (50, -5).
- **The Horizon (Y=10)**: Distribution Manager (50, 10).
- **The Surface Structures (Y=10 to Y=80)**: 
  - GRID Core (50, 40) - The Heart.
  - Mothership (20, 70) & Resonance (80, 70).
  - Light of the Seven (50, 80) - The Apex.
  - The Arena (50, 60).
- **The Subterranean Drift (Y < 0 or High X)**: 
  - Temporal Drift (100, 10) - Moving off-canvas.

---

## Status
- [x] Domains Identified: 14/14
- [x] Coordinates Mapped: 14/14
- [x] Initial Context Refreshed (Disney: Finding Nemo)
