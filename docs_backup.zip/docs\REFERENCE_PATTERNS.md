# 🎯 GRID PROJECT - REFERENCE PATTERNS

**Date:** 2026-01-08
**Purpose:** Extracted patterns from reference tracks for alignment
**Status:** Phase 1 - Pattern Extraction Complete

---

## 📊 EXECUTIVE SUMMARY

This document contains all patterns extracted from the 5 reference tracks (Security Module, Mothership Application, RAG System, Grid Core, Cognitive Layer). These patterns serve as templates for aligning other modules to the reference architecture.

**Reference Tracks:**
1. Security Module (9.5/10) - Reference Track #1
2. Mothership Application (9.0/10) - Reference Track #2
3. RAG System (9.0/10) - Reference Track #3
4. Grid Core Intelligence (8.5/10) - Reference Track #4
5. Cognitive Layer (8.0/10) - Reference Track #5

---

## 🔐 REFERENCE TRACK #1: SECURITY MODULE PATTERNS

**Source:** `application/mothership/security/secret_validation.py`
**Strength:** 9.5/10

### Pattern 1.1: Environment-Aware Validation

**Description:** Validation logic that behaves differently based on environment (production vs development).

**Pattern:**
```python
def validate_secret(secret: str, environment: str = "production") -> SecretStrength:
    """Validate secret with environment-aware behavior."""
    if not secret:
        if environment.lower() == "production":
            raise SecretValidationError("CRITICAL: Secret required in production")
        else:
            logger.warning("WARNING: Secret not set (development mode)")
            return SecretStrength.WEAK

    # Continue validation...
```

**Key Features:**
- Production: Fail fast with clear error messages
- Development: Warn but allow (with clear warnings)
- Clear error messages with remediation steps
- Security audit logging (masked)

**When to Use:**
- Configuration validation
- Startup checks
- Secret/credential validation
- Any critical security validation

**Template:**
```python
def validate_critical_setting(value: Optional[str], setting_name: str, environment: str = "production") -> None:
    """Validate critical setting with environment awareness."""
    if not value or not value.strip():
        if environment.lower() == "production":
            raise ValidationError(
                f"CRITICAL: {setting_name} is required in production. "
                f"Set {setting_name} environment variable."
            )
        else:
            logger.warning(f"WARNING: {setting_name} not set (development mode)")
            return

    # Continue validation...
```

**Reference:** `application/mothership/security/secret_validation.py:135-213`

---

### Pattern 1.2: Fail-Fast with Helpful Errors

**Description:** Fail immediately with clear error messages that include remediation steps.

**Pattern:**
```python
def get_secret_from_env(env_var: str, required: bool = True, environment: str = "production") -> str:
    """Get secret from environment with validation."""
    secret = os.getenv(env_var)

    if not secret or not secret.strip():
        if required:
            if environment.lower() == "production":
                raise SecretValidationError(
                    f"Required secret environment variable '{env_var}' is not set. "
                    f"This is a CRITICAL security issue in production. "
                    f"Set {env_var} to a secure value (use generate_secure_secret() to create one)."
                )
            else:
                raise SecretValidationError(
                    f"Required secret environment variable '{env_var}' is not set. "
                    f"Set {env_var} in your environment or .env file."
                )

    # Validate strength...
    return secret
```

**Key Features:**
- Immediate failure for critical issues
- Clear error messages with context
- Remediation steps included
- Security classification (CRITICAL, WARNING)

**When to Use:**
- Startup validation
- Configuration validation
- Critical security checks
- Production deployment checks

**Template:**
```python
def validate_critical_config(config: Config, environment: str = "production") -> None:
    """Validate critical configuration with fail-fast."""
    issues = []

    if not config.secret_key:
        if environment.lower() == "production":
            raise ConfigValidationError(
                "CRITICAL: secret_key is required in production. "
                "Generate with: python -m application.mothership.security.secret_validation generate"
            )
        issues.append("WARNING: secret_key not set")

    if issues:
        logger.warning("Configuration issues: " + ", ".join(issues))
```

**Reference:** `application/mothership/security/secret_validation.py:135-213`

---

### Pattern 1.3: Secret Strength Validation

**Description:** Validate secret strength with OWASP-compliant checks and environment-aware behavior.

**Pattern:**
```python
def validate_secret_strength(secret: str, environment: str = "production") -> SecretStrength:
    """Validate secret strength following OWASP guidelines."""
    if not secret:
        raise SecretValidationError("Secret key cannot be empty")

    length = len(secret)

    # Check minimum length (OWASP: 32 chars for HS256)
    if length < MIN_SECRET_LENGTH:
        raise SecretValidationError(
            f"Secret key must be at least {MIN_SECRET_LENGTH} characters "
            f"(current: {length}). Use generate_secure_secret() to create a secure key."
        )

    # Check entropy (character diversity)
    unique_chars = len(set(secret))
    entropy_ratio = unique_chars / max(length, 1)

    # Classify strength
    if length >= RECOMMENDED_SECRET_LENGTH and entropy_ratio >= 0.5:
        strength = SecretStrength.STRONG
    elif length >= MIN_SECRET_LENGTH and entropy_ratio >= 0.3:
        strength = SecretStrength.ACCEPTABLE
    else:
        strength = SecretStrength.WEAK

    # In production, reject weak secrets
    if environment.lower() == "production" and strength == SecretStrength.WEAK:
        raise SecretValidationError(
            f"Secret key is too weak for production. "
            f"Length: {length}, Entropy ratio: {entropy_ratio:.2f}. "
            f"Generate a secure key with generate_secure_secret()."
        )

    return strength
```

**Key Features:**
- OWASP-compliant (minimum 32 chars for HS256)
- Entropy validation (character diversity)
- Weak pattern detection
- Environment-aware rejection

**When to Use:**
- Secret/credential validation
- API key validation
- Token validation
- Password policy validation

**Template:**
```python
def validate_credential_strength(credential: str, min_length: int = 32, environment: str = "production") -> Strength:
    """Validate credential strength."""
    length = len(credential)

    if length < min_length:
        if environment.lower() == "production":
            raise ValidationError(f"Credential must be at least {min_length} characters")
        return Strength.WEAK

    # Entropy check...
    unique_chars = len(set(credential))
    entropy_ratio = unique_chars / max(length, 1)

    if entropy_ratio < 0.3:
        if environment.lower() == "production":
            raise ValidationError("Credential entropy too low for production")
        return Strength.WEAK

    return Strength.STRONG
```

**Reference:** `application/mothership/security/secret_validation.py:64-133`

---

### Pattern 1.4: Security Audit Logging (Masked)

**Description:** Log security events without exposing sensitive information.

**Pattern:**
```python
def get_secret_from_env(env_var: str, required: bool = True, environment: str = "production") -> str:
    """Get secret from environment with validation."""
    secret = os.getenv(env_var)
    # ... validation logic ...

    # Security audit log (without exposing the secret)
    secret_hash = hashlib.sha256(secret.encode()).hexdigest()[:16]
    logger.info(
        f"Secret loaded from '{env_var}' (length={len(secret)}, "
        f"strength={strength.value}, hash={secret_hash})"
    )

    return secret

def mask_secret(secret: str, visible_chars: int = 4) -> str:
    """Mask secret for logging/display purposes."""
    if not secret or len(secret) <= visible_chars * 2:
        return "***"
    return f"{secret[:visible_chars]}...{secret[-visible_chars:]}"
```

**Key Features:**
- Never log actual secrets/credentials
- Use hashes or masks for audit trails
- Include metadata (length, strength, hash)
- Clear audit trail for security events

**When to Use:**
- Secret loading/validation
- Authentication events
- Authorization checks
- Any security-critical operations

**Template:**
```python
def log_security_event(event: str, credential_name: str, credential_value: str) -> None:
    """Log security event without exposing credential."""
    credential_hash = hashlib.sha256(credential_value.encode()).hexdigest()[:16]
    masked_value = mask_secret(credential_value)

    logger.info(
        f"Security event: {event} | "
        f"Credential: {credential_name} | "
        f"Length: {len(credential_value)} | "
        f"Hash: {credential_hash} | "
        f"Masked: {masked_value}"
    )
```

**Reference:** `application/mothership/security/secret_validation.py:205-229`

---

## 🏗️ REFERENCE TRACK #2: MOTHERSHIP APPLICATION PATTERNS

**Source:** `application/mothership/`
**Strength:** 9.0/10

### Pattern 2.1: Layered Architecture

**Description:** Clean separation of concerns with layers: Routers → Services → Repositories → Models.

**Pattern Structure:**
```
application/mothership/
├── routers/          # API endpoints (FastAPI routes)
│   ├── auth.py
│   ├── billing.py
│   └── navigation.py
├── services/         # Business logic layer
│   ├── session_service.py
│   ├── operation_service.py
│   └── __init__.py  # CockpitService facade
├── repositories/     # Data access layer
│   ├── session_repository.py
│   ├── task_repository.py
│   └── __init__.py  # UnitOfWork
├── models/          # Domain models (Pydantic)
│   ├── session.py
│   ├── operation.py
│   └── component.py
└── schemas/         # Request/Response schemas (Pydantic v2)
    ├── session_schemas.py
    └── operation_schemas.py
```

**Key Features:**
- Clear layer boundaries
- Dependency flow: Routers → Services → Repositories → Models
- Separation of concerns
- Testable architecture

**When to Use:**
- New API modules
- Application layer structure
- FastAPI applications
- Any service-oriented architecture

**Template:**
```python
# Router layer (routers/my_feature.py)
from fastapi import APIRouter, Depends
from ..services import MyFeatureService
from ..schemas import MyFeatureRequest, MyFeatureResponse

router = APIRouter(prefix="/api/v1/my-feature", tags=["my-feature"])

@router.post("/endpoint")
async def my_endpoint(
    request: MyFeatureRequest,
    service: MyFeatureService = Depends(get_my_feature_service)
) -> MyFeatureResponse:
    """My feature endpoint."""
    result = await service.process(request)
    return MyFeatureResponse.from_result(result)

# Service layer (services/my_feature_service.py)
class MyFeatureService:
    def __init__(self, repository: MyFeatureRepository):
        self._repository = repository

    async def process(self, request: MyFeatureRequest) -> Result:
        # Business logic here
        entity = await self._repository.get(request.id)
        # Process...
        return Result(...)

# Repository layer (repositories/my_feature_repository.py)
class MyFeatureRepository:
    def __init__(self, store: StateStore):
        self._store = store

    async def get(self, id: str) -> Optional[MyFeatureModel]:
        return self._store.my_features.get(id)
```

**Reference:** `application/mothership/` structure

---

### Pattern 2.2: Service Facade Pattern

**Description:** Main service that coordinates sub-services and provides unified interface.

**Pattern:**
```python
class CockpitService:
    """Main cockpit service providing a unified interface."""

    def __init__(
        self,
        session_ttl_minutes: int = 60,
        max_sessions: int = 100,
        max_concurrent_operations: int = 50,
    ):
        self._state = CockpitState()
        self._started = False

        # Initialize sub-services
        self.sessions = SessionService(
            self._state,
            default_ttl_minutes=session_ttl_minutes,
            max_sessions=max_sessions,
        )
        self.operations = OperationService(
            self._state,
            max_concurrent_operations=max_concurrent_operations,
        )
        self.components = ComponentService(self._state)
        self.alerts = AlertService(self._state)

        # Unified event handlers
        self._event_handlers: List[EventHandler] = []

    @property
    def is_healthy(self) -> bool:
        """Check if cockpit is healthy."""
        return (
            self._started
            and self._state.state == SystemState.ONLINE
            and all(c.is_healthy() for c in self._state.components.values())
        )

    def add_event_handler(self, handler: EventHandler) -> None:
        """Register unified event handler for all services."""
        self._event_handlers.append(handler)
        self.sessions.add_event_handler(handler)
        self.operations.add_event_handler(handler)
        self.components.add_event_handler(handler)
        self.alerts.add_event_handler(handler)
```

**Key Features:**
- Coordinates sub-services
- Unified interface
- Shared state management
- Event handler coordination

**When to Use:**
- Complex services with multiple sub-services
- Services that need coordination
- Facade for related functionality
- Unified entry point for services

**Template:**
```python
class MyFeatureService:
    """Main feature service coordinating sub-services."""

    def __init__(self, config: MyFeatureConfig):
        self._state = MyFeatureState()

        # Initialize sub-services
        self.sub_service_1 = SubService1(self._state, config.service1_config)
        self.sub_service_2 = SubService2(self._state, config.service2_config)
        self.sub_service_3 = SubService3(self._state, config.service3_config)

    @property
    def is_healthy(self) -> bool:
        """Check if all sub-services are healthy."""
        return (
            self.sub_service_1.is_healthy()
            and self.sub_service_2.is_healthy()
            and self.sub_service_3.is_healthy()
        )
```

**Reference:** `application/mothership/services/__init__.py:1026-1080`

---

### Pattern 2.3: Repository Pattern with Unit of Work

**Description:** Clean data access layer with repository pattern and Unit of Work for transactions.

**Pattern:**
```python
# Unit of Work
class UnitOfWork:
    """Unit of Work pattern for coordinating repository operations."""

    def __init__(self, store: Optional[StateStore] = None):
        self._store = store or get_state_store()
        self.sessions = SessionRepository(self._store)
        self.tasks = TaskRepository(self._store)
        self.components = ComponentRepository(self._store)
        self.alerts = AlertRepository(self._store)
        self.cockpit = CockpitStateRepository(self._store)

    @asynccontextmanager
    async def transaction(self) -> AsyncIterator["UnitOfWork"]:
        """Execute operations within a transaction."""
        async with self._store.transaction():
            yield self

    async def get_snapshot(self) -> Dict[str, Any]:
        """Get a snapshot of all state."""
        return self._store.get_snapshot()

# Repository
class SessionRepository:
    """Repository for session data access."""

    def __init__(self, store: StateStore):
        self._store = store

    async def get(self, id: str) -> Optional[Session]:
        """Get session by ID."""
        return self._store.sessions.get(id)

    async def add(self, session: Session) -> Session:
        """Add new session."""
        self._store.sessions[id] = session
        return session

    async def update(self, session: Session) -> Session:
        """Update existing session."""
        self._store.sessions[session.id] = session
        return session

    async def delete(self, id: str) -> None:
        """Delete session."""
        del self._store.sessions[id]
```

**Key Features:**
- Clean separation of data access
- Unit of Work for transactions
- Repository abstraction
- Consistent interface

**When to Use:**
- Data access layer
- Database operations
- State management
- Transaction coordination

**Template:**
```python
class MyFeatureRepository:
    """Repository for my feature data access."""

    def __init__(self, store: StateStore):
        self._store = store

    async def get(self, id: str) -> Optional[MyFeatureModel]:
        """Get by ID."""
        return self._store.my_features.get(id)

    async def list(self, filters: Optional[Dict] = None) -> List[MyFeatureModel]:
        """List all matching."""
        items = list(self._store.my_features.values())
        if filters:
            # Apply filters...
            pass
        return items

    async def add(self, item: MyFeatureModel) -> MyFeatureModel:
        """Add new item."""
        self._store.my_features[item.id] = item
        return item

    async def update(self, item: MyFeatureModel) -> MyFeatureModel:
        """Update existing item."""
        self._store.my_features[item.id] = item
        return item

    async def delete(self, id: str) -> None:
        """Delete item."""
        del self._store.my_features[id]
```

**Reference:** `application/mothership/repositories/__init__.py:636-684`

---

### Pattern 2.4: Dependency Injection via FastAPI

**Description:** Use FastAPI's dependency injection for service and repository instances.

**Pattern:**
```python
# dependencies.py
from fastapi import Depends
from .services import CockpitService
from .repositories import UnitOfWork, get_unit_of_work

def get_cockpit_service() -> CockpitService:
    """Get cockpit service instance."""
    return CockpitService()

def get_session_service(
    cockpit: CockpitService = Depends(get_cockpit_service)
) -> SessionService:
    """Get session service instance."""
    return cockpit.sessions

# router.py
from fastapi import APIRouter, Depends
from .dependencies import get_session_service
from .services import SessionService

router = APIRouter(prefix="/api/v1/sessions")

@router.get("/{session_id}")
async def get_session(
    session_id: str,
    service: SessionService = Depends(get_session_service)
) -> SessionResponse:
    """Get session by ID."""
    session = await service.get(session_id)
    return SessionResponse.from_model(session)
```

**Key Features:**
- FastAPI dependency injection
- Reusable dependencies
- Testable (easy to mock)
- Clear dependency graph

**When to Use:**
- FastAPI routers
- Service instantiation
- Repository access
- Configuration access

**Template:**
```python
# dependencies.py
def get_my_feature_service() -> MyFeatureService:
    """Get my feature service."""
    return MyFeatureService()

# router.py
@router.get("/endpoint")
async def my_endpoint(
    service: MyFeatureService = Depends(get_my_feature_service)
) -> Response:
    """My endpoint."""
    return await service.process()
```

**Reference:** `application/mothership/routers/` and `application/mothership/dependencies.py`

---

## 🧠 REFERENCE TRACK #3: RAG SYSTEM PATTERNS

**Source:** `tools/rag/`
**Strength:** 9.0/10

### Pattern 3.1: Factory Pattern for Providers

**Description:** Factory pattern for creating provider instances based on configuration.

**Pattern:**
```python
class EmbeddingProviderType(str, Enum):
    """Types of embedding providers."""
    OLLAMA = "ollama"
    HUGGINGFACE = "huggingface"
    SIMPLE = "simple"

def get_embedding_provider(
    provider_type: Optional[str] = None,
    config: Optional[RAGConfig] = None
) -> BaseEmbeddingProvider:
    """Get an embedding provider."""
    if config is None:
        config = RAGConfig.from_env()

    if provider_type is None:
        provider_type = config.embedding_provider if config else EmbeddingProviderType.HUGGINGFACE.value

    provider_type = provider_type.lower()

    if provider_type == EmbeddingProviderType.OLLAMA.value:
        from .nomic_v2 import OllamaEmbeddingProvider
        return OllamaEmbeddingProvider(
            model=config.embedding_model,
            base_url=config.ollama_base_url
        )
    elif provider_type == EmbeddingProviderType.HUGGINGFACE.value:
        from .huggingface import HuggingFaceEmbeddingProvider
        return HuggingFaceEmbeddingProvider(model_name=config.embedding_model)
    elif provider_type == EmbeddingProviderType.SIMPLE.value:
        from .simple import SimpleEmbedding
        return SimpleEmbedding()
    else:
        raise ValueError(
            f"Unknown embedding provider type: {provider_type}. "
            f"Available: {', '.join([e.value for e in EmbeddingProviderType])}"
        )
```

**Key Features:**
- Configuration-driven creation
- Provider abstraction (`BaseEmbeddingProvider`)
- Lazy imports (only import what's needed)
- Clear error messages

**When to Use:**
- Provider selection (local vs cloud)
- Plugin architectures
- Multiple implementation options
- Configuration-driven instantiation

**Template:**
```python
class MyProviderType(str, Enum):
    """Types of my providers."""
    LOCAL = "local"
    CLOUD = "cloud"
    MOCK = "mock"

def get_my_provider(
    provider_type: Optional[str] = None,
    config: Optional[MyConfig] = None
) -> BaseMyProvider:
    """Get my provider instance."""
    if config is None:
        config = MyConfig.from_env()

    if provider_type is None:
        provider_type = config.provider_type if config else MyProviderType.LOCAL.value

    provider_type = provider_type.lower()

    if provider_type == MyProviderType.LOCAL.value:
        from .local_provider import LocalMyProvider
        return LocalMyProvider(config.local_config)
    elif provider_type == MyProviderType.CLOUD.value:
        from .cloud_provider import CloudMyProvider
        return CloudMyProvider(config.cloud_config)
    elif provider_type == MyProviderType.MOCK.value:
        from .mock_provider import MockMyProvider
        return MockMyProvider()
    else:
        raise ValueError(
            f"Unknown provider type: {provider_type}. "
            f"Available: {', '.join([e.value for e in MyProviderType])}"
        )
```

**Reference:** `tools/rag/embeddings/factory.py`

---

### Pattern 3.2: Configuration-Driven Creation

**Description:** Configuration dataclass with environment variable support and validation.

**Pattern:**
```python
@dataclass
class RAGConfig:
    """Configuration for RAG system."""

    # Embedding configuration
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    embedding_mode: ModelMode = ModelMode.LOCAL
    embedding_provider: str = "huggingface"

    # LLM configuration
    llm_model_local: str = "ministral-3:3b"
    llm_model_cloud: Optional[str] = None
    llm_mode: ModelMode = ModelMode.LOCAL

    # Vector store configuration
    vector_store_path: str = ".rag_db"
    collection_name: str = "grid_knowledge_base"

    @classmethod
    def from_env(cls) -> "RAGConfig":
        """Create configuration from environment variables."""
        return cls(
            embedding_model=os.getenv("RAG_EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2"),
            embedding_mode=ModelMode(os.getenv("RAG_EMBEDDING_MODE", "local")),
            embedding_provider=os.getenv("RAG_EMBEDDING_PROVIDER", "huggingface"),
            llm_model_local=os.getenv("RAG_LLM_MODEL_LOCAL", "ministral-3:3b"),
            llm_mode=ModelMode(os.getenv("RAG_LLM_MODE", "local")),
            vector_store_path=os.getenv("RAG_VECTOR_STORE_PATH", ".rag_db"),
            collection_name=os.getenv("RAG_COLLECTION_NAME", "grid_knowledge_base"),
            # ... more config ...
        )

    def ensure_local_only(self) -> None:
        """Ensure configuration is set for local-only operation."""
        if self.embedding_mode == ModelMode.CLOUD:
            raise ValueError(
                "Cloud embedding mode not allowed. "
                "Set RAG_EMBEDDING_MODE=local or use local mode."
            )
        if self.llm_mode == ModelMode.CLOUD and not self.ollama_cloud_url:
            raise ValueError(
                "Cloud LLM mode requires OLLAMA_CLOUD_URL to be set. "
                "For local-only operation, set RAG_LLM_MODE=local"
            )
```

**Key Features:**
- Dataclass for configuration
- Environment variable support (`from_env()`)
- Default values
- Validation methods (`ensure_local_only()`)

**When to Use:**
- Module configuration
- Provider configuration
- Feature flags
- Environment-specific settings

**Template:**
```python
@dataclass
class MyFeatureConfig:
    """Configuration for my feature."""

    provider_type: str = "local"
    local_path: str = "./local_data"
    cloud_endpoint: Optional[str] = None
    enabled: bool = True

    @classmethod
    def from_env(cls) -> "MyFeatureConfig":
        """Create configuration from environment variables."""
        return cls(
            provider_type=os.getenv("MY_FEATURE_PROVIDER", "local"),
            local_path=os.getenv("MY_FEATURE_LOCAL_PATH", "./local_data"),
            cloud_endpoint=os.getenv("MY_FEATURE_CLOUD_ENDPOINT"),
            enabled=os.getenv("MY_FEATURE_ENABLED", "true").lower() == "true",
        )

    def validate(self) -> None:
        """Validate configuration."""
        if self.provider_type == "cloud" and not self.cloud_endpoint:
            raise ValueError("Cloud provider requires cloud_endpoint to be set")
```

**Reference:** `tools/rag/config.py`

---

### Pattern 3.3: Local-First Architecture

**Description:** Default to local providers, validate local-only operation.

**Pattern:**
```python
class ModelMode(str, Enum):
    """Model execution mode."""
    LOCAL = "local"  # Use local models
    CLOUD = "cloud"  # Use cloud models

@dataclass
class RAGConfig:
    embedding_mode: ModelMode = ModelMode.LOCAL  # Default to local
    llm_mode: ModelMode = ModelMode.LOCAL  # Default to local

    def ensure_local_only(self) -> None:
        """Ensure configuration is set for local-only operation."""
        if self.embedding_mode == ModelMode.CLOUD:
            raise ValueError(
                "Cloud embedding mode not allowed. "
                "Set RAG_EMBEDDING_MODE=local or use local mode."
            )
        if self.llm_mode == ModelMode.CLOUD and not self.ollama_cloud_url:
            raise ValueError(
                "Cloud LLM mode requires OLLAMA_CLOUD_URL to be set. "
                "For local-only operation, set RAG_LLM_MODE=local"
            )

def get_embedding_provider(config: Optional[RAGConfig] = None) -> BaseEmbeddingProvider:
    """Get embedding provider (defaults to local)."""
    if config is None:
        config = RAGConfig.from_env()

    # Default to local provider
    provider_type = config.embedding_provider if config else "huggingface"

    if provider_type == "ollama":
        # Local Ollama provider
        return OllamaEmbeddingProvider(
            model=config.embedding_model,
            base_url=config.ollama_base_url  # Local: http://localhost:11434
        )
```

**Key Features:**
- Default to local providers
- Explicit validation for local-only
- Clear error messages
- Privacy-first approach

**When to Use:**
- Systems requiring local-first operation
- Privacy-sensitive features
- Offline-capable systems
- Cost-optimized systems

**Template:**
```python
class ProviderMode(str, Enum):
    """Provider mode."""
    LOCAL = "local"
    CLOUD = "cloud"

@dataclass
class MyFeatureConfig:
    provider_mode: ProviderMode = ProviderMode.LOCAL  # Default to local

    def ensure_local_only(self) -> None:
        """Ensure local-only operation."""
        if self.provider_mode == ProviderMode.CLOUD:
            raise ValueError(
                "Cloud provider mode not allowed. "
                "Set MY_FEATURE_PROVIDER_MODE=local"
            )
```

**Reference:** `tools/rag/config.py:9-102`

---

## 🧩 REFERENCE TRACK #4: GRID CORE PATTERNS

**Source:** `grid/`
**Strength:** 8.5/10

### Pattern 4.1: Graceful Imports with Fallbacks

**Description:** Import modules with try/except, set to None if unavailable, export conditionally.

**Pattern:**
```python
# grid/__init__.py
try:
    from .essence.core_state import EssentialState
except ImportError:  # pragma: no cover
    EssentialState = None  # type: ignore

try:
    from .patterns.recognition import PatternRecognition
except ImportError:  # pragma: no cover
    PatternRecognition = None  # type: ignore

# ... more imports ...

__all__ = [
    # Core
    *(["EssentialState"] if EssentialState is not None else []),
    *(["PatternRecognition"] if PatternRecognition is not None else []),
    *(["Context"] if Context is not None else []),
    # ... more exports ...
]
```

**Key Features:**
- Graceful degradation
- Conditional exports in `__all__`
- Type ignore for None assignments
- Clear module availability

**When to Use:**
- Optional dependencies
- Module initialization
- Backward compatibility
- Progressive enhancement

**Template:**
```python
# my_module/__init__.py
try:
    from .feature_a import FeatureA
except ImportError:  # pragma: no cover
    FeatureA = None  # type: ignore

try:
    from .feature_b import FeatureB
except ImportError:  # pragma: no cover
    FeatureB = None  # type: ignore

__all__ = [
    *(["FeatureA"] if FeatureA is not None else []),
    *(["FeatureB"] if FeatureB is not None else []),
]
```

**Reference:** `grid/__init__.py:18-143`

---

### Pattern 4.2: Clear Module Exports

**Description:** Explicit `__all__` exports with conditional inclusion based on availability.

**Pattern:**
```python
# grid/__init__.py
__all__ = [
    # Core
    *(["EssentialState"] if EssentialState is not None else []),
    *(["PatternRecognition"] if PatternRecognition is not None else []),
    # Organization
    *(
        [
            "Organization",
            "OrganizationRole",
            "OrganizationManager",
            "User",
            "UserRole",
            "UserStatus",
            "DisciplineManager",
        ]
        if Organization is not None
        else []
    ),
    # ... more groups ...
]
```

**Key Features:**
- Explicit `__all__` list
- Conditional exports
- Grouped by domain
- Clear public API

**When to Use:**
- Module `__init__.py` files
- Public API definition
- Package exports
- Library interfaces

**Template:**
```python
# my_module/__init__.py
__all__ = [
    # Core features
    *(["CoreFeature1", "CoreFeature2"] if CoreFeature1 is not None else []),
    # Optional features
    *(["OptionalFeature1"] if OptionalFeature1 is not None else []),
]
```

**Reference:** `grid/__init__.py:102-143`

---

### Pattern 4.3: Lazy Loading with Import Errors

**Description:** Load optional modules only when needed, handle import errors gracefully.

**Pattern:**
```python
# grid/skills/registry.py
def _load_builtin_skills(registry: SkillRegistry) -> None:
    """Load builtin skills with graceful error handling."""
    import importlib
    import logging

    logger = logging.getLogger(__name__)

    skills_to_load = [
        ("youtube_transcript_analyze", ".youtube_transcript_analyze"),
        ("intelligence_git_analyze", ".intelligence_git_analyze"),
        # ... more skills ...
    ]

    for name, relative_path in skills_to_load:
        try:
            module = importlib.import_module(relative_path, package="grid.skills")
            skill = getattr(module, name)
            registry.register(skill)
        except Exception as e:
            error_msg = f"Failed to load skill '{name}' from '{relative_path}': {type(e).__name__}: {e}"
            logger.error(error_msg)
            # Continue loading other skills even if one fails
```

**Key Features:**
- Lazy loading (only when needed)
- Graceful error handling
- Continue on failure
- Clear error logging

**When to Use:**
- Plugin loading
- Optional feature loading
- Registry initialization
- Progressive enhancement

**Template:**
```python
def _load_features(registry: FeatureRegistry) -> None:
    """Load features with graceful error handling."""
    import importlib
    import logging

    logger = logging.getLogger(__name__)

    features_to_load = [
        ("feature_a", ".feature_a"),
        ("feature_b", ".feature_b"),
    ]

    for name, relative_path in features_to_load:
        try:
            module = importlib.import_module(relative_path, package="my.module")
            feature = getattr(module, name)
            registry.register(feature)
        except Exception as e:
            logger.error(f"Failed to load feature '{name}': {e}")
            # Continue loading other features
```

**Reference:** `grid/skills/registry.py:24-57`

---

## 🧠 REFERENCE TRACK #5: COGNITIVE LAYER PATTERNS

**Source:** `light_of_the_seven/cognitive_layer/`
**Strength:** 8.0/10

### Pattern 5.1: Domain Boundaries

**Description:** Clear domain separation with dedicated modules for each domain concept.

**Pattern Structure:**
```
cognitive_layer/
├── decision_support/    # Bounded rationality, decision support
├── cognitive_load/      # Cognitive load assessment and management
├── mental_models/       # Mental model representations
├── navigation/          # Navigation agent system
│   ├── agents/          # Agent implementations
│   ├── learning/        # Learning infrastructure
│   └── schemas/         # Pydantic input schemas
├── integration/         # Integration utilities
└── schemas/             # General cognitive schemas
```

**Key Features:**
- Clear domain boundaries
- Domain-specific modules
- Integration modules
- Well-defined interfaces

**When to Use:**
- Complex domain models
- Research-based modules
- Domain-driven design
- Modular architectures

**Template:**
```python
# my_domain/
├── domain_a/        # Domain A specific logic
├── domain_b/        # Domain B specific logic
├── integration/     # Cross-domain integration
└── schemas/         # Shared schemas
```

**Reference:** `light_of_the_seven/cognitive_layer/README.md:1-153`

---

### Pattern 5.2: Integration Modules

**Description:** Dedicated integration modules for cross-domain or external system integration.

**Pattern:**
```python
# cognitive_layer/integration/
# Integration utilities for connecting cognitive layer with GRID core

# cognitive_layer/navigation/agents/
# Agent implementations with learning capabilities

# cognitive_layer/navigation/learning/
# Learning infrastructure for adaptive behavior
```

**Key Features:**
- Separation of integration concerns
- Clear integration points
- Modular integration
- Testable integration

**When to Use:**
- External system integration
- Cross-domain integration
- System boundaries
- Integration testing

**Template:**
```python
# my_module/integration/
├── external_api.py      # External API integration
├── core_integration.py  # Core system integration
└── event_bus.py         # Event bus integration
```

**Reference:** `light_of_the_seven/cognitive_layer/` structure

---

## 🎯 PATTERN APPLICATION MATRIX

| Pattern | Source | Target Modules | Priority |
|---------|--------|---------------|----------|
| Environment-Aware Validation | Security | Config, Startup | High |
| Fail-Fast with Helpful Errors | Security | Config, Startup | High |
| Layered Architecture | Mothership | Resonance API | High |
| Service Facade | Mothership | Resonance API | Medium |
| Repository Pattern | Mothership | Resonance API | Medium |
| Factory Pattern | RAG | Other Tools | Medium |
| Configuration-Driven | RAG | Other Tools | Medium |
| Local-First | RAG | All Modules | High |
| Graceful Imports | Grid Core | All Modules | Medium |
| Clear Exports | Grid Core | All Modules | Medium |
| Domain Boundaries | Cognitive | All Modules | Low |

---

## 📋 NEXT STEPS

1. **Create ALIGNMENT_CHECKLIST.md** - Gap analysis and priorities
2. **Apply patterns to target modules** - Start with high-priority patterns
3. **Validate alignment** - Ensure consistency across modules

---

**Status:** ✅ Phase 1 Complete - Patterns Extracted
**Next:** Create ALIGNMENT_CHECKLIST.md
**Reference Tracks:** 5 identified and documented
