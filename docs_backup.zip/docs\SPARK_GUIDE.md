# Spark ⚡ - Universal Morphable Invoker

> *"A single spark ignites a thousand possibilities."*

## Quick Start

```python
from grid.spark import spark

# Basic invocation
result = spark("diagnose import errors")
print(result.output)
```

---

## CLI Usage

```powershell
# From e:\grid\src
python -m grid.spark "your request"
python -m grid.spark --persona navigator "check paths"
python -m grid.spark --list

# With PowerShell wrapper (after `. scripts/spark.ps1`)
spark "diagnose import errors"
```

---

## Personas

| Persona | What It Does | Uses |
|---------|--------------|------|
| `navigator` | Path resolution, import diagnostics | `territory_map.py` |
| `resonance` | Activity feedback with ADSR | `activity_resonance.py` |
| `agentic` | Skill retrieval and execution | `skill_retriever.py` |
| `reasoning` | Multi-source reasoning (KG + LLM) | `reasoning_orchestrator.py` |

---

## Python API

### Basic Invocation
```python
from grid.spark import spark

result = spark("find relevant skills")
print(result.output)      # The result data
print(result.persona)     # Which persona was used
print(result.duration_ms) # Execution time
```

### With Persona
```python
result = spark("diagnose No module named application", persona="navigator")
# Output: {"error": "...", "suggestion": "PYTHONPATH issue...", "zones": [...]}
```

### Context Manager
```python
with spark.as_navigator() as nav:
    result = nav.diagnose("check mothership imports")
```

### Parallel Execution
```python
import asyncio

results = asyncio.run(spark.parallel([
    "task 1",
    "task 2",
    "task 3"
], mode="kanye"))  # Kanye = parallel, Jay = sequential
```

---

## Lifecycle (ADSR-Inspired)

```
IDLE → ATTACK → SUSTAIN → RELEASE → COMPLETE
        ↑          ↑          ↑
    trigger   execute    cleanup
```

### Hooks
```python
from grid.spark import Spark

s = Spark()

@s.on_attack
def setup():
    print("Starting...")

@s.on_release
def cleanup():
    print("Done!")
```

---

## Files

```
src/grid/spark/
├── __init__.py     # Main spark() function
├── core.py         # Spark class, lifecycle, parallel
├── personas.py     # Navigator, Resonance, Agentic, Reasoning
├── cli.py          # CLI interface
└── __main__.py     # python -m grid.spark

scripts/
└── spark.ps1       # PowerShell wrapper
```

---

## Custom Personas

```python
from grid.spark import Spark, Persona

class MyPersona(Persona):
    name = "custom"
    description = "My custom persona"
    
    def execute(self, request, context=None):
        return {"processed": request}

# Register
s = Spark()
s.register_persona("custom", MyPersona())
```

---

*Built with the momentum of Jay's methodology and Kanye's wild experiments.*
