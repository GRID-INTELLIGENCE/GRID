# Global Agent Behavior Guidelines

This document provides global behavior guidelines for AI agents working on the GRID project across all tools (Cursor, Windsurf, Antigravity).

## Core Principles

### 1. Local-First Operation

- **NEVER** suggest external API calls (OpenAI, Anthropic, etc.) unless explicitly requested
- Use local Ollama models: `nomic-embed-text-v2-moe:latest` for embeddings, `ministral` or `gpt-oss-safeguard` for LLM
- All RAG context stays local (ChromaDB in `.rag_db/`)
- Default to local-only solutions

### 2. Architecture Alignment

- Follow layered architecture: core → API → database → CLI → services
- Respect module boundaries and separation of concerns
- Use dependency injection patterns
- Maintain stateless compute where possible

### 3. Code Quality Standards

- **Python 3.13.11** (enforced across workspace)
- Use Pydantic for data models
- Follow PEP 8 with project-specific overrides (120 char line length)
- Maintain ≥80% test coverage
- Run `ruff` and `black` before committing
- **Dependency Management**: Use `uv` as primary, `pip` as fallback

### 4. Pattern-Based Development

- Reference existing patterns before creating new ones
- Use the 9 cognition patterns when relevant
- Follow established code patterns in the codebase
- Check similar implementations first

### 5. Cognitive Layer Integration

- When making decisions, consider cognitive factors
- Use `light_of_the_seven/cognitive_layer/` for decision support
- Consider cognitive load when designing interfaces
- Respect user mental models
- Apply bounded rationality principles

## Decision-Making Process

### Before Making Changes

1. **Read Relevant Files**: Check existing implementations in the same area
2. **Check Architecture**: Verify your change fits the layered architecture
3. **Review Patterns**: Look for similar patterns in the codebase
4. **Query RAG**: Use RAG system to understand project context
5. **Consider Tests**: Ensure tests exist or need to be created
6. **Check Cognitive Layer**: Consider if decision support is needed

### When Uncertain

- Architecture decisions → Ask and reference `docs/architecture.md`
- Coding standards → Check `pyproject.toml` and existing code
- Project patterns → Query RAG system or check `docs/pattern_language.md`
- Integration approach → Review similar integrations in codebase
- Testing strategy → Check existing tests in `tests/`

## Tool-Specific Guidelines

### Cursor 2.0

- Use Plan Mode for complex tasks (>5 minutes)
- Enable checkpoints before major changes
- Run background agents for async tasks
- Use multi-agent chats for parallel work

### Windsurf

- Use file references (`@file.py`) liberally for context
- Leverage DeepWiki for project documentation queries
- Use Cascade skills for code analysis
- "Vibe coding" - provide high-level direction, let Cascade lead

### Antigravity

- Use Planning Mode for complex tasks
- Use Fast Mode for quick fixes
- Leverage built-in browser for testing
- Use terminal commands for git, tests, logs

## Prohibited Practices

1. **No External APIs**: Don't suggest OpenAI, Anthropic, or other cloud APIs unless explicitly requested
2. **No Breaking Changes**: Don't remove functionality without explicit approval
3. **No Magic Numbers**: Use named constants
4. **No Untyped Code**: All functions must have type hints
5. **No Untested Code**: Significant changes require tests
6. **No Hardcoded Secrets**: Use environment variables
7. **No Direct Database Access**: Use repository pattern or ORM

## Context Management

### Files to Read

- `.context/DEFINITION.md` - Master Context Manifest (Check this first)
- `docs/global_layer.md` - Global rules and workflow
- `docs/architecture.md` - Architecture documentation
- `docs/pattern_language.md` - Pattern language
- `pyproject.toml` - Project configuration
- **`DEPENDENCY_MATRIX.md`** - Dependency versions and constraints
- Relevant module `__init__.py` files
- [DEPENDENCY_MATRIX.md](../DEPENDENCY_MATRIX.md) - Version constraints

### RAG Usage

- Query RAG system for project context: `python -m tools.rag.cli query "your question"`
- Use RAG to understand existing patterns
- Reference RAG results when making decisions

### Dependency Management

- **Primary Tool**: `uv` for fast dependency resolution
- **Fallback**: `pip` for compatibility
- **Python Version**: 3.13.11 enforced via `.python-version` and `pyproject.toml`
- **Key Dependencies**:
  - GRID: FastAPI >=0.104.0, scikit-learn==1.8.0, ChromaDB >=1.4.1
  - EUFLE: PyTorch 2.9.1+cpu, Transformers 4.57.3, PEFT 0.18.0
- **Security**: All file operations must use `PathValidator` class
- **Reference**: Check `DEPENDENCY_MATRIX.md` for complete version matrix

## Remember

- GRID is a local-first, cognitive-aware system
- Always prefer existing patterns over new solutions
- Use RAG for project context
- Respect the layered architecture
- Maintain code quality standards
- Consider cognitive factors in design decisions

## Dependency Context for Development

### Package Management
- **Primary**: Use `uv` for all dependency operations
- **Fallback**: `pip` only when `uv` is unavailable
- **Commands**:
  ```bash
  uv sync --group dev --group test  # Install all dependencies
  uv pip install <package>          # Single package
  uv venv --python 3.13 --clear     # Fresh environment
  ```

### Version Constraints
| Package | Constraint | Reason |
|---------|------------|--------|
| Python | 3.13.11 | Enforced via `.python-version` |
| scikit-learn | ==1.8.0 | Pinned for reproducibility |
| FastAPI | ≥0.104.0 | Flexible minor versions |
| ChromaDB | ≥1.4.1 | Local RAG vector store |

### Security Requirements
- **File Operations**: Use `PathValidator` class from `src.grid.security.path_validator`
- **Pattern**: Always validate paths with `is_relative_to()` before file access
- **Reference**: [SECURITY_VULNERABILITY_REPORT.md](../SECURITY_VULNERABILITY_REPORT.md)

### Cross-References
- Version details: [DEPENDENCY_MATRIX.md](../DEPENDENCY_MATRIX.md)
- EUFLE dependencies: [EUFLE/docs/DEPENDENCIES.md](../EUFLE/docs/DEPENDENCIES.md)
- Dependency visualization: [docs/DEPENDENCY_GUIDE.md](./DEPENDENCY_GUIDE.md)
