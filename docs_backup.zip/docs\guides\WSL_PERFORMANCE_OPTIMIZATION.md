# WSL Performance Optimization Guide for GRID

> **Target**: 2-3x performance improvement for development workflows
> **Time to implement**: ~2 hours
> **Impact**: Immediate improvement in file I/O, compilation, and test execution

---

## Table of Contents

1. [Quick Wins (30 minutes)](#quick-wins-30-minutes)
2. [WSL Configuration](#wsl-configuration)
3. [File System Optimization](#file-system-optimization)
4. [Memory and CPU Tuning](#memory-and-cpu-tuning)
5. [Docker Integration](#docker-integration)
6. [Development Workflow](#development-workflow)
7. [Monitoring & Benchmarking](#monitoring--benchmarking)
8. [Troubleshooting](#troubleshooting)

---

## Quick Wins (30 minutes)

### 1. Create `.wslconfig` (Windows side)

Create or edit `%USERPROFILE%\.wslconfig`:

```ini
[wsl2]
# Processors - use 75% of available cores
processors=6

# Memory - use 50% of system RAM (adjust based on your total RAM)
memory=8GB

# Swap - match memory for optimal performance
swap=8GB

# Disable page reporting for better performance
pageReporting=false

# Increase virtual memory
vmIdleTimeout=60000

# Network settings
localhostForwarding=true

# Experimental features (Windows 11 22H2+)
[experimental]
autoMemoryReclaim=gradual
sparseVhd=true
```

**Apply changes:**
```powershell
wsl --shutdown
wsl
```

### 2. Move Project to WSL Filesystem

**Current setup**: `E:\grid` (Windows filesystem - SLOW)
**Optimal setup**: `\\wsl$\Ubuntu\home\username\grid` (WSL filesystem - FAST)

**Why**: Accessing Windows filesystem from WSL is 2-10x slower than native WSL filesystem.

**Migration steps:**

```bash
# In WSL
cd ~
mkdir -p projects
cp -r /mnt/e/grid ~/projects/grid

# Update git remotes if needed
cd ~/projects/grid
git remote -v
```

**Update your IDE paths:**
- VS Code: Open folder via `\\wsl$\Ubuntu\home\username\projects\grid`
- Windsurf: Same path structure

### 3. Optimize Git Operations

Create `~/.gitconfig` in WSL:

```ini
[core]
    # Disable file mode checks (Windows compatibility)
    filemode = false
    # Use faster compression
    compression = 0
    # Improve status performance
    untrackedCache = true
    fsmonitor = true

[feature]
    manyFiles = true

[index]
    threads = true
    version = 4

[pack]
    threads = 0
    windowMemory = 256m

[gc]
    auto = 256

[fetch]
    parallel = 8

[status]
    submoduleSummary = false
    showUntrackedFiles = normal
```

---

## WSL Configuration

### Update WSL to Latest Version

```powershell
# In PowerShell (Admin)
wsl --update
wsl --version

# Should show WSL version 2.0.0+
```

### Create `/etc/wsl.conf` (WSL side)

```bash
sudo nano /etc/wsl.conf
```

Add:

```ini
[boot]
systemd=true
command="mount --make-rshared /"

[automount]
enabled = true
root = /mnt/
options = "metadata,umask=22,fmask=11"
mountFsTab = true

[network]
generateHosts = true
generateResolvConf = true
hostname = wsl-grid

[interop]
enabled = true
appendWindowsPath = true

[user]
default = your_username
```

**Apply:**
```bash
wsl --shutdown
wsl
```

---

## File System Optimization

### 1. Use Case-Insensitive Directories (for cross-platform compatibility)

```bash
# Create case-insensitive directory for your project
mkdir -p ~/projects
cd ~/projects
sudo chattr +F grid  # Make case-insensitive
```

### 2. Disable Windows Defender Scanning for WSL

**Add exclusions in Windows Security:**

```powershell
# In PowerShell (Admin)
Add-MpPreference -ExclusionPath "\\wsl$\Ubuntu"
Add-MpPreference -ExclusionPath "%LOCALAPPDATA%\Packages\CanonicalGroupLimited*"
Add-MpPreference -ExclusionProcess "wsl.exe"
Add-MpPreference -ExclusionProcess "wslhost.exe"
```

### 3. Optimize Python Virtual Environments

Place `.venv` in WSL filesystem, not Windows:

```bash
cd ~/projects/grid
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 4. Enable Fast File Operations

```bash
# Install tools for faster operations
sudo apt update
sudo apt install -y \
    build-essential \
    git \
    rsync \
    parallel \
    pigz \
    pv

# Configure rsync for faster copies
alias rsync='rsync -avhP --progress'
```

---

## Memory and CPU Tuning

### 1. Optimize Swap Configuration

```bash
# Check current swap
free -h

# Configure swap (if needed)
sudo swapoff -a
sudo dd if=/dev/zero of=/swapfile bs=1M count=8192
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# Add to /etc/fstab
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
```

### 2. Tune Kernel Parameters

Edit `/etc/sysctl.conf`:

```bash
sudo nano /etc/sysctl.conf
```

Add:

```ini
# File system tuning
fs.file-max = 2097152
fs.inotify.max_user_watches = 524288
fs.inotify.max_user_instances = 512

# Network tuning
net.core.rmem_max = 134217728
net.core.wmem_max = 134217728
net.ipv4.tcp_rmem = 4096 87380 67108864
net.ipv4.tcp_wmem = 4096 65536 67108864

# Virtual memory tuning
vm.swappiness = 10
vm.vfs_cache_pressure = 50
vm.dirty_ratio = 10
vm.dirty_background_ratio = 5
```

Apply:
```bash
sudo sysctl -p
```

---

## Docker Integration

### 1. Use Docker Desktop with WSL2 Backend

Enable in Docker Desktop settings:
- **Use the WSL 2 based engine**: ✓
- **Resources > WSL Integration**: Enable for your distro

### 2. Optimize Docker for Development

Create `~/.docker/daemon.json`:

```json
{
  "features": {
    "buildkit": true
  },
  "experimental": true,
  "max-concurrent-downloads": 10,
  "max-concurrent-uploads": 10,
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
```

### 3. Use BuildKit for Faster Builds

```bash
# Add to ~/.bashrc or ~/.zshrc
export DOCKER_BUILDKIT=1
export COMPOSE_DOCKER_CLI_BUILD=1
```

---

## Development Workflow

### 1. Fast Terminal Setup (Zsh + Oh My Zsh)

```bash
# Install Zsh
sudo apt install -y zsh

# Install Oh My Zsh
sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"

# Install fast plugins
git clone https://github.com/zsh-users/zsh-autosuggestions ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions
git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
```

Edit `~/.zshrc`:

```bash
plugins=(
    git
    docker
    docker-compose
    python
    pip
    virtualenv
    zsh-autosuggestions
    zsh-syntax-highlighting
)

# Performance optimizations
DISABLE_AUTO_UPDATE=true
DISABLE_MAGIC_FUNCTIONS=true
```

### 2. Optimize Python Development

```bash
# Install pyenv for multiple Python versions
curl https://pyenv.run | bash

# Add to ~/.zshrc or ~/.bashrc
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init --path)"
eval "$(pyenv init -)"

# Install Python
pyenv install 3.13
pyenv global 3.13

# Install uv (faster pip alternative)
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### 3. Use Parallel Test Execution

```bash
# Install pytest-xdist
pip install pytest-xdist

# Run tests in parallel
pytest -n auto  # Use all cores
pytest -n 4     # Use 4 cores
```

---

## Monitoring & Benchmarking

### 1. Monitor WSL Resource Usage

```bash
# CPU and memory
htop

# Disk I/O
sudo iotop

# Real-time stats
watch -n 1 'free -h && df -h'
```

### 2. Benchmark File Operations

Create `~/benchmark.sh`:

```bash
#!/bin/bash

echo "=== File System Benchmark ==="

# Write test
echo "Write speed:"
dd if=/dev/zero of=testfile bs=1M count=1024 oflag=direct 2>&1 | grep copied

# Read test
echo "Read speed:"
dd if=testfile of=/dev/null bs=1M iflag=direct 2>&1 | grep copied

# Cleanup
rm testfile

# Git operations
echo -e "\n=== Git Operations ==="
time git status

# Python import speed
echo -e "\n=== Python Import Speed ==="
time python -c "import numpy, pandas, fastapi"

# Test suite speed
echo -e "\n=== Test Suite ==="
cd ~/projects/grid
time pytest tests/unit -x --tb=line -q
```

Run:
```bash
chmod +x ~/benchmark.sh
./benchmark.sh
```

### 3. Before/After Comparison

**Before optimization:**
```bash
./benchmark.sh > before.txt
```

**After optimization:**
```bash
./benchmark.sh > after.txt
diff -u before.txt after.txt
```

---

## Performance Optimization Checklist

### Immediate (30 minutes)
- [ ] Create `.wslconfig` with optimal settings
- [ ] Add Windows Defender exclusions
- [ ] Move project to WSL filesystem
- [ ] Configure Git for performance
- [ ] Restart WSL

### Medium (1 hour)
- [ ] Create `/etc/wsl.conf`
- [ ] Tune kernel parameters
- [ ] Set up fast terminal (Zsh)
- [ ] Configure Docker for WSL2
- [ ] Install development tools

### Advanced (30 minutes)
- [ ] Benchmark current performance
- [ ] Optimize swap configuration
- [ ] Set up parallel test execution
- [ ] Configure build caching
- [ ] Re-benchmark and compare

---

## Expected Performance Improvements

| Operation | Before | After | Improvement |
|-----------|--------|-------|-------------|
| `git status` | 2-3s | <0.5s | **5-6x faster** |
| `pytest` (unit tests) | 60s | 20-25s | **2.5-3x faster** |
| `pip install` | 120s | 40-50s | **2-3x faster** |
| File copy (1GB) | 45s | 8-10s | **4-5x faster** |
| `ruff check .` | 15s | 3-4s | **4-5x faster** |
| Docker build | 180s | 60-80s | **2-3x faster** |

---

## Troubleshooting

### WSL won't start after configuration

```powershell
# Reset WSL
wsl --shutdown
wsl --unregister Ubuntu  # WARNING: This deletes the distro
wsl --install -d Ubuntu
```

### "Out of memory" errors

Increase memory in `.wslconfig`:
```ini
memory=12GB
swap=16GB
```

### Slow file operations persist

1. Verify project is in WSL filesystem:
   ```bash
   pwd  # Should show /home/username/..., not /mnt/...
   ```

2. Check Windows Defender exclusions:
   ```powershell
   Get-MpPreference | Select-Object -ExpandProperty ExclusionPath
   ```

3. Disable VPN/Antivirus temporarily to test

### Docker connectivity issues

```bash
# Reset Docker networking
wsl --shutdown
net stop com.docker.service
net start com.docker.service
```

### Git performance still slow

```bash
# Rebuild git index
git update-index --really-refresh
git gc --aggressive --prune=now
```

---

## Integration with GRID Project

### Update Project Paths

After moving to WSL filesystem, update:

1. **VS Code settings** (`.vscode/settings.json`):
   ```json
   {
     "python.defaultInterpreterPath": "${workspaceFolder}/.venv/bin/python",
     "terminal.integrated.defaultProfile.linux": "zsh"
   }
   ```

2. **Environment variables** (`.env`):
   ```bash
   # Use WSL paths
   GRID_ROOT=/home/username/projects/grid
   PYTHONPATH=/home/username/projects/grid/src
   ```

3. **Docker Compose** (`docker-compose.yml`):
   ```yaml
   volumes:
     - .:/app  # Now uses WSL filesystem
     - ./.venv:/app/.venv
   ```

### Fast Development Commands

Add to `~/.zshrc` or `~/.bashrc`:

```bash
# GRID project aliases
alias grid='cd ~/projects/grid'
alias grid-test='cd ~/projects/grid && pytest -n auto'
alias grid-lint='cd ~/projects/grid && ruff check . && mypy src'
alias grid-serve='cd ~/projects/grid && uvicorn application.mothership.main:app --reload'
alias grid-mcp='cd ~/projects/grid && ./scripts/start_mcp_servers.ps1'
```

---

## Maintenance

### Weekly
- [ ] Run `wsl --update`
- [ ] Check disk usage: `df -h`
- [ ] Clean Docker: `docker system prune -af --volumes`
- [ ] Update packages: `sudo apt update && sudo apt upgrade`

### Monthly
- [ ] Re-run benchmarks
- [ ] Review `.wslconfig` settings
- [ ] Check for WSL2 kernel updates
- [ ] Clear pip cache: `pip cache purge`

---

## Additional Resources

- [WSL Best Practices](https://learn.microsoft.com/en-us/windows/wsl/best-practices)
- [WSL Advanced Settings](https://learn.microsoft.com/en-us/windows/wsl/wsl-config)
- [Docker WSL2 Backend](https://docs.docker.com/desktop/wsl/)
- [Git Performance Tips](https://git-scm.com/docs/git-config#Documentation/git-config.txt-coreuntrackedCache)

---

## Next Steps After Optimization

1. Run the benchmark script to establish baseline
2. Apply quick wins (30 minutes)
3. Restart WSL and verify improvements
4. Apply medium optimizations (1 hour)
5. Re-benchmark and document improvements
6. Update team documentation with new workflow

---

*Last updated: 2024*
*Tested on: Windows 11 Build 28000, WSL2 2.0.0+, Ubuntu 22.04*