# Unified SDK/Service Mapping Matrix

| API Entity | Internal Implementation | External SDK Package | Missing High-Level SDK / Recommendation |
|---|---|---|---|
| Agentic System | `grid.agentic.AgenticSystem` | Custom | Publish unified `grid-sdk-python` wrapper: session/client, auth, telemetry, error types |
| Agent Experience | Custom Implementation | None | Fold into `grid-sdk-python` as UX/session facade with pluggable channels |
| Navigation | Custom Implementation | None | Add navigation module to `grid-sdk-python` with pathing endpoints + typing |
| Plan | Custom Implementation | None | Include plan orchestration client with schemas in `grid-sdk-python` |
| Decision | `light_of_the_seven` Custom Implementation | `mistralai` (via SDK) | Provide decision client in `grid-sdk-python`; expose strategy selection with Mistral/OpenAI provider switch |
| Intelligence Process | `grid.application.IntelligenceApplication` | `openai`, `mistralai` (via SDK) | Surface as `intelligence` module in `grid-sdk-python` with provider abstraction |
| Payment | `application.mothership.services.payment` | `stripe` | Covered; just expose thin billing client in `grid-sdk-python` |
| Subscription | (Nested under Payment) | `stripe` | Covered via Payment module |
| SQL Connection | `application.mothership.db` | `databricks-sql-connector`, `sqlalchemy` | Covered; expose connection factory helpers (opt) in SDK utils |
| Models | (Nested under Database) | `databricks-sql-connector`, `sqlalchemy` | Covered; document model registry access if applicable |
| System State | `application.mothership.routers.cockpit` | None (Internal) | Add read-only cockpit/status client in `grid-sdk-python` |
| Diagnostics | (Nested under Cockpit) | None | Expose health/diag endpoints in SDK |
| EQ Client (Local-First) | `EQ/api_client.py` | Custom (Local Token Storage) | Expand to robust local-first sync layer + bundle into `grid-sdk-python` |

## SDK Usage Examples (Optimized & Extracted)

### A. Payment Gateway (Stripe Integration)
```python
# application/mothership/services/payment/stripe_gateway.py
from stripe import PaymentIntent

def create_payment_intent(amount_cents: int, currency: str, description: str, metadata: dict = None, idempotency_key: str = None) -> PaymentIntent:
    """Create a Stripe Payment Intent."""
    return PaymentIntent.create(
        amount=amount_cents,
        currency=currency.lower(),
        description=description,
        metadata=metadata or {},
        idempotency_key=idempotency_key,
    )
```

### B. Data Connectivity (Databricks SDK)
```python
# application/mothership/db/databricks_connector.py
from databricks import sql

class DatabricksConnector:
    def __init__(self, working_hostname: str, http_path: str, access_token: str):
        self.working_hostname = working_hostname
        self.http_path = http_path
        self.access_token = access_token

    def execute_query(self, query: str) -> list:
        """Execute a query using Databricks SQL."""
        with sql.connect(
            server_hostname=self.working_hostname,
            http_path=self.http_path,
            access_token=self.access_token,
            connection_timeout=30,
        ) as conn:
            with conn.cursor() as cursor:
                cursor.execute(query)
                return cursor.fetchall()
```

### C. Classification (Scikit-Learn Pattern)
```python
# e:\grid\pipeline\services\classification.py
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

class TextClassifier:
    def __init__(self):
        self.vectorizer = TfidfVectorizer(max_features=5000, stop_words="english")
        self.classifier = LogisticRegression(random_state=42, max_iter=1000)

    def fit(self, X: list) -> None:
        """Fit the model to training data."""
        X_vectorized = self.vectorizer.fit_transform(X)
        self.classifier.fit(X_vectorized, y)

    def predict(self, X: list) -> list:
        """Predict class labels."""
        X_vectorized = self.vectorizer.transform(X)
        return self.classifier.predict(X_vectorized)
```

### D. Internal SDK Template (EQ Client)
```python
# /e:/grid/EQ/api_client.py
from typing import AsyncGenerator, Optional
import httpx

class APIClient:
    def __init__(self, config: dict, token: str):
        self.config = config
        self.token = token

    async def __aenter__(self):
        self.client = httpx.AsyncClient(**self.config)
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.client.aclose()

    async def get_profile(self) -> dict:
        """Fetch user profile."""
        async with self.client.get("/api/profile") as resp:
            return resp.json()

    async def get_track(self, track_id: str) -> dict:
        """Fetch track details."""
        async with self.client.get(f"/api/track/{track_id}") as resp:
            return resp.json()
```

### E. Mistral AI Integration (Decision Engine)
```python
# grid_sdk/decision/client.py
from mistralai import Mistral
from .models import DecisionRequest, DecisionResponse, Strategy

class DecisionClient:
    def __init__(self, api_key: str, default_provider: str = "mistral"):
        self.mistral = Mistral(api_key=api_key)
        self.default_provider = default_provider

    async def decide(self, request: DecisionRequest) -> DecisionResponse:
        """Get a decision from Mistral AI."""
        if request.provider == "mistral":
            resp = self.mistral.chat.complete(
                model=request.model or "mistral-large-latest",
                messages=[{"role": "user", "content": request.context["prompt"]}],
                temperature=request.temperature,
            )
            return DecisionResponse(
                decision=resp.choices[0].message.content,
                strategy=request.strategy,
                provider="mistral",
                model=resp.model,
                usage=resp.usage.dict(),
            )
        # fallback to OpenAI or others
        raise NotImplementedError("Provider not implemented")
```

## Architecture & Dependency Gap Mitigation Plan

### A. Unified `grid-sdk-python` Package
**Objective**: Aggregate missing APIs (Agentic, Navigation, Intelligence) into a high-level SDK.

**Implementation Steps**:
1. **Create `grid-sdk/python` directory** with modular sub-packages:
   - `agentic`
   - `navigation`
   - `intelligence`
   - `payment` (reused from existing)
   - `database` (reused from existing)
2. **Use `EQ/api_client.py` as a template** for async SDK clients:
   ```python
   from typing import AsyncGenerator
   import httpx

   class GridAgenticClient:
       def __init__(self, config: dict, token: str):
           self.config = config
           self.token = token

       async def __aenter__(self):
           self.client = httpx.AsyncClient(**self.config)
           return self

       async def get_agent(self, agent_id: str) -> dict:
           """Fetch agent details."""
           async with self.client.get(f"/api/agent/{agent_id}") as resp:
               return resp.json()
   ```
3. **Register SDK in `pyproject.toml`**:
   ```toml
   [project]
   name = "grid-sdk-python"
   version = "0.1.0"
   dependencies = [
       "httpx>=0.23.0",
       "pydantic>=2.0.0",
       "scikit-learn>=1.6.0",
       "mistralai>=1.0.0",
   ]
   ```

### B. Dependency Version Drift Fix
**Problem**: `scikit-learn` version mismatch in `uv.lock` vs. `pyproject.toml`.
**Solution**:
1. **Update `pyproject.toml`** to match `uv.lock`:
   ```toml
   [tool.poetry.dependencies]
   scikit-learn = "1.6.0"  # Pin to correct version
   ```
2. **Run `poetry lock`** to update `uv.lock`.

### C. Local-First Sync Layer
**Objective**: Expand EQ’s `.tokens.json` into a **local-first state synchronization layer**.

**Implementation Steps**:
1. **Create `grid-sdk/local` package** with:
   - `TokenManager` (persistent storage)
   - `SyncAdapter` (sync with API on demand)
2. **Example Integration**:
   ```python
   from grid_sdk.local import TokenManager

   manager = TokenManager(".tokens.json")
   manager.load()  # Load cached tokens
   manager.sync()  # Sync with API if needed
   ```

## Next Steps
1. ✅ **File structure created** for `grid-sdk/python` with modular sub-packages.
2. ✅ **First SDK module drafted** (`agentic` with models, client, tests).
3. ✅ **Expanded modules**: navigation, intelligence, decision with Mistral AI integration.
4. ✅ **Dependency drift resolved** with `poetry lock`; Mistral AI added.
5. **Next**: Add unit tests for navigation/intelligence/decision; implement local-first sync layer.
